//! Pure data model for Books — no CRDT, no rendering.
//!
//! Two families live here:
//!
//! 1. **Book content** ([`Book`] / [`Chapter`] / [`Block`] / [`Span`]) — the
//!    parsed, reflowable representation of an EPUB. Immutable once parsed;
//!    treated as a render cache, NOT stored in the CRDT (it's large and
//!    regenerable from the bundled `.epub`).
//!
//! 2. **The shared annotation model** ([`Annotation`] / [`AnnoKind`] /
//!    [`HiColor`]) — this is the part the PDF reader and word processor are
//!    meant to reuse, so it is deliberately document-agnostic. An annotation
//!    is an **anchor** (which document, where) plus a **payload** (what kind,
//!    what colour, what note). See [`Annotation`] for the anchoring contract.

// This module's several `from_str(s: &str) -> Self` methods are deliberately
// infallible tag parsers with a default fallback (unknown/legacy tags map to
// a sensible variant rather than erroring) -- a different contract from
// `std::str::FromStr::from_str`, which returns `Result`. Implementing the
// trait would force a `Result` return and ripple `.parse()`/`?` handling
// through every call site for no behavioural benefit, so the name collision
// is accepted here rather than exempted call-by-call.
#![allow(clippy::should_implement_trait)]

use std::sync::Arc;

use serde::{Deserialize, Serialize};
use uuid::Uuid;

// --- Book content ------------------------------------------------------------

/// Decoded, downscaled cover artwork extracted from an EPUB. Held behind an
/// `Arc` so a [`Book`] stays cheap to clone and the pixels are decoded
/// exactly once (at load), never per frame.
#[derive(Clone, Debug)]
pub struct Cover {
    pub rgba: Arc<Vec<u8>>,
    pub width: u32,
    pub height: u32,
}

/// One reflowable book: ordered chapters (the EPUB spine) plus metadata.
#[derive(Clone, Debug, Default)]
pub struct Book {
    /// Stable id used as the key into the CRDT library + annotation store.
    pub id: String,
    pub title: String,
    pub author: String,
    pub publisher: String,
    /// BCP-47 language from EPUB metadata, used for TeX/Liang hyphenation.
    pub language: String,
    pub description: String,
    pub chapters: Vec<Chapter>,
    /// Index into the theme accent/semantic ramps used to tint the spine on
    /// the shelf. Purely cosmetic; resolved against the live `Theme`.
    pub cover_tint: usize,
    /// Short subject line shown on the cover, e.g. "Fable".
    pub subject: String,
    /// Real cover artwork decoded from the EPUB, when it carries one. `None`
    /// falls back to a generated spine tinted by [`Self::cover_tint`].
    pub cover: Option<Cover>,
}

impl Book {
    /// Total number of blocks across every chapter — a cheap proxy for length.
    pub fn block_count(&self) -> usize {
        self.chapters.iter().map(|c| c.blocks.len()).sum()
    }

    pub fn chapter(&self, i: usize) -> Option<&Chapter> {
        self.chapters.get(i)
    }
}

/// One spine document (an XHTML file in the EPUB), parsed into blocks.
#[derive(Clone, Debug, Default)]
pub struct Chapter {
    /// TOC label (from the nav/ncx), falling back to the first heading.
    pub title: String,
    /// The XHTML href this chapter came from (used to resolve TOC targets).
    pub href: String,
    pub blocks: Vec<Block>,
}

impl Chapter {
    /// Plain text of one block (spans concatenated) — used for annotation
    /// excerpts and word counts.
    pub fn block_text(&self, i: usize) -> String {
        self.blocks
            .get(i)
            .map(Block::plain_text)
            .unwrap_or_default()
    }
}

/// A flow-level block. Kinds map to the structural HTML elements an EPUB
/// chapter actually uses; styling (size, weight, indent) is derived from the
/// kind at layout time, never stored here.
#[derive(Clone, Debug, PartialEq)]
pub enum Block {
    /// `<h1>`..`<h6>` — `level` is 1-based and clamped to 1..=3 for layout.
    Heading { level: u8, spans: Vec<Span> },
    /// `<p>`
    Paragraph { spans: Vec<Span> },
    /// `<blockquote>` — rendered indented with a rule.
    Quote { spans: Vec<Span> },
    /// One `<li>` inside `<ul>`/`<ol>`. `ordered` picks bullet vs number;
    /// `index` is the 1-based ordinal for ordered lists.
    ListItem {
        spans: Vec<Span>,
        ordered: bool,
        index: usize,
    },
    /// Presentation `MathML` lowered into the toolkit's shared expression tree.
    Math {
        expr: ui::math::MathExpr,
        /// Linear fallback used for search, accessibility, and annotations.
        source: String,
        display: bool,
    },
    /// `<hr/>` — a section break.
    Separator,
}

impl Block {
    pub fn spans(&self) -> &[Span] {
        match self {
            Block::Heading { spans, .. }
            | Block::Paragraph { spans }
            | Block::Quote { spans }
            | Block::ListItem { spans, .. } => spans,
            Block::Math { .. } | Block::Separator => &[],
        }
    }

    pub fn plain_text(&self) -> String {
        // Spans are trimmed; a word break at a style boundary is carried by the
        // next span's `space_before` flag, so re-insert those spaces here.
        if let Block::Math { source, .. } = self {
            return source.clone();
        }
        let mut out = String::new();
        for (i, s) in self.spans().iter().enumerate() {
            if i > 0 && s.space_before {
                out.push(' ');
            }
            out.push_str(&s.text);
        }
        out
    }

    pub fn is_separator(&self) -> bool {
        matches!(self, Block::Separator)
    }
}

/// An inline run with uniform styling. The smallest unit the renderer paints.
///
/// Span text is *trimmed* at style boundaries: the whitespace that separated
/// this run from the previous one is not stored in `text` but recorded in
/// `space_before`, so `"burning <em>for</em>."` yields a `for` run with a
/// leading space and a `.` run with none. The layout and `plain_text` both
/// consult `space_before` to decide whether to insert a gap.
#[derive(Clone, Debug, PartialEq)]
#[allow(
    clippy::struct_excessive_bools,
    reason = "bold/italic/code/space_before are independent inline style flags a span can \
              carry in any combination, not a state machine"
)]
pub struct Span {
    pub text: String,
    /// Structured inline `MathML`. `text` remains its accessible linear form.
    pub math: Option<ui::math::MathExpr>,
    pub bold: bool,
    pub italic: bool,
    pub code: bool,
    /// Whether a word break separated this run from the previous one. Ignored
    /// for the first run of a block (it starts the line).
    pub space_before: bool,
}

impl Span {
    pub fn plain(text: impl Into<String>) -> Self {
        Self {
            text: text.into(),
            math: None,
            bold: false,
            italic: false,
            code: false,
            space_before: false,
        }
    }
}

// --- Shared annotation model (reused by PDF reader + word processor) --------

/// What an annotation *is*. All three share one anchor so a unified
/// sidebar/list can present them together.
#[derive(Clone, Copy, Debug, PartialEq, Eq, Serialize, Deserialize)]
#[serde(rename_all = "snake_case")]
pub enum AnnoKind {
    /// A saved place. Anchors to a location; carries no range.
    Bookmark,
    /// A coloured marking over a passage. Anchors to a range; may carry a note.
    Highlight,
    /// A free-text comment attached to a passage.
    Note,
}

impl AnnoKind {
    pub fn label(self) -> &'static str {
        match self {
            AnnoKind::Bookmark => "Bookmark",
            AnnoKind::Highlight => "Highlight",
            AnnoKind::Note => "Note",
        }
    }
    pub fn as_str(self) -> &'static str {
        match self {
            AnnoKind::Bookmark => "bookmark",
            AnnoKind::Highlight => "highlight",
            AnnoKind::Note => "note",
        }
    }
    pub fn from_str(s: &str) -> Self {
        match s {
            "bookmark" => AnnoKind::Bookmark,
            "note" => AnnoKind::Note,
            _ => AnnoKind::Highlight,
        }
    }
}

/// Highlight palette. Kept as a small enum (rather than raw RGB) so the colour
/// stays semantic and the OS theme can map it to on-brand swatches. The reader
/// resolves each to a concrete `Color` at draw time.
#[derive(Clone, Copy, Debug, PartialEq, Eq, Serialize, Deserialize)]
#[serde(rename_all = "snake_case")]
pub enum HiColor {
    Yellow,
    Green,
    Blue,
    Pink,
    Purple,
}

impl HiColor {
    pub const ALL: [HiColor; 5] = [
        HiColor::Yellow,
        HiColor::Green,
        HiColor::Blue,
        HiColor::Pink,
        HiColor::Purple,
    ];

    pub fn as_str(self) -> &'static str {
        match self {
            HiColor::Yellow => "yellow",
            HiColor::Green => "green",
            HiColor::Blue => "blue",
            HiColor::Pink => "pink",
            HiColor::Purple => "purple",
        }
    }
    pub fn from_str(s: &str) -> Self {
        match s {
            "green" => HiColor::Green,
            "blue" => HiColor::Blue,
            "pink" => HiColor::Pink,
            "purple" => HiColor::Purple,
            _ => HiColor::Yellow,
        }
    }
    /// Base RGB for the swatch. The reader applies alpha for the text overlay.
    pub fn rgb(self) -> (u8, u8, u8) {
        match self {
            HiColor::Yellow => (250, 204, 21),  // amber-400
            HiColor::Green => (52, 211, 153),   // emerald-400
            HiColor::Blue => (96, 165, 250),    // blue-400
            HiColor::Pink => (244, 114, 182),   // pink-400
            HiColor::Purple => (167, 139, 250), // violet-400
        }
    }
}

/// One annotation. The reusable anchor contract: `doc_id` (which document),
/// `chapter` (coarse location: spine index / page / section), `block`
/// (paragraph index), `start`/`end` (char offsets, both 0 for a
/// [`AnnoKind::Bookmark`]), and `excerpt` (a text snapshot so the sidebar
/// renders without re-resolving and a reflow can re-locate the anchor).
/// Payload is `kind` + `color` + `note`.
#[derive(Clone, Debug, Serialize, Deserialize)]
pub struct Annotation {
    pub id: Uuid,
    pub doc_id: String,
    pub kind: AnnoKind,
    pub chapter: usize,
    pub block: usize,
    pub start: usize,
    pub end: usize,
    pub excerpt: String,
    pub note: String,
    pub color: HiColor,
    /// Creation time, ms since epoch. Used to sort the sidebar.
    pub created: u64,
    /// The logical annotation this row belongs to. A multi-paragraph
    /// highlight is one [`AnnoKind::Highlight`] row per spanned block,
    /// sharing one `group` (one click, one delete); comments on it are
    /// [`AnnoKind::Note`] rows carrying the same `group`. A standalone
    /// bookmark or note is its own group (`group == id`).
    #[serde(default = "Uuid::new_v4")]
    pub group: Uuid,
}

impl Annotation {
    pub fn new(doc_id: &str, kind: AnnoKind, chapter: usize, block: usize) -> Self {
        let id = Uuid::new_v4();
        Self {
            id,
            doc_id: doc_id.to_string(),
            kind,
            chapter,
            block,
            start: 0,
            end: 0,
            excerpt: String::new(),
            note: String::new(),
            color: HiColor::Yellow,
            created: now_ms(),
            group: id,
        }
    }

    #[must_use]
    pub fn with_excerpt(mut self, s: impl Into<String>) -> Self {
        self.excerpt = s.into();
        self
    }
    #[must_use]
    pub fn with_color(mut self, c: HiColor) -> Self {
        self.color = c;
        self
    }
    #[must_use]
    pub fn with_note(mut self, n: impl Into<String>) -> Self {
        self.note = n.into();
        self
    }
    /// Bind this row to a logical annotation group (a multi-block highlight and
    /// its comments all share one group).
    #[must_use]
    pub fn with_group(mut self, g: Uuid) -> Self {
        self.group = g;
        self
    }
}

/// Milliseconds since the Unix epoch; monotone enough for sort order.
pub fn now_ms() -> u64 {
    use std::time::{SystemTime, UNIX_EPOCH};
    SystemTime::now()
        .duration_since(UNIX_EPOCH)
        .map_or(0, |d| d.as_millis() as u64)
}

// --- Reading settings + per-book progress ------------------------------------

/// One of the three classic e-reader page tints. These tint the *content
/// surface* (the page), layered on top of the OS theme that drives all chrome.
#[derive(Clone, Copy, Debug, PartialEq, Eq, Serialize, Deserialize)]
#[serde(rename_all = "snake_case")]
pub enum ReadTheme {
    Light,
    Sepia,
    Dark,
    /// Maximum-contrast reading: a true-black page with white ink and a vivid
    /// accent, for low-vision reading. A first-class tint alongside the classics.
    HighContrast,
}

impl ReadTheme {
    pub const ALL: [ReadTheme; 4] = [
        ReadTheme::Light,
        ReadTheme::Sepia,
        ReadTheme::Dark,
        ReadTheme::HighContrast,
    ];
    pub fn label(self) -> &'static str {
        match self {
            ReadTheme::Light => "Light",
            ReadTheme::Sepia => "Sepia",
            ReadTheme::Dark => "Dark",
            ReadTheme::HighContrast => "High contrast",
        }
    }
    pub fn as_str(self) -> &'static str {
        match self {
            ReadTheme::Light => "light",
            ReadTheme::Sepia => "sepia",
            ReadTheme::Dark => "dark",
            ReadTheme::HighContrast => "high-contrast",
        }
    }
    pub fn from_str(s: &str) -> Self {
        match s {
            "sepia" => ReadTheme::Sepia,
            "dark" => ReadTheme::Dark,
            "high-contrast" | "high_contrast" | "hc" => ReadTheme::HighContrast,
            _ => ReadTheme::Light,
        }
    }
}

/// How the reader lays the book out: the three modes share one paginated
/// layout ([`crate::paginate::ChapterLayout`]), differing only in which
/// slice of the flow is shown. `Paged` turns whole pages; `Continuous`
/// scrolls by pixels and rolls into the next/previous chapter at the ends;
/// `TwoUp` shows two facing pages and turns them together.
#[derive(Clone, Copy, Debug, PartialEq, Eq, Serialize, Deserialize)]
#[serde(rename_all = "snake_case")]
pub enum ReadMode {
    Paged,
    Continuous,
    TwoUp,
}

/// Paragraph-composition policy used by the reader. `Book` enables the full
/// typesetting pipeline; `Ragged` keeps natural spacing and disables automatic
/// hyphenation/micro-expansion for readers who prefer an uneven right edge.
#[derive(Clone, Copy, Debug, Default, PartialEq, Eq, Serialize, Deserialize)]
#[serde(rename_all = "snake_case")]
pub enum CompositionStyle {
    #[default]
    Book,
    Ragged,
}

impl CompositionStyle {
    pub const ALL: [Self; 2] = [Self::Book, Self::Ragged];

    pub const fn label(self) -> &'static str {
        match self {
            Self::Book => "Book",
            Self::Ragged => "Ragged",
        }
    }

    pub const fn as_str(self) -> &'static str {
        match self {
            Self::Book => "book",
            Self::Ragged => "ragged",
        }
    }

    pub fn from_str(value: &str) -> Self {
        match value {
            "ragged" => Self::Ragged,
            _ => Self::Book,
        }
    }

    pub const fn justified(self) -> bool {
        matches!(self, Self::Book)
    }
}

impl ReadMode {
    pub const ALL: [ReadMode; 3] = [ReadMode::Paged, ReadMode::Continuous, ReadMode::TwoUp];

    pub fn label(self) -> &'static str {
        match self {
            ReadMode::Paged => "Page",
            ReadMode::Continuous => "Scroll",
            ReadMode::TwoUp => "Spread",
        }
    }
    pub fn as_str(self) -> &'static str {
        match self {
            ReadMode::Paged => "paged",
            ReadMode::Continuous => "continuous",
            ReadMode::TwoUp => "two_up",
        }
    }
    pub fn from_str(s: &str) -> Self {
        match s {
            "continuous" | "scroll" => ReadMode::Continuous,
            "two_up" | "two-up" | "spread" => ReadMode::TwoUp,
            _ => ReadMode::Paged,
        }
    }
    /// Whether this mode scrolls the flow continuously (no page snapping).
    pub fn is_continuous(self) -> bool {
        matches!(self, ReadMode::Continuous)
    }
    /// How many pages advance per page-turn in this mode.
    pub fn page_stride(self) -> usize {
        match self {
            ReadMode::TwoUp => 2,
            _ => 1,
        }
    }
}

/// Which font *class* a registered face resolves to. `Default` is the reader's
/// proportional face (also used for EPUB-specified text); `Serif` / `Mono` are
/// the other generic classes; `Named` targets a specific installed family the
/// reader picked from the system font list.
#[derive(Clone, Debug, PartialEq, Eq, Serialize, Deserialize)]
pub enum FontKind {
    Default,
    Serif,
    Mono,
    Named(String),
}

impl FontKind {
    /// Encode as a single scalar string for the CRDT.
    pub fn as_code(&self) -> String {
        match self {
            FontKind::Default => "default".to_string(),
            FontKind::Serif => "serif".to_string(),
            FontKind::Mono => "mono".to_string(),
            FontKind::Named(n) => format!("named:{n}"),
        }
    }
    pub fn from_code(s: &str) -> Self {
        if let Some(n) = s.strip_prefix("named:") {
            return FontKind::Named(n.to_string());
        }
        match s {
            "serif" => FontKind::Serif,
            "mono" => FontKind::Mono,
            _ => FontKind::Default,
        }
    }
    /// Whether body text should render in the monospace family.
    pub fn is_mono(&self) -> bool {
        matches!(self, FontKind::Mono)
    }
}

/// A registered reading font. Fonts carry a display name and a per-face size
/// multiplier (installed faces differ in x-height, so the same nominal size
/// reads larger or smaller). `shown` controls whether it appears in the quick
/// display-settings font row. Unlike colour schemes, fonts are **not**
/// duplicable — a face is a face; there is no per-instance colour to vary.
#[derive(Clone, Debug, PartialEq, Serialize, Deserialize)]
pub struct FontEntry {
    pub id: String,
    pub kind: FontKind,
    pub name: String,
    /// Multiplier on top of the global text-size setting. Clamped to bounds.
    pub size_mult: f32,
    /// Whether this font appears in the quick display-settings picker.
    pub shown: bool,
}

impl FontEntry {
    pub const MULT_MIN: f32 = 0.7;
    pub const MULT_MAX: f32 = 1.4;

    pub fn new(id: &str, kind: FontKind, name: &str, size_mult: f32, shown: bool) -> Self {
        Self {
            id: id.to_string(),
            kind,
            name: name.to_string(),
            size_mult: size_mult.clamp(Self::MULT_MIN, Self::MULT_MAX),
            shown,
        }
    }
}

/// The built-in font registry: the reader's default proportional face plus a
/// serif book face and a monospace face. A fresh library starts here; the font
/// manager can add installed families, rename, retune size, or hide any of them.
pub fn default_fonts() -> Vec<FontEntry> {
    vec![
        FontEntry::new("default", FontKind::Default, "Default", 1.0, true),
        FontEntry::new("serif", FontKind::Serif, "Serif", 1.05, true),
        FontEntry::new("mono", FontKind::Mono, "Mono", 0.96, true),
    ]
}

// ===========================================================================
// Colour schemes
// ===========================================================================

/// Relative luminance (0..1) of an sRGB colour, for light/dark decisions.
pub fn luminance(c: [u8; 3]) -> f32 {
    (0.299 * f32::from(c[0]) + 0.587 * f32::from(c[1]) + 0.114 * f32::from(c[2])) / 255.0
}

/// Linear blend of two colours; `t` in 0..1 moves from `a` to `b`.
pub fn mix(a: [u8; 3], b: [u8; 3], t: f32) -> [u8; 3] {
    let t = t.clamp(0.0, 1.0);
    [
        (f32::from(a[0]) * (1.0 - t) + f32::from(b[0]) * t).round() as u8,
        (f32::from(a[1]) * (1.0 - t) + f32::from(b[1]) * t).round() as u8,
        (f32::from(a[2]) * (1.0 - t) + f32::from(b[2]) * t).round() as u8,
    ]
}

#[allow(
    clippy::many_single_char_names,
    reason = "r, g, b, h, s, l are the standard RGB/HSL channel names; inventing longer ones \
              would only hurt readability here"
)]
fn rgb_to_hsl(c: [u8; 3]) -> (f32, f32, f32) {
    let (r, g, b) = (
        f32::from(c[0]) / 255.0,
        f32::from(c[1]) / 255.0,
        f32::from(c[2]) / 255.0,
    );
    let max = r.max(g).max(b);
    let min = r.min(g).min(b);
    let l = f32::midpoint(max, min);
    if (max - min).abs() < 1e-6 {
        return (0.0, 0.0, l);
    }
    let d = max - min;
    let s = if l > 0.5 {
        d / (2.0 - max - min)
    } else {
        d / (max + min)
    };
    #[allow(
        clippy::float_cmp,
        reason = "max is exactly one of r/g/b via f32::max (a selection, not an independent \
                  computation), so exact equality is the correct test"
    )]
    let h = if max == r {
        ((g - b) / d + if g < b { 6.0 } else { 0.0 }) * 60.0
    } else if max == g {
        ((b - r) / d + 2.0) * 60.0
    } else {
        ((r - g) / d + 4.0) * 60.0
    };
    (h, s, l)
}

/// Standard HSV → sRGB. `h` in degrees (any range; wrapped), `s`/`v` in 0..1.
/// The colour picker edits in HSV so hue stays stable while dragging value on
/// the achromatic axis; this is the conversion it commits back through.
#[allow(
    clippy::many_single_char_names,
    reason = "h, s, v, i, f, p, q, t, r, g, b are the standard HSV/RGB channel and \
              interpolation names; inventing longer ones would only hurt readability here"
)]
pub fn hsv_to_rgb(h: f32, s: f32, v: f32) -> [u8; 3] {
    let h = ((h % 360.0) + 360.0) % 360.0 / 60.0;
    let s = s.clamp(0.0, 1.0);
    let v = v.clamp(0.0, 1.0);
    let i = h.floor() as i32;
    let f = h - i as f32;
    let p = v * (1.0 - s);
    let q = v * (1.0 - f * s);
    let t = v * (1.0 - (1.0 - f) * s);
    let (r, g, b) = match i.rem_euclid(6) {
        0 => (v, t, p),
        1 => (q, v, p),
        2 => (p, v, t),
        3 => (p, q, v),
        4 => (t, p, v),
        _ => (v, p, q),
    };
    [
        (r * 255.0).round().clamp(0.0, 255.0) as u8,
        (g * 255.0).round().clamp(0.0, 255.0) as u8,
        (b * 255.0).round().clamp(0.0, 255.0) as u8,
    ]
}

/// Inverse of [`hsv_to_rgb`]. Returns `(h_degrees, s, v)`; hue is 0 on the
/// achromatic axis (callers editing a grey preserve their prior hue).
#[allow(
    clippy::many_single_char_names,
    reason = "r, g, b, h, s, v are the standard RGB/HSV channel names; inventing longer ones \
              would only hurt readability here"
)]
pub fn rgb_to_hsv(c: [u8; 3]) -> (f32, f32, f32) {
    let (r, g, b) = (
        f32::from(c[0]) / 255.0,
        f32::from(c[1]) / 255.0,
        f32::from(c[2]) / 255.0,
    );
    let max = r.max(g).max(b);
    let min = r.min(g).min(b);
    let d = max - min;
    let v = max;
    let s = if max <= f32::EPSILON { 0.0 } else { d / max };
    #[allow(
        clippy::float_cmp,
        reason = "max is exactly one of r/g/b via f32::max (a selection, not an independent \
                  computation), so exact equality is the correct test"
    )]
    let h = if d <= f32::EPSILON {
        0.0
    } else if max == r {
        60.0 * (((g - b) / d).rem_euclid(6.0))
    } else if max == g {
        60.0 * (((b - r) / d) + 2.0)
    } else {
        60.0 * (((r - g) / d) + 4.0)
    };
    (((h % 360.0) + 360.0) % 360.0, s, v)
}

/// Parse a `#RRGGBB` / `RRGGBB` hex string into an sRGB triple.
pub fn parse_hex(s: &str) -> Option<[u8; 3]> {
    let s = s.trim().trim_start_matches('#');
    if s.len() != 6 || !s.bytes().all(|b| b.is_ascii_hexdigit()) {
        return None;
    }
    let v = u32::from_str_radix(s, 16).ok()?;
    Some([
        ((v >> 16) & 0xFF) as u8,
        ((v >> 8) & 0xFF) as u8,
        (v & 0xFF) as u8,
    ])
}

/// `#RRGGBB` hex string for an sRGB triple.
pub fn hex_string(c: [u8; 3]) -> String {
    format!("#{:02X}{:02X}{:02X}", c[0], c[1], c[2])
}

#[allow(
    clippy::many_single_char_names,
    reason = "h, s, l, c, x, m, r, g, b are the standard HSL-to-RGB algorithm variable names"
)]
fn hsl_to_rgb(h: f32, s: f32, l: f32) -> [u8; 3] {
    let h = ((h % 360.0) + 360.0) % 360.0;
    let c = (1.0 - (2.0 * l - 1.0).abs()) * s;
    let x = c * (1.0 - (((h / 60.0) % 2.0) - 1.0).abs());
    let m = l - c / 2.0;
    let (r, g, b) = match (h / 60.0) as u32 {
        0 => (c, x, 0.0),
        1 => (x, c, 0.0),
        2 => (0.0, c, x),
        3 => (0.0, x, c),
        4 => (x, 0.0, c),
        _ => (c, 0.0, x),
    };
    [
        ((r + m) * 255.0).round() as u8,
        ((g + m) * 255.0).round() as u8,
        ((b + m) * 255.0).round() as u8,
    ]
}

/// The derived palette parts returned by [`ColorScheme::palette_parts`]:
/// `(page, page_edge, ink, ink_dim, rule, code_bg)`.
pub type PaletteParts = ([u8; 3], [u8; 3], [u8; 3], [u8; 3], [u8; 3], [u8; 3]);

/// A reader colour scheme: a page (paper) colour, body ink, and an accent, plus
/// a dark flag. The rest of the palette (faint edges, dim ink, rules, code
/// chips) is **derived**, so a scheme stays coherent from just these three
/// colours — and so a whole scheme can be spun up from one background colour.
#[derive(Clone, Debug, PartialEq, Serialize, Deserialize)]
pub struct ColorScheme {
    pub id: String,
    pub name: String,
    pub page: [u8; 3],
    pub ink: [u8; 3],
    pub accent: [u8; 3],
    pub dark: bool,
    pub enabled: bool,
    /// Built-in presets can be disabled/duplicated but never deleted or edited.
    pub builtin: bool,
}

impl ColorScheme {
    /// The three editable colours, labelled — drives the per-colour editor.
    pub fn slots(&self) -> [(&'static str, [u8; 3]); 3] {
        [
            ("Page", self.page),
            ("Text", self.ink),
            ("Accent", self.accent),
        ]
    }

    pub fn set_slot(&mut self, i: usize, c: [u8; 3]) {
        match i {
            0 => self.page = c,
            1 => self.ink = c,
            _ => self.accent = c,
        }
        // Keep the dark flag consistent with the paper so highlight alpha and
        // ink defaults stay sensible after an edit.
        self.dark = luminance(self.page) < 0.5;
    }

    /// Derive a full scheme from one background colour: pick a legible ink
    /// (warm off-white on a dark paper, near-black on a light one) and a vivid,
    /// hue-rotated accent that keeps contrast against the paper.
    pub fn from_bg(id: &str, name: &str, bg: [u8; 3]) -> Self {
        let dark = luminance(bg) < 0.5;
        let ink = if dark {
            [0xEA, 0xE4, 0xD8]
        } else {
            [0x22, 0x20, 0x1E]
        };
        let (h, _s, _l) = rgb_to_hsl(bg);
        let acc_l = if dark { 0.64 } else { 0.48 };
        let accent = hsl_to_rgb(h + 150.0, 0.62, acc_l);
        Self {
            id: id.to_string(),
            name: name.to_string(),
            page: bg,
            ink,
            accent,
            dark,
            enabled: true,
            builtin: false,
        }
    }

    /// The derived palette parts `(page, page_edge, ink, ink_dim, rule, code_bg)`.
    pub fn palette_parts(&self) -> PaletteParts {
        let page = self.page;
        let ink = self.ink;
        (
            page,
            mix(page, ink, 0.14), // page_edge
            ink,
            mix(ink, page, 0.42), // ink_dim
            mix(page, ink, 0.22), // rule
            mix(page, ink, 0.10), // code_bg
        )
    }
}

/// The built-in colour schemes (mirrors the three classic tints). They ship
/// enabled; the scheme manager can disable, duplicate, or clone them.
pub fn default_schemes() -> Vec<ColorScheme> {
    vec![
        ColorScheme {
            id: "light".into(),
            name: "Light".into(),
            page: [0xFC, 0xFC, 0xFA],
            ink: [0x1B, 0x1B, 0x1F],
            accent: [0x3B, 0x82, 0xF6],
            dark: false,
            enabled: true,
            builtin: true,
        },
        ColorScheme {
            id: "sepia".into(),
            name: "Sepia".into(),
            page: [0xF6, 0xEC, 0xD8],
            ink: [0x40, 0x33, 0x22],
            accent: [0xB4, 0x6A, 0x2E],
            dark: false,
            enabled: true,
            builtin: true,
        },
        ColorScheme {
            // A warm-*neutral* charcoal — deliberately close to grey so it never
            // reads as sepia/brown, but with a hair of warmth (R ≥ B) so it stays
            // comfortable for long reading rather than a clinical blue-black.
            id: "dark".into(),
            name: "Dark".into(),
            page: [0x1E, 0x1D, 0x1C],
            ink: [0xE7, 0xE5, 0xE1],
            accent: [0x8A, 0xB4, 0xF8],
            dark: true,
            enabled: true,
            builtin: true,
        },
        ColorScheme {
            // Maximum contrast: a true-black page, pure-white ink, and a vivid
            // amber accent that stays unmistakable against the black. For
            // low-vision reading; its reading palette is fixed in `reader_theme`.
            id: "high-contrast".into(),
            name: "High contrast".into(),
            page: [0x00, 0x00, 0x00],
            ink: [0xFF, 0xFF, 0xFF],
            accent: [0xFF, 0xD5, 0x2E],
            dark: true,
            enabled: true,
            builtin: true,
        },
    ]
}

/// Global reading preferences, shared across the library and persisted in the
/// CRDT so collaborators see a consistent layout when reading together.
#[derive(Clone, Debug, PartialEq, Serialize, Deserialize)]
pub struct Settings {
    /// Body font size multiplier; 1.0 == 19px base. Clamped to [0.8, 1.8].
    pub font_scale: f32,
    /// Line-height multiplier on top of the font's own 1.25. [0.95, 1.6].
    pub line_spacing: f32,
    /// Id of the selected [`FontEntry`] in the registry. Empty means "use the
    /// registry default".
    pub font_id: String,
    /// Built-in page tint. Retained for the three classic presets; a custom
    /// colour scheme (when selected) is carried by `scheme_id`.
    pub theme: ReadTheme,
    /// Id of a selected custom colour scheme, or empty to use `theme`.
    pub scheme_id: String,
    /// How the page is laid out (single page / continuous scroll / two-up
    /// spread). A reading preference, shared across the library like the tint.
    pub mode: ReadMode,
    /// Paragraph fitting policy. Defaults to book-quality composition.
    pub composition: CompositionStyle,
}

impl Default for Settings {
    fn default() -> Self {
        Self {
            font_scale: 1.0,
            line_spacing: 1.2,
            // Empty means "the reader's default reading face" — which resolves to
            // the serif book font (see `BooksApp::active_font`), because books
            // read best in serif. The picker offers the sans "Default" + mono.
            font_id: String::new(),
            theme: ReadTheme::Sepia,
            scheme_id: String::new(),
            mode: ReadMode::Paged,
            composition: CompositionStyle::Book,
        }
    }
}

impl Settings {
    pub const FONT_MIN: f32 = 0.8;
    pub const FONT_MAX: f32 = 1.8;
    pub const SPACING_MIN: f32 = 0.95;
    pub const SPACING_MAX: f32 = 1.6;

    /// Base body size in logical px before the scale multiplier.
    pub const BASE_SIZE: f32 = 19.0;

    pub fn body_size(&self) -> f32 {
        Self::BASE_SIZE * self.font_scale
    }

    /// Body size including a selected font's per-face size multiplier.
    pub fn body_size_with(&self, font_mult: f32) -> f32 {
        Self::BASE_SIZE * self.font_scale * font_mult
    }
}

/// Where the reader left off in one book.
#[derive(Clone, Copy, Debug, Default, PartialEq, Serialize, Deserialize)]
pub struct Progress {
    pub chapter: usize,
    pub page: usize,
    /// 0.0..=1.0 fraction through the whole book, for the shelf bar.
    pub fraction: f32,
    /// ms-since-epoch this book was last opened, for the "recently opened"
    /// shelf sort. 0 means never opened.
    pub opened: u64,
}

impl Progress {
    /// A book counts as "read" once the reader is essentially at the end — used
    /// by the shelf's "hide read books" filter.
    pub fn is_read(&self) -> bool {
        self.fraction >= 0.985
    }
}

// --- Library shelf preferences -----------------------------------------------

/// How the library shelf orders its books. Persisted so the shelf keeps the
/// reader's chosen ordering across sessions and collaborators.
#[derive(Clone, Copy, Debug, PartialEq, Eq, Serialize, Deserialize)]
#[serde(rename_all = "snake_case")]
pub enum LibrarySort {
    Title,
    Author,
    /// Most-recently-opened first.
    Recent,
    /// Furthest-read first.
    Progress,
}

impl LibrarySort {
    pub const ALL: [LibrarySort; 4] = [
        LibrarySort::Title,
        LibrarySort::Author,
        LibrarySort::Recent,
        LibrarySort::Progress,
    ];

    pub fn label(self) -> &'static str {
        match self {
            LibrarySort::Title => "Title",
            LibrarySort::Author => "Author",
            LibrarySort::Recent => "Recently opened",
            LibrarySort::Progress => "Progress",
        }
    }
    pub fn as_str(self) -> &'static str {
        match self {
            LibrarySort::Title => "title",
            LibrarySort::Author => "author",
            LibrarySort::Recent => "recent",
            LibrarySort::Progress => "progress",
        }
    }
    pub fn from_str(s: &str) -> Self {
        match s {
            "author" => LibrarySort::Author,
            "recent" => LibrarySort::Recent,
            "progress" => LibrarySort::Progress,
            _ => LibrarySort::Title,
        }
    }
}

/// One book the reader has added to their library, persisted in the CRDT.
/// Keyed by the content-hash [`id`](Book::id): re-adding the same file
/// updates the same entry, and a workspace-shared book keeps one identity
/// everywhere. Its device path is deliberately *not* part of this replicated
/// record: a peer can resolve a shared object from its content id, while local
/// source locations remain private to the device that granted them.
#[derive(Clone, Debug, PartialEq, Eq)]
pub struct LibraryEntry {
    /// Content-hash id, shared with the book's annotations + progress.
    pub id: String,
    /// Whether a content-addressed copy is available in the collaborative
    /// workspace. Its filename is deterministically derived from [`Self::id`],
    /// so no host-specific path needs replication.
    pub shared: bool,
    pub title: String,
    pub author: String,
    pub subject: String,
    /// When the book was first added (ms since epoch), for a "recently added"
    /// reading of the shelf.
    pub added: u64,
}

/// Persisted shelf preferences: the sort order and whether finished books are
/// hidden.
#[derive(Clone, Copy, Debug, PartialEq, Eq, Serialize, Deserialize)]
pub struct LibraryPrefs {
    pub sort: LibrarySort,
    pub hide_read: bool,
}

impl Default for LibraryPrefs {
    fn default() -> Self {
        Self {
            sort: LibrarySort::Title,
            hide_read: false,
        }
    }
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn hicolor_round_trips() {
        for c in HiColor::ALL {
            assert_eq!(HiColor::from_str(c.as_str()), c);
        }
    }

    #[test]
    fn annokind_round_trips() {
        for k in [AnnoKind::Bookmark, AnnoKind::Highlight, AnnoKind::Note] {
            assert_eq!(AnnoKind::from_str(k.as_str()), k);
        }
    }

    #[test]
    fn read_theme_round_trips() {
        for t in ReadTheme::ALL {
            assert_eq!(ReadTheme::from_str(t.as_str()), t);
        }
    }

    #[test]
    fn read_mode_round_trips_and_defaults_to_paged() {
        for m in ReadMode::ALL {
            assert_eq!(ReadMode::from_str(m.as_str()), m);
        }
        assert_eq!(ReadMode::from_str("nonsense"), ReadMode::Paged);
        assert_eq!(
            Settings::default().mode,
            ReadMode::Paged,
            "readers open paged by default"
        );
        assert_eq!(ReadMode::TwoUp.page_stride(), 2, "a spread turns two pages");
        assert_eq!(ReadMode::Paged.page_stride(), 1);
        assert!(ReadMode::Continuous.is_continuous());
        assert!(!ReadMode::Paged.is_continuous());
    }

    #[test]
    fn font_kind_round_trips_including_named() {
        for k in [
            FontKind::Default,
            FontKind::Serif,
            FontKind::Mono,
            FontKind::Named("Literata".into()),
        ] {
            assert_eq!(FontKind::from_code(&k.as_code()), k);
        }
    }

    #[test]
    fn default_fonts_are_shown_and_unique() {
        let f = default_fonts();
        assert!(
            f.iter().any(|e| e.kind == FontKind::Serif),
            "a serif face ships by default"
        );
        assert!(
            f.iter().all(|e| e.shown),
            "the built-in fonts all show in quick settings"
        );
        let ids: std::collections::HashSet<_> = f.iter().map(|e| &e.id).collect();
        assert_eq!(ids.len(), f.len(), "font ids are unique");
    }

    #[test]
    fn block_plain_text_concats_spans() {
        let b = Block::Paragraph {
            spans: vec![
                Span::plain("Hello "),
                Span {
                    text: "world".into(),
                    math: None,
                    bold: true,
                    italic: false,
                    code: false,
                    space_before: false,
                },
            ],
        };
        assert_eq!(b.plain_text(), "Hello world");
    }

    #[test]
    fn settings_body_size_scales() {
        let s = Settings {
            font_scale: 1.5,
            ..Default::default()
        };
        assert!((s.body_size() - Settings::BASE_SIZE * 1.5).abs() < 0.01);
    }

    #[test]
    fn composition_style_has_stable_storage_names() {
        assert_eq!(CompositionStyle::Book.as_str(), "book");
        assert_eq!(
            CompositionStyle::from_str("ragged"),
            CompositionStyle::Ragged
        );
        assert_eq!(
            CompositionStyle::from_str("unknown"),
            CompositionStyle::Book,
            "unknown persisted values retain the book-quality default"
        );
    }

    #[test]
    fn scheme_from_dark_bg_derives_light_ink_and_contrasting_accent() {
        let s = ColorScheme::from_bg("u1", "Midnight", [0x12, 0x14, 0x1C]);
        assert!(s.dark, "a dark background yields a dark scheme");
        assert!(
            luminance(s.ink) > 0.7,
            "ink is a light off-white on a dark paper"
        );
        assert_eq!(s.page, [0x12, 0x14, 0x1C], "paper is the given background");
        // The accent must stand clearly apart from the paper in luminance.
        assert!(
            (luminance(s.accent) - luminance(s.page)).abs() > 0.2,
            "accent contrasts with the paper",
        );
    }

    #[test]
    fn scheme_from_light_bg_derives_dark_ink() {
        let s = ColorScheme::from_bg("u2", "Paper", [0xF3, 0xEE, 0xE2]);
        assert!(!s.dark, "a light background yields a light scheme");
        assert!(luminance(s.ink) < 0.3, "ink is near-black on a light paper");
    }

    #[test]
    fn scheme_derived_parts_sit_between_page_and_ink() {
        let s = ColorScheme::from_bg("u3", "Warm", [0x20, 0x1C, 0x18]);
        let (page, edge, ink, dim, _rule, _code) = s.palette_parts();
        assert_eq!(page, s.page);
        assert_eq!(ink, s.ink);
        // Derived tones are genuine blends, never equal to an endpoint.
        assert_ne!(edge, page);
        assert_ne!(dim, ink);
    }

    #[test]
    fn hsv_round_trips_through_rgb() {
        for c in [
            [0xFA, 0xCC, 0x15],
            [0x34, 0xD3, 0x99],
            [0x3B, 0x82, 0xF6],
            [0x10, 0x10, 0x12],
        ] {
            let (h, s, v) = rgb_to_hsv(c);
            let back = hsv_to_rgb(h, s, v);
            for i in 0..3 {
                assert!(
                    (i32::from(c[i]) - i32::from(back[i])).abs() <= 1,
                    "channel {i}: {c:?} -> {back:?}"
                );
            }
        }
    }

    #[test]
    fn hsv_value_axis_controls_lightness() {
        // Full value is bright; zero value is black, hue preserved on the way.
        assert_eq!(hsv_to_rgb(210.0, 0.6, 0.0), [0, 0, 0]);
        let bright = hsv_to_rgb(210.0, 0.6, 1.0);
        assert!(
            bright.iter().any(|&c| c > 200),
            "high value is a bright colour"
        );
    }

    #[test]
    fn hex_parses_and_formats_round_trip() {
        assert_eq!(parse_hex("#3B82F6"), Some([0x3B, 0x82, 0xF6]));
        assert_eq!(parse_hex("3b82f6"), Some([0x3B, 0x82, 0xF6]));
        assert_eq!(parse_hex("nope"), None);
        assert_eq!(parse_hex("#12345"), None);
        assert_eq!(hex_string([0x3B, 0x82, 0xF6]), "#3B82F6");
    }

    #[test]
    fn library_sort_round_trips() {
        for s in LibrarySort::ALL {
            assert_eq!(LibrarySort::from_str(s.as_str()), s);
        }
    }

    #[test]
    fn progress_is_read_at_the_end() {
        assert!(
            !Progress {
                fraction: 0.5,
                ..Default::default()
            }
            .is_read()
        );
        assert!(
            Progress {
                fraction: 1.0,
                ..Default::default()
            }
            .is_read()
        );
    }

    #[test]
    fn dark_scheme_is_neutral_not_brown() {
        let dark = default_schemes()
            .into_iter()
            .find(|s| s.id == "dark")
            .unwrap();
        // Warm (red ≥ blue) but only barely — a genuine charcoal, not a sepia.
        assert!(dark.page[0] >= dark.page[2], "kept faintly warm");
        assert!(dark.page[0] - dark.page[2] <= 6, "not a brown/sepia paper");
        assert!(luminance(dark.page) < 0.2, "still a dark page");
    }

    #[test]
    fn high_contrast_builtin_is_maximal_contrast() {
        let hc = default_schemes()
            .into_iter()
            .find(|s| s.id == "high-contrast")
            .unwrap();
        assert!(
            hc.builtin && hc.dark,
            "high contrast ships as a dark built-in"
        );
        assert!(luminance(hc.page) < 0.02, "a true-black page");
        assert!(luminance(hc.ink) > 0.98, "white ink");
        // It is a first-class built-in tint: the ReadTheme enum round-trips its id.
        assert_eq!(ReadTheme::from_str(&hc.id), ReadTheme::HighContrast);
        assert_eq!(ReadTheme::HighContrast.as_str(), "high-contrast");
    }

    #[test]
    fn set_slot_recomputes_dark_from_paper() {
        let mut s = default_schemes()[0].clone(); // Light
        assert!(!s.dark);
        s.set_slot(0, [0x10, 0x10, 0x12]); // paint the paper dark
        assert!(
            s.dark,
            "editing the page to a dark colour flips the scheme dark"
        );
    }
}
