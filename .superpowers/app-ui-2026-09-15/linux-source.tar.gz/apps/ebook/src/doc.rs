//! Automerge document layer for Books: everything the user can change lives
//! in the shared CRDT so undo/redo and live collaboration work for free.
//!
//! ```text
//! root
//! ├── "settings"        (Map)  font_scale(f64) line_spacing(f64) font(str) theme(str)
//! ├── "library"         (Map keyed by book-id)  { title, author, subject, shared, added }
//! ├── "library_tombstones" (Map keyed by book-id) true
//! ├── "progress"        (Map keyed by book-id)  { chapter, page, fraction }
//! ├── "annotations"     (Map keyed by uuid)     { doc_id, kind, chapter, block,
//! │                                               start, end, excerpt, note,
//! │                                               color, created }
//! ├── "annotation_tombstones" (Map keyed by uuid) true
//! └── "highlight_tombstones"  (Map keyed by group uuid) true
//! ```
//!
//! Library, progress and annotations are all keyed by the content-hash book
//! id, so a book's shelf entry, reading position, and every annotation
//! travel together across devices and to anyone it's shared with. Annotation
//! Library, annotation and highlight tombstones are monotonic: a delete wins over an offline
//! edit/add that arrives later, rather than allowing a removed row to be
//! resurrected by a concurrent map write. Raw source
//! locations and watched folders are local capability state, never document
//! data. The reader's transient view (open book, page, selection) stays
//! per-peer, out of the document.

#[cfg(test)]
use automerge::ActorId;
use automerge::transaction::Transactable;
use automerge::{AutoCommit, ObjId, ObjType, ROOT, ReadDoc, ScalarValue, Value};
use uuid::Uuid;

use crate::model::{
    AnnoKind, Annotation, ColorScheme, FontEntry, FontKind, HiColor, LibraryEntry, LibraryPrefs,
    LibrarySort, Progress, ReadMode, ReadTheme, Settings, default_fonts, default_schemes, now_ms,
};

/// Pack an sRGB triple into a single int for the CRDT.
fn pack_rgb(c: [u8; 3]) -> i64 {
    (i64::from(c[0]) << 16) | (i64::from(c[1]) << 8) | i64::from(c[2])
}
fn unpack_rgb(v: i64) -> [u8; 3] {
    [
        ((v >> 16) & 0xFF) as u8,
        ((v >> 8) & 0xFF) as u8,
        (v & 0xFF) as u8,
    ]
}

/// Stateless namespace of document helpers.
pub struct BooksDoc;

impl BooksDoc {
    // --- generic helpers ---------------------------------------------------

    // `put_object` here only ever creates a fresh map at a key we either just
    // resolved as ROOT or as a map this same function created, so there is no
    // real fallback `ObjId` to substitute on error — a failure here means the
    // document itself is corrupt.
    #[allow(
        clippy::expect_used,
        reason = "put_object on ROOT or a map this fn created cannot fail short of document corruption, which has no meaningful ObjId fallback"
    )]
    fn get_or_make_map(doc: &mut AutoCommit, parent: &ObjId, key: &str) -> ObjId {
        match doc.get(parent, key) {
            Ok(Some((Value::Object(ObjType::Map), id))) => id,
            _ => doc
                .put_object(parent, key, ObjType::Map)
                .expect("put_object map never fails"),
        }
    }

    fn root_map(doc: &mut AutoCommit, key: &str) -> ObjId {
        let root = ROOT;
        Self::get_or_make_map(doc, &root, key)
    }

    fn scalar_f64(doc: &AutoCommit, obj: &ObjId, key: &str) -> Option<f64> {
        match doc.get(obj, key) {
            Ok(Some((Value::Scalar(v), _))) => match v.as_ref() {
                ScalarValue::F64(f) => Some(*f),
                ScalarValue::Int(i) => Some(*i as f64),
                ScalarValue::Uint(u) => Some(*u as f64),
                _ => None,
            },
            _ => None,
        }
    }

    fn scalar_i64(doc: &AutoCommit, obj: &ObjId, key: &str) -> Option<i64> {
        match doc.get(obj, key) {
            Ok(Some((Value::Scalar(v), _))) => match v.as_ref() {
                ScalarValue::Int(i) => Some(*i),
                ScalarValue::Uint(u) => Some(*u as i64),
                ScalarValue::F64(f) => Some(*f as i64),
                _ => None,
            },
            _ => None,
        }
    }

    fn scalar_bool(doc: &AutoCommit, obj: &ObjId, key: &str) -> Option<bool> {
        match doc.get(obj, key) {
            Ok(Some((Value::Scalar(v), _))) => match v.as_ref() {
                ScalarValue::Boolean(b) => Some(*b),
                _ => None,
            },
            _ => None,
        }
    }

    fn scalar_str(doc: &AutoCommit, obj: &ObjId, key: &str) -> Option<String> {
        match doc.get(obj, key) {
            Ok(Some((Value::Scalar(v), _))) => match v.as_ref() {
                ScalarValue::Str(s) => Some(s.to_string()),
                _ => None,
            },
            _ => None,
        }
    }

    // --- settings ----------------------------------------------------------

    pub fn has_settings(doc: &AutoCommit) -> bool {
        matches!(
            doc.get(&ROOT, "settings"),
            Ok(Some((Value::Object(ObjType::Map), _)))
        )
    }

    pub fn write_settings(doc: &mut AutoCommit, s: &Settings) {
        let m = Self::root_map(doc, "settings");
        let _ = doc.put(&m, "font_scale", f64::from(s.font_scale));
        let _ = doc.put(&m, "line_spacing", f64::from(s.line_spacing));
        let _ = doc.put(&m, "font_id", s.font_id.as_str());
        let _ = doc.put(&m, "theme", s.theme.as_str());
        let _ = doc.put(&m, "scheme_id", s.scheme_id.as_str());
        let _ = doc.put(&m, "mode", s.mode.as_str());
        let _ = doc.put(&m, "composition", s.composition.as_str());
    }

    pub fn read_settings(doc: &AutoCommit) -> Settings {
        let mut s = Settings::default();
        let Ok(Some((Value::Object(ObjType::Map), m))) = doc.get(&ROOT, "settings") else {
            return s;
        };
        if let Some(v) = Self::scalar_f64(doc, &m, "font_scale") {
            s.font_scale = (v as f32).clamp(Settings::FONT_MIN, Settings::FONT_MAX);
        }
        if let Some(v) = Self::scalar_f64(doc, &m, "line_spacing") {
            s.line_spacing = (v as f32).clamp(Settings::SPACING_MIN, Settings::SPACING_MAX);
        }
        if let Some(v) = Self::scalar_str(doc, &m, "font_id") {
            s.font_id = v;
        }
        if let Some(v) = Self::scalar_str(doc, &m, "theme") {
            s.theme = ReadTheme::from_str(&v);
        }
        if let Some(v) = Self::scalar_str(doc, &m, "scheme_id") {
            s.scheme_id = v;
        }
        if let Some(v) = Self::scalar_str(doc, &m, "mode") {
            s.mode = ReadMode::from_str(&v);
        }
        if let Some(v) = Self::scalar_str(doc, &m, "composition") {
            s.composition = crate::model::CompositionStyle::from_str(&v);
        }
        s
    }

    // --- font registry -----------------------------------------------------

    /// Read the registered fonts. When none are stored (a fresh library) the
    /// built-in [`default_fonts`] set is returned without writing, so the
    /// document stays clean until the user actually edits the registry.
    pub fn read_fonts(doc: &AutoCommit) -> Vec<FontEntry> {
        let Ok(Some((Value::Object(ObjType::List), list))) = doc.get(&ROOT, "fonts") else {
            return default_fonts();
        };
        let mut out = Vec::new();
        for i in 0..doc.length(&list) {
            let Ok(Some((Value::Object(ObjType::Map), e))) = doc.get(&list, i) else {
                continue;
            };
            let id = Self::scalar_str(doc, &e, "id").unwrap_or_default();
            if id.is_empty() {
                continue;
            }
            out.push(FontEntry {
                kind: FontKind::from_code(
                    &Self::scalar_str(doc, &e, "kind").unwrap_or_else(|| "default".into()),
                ),
                name: Self::scalar_str(doc, &e, "name").unwrap_or_else(|| id.clone()),
                size_mult: Self::scalar_f64(doc, &e, "size_mult").map_or(1.0, |v| {
                    (v as f32).clamp(FontEntry::MULT_MIN, FontEntry::MULT_MAX)
                }),
                shown: Self::scalar_bool(doc, &e, "shown").unwrap_or(true),
                id,
            });
        }
        if out.is_empty() { default_fonts() } else { out }
    }

    /// Replace the whole font registry (the manager edits the list wholesale).
    ///
    /// # Panics
    ///
    /// Panics if creating the fresh `"fonts"` list (or a fresh entry map
    /// inside it) fails, which only happens if the document itself is
    /// corrupt — there is no meaningful `ObjId` to fall back to.
    #[allow(
        clippy::expect_used,
        reason = "put_object/insert_object on a freshly-created list cannot fail short of document corruption, which has no meaningful ObjId fallback"
    )]
    pub fn write_fonts(doc: &mut AutoCommit, fonts: &[FontEntry]) {
        let list = doc
            .put_object(&ROOT, "fonts", ObjType::List)
            .expect("put_object list never fails");
        for (i, f) in fonts.iter().enumerate() {
            let e = doc
                .insert_object(&list, i, ObjType::Map)
                .expect("insert_object map never fails");
            let _ = doc.put(&e, "id", f.id.as_str());
            let _ = doc.put(&e, "kind", f.kind.as_code());
            let _ = doc.put(&e, "name", f.name.as_str());
            let _ = doc.put(&e, "size_mult", f64::from(f.size_mult));
            let _ = doc.put(&e, "shown", f.shown);
        }
    }

    /// The registry-wide default font id (used when a book has no explicit
    /// per-reader selection). Empty string means "the first registered font".
    pub fn read_default_font(doc: &AutoCommit) -> String {
        match doc.get(&ROOT, "settings") {
            Ok(Some((Value::Object(ObjType::Map), m))) => {
                Self::scalar_str(doc, &m, "default_font").unwrap_or_default()
            }
            _ => String::new(),
        }
    }

    pub fn write_default_font(doc: &mut AutoCommit, id: &str) {
        let m = Self::root_map(doc, "settings");
        let _ = doc.put(&m, "default_font", id);
    }

    // --- library shelf preferences ----------------------------------------

    /// Read the shelf's sort order + hide-read flag (defaults when unset).
    pub fn read_library_prefs(doc: &AutoCommit) -> LibraryPrefs {
        let mut p = LibraryPrefs::default();
        let Ok(Some((Value::Object(ObjType::Map), m))) = doc.get(&ROOT, "settings") else {
            return p;
        };
        if let Some(v) = Self::scalar_str(doc, &m, "library_sort") {
            p.sort = LibrarySort::from_str(&v);
        }
        if let Some(v) = Self::scalar_bool(doc, &m, "library_hide_read") {
            p.hide_read = v;
        }
        p
    }

    pub fn write_library_prefs(doc: &mut AutoCommit, p: &LibraryPrefs) {
        let m = Self::root_map(doc, "settings");
        let _ = doc.put(&m, "library_sort", p.sort.as_str());
        let _ = doc.put(&m, "library_hide_read", p.hide_read);
    }

    // --- the library: books the reader has added, keyed by content-hash id -

    /// Add or update a book in the library. Re-importing the same file (same
    /// content id) refreshes its public metadata while preserving the original
    /// "added" time. Source paths are device-private capability grants and
    /// must never be written to the shared document.
    pub fn upsert_library_entry(doc: &mut AutoCommit, e: &LibraryEntry) {
        // Only an explicit, user-consented import may restore a removed shelf
        // row. Ordinary delayed metadata upserts must not resurrect it.
        if Self::library_is_removed(doc, &e.id) {
            return;
        }
        let lib = Self::root_map(doc, "library");
        let existing_added = match doc.get(&lib, e.id.as_str()) {
            Ok(Some((Value::Object(ObjType::Map), id))) => Self::scalar_i64(doc, &id, "added")
                .filter(|&v| v > 0)
                .map(|v| v as u64),
            _ => None,
        };
        let entry = Self::get_or_make_map(doc, &lib, &e.id);
        // Earlier development snapshots stored a raw source path here. Clear
        // it whenever this row is touched so a normal import repairs old
        // replicated state instead of extending the disclosure indefinitely.
        let _ = doc.delete(&entry, "path");
        let _ = doc.put(&entry, "title", e.title.as_str());
        let _ = doc.put(&entry, "author", e.author.as_str());
        let _ = doc.put(&entry, "subject", e.subject.as_str());
        let was_shared = Self::scalar_bool(doc, &entry, "shared").unwrap_or(false);
        let _ = doc.put(&entry, "shared", was_shared || e.shared);
        let added = existing_added.unwrap_or_else(|| if e.added > 0 { e.added } else { now_ms() });
        let _ = doc.put(&entry, "added", added as i64);
    }

    /// Drop a book from the library. Its annotations + progress are left in place
    /// (keyed by content id) so re-adding the same file restores them.
    pub fn remove_library_entry(doc: &mut AutoCommit, id: &str) {
        let tombstones = Self::root_map(doc, "library_tombstones");
        let _ = doc.put(&tombstones, id, true);
        let lib = Self::root_map(doc, "library");
        let _ = doc.delete(&lib, id);
    }

    /// A fresh, user-consented import is the sole restore path for a shelf
    /// tombstone. This keeps delayed metadata writes from reviving a removed
    /// book while retaining the intentional "remove then re-add" workflow.
    pub fn restore_library_entry(doc: &mut AutoCommit, e: &LibraryEntry) {
        if let Ok(Some((Value::Object(ObjType::Map), tombstones))) =
            doc.get(&ROOT, "library_tombstones")
        {
            let _ = doc.delete(&tombstones, &e.id);
        }
        Self::upsert_library_entry(doc, e);
    }

    pub fn library_is_removed(doc: &AutoCommit, id: &str) -> bool {
        Self::has_tombstone(doc, "library_tombstones", id)
    }

    /// Every book in the library, ordered by when it was added (oldest first) so
    /// the shelf has a stable base order the sort control then re-orders.
    pub fn read_library_entries(doc: &AutoCommit) -> Vec<LibraryEntry> {
        let Ok(Some((Value::Object(ObjType::Map), lib))) = doc.get(&ROOT, "library") else {
            return Vec::new();
        };
        let mut out = Vec::new();
        let keys: Vec<String> = doc.keys(&lib).collect();
        for key in keys {
            if Self::library_is_removed(doc, &key) {
                continue;
            }
            let Ok(Some((Value::Object(ObjType::Map), e))) = doc.get(&lib, key.as_str()) else {
                continue;
            };
            out.push(LibraryEntry {
                id: key,
                shared: Self::scalar_bool(doc, &e, "shared").unwrap_or(false),
                title: Self::scalar_str(doc, &e, "title").unwrap_or_default(),
                author: Self::scalar_str(doc, &e, "author").unwrap_or_default(),
                subject: Self::scalar_str(doc, &e, "subject").unwrap_or_default(),
                added: Self::scalar_i64(doc, &e, "added").unwrap_or(0).max(0) as u64,
            });
        }
        out.sort_by(|a, b| a.added.cmp(&b.added).then_with(|| a.id.cmp(&b.id)));
        out
    }

    /// Remove raw path fields left by older app versions. The metadata and
    /// content id survive, so a device can rediscover a local file through a
    /// user-granted watched folder and peers can resolve the canonical shared
    /// object without learning where either device stored it.
    pub fn strip_legacy_library_paths(doc: &mut AutoCommit) {
        if let Ok(Some((Value::Object(ObjType::Map), lib))) = doc.get(&ROOT, "library") {
            let keys: Vec<String> = doc.keys(&lib).collect();
            for key in keys {
                if let Ok(Some((Value::Object(ObjType::Map), entry))) = doc.get(&lib, key.as_str())
                {
                    let _ = doc.delete(&entry, "path");
                }
            }
        }
        // Folder watches are local capability grants, never collaborative
        // preferences. Older documents held them as raw strings too.
        let _ = doc.delete(&ROOT, "watched_folders");
    }

    // --- colour schemes ----------------------------------------------------

    /// Read the registered colour schemes, falling back to the built-ins when
    /// none are stored (kept out of the document until the user edits them).
    pub fn read_schemes(doc: &AutoCommit) -> Vec<ColorScheme> {
        let Ok(Some((Value::Object(ObjType::List), list))) = doc.get(&ROOT, "schemes") else {
            return default_schemes();
        };
        let mut out = Vec::new();
        for i in 0..doc.length(&list) {
            let Ok(Some((Value::Object(ObjType::Map), e))) = doc.get(&list, i) else {
                continue;
            };
            let id = Self::scalar_str(doc, &e, "id").unwrap_or_default();
            if id.is_empty() {
                continue;
            }
            let page = unpack_rgb(Self::scalar_i64(doc, &e, "page").unwrap_or(0));
            out.push(ColorScheme {
                name: Self::scalar_str(doc, &e, "name").unwrap_or_else(|| id.clone()),
                page,
                ink: unpack_rgb(Self::scalar_i64(doc, &e, "ink").unwrap_or(0)),
                accent: unpack_rgb(Self::scalar_i64(doc, &e, "accent").unwrap_or(0)),
                dark: Self::scalar_bool(doc, &e, "dark")
                    .unwrap_or_else(|| crate::model::luminance(page) < 0.5),
                enabled: Self::scalar_bool(doc, &e, "enabled").unwrap_or(true),
                builtin: Self::scalar_bool(doc, &e, "builtin").unwrap_or(false),
                id,
            });
        }
        if out.is_empty() {
            default_schemes()
        } else {
            out
        }
    }

    /// Replace the whole scheme registry (the manager edits it wholesale).
    ///
    /// # Panics
    ///
    /// Panics if creating the fresh `"schemes"` list (or a fresh entry map
    /// inside it) fails, which only happens if the document itself is
    /// corrupt — there is no meaningful `ObjId` to fall back to.
    #[allow(
        clippy::expect_used,
        reason = "put_object/insert_object on a freshly-created list cannot fail short of document corruption, which has no meaningful ObjId fallback"
    )]
    pub fn write_schemes(doc: &mut AutoCommit, schemes: &[ColorScheme]) {
        let list = doc
            .put_object(&ROOT, "schemes", ObjType::List)
            .expect("put_object list never fails");
        for (i, s) in schemes.iter().enumerate() {
            let e = doc
                .insert_object(&list, i, ObjType::Map)
                .expect("insert_object map never fails");
            let _ = doc.put(&e, "id", s.id.as_str());
            let _ = doc.put(&e, "name", s.name.as_str());
            let _ = doc.put(&e, "page", pack_rgb(s.page));
            let _ = doc.put(&e, "ink", pack_rgb(s.ink));
            let _ = doc.put(&e, "accent", pack_rgb(s.accent));
            let _ = doc.put(&e, "dark", s.dark);
            let _ = doc.put(&e, "enabled", s.enabled);
            let _ = doc.put(&e, "builtin", s.builtin);
        }
    }

    // --- progress ----------------------------------------------------------

    pub fn write_progress(doc: &mut AutoCommit, book_id: &str, p: &Progress) {
        let progress = Self::root_map(doc, "progress");
        let entry = Self::get_or_make_map(doc, &progress, book_id);
        let _ = doc.put(&entry, "chapter", p.chapter as i64);
        let _ = doc.put(&entry, "page", p.page as i64);
        let _ = doc.put(&entry, "fraction", f64::from(p.fraction));
        // Preserve a previously recorded open time; only advance it (0 = never).
        if p.opened > 0 {
            let _ = doc.put(&entry, "opened", p.opened as i64);
        }
    }

    pub fn read_progress(doc: &AutoCommit, book_id: &str) -> Progress {
        let Ok(Some((Value::Object(ObjType::Map), progress))) = doc.get(&ROOT, "progress") else {
            return Progress::default();
        };
        let Ok(Some((Value::Object(ObjType::Map), entry))) = doc.get(&progress, book_id) else {
            return Progress::default();
        };
        Progress {
            chapter: Self::scalar_i64(doc, &entry, "chapter").unwrap_or(0).max(0) as usize,
            page: Self::scalar_i64(doc, &entry, "page").unwrap_or(0).max(0) as usize,
            fraction: Self::scalar_f64(doc, &entry, "fraction").unwrap_or(0.0) as f32,
            opened: Self::scalar_i64(doc, &entry, "opened").unwrap_or(0).max(0) as u64,
        }
    }

    // --- annotations -------------------------------------------------------

    fn annotations_map(doc: &mut AutoCommit) -> ObjId {
        Self::root_map(doc, "annotations")
    }

    /// A deletion marker is deliberately a separate, keyed CRDT map rather
    /// than a `delete` of the annotation entry. Automerge merges a map delete
    /// with a concurrent field edit, which can make a supposedly deleted
    /// annotation visible again. A monotonic marker gives deletion a stable
    /// winner without turning the annotation collection into a JSON blob.
    fn tombstone_map(doc: &mut AutoCommit, key: &str) -> ObjId {
        Self::root_map(doc, key)
    }

    fn has_tombstone(doc: &AutoCommit, key: &str, id: &str) -> bool {
        let Ok(Some((Value::Object(ObjType::Map), tombstones))) = doc.get(&ROOT, key) else {
            return false;
        };
        Self::scalar_bool(doc, &tombstones, id).unwrap_or(false)
    }

    pub fn annotation_is_deleted(doc: &AutoCommit, id: Uuid) -> bool {
        Self::has_tombstone(doc, "annotation_tombstones", &id.to_string())
    }

    pub fn group_is_deleted(doc: &AutoCommit, group: Uuid) -> bool {
        Self::has_tombstone(doc, "highlight_tombstones", &group.to_string())
    }

    /// Whether a row may still be changed or shown.  A row tombstone is
    /// sufficient to hide a standalone annotation; rows belonging to a
    /// deleted highlight group are hidden as well.  Keeping this check here
    /// prevents a late edit action from mutating an otherwise invisible row
    /// after a collaborator deleted its parent highlight.
    pub fn annotation_is_live(doc: &AutoCommit, id: Uuid) -> bool {
        if Self::annotation_is_deleted(doc, id) {
            return false;
        }
        let Ok(Some((Value::Object(ObjType::Map), map))) = doc.get(&ROOT, "annotations") else {
            return false;
        };
        let Ok(Some((Value::Object(ObjType::Map), entry))) = doc.get(&map, id.to_string()) else {
            return false;
        };
        let group = Self::scalar_str(doc, &entry, "group")
            .and_then(|value| value.parse().ok())
            .unwrap_or(id);
        !Self::group_is_deleted(doc, group)
    }

    fn mark_tombstone(doc: &mut AutoCommit, map_key: &str, id: Uuid) {
        let tombstones = Self::tombstone_map(doc, map_key);
        let _ = doc.put(&tombstones, id.to_string().as_str(), true);
    }

    pub fn upsert_annotation(doc: &mut AutoCommit, a: &Annotation) {
        // IDs and logical highlight groups are minted exactly once. Never let
        // a delayed duplicate/add resurrect something a collaborator deleted.
        if Self::annotation_is_deleted(doc, a.id) || Self::group_is_deleted(doc, a.group) {
            return;
        }
        // An annotation id never changes logical highlight group. Apart from
        // making accidental UUID reuse harmless, this prevents a stale row
        // hidden by a group tombstone from being reattached to a new group.
        if let Ok(Some((Value::Object(ObjType::Map), map))) = doc.get(&ROOT, "annotations")
            && let Ok(Some((Value::Object(ObjType::Map), entry))) = doc.get(&map, a.id.to_string())
        {
            let existing_group = Self::scalar_str(doc, &entry, "group")
                .and_then(|value| value.parse().ok())
                .unwrap_or(a.id);
            if existing_group != a.group || Self::group_is_deleted(doc, existing_group) {
                return;
            }
        }
        let map = Self::annotations_map(doc);
        let key = a.id.to_string();
        let entry = Self::get_or_make_map(doc, &map, &key);
        let _ = doc.put(&entry, "doc_id", a.doc_id.as_str());
        let _ = doc.put(&entry, "kind", a.kind.as_str());
        let _ = doc.put(&entry, "chapter", a.chapter as i64);
        let _ = doc.put(&entry, "block", a.block as i64);
        let _ = doc.put(&entry, "start", a.start as i64);
        let _ = doc.put(&entry, "end", a.end as i64);
        let _ = doc.put(&entry, "excerpt", a.excerpt.as_str());
        let _ = doc.put(&entry, "note", a.note.as_str());
        let _ = doc.put(&entry, "color", a.color.as_str());
        let _ = doc.put(&entry, "created", a.created as i64);
        let _ = doc.put(&entry, "group", a.group.to_string().as_str());
    }

    pub fn remove_annotation(doc: &mut AutoCommit, id: Uuid) {
        Self::mark_tombstone(doc, "annotation_tombstones", id);
    }

    /// Remove every annotation row belonging to one logical group — a highlight
    /// (its per-block pieces) together with all of its comments.
    pub fn remove_group(doc: &mut AutoCommit, group: Uuid) {
        // Capture current children while they are still visible, then write
        // both the durable group marker and child markers. The operation is
        // atomic on this replica; the group marker still hides any offline
        // comment which arrives later through a merge.
        let ids: Vec<Uuid> = Self::list_annotations(doc)
            .into_iter()
            .filter(|a| a.group == group)
            .map(|a| a.id)
            .collect();
        Self::mark_tombstone(doc, "highlight_tombstones", group);
        for id in ids {
            Self::remove_annotation(doc, id);
        }
    }

    pub fn list_annotations(doc: &AutoCommit) -> Vec<Annotation> {
        let Ok(Some((Value::Object(ObjType::Map), map))) = doc.get(&ROOT, "annotations") else {
            return Vec::new();
        };
        let mut out = Vec::new();
        for key in doc.keys(&map) {
            let Ok(id) = key.parse::<Uuid>() else {
                continue;
            };
            if Self::annotation_is_deleted(doc, id) {
                continue;
            }
            let Ok(Some((Value::Object(ObjType::Map), e))) = doc.get(&map, key.as_str()) else {
                continue;
            };
            let a = Annotation {
                id,
                doc_id: Self::scalar_str(doc, &e, "doc_id").unwrap_or_default(),
                kind: AnnoKind::from_str(&Self::scalar_str(doc, &e, "kind").unwrap_or_default()),
                chapter: Self::scalar_i64(doc, &e, "chapter").unwrap_or(0).max(0) as usize,
                block: Self::scalar_i64(doc, &e, "block").unwrap_or(0).max(0) as usize,
                start: Self::scalar_i64(doc, &e, "start").unwrap_or(0).max(0) as usize,
                end: Self::scalar_i64(doc, &e, "end").unwrap_or(0).max(0) as usize,
                excerpt: Self::scalar_str(doc, &e, "excerpt").unwrap_or_default(),
                note: Self::scalar_str(doc, &e, "note").unwrap_or_default(),
                color: HiColor::from_str(&Self::scalar_str(doc, &e, "color").unwrap_or_default()),
                created: Self::scalar_i64(doc, &e, "created").unwrap_or(0).max(0) as u64,
                // Older rows predate grouping; fall back to a self-group (the
                // row's own id) so each behaves as a standalone mark.
                group: Self::scalar_str(doc, &e, "group")
                    .and_then(|s| s.parse().ok())
                    .unwrap_or(id),
            };
            if !Self::group_is_deleted(doc, a.group) {
                out.push(a);
            }
        }
        out
    }

    /// Annotations for one book, sorted by location then creation time.
    pub fn annotations_for(doc: &AutoCommit, book_id: &str) -> Vec<Annotation> {
        let mut v: Vec<Annotation> = Self::list_annotations(doc)
            .into_iter()
            .filter(|a| a.doc_id == book_id)
            .collect();
        v.sort_by(|a, b| {
            (a.chapter, a.block, a.start, a.created).cmp(&(b.chapter, b.block, b.start, b.created))
        });
        v
    }
}

#[cfg(test)]
mod tests {
    use super::*;
    use crate::model::{AnnoKind, HiColor};

    #[test]
    fn settings_round_trip() {
        let mut doc = AutoCommit::new();
        let s = Settings {
            font_scale: 1.3,
            line_spacing: 1.45,
            font_id: "serif".into(),
            theme: ReadTheme::Dark,
            scheme_id: "midnight".into(),
            mode: crate::model::ReadMode::TwoUp,
            composition: crate::model::CompositionStyle::Ragged,
        };
        BooksDoc::write_settings(&mut doc, &s);
        let back = BooksDoc::read_settings(&doc);
        assert!((back.font_scale - 1.3).abs() < 0.001);
        assert!((back.line_spacing - 1.45).abs() < 0.001);
        assert_eq!(back.font_id, "serif");
        assert_eq!(back.theme, ReadTheme::Dark);
        assert_eq!(back.scheme_id, "midnight");
        assert_eq!(
            back.mode,
            crate::model::ReadMode::TwoUp,
            "reading mode persists"
        );
        assert_eq!(
            back.composition,
            crate::model::CompositionStyle::Ragged,
            "composition style persists"
        );
        // A fresh document defaults to the paged reading mode.
        assert_eq!(
            BooksDoc::read_settings(&AutoCommit::new()).mode,
            crate::model::ReadMode::Paged
        );
        assert_eq!(
            BooksDoc::read_settings(&AutoCommit::new()).composition,
            crate::model::CompositionStyle::Book
        );
    }

    #[test]
    fn fonts_registry_defaults_and_round_trips() {
        let mut doc = AutoCommit::new();
        // No stored registry -> the built-in defaults, without writing.
        let defaults = BooksDoc::read_fonts(&doc);
        assert!(defaults.iter().any(|f| f.kind == FontKind::Serif));

        // A custom registry (rename + hide + a named face) round-trips exactly.
        let mut custom = default_fonts();
        custom[0].name = "Book".into();
        custom[1].shown = false;
        custom.push(FontEntry::new(
            "u1",
            FontKind::Named("Literata".into()),
            "Literata",
            1.1,
            true,
        ));
        BooksDoc::write_fonts(&mut doc, &custom);
        let back = BooksDoc::read_fonts(&doc);
        assert_eq!(back.len(), custom.len());
        assert_eq!(back[0].name, "Book");
        assert!(!back[1].shown);
        assert_eq!(
            back.last().unwrap().kind,
            FontKind::Named("Literata".into())
        );
        assert!((back.last().unwrap().size_mult - 1.1).abs() < 0.001);
    }

    #[test]
    fn progress_round_trip() {
        let mut doc = AutoCommit::new();
        let p = Progress {
            chapter: 2,
            page: 5,
            fraction: 0.42,
            opened: 1_720_000_000_000,
        };
        BooksDoc::write_progress(&mut doc, "book:x", &p);
        let back = BooksDoc::read_progress(&doc, "book:x");
        assert_eq!(back.chapter, 2);
        assert_eq!(back.page, 5);
        assert!((back.fraction - 0.42).abs() < 0.001);
        assert_eq!(
            back.opened, 1_720_000_000_000,
            "open time persists for recent-sort"
        );
        // Unknown book -> default.
        assert_eq!(BooksDoc::read_progress(&doc, "nope"), Progress::default());
    }

    #[test]
    fn library_prefs_round_trip() {
        let mut doc = AutoCommit::new();
        assert_eq!(BooksDoc::read_library_prefs(&doc), LibraryPrefs::default());
        let p = LibraryPrefs {
            sort: LibrarySort::Recent,
            hide_read: true,
        };
        BooksDoc::write_library_prefs(&mut doc, &p);
        assert_eq!(BooksDoc::read_library_prefs(&doc), p);
    }

    #[test]
    fn schemes_registry_round_trips_with_a_custom_scheme() {
        let mut doc = AutoCommit::new();
        assert_eq!(BooksDoc::read_schemes(&doc).len(), default_schemes().len());
        let mut schemes = default_schemes();
        schemes[0].enabled = false; // disable a built-in
        schemes.push(ColorScheme::from_bg("u1", "Ocean", [0x0A, 0x22, 0x33]));
        BooksDoc::write_schemes(&mut doc, &schemes);
        let back = BooksDoc::read_schemes(&doc);
        assert_eq!(back.len(), schemes.len());
        assert!(!back[0].enabled, "disabled state round-trips");
        let custom = back.last().unwrap();
        assert_eq!(custom.name, "Ocean");
        assert_eq!(custom.page, [0x0A, 0x22, 0x33]);
        assert!(custom.dark && !custom.builtin);
    }

    #[test]
    fn annotations_upsert_list_remove() {
        let mut doc = AutoCommit::new();
        let a = Annotation::new("book:x", AnnoKind::Highlight, 1, 3)
            .with_excerpt("a passage")
            .with_color(HiColor::Green)
            .with_note("nice");
        let id = a.id;
        BooksDoc::upsert_annotation(&mut doc, &a);
        let list = BooksDoc::annotations_for(&doc, "book:x");
        assert_eq!(list.len(), 1);
        assert_eq!(list[0].kind, AnnoKind::Highlight);
        assert_eq!(list[0].color, HiColor::Green);
        assert_eq!(list[0].note, "nice");
        // Update in place (no duplicate).
        let mut a2 = a.clone();
        a2.note = "edited".into();
        BooksDoc::upsert_annotation(&mut doc, &a2);
        assert_eq!(BooksDoc::annotations_for(&doc, "book:x").len(), 1);
        assert_eq!(BooksDoc::annotations_for(&doc, "book:x")[0].note, "edited");
        // Remove.
        BooksDoc::remove_annotation(&mut doc, id);
        assert!(BooksDoc::annotations_for(&doc, "book:x").is_empty());
        assert!(BooksDoc::annotation_is_deleted(&doc, id));

        // A stale peer can still carry the old row. It must not revive a
        // deletion just because its map write arrives after the tombstone.
        BooksDoc::upsert_annotation(&mut doc, &a2);
        assert!(BooksDoc::annotations_for(&doc, "book:x").is_empty());
    }

    #[test]
    fn group_tombstone_hides_a_late_comment_without_deleting_unrelated_rows() {
        let mut doc = AutoCommit::new();
        let group = Uuid::from_u128(0x1111_2222_3333_4444_5555_6666_7777_8888);
        let highlight = Annotation::new("book:x", AnnoKind::Highlight, 0, 1).with_group(group);
        let comment = Annotation::new("book:x", AnnoKind::Note, 0, 1)
            .with_group(group)
            .with_note("late peer comment");
        let unrelated = Annotation::new("book:x", AnnoKind::Note, 0, 2).with_note("keep me");
        BooksDoc::upsert_annotation(&mut doc, &highlight);
        BooksDoc::remove_group(&mut doc, group);
        // Simulate an offline peer's comment arriving after the group was
        // deleted. The row is never reintroduced to the visible collection.
        BooksDoc::upsert_annotation(&mut doc, &comment);
        BooksDoc::upsert_annotation(&mut doc, &unrelated);

        assert!(BooksDoc::group_is_deleted(&doc, group));
        assert!(BooksDoc::annotation_is_deleted(&doc, highlight.id));
        let rows = BooksDoc::annotations_for(&doc, "book:x");
        assert_eq!(rows.len(), 1);
        assert_eq!(rows[0].id, unrelated.id);
    }

    #[test]
    fn tombstones_win_when_independent_replicas_merge() {
        let mut base = AutoCommit::new();
        let group = Uuid::from_u128(0x1111_2222_3333_4444_5555_6666_7777_8888);
        let highlight = Annotation::new("book:x", AnnoKind::Highlight, 0, 1).with_group(group);
        let comment = Annotation::new("book:x", AnnoKind::Note, 0, 1)
            .with_group(group)
            .with_note("offline comment");
        BooksDoc::upsert_annotation(&mut base, &highlight);

        // Different actors diverge from the same ancestor: one reader deletes
        // the highlight while another reader adds a comment to it offline.
        let mut deleting_peer = base.fork().with_actor(ActorId::random());
        let mut editing_peer = base.fork().with_actor(ActorId::random());
        BooksDoc::remove_group(&mut deleting_peer, group);
        BooksDoc::upsert_annotation(&mut editing_peer, &comment);

        deleting_peer
            .merge(&mut editing_peer)
            .expect("independent replicas merge");
        editing_peer
            .merge(&mut deleting_peer)
            .expect("second replica converges");

        for peer in [&deleting_peer, &editing_peer] {
            assert!(BooksDoc::group_is_deleted(peer, group));
            assert!(BooksDoc::annotations_for(peer, "book:x").is_empty());
            assert!(!BooksDoc::annotation_is_live(peer, highlight.id));
            assert!(!BooksDoc::annotation_is_live(peer, comment.id));
        }
    }

    #[test]
    fn library_entries_round_trip_and_preserve_added_time() {
        use crate::model::LibraryEntry;
        let mut doc = AutoCommit::new();
        assert!(
            BooksDoc::read_library_entries(&doc).is_empty(),
            "fresh library is empty"
        );

        let e = LibraryEntry {
            id: "book:abc".into(),
            shared: false,
            title: "Novel".into(),
            author: "A. Writer".into(),
            subject: "Fiction".into(),
            added: 1_000,
        };
        BooksDoc::upsert_library_entry(&mut doc, &e);
        let back = BooksDoc::read_library_entries(&doc);
        assert_eq!(back.len(), 1);
        assert_eq!(back[0], e);

        // Re-importing the same content after it is shared advertises the
        // canonical workspace availability, but still keeps its shelf order.
        let moved = LibraryEntry {
            shared: true,
            added: 9_999,
            ..e.clone()
        };
        BooksDoc::upsert_library_entry(&mut doc, &moved);
        let back = BooksDoc::read_library_entries(&doc);
        assert_eq!(
            back.len(),
            1,
            "same content id updates in place, not duplicated"
        );
        assert!(back[0].shared, "shared availability is replicated");
        assert_eq!(
            back[0].added, 1_000,
            "added time is preserved across a re-import"
        );
        let bytes = doc.save();
        let stored = String::from_utf8_lossy(&bytes);
        assert!(
            !stored.contains("/home/reader/Novel.epub"),
            "a source path must not enter the replicated document"
        );

        BooksDoc::remove_library_entry(&mut doc, "book:abc");
        assert!(
            BooksDoc::read_library_entries(&doc).is_empty(),
            "removed from the shelf"
        );
    }

    #[test]
    fn legacy_location_fields_are_removed_before_syncing() {
        let mut doc = AutoCommit::new();
        let library = doc.put_object(&ROOT, "library", ObjType::Map).unwrap();
        let entry = doc
            .put_object(&library, "book:legacy", ObjType::Map)
            .unwrap();
        doc.put(&entry, "path", "/private/device/novel.epub")
            .unwrap();
        let watches = doc
            .put_object(&ROOT, "watched_folders", ObjType::List)
            .unwrap();
        doc.insert(&watches, 0, "/private/device/books").unwrap();

        BooksDoc::strip_legacy_library_paths(&mut doc);
        // Automerge preserves historical operation payloads for existing
        // replicas, but after migration the current collaborative state has no
        // readable location field and future changes cannot replicate one.
        assert!(doc.get(&entry, "path").unwrap().is_none());
        assert!(doc.get(&ROOT, "watched_folders").unwrap().is_none());
    }

    #[test]
    fn annotations_filtered_by_book() {
        let mut doc = AutoCommit::new();
        BooksDoc::upsert_annotation(
            &mut doc,
            &Annotation::new("book:a", AnnoKind::Bookmark, 0, 0),
        );
        BooksDoc::upsert_annotation(&mut doc, &Annotation::new("book:b", AnnoKind::Note, 0, 0));
        assert_eq!(BooksDoc::annotations_for(&doc, "book:a").len(), 1);
        assert_eq!(BooksDoc::annotations_for(&doc, "book:b").len(), 1);
    }
}
