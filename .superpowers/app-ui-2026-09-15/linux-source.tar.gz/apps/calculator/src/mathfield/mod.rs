//! A GeoGebra-class 2D math input field, built locally for the calculator's
//! Graph 2D / Graph 3D function editors.
//!
//! This replaces the old "type into a `String`, draw a literal `|`" editors
//! with a real structured editor: the formula is a tree of math atoms
//! ([`model`]), the caret is a genuine insertion point in that tree
//! ([`edit`]), it lays out as stacked 2D notation ([`layout`]) and renders a
//! real caret bar + selection band into the Vello scene ([`render`]).
//!
//! The field serializes to the flat ASCII string the existing
//! [`crate::engine`] parses, so graphing keeps working unchanged, and the
//! caller persists that string in the CRDT exactly as before.

pub mod edit;
pub mod layout;
pub mod model;
pub mod render;

use ui::text_render::TextRenderer;
use ui::theme::Theme;
use vello::Scene;
use vello::kurbo::{Affine, Point, Rect, Vec2};
use vello::peniko::{BlendMode, Color, Fill};
use winit::event::Modifiers;
use winit::keyboard::{Key as WKey, NamedKey};

use edit::Editor;
use layout::Layout;

/// A controller wrapping one editable formula. The graph screens own one of
/// these per function row and feed it the linear string from the model.
pub struct MathField {
    editor: Editor,
    /// Source linear string the editor was last built from; used to detect
    /// external (CRDT) changes and avoid clobbering local edits.
    source: String,
    /// On-screen content rect (set each layout pass).
    rect: Rect,
    /// Cached layout from the last draw, in content-local coords.
    layout: Option<Layout>,
    /// Signature `(linear form, base size)` the cached [`Self::layout`] was
    /// built from. Layout is rect-independent (content-local coords), so it
    /// only needs rebuilding when the formula content or the font size
    /// changes — not on every frame, pan, hover, or caret move. This is what
    /// keeps typing from re-shaping the whole formula each frame.
    layout_sig: Option<(String, f32)>,
    base_size: f32,
    /// Accessibility text-scale multiplier supplied by the owning graph panel.
    text_scale: f32,
    /// Whether a drag-select is in progress.
    dragging: bool,
    /// Content-local pixels scrolled off the top-left. Keeps a long or tall
    /// formula scrolling *within* the fixed field rect instead of overflowing
    /// it (which used to make the formula appear to resize the row). Updated to
    /// keep the caret in view while typing, and by the mouse wheel.
    scroll: Vec2,
}

impl MathField {
    pub fn new(linear: &str) -> Self {
        MathField {
            editor: Editor::from_linear(&editor_linear(linear)),
            source: linear.to_string(),
            rect: Rect::ZERO,
            layout: None,
            layout_sig: None,
            base_size: layout::BASE_SIZE,
            text_scale: 1.0,
            dragging: false,
            scroll: Vec2::ZERO,
        }
    }

    #[must_use]
    pub fn with_size(mut self, size: f32) -> Self {
        self.base_size = size;
        self
    }

    /// Apply the active UI text scale before measuring or rendering this
    /// structured field. Changing it invalidates the cached glyph geometry via
    /// the effective-size layout signature below.
    pub fn set_text_scale(&mut self, scale: f32) {
        self.text_scale = scale.clamp(0.5, 4.0);
    }

    /// Sync the editor to an external linear string (e.g. loaded from the
    /// CRDT). Only rebuilds when the string actually differs from what this
    /// field last produced, so it never stomps an in-progress edit. The
    /// stored form is the engine form (`*`); the editor uses `·` internally.
    pub fn set_source(&mut self, linear: &str) {
        if linear != self.source {
            self.editor = Editor::from_linear(&editor_linear(linear));
            self.source = linear.to_string();
        }
    }

    /// The current content as a linear string the engine parses. The editor
    /// stores `·` for multiplication (`GeoGebra` style); the engine wants `*`.
    pub fn linear(&self) -> String {
        engine_linear(&self.editor.to_linear())
    }

    pub fn is_empty(&self) -> bool {
        self.editor.expr.is_empty()
    }

    /// Park the caret inside the first 2D structure (fraction numerator,
    /// power exponent, or radicand) so a static frame shows the caret living
    /// *inside* a structure rather than at the row's end. Used to seed the
    /// `--shots` view; harmless for live use (the first real key resets it).
    pub fn park_caret_in_structure(&mut self) {
        self.editor.park_in_first_structure();
    }

    /// Park a representative selection (a span of atoms in the first
    /// structure, else the whole root row) so a static frame can show the
    /// drag-selection highlight band. Seed-only; cleared by the first key.
    pub fn park_demo_selection(&mut self) {
        self.editor.park_demo_selection();
    }

    /// Park the caret at the very end of the formula (shot/demo helper), so a
    /// static frame of a long formula shows it scrolled to its tail with the
    /// caret in view.
    pub fn park_caret_at_end(&mut self) {
        self.editor.end(false);
    }

    /// Set the content rect for this frame and (re)build the layout.
    pub fn set_rect(&mut self, rect: Rect, tr: &mut TextRenderer) {
        self.rect = rect;
        self.relayout(tr);
    }

    fn relayout(&mut self, tr: &mut TextRenderer) {
        // Rebuild only when the content or size actually changed. The linear
        // form is a faithful signature of the (canonical) tree the editor
        // builds, and is far cheaper to compute than a full measure+box pass.
        let size = self.base_size * self.text_scale;
        let sig = (self.editor.to_linear(), size);
        if self.layout.is_none() || self.layout_sig.as_ref() != Some(&sig) {
            self.layout = Some(layout::layout(&self.editor.expr.root, tr, size));
            self.layout_sig = Some(sig);
        }
        // Track the caret every pass (a caret move doesn't change the content
        // signature, but must still bring the caret back into view).
        self.ensure_caret_visible();
    }

    /// Left padding between the field edge and the content.
    const PAD_X: f64 = 4.0;

    /// Origin (top-left) where content is drawn. Horizontally the content is
    /// left-padded and shifted by the horizontal scroll; vertically it is
    /// centered when it fits and top-aligned + scrolled when it is taller than
    /// the field, so the field never grows with the formula.
    fn content_origin(&self) -> Point {
        let h = self.layout.as_ref().map_or(0.0, |l| l.height);
        let view_h = self.rect.height();
        let y = if h <= view_h {
            self.rect.y0 + (view_h - h) / 2.0
        } else {
            self.rect.y0 - self.scroll.y
        };
        Point::new(self.rect.x0 + Self::PAD_X - self.scroll.x, y)
    }

    /// Visible content width (field width minus the left pad).
    fn view_w(&self) -> f64 {
        (self.rect.width() - Self::PAD_X).max(1.0)
    }

    /// Maximum scroll offsets for the current content + field size.
    fn scroll_bounds(&self) -> (f64, f64) {
        match self.layout.as_ref() {
            Some(l) => (
                (l.width - self.view_w()).max(0.0),
                (l.height - self.rect.height()).max(0.0),
            ),
            None => (0.0, 0.0),
        }
    }

    /// Nudge the scroll so the caret stays inside the field, then clamp both
    /// axes to the content. Called every layout pass.
    fn ensure_caret_visible(&mut self) {
        // Read what we need out of the (immutably borrowed) layout first, so we
        // can mutate `self.scroll` afterwards without a borrow conflict.
        let caret = {
            let Some(layout) = self.layout.as_ref() else {
                return;
            };
            render::caret_gap(layout, &self.editor.caret.steps, self.editor.caret.offset)
                .map(|g| (g.x, g.top, g.bottom))
        };
        let view_w = self.view_w();
        let view_h = self.rect.height();
        let content_h = self.layout.as_ref().map_or(0.0, |l| l.height);
        let margin = 8.0f64;
        if let Some((cx, ctop, cbot)) = caret {
            if cx < self.scroll.x + margin {
                self.scroll.x = cx - margin;
            } else if cx > self.scroll.x + view_w - margin {
                self.scroll.x = cx - view_w + margin;
            }
            if content_h > view_h {
                if ctop < self.scroll.y {
                    self.scroll.y = ctop;
                } else if cbot > self.scroll.y + view_h {
                    self.scroll.y = cbot - view_h;
                }
            }
        }
        let (max_x, max_y) = self.scroll_bounds();
        self.scroll.x = self.scroll.x.clamp(0.0, max_x);
        self.scroll.y = self.scroll.y.clamp(0.0, max_y);
    }

    /// Scroll the content by `(dx, dy)` content pixels (e.g. from the wheel),
    /// clamped to the content extent.
    pub fn scroll_by(&mut self, dx: f64, dy: f64) {
        let (max_x, max_y) = self.scroll_bounds();
        self.scroll.x = (self.scroll.x + dx).clamp(0.0, max_x);
        self.scroll.y = (self.scroll.y + dy).clamp(0.0, max_y);
    }

    /// Whether the content currently overflows the field on either axis (so it
    /// is scrolled rather than fully visible).
    pub fn overflows(&self) -> bool {
        let (mx, my) = self.scroll_bounds();
        mx > 0.0 || my > 0.0
    }

    /// Draw the field. `focused` controls caret visibility.
    pub fn draw(
        &mut self,
        scene: &mut Scene,
        t: Affine,
        tr: &mut TextRenderer,
        theme: &Theme,
        text_color: Color,
        focused: bool,
    ) {
        self.relayout(tr);
        let Some(layout) = self.layout.as_ref() else {
            return;
        };
        let origin = self.content_origin();
        let steps = &self.editor.caret.steps;
        let caret = render::caret_gap(layout, steps, self.editor.caret.offset);
        let sel = self.editor.selection();
        let sel_gaps = render::row_gaps(layout, steps);
        let sel_gaps_ref: Vec<(usize, &layout::Gap)> = sel_gaps;
        // Clip to the field rect so a long/tall formula scrolls within a
        // bounded box instead of spilling over neighbouring rows.
        scene.push_layer(Fill::NonZero, BlendMode::default(), 1.0, t, &self.rect);
        render::draw_field(
            scene,
            t,
            tr,
            theme,
            layout,
            origin,
            caret,
            sel.as_ref(),
            &sel_gaps_ref,
            text_color,
            focused,
        );
        scene.pop_layer();
    }

    /// Map remote collaborators' scene-space cursor positions onto this field's
    /// 2D glyph layout, returning a caret-bar rect + colour for each cursor that
    /// lands within the field. This is what turns a peer's `RemoteCursorMoved`
    /// event into a caret drawn *inside* the structured formula (snapped to the
    /// nearest insertion gap), rather than only a floating pointer over the
    /// window.
    pub fn remote_caret_bars(&self, cursors: &[(Point, Color)]) -> Vec<(Rect, Color)> {
        let Some(layout) = self.layout.as_ref() else {
            return Vec::new();
        };
        let origin = self.content_origin();
        let mut out = Vec::new();
        for (p, col) in cursors {
            if !self.rect.contains(*p) {
                continue;
            }
            let lx = p.x - origin.x;
            let ly = p.y - origin.y;
            if let Some(g) = layout::nearest_gap(&layout.gaps, lx, ly) {
                let x = origin.x + g.x;
                let bar = Rect::new(x - 1.0, origin.y + g.top, x + 1.0, origin.y + g.bottom);
                out.push((bar, *col));
            }
        }
        out
    }

    /// Draw remote collaborators' carets into this field (clipped to its rect),
    /// each in the peer's colour. Call after [`MathField::draw`].
    pub fn draw_remote_carets(&self, scene: &mut Scene, t: Affine, cursors: &[(Point, Color)]) {
        let bars = self.remote_caret_bars(cursors);
        if bars.is_empty() {
            return;
        }
        scene.push_layer(Fill::NonZero, BlendMode::default(), 1.0, t, &self.rect);
        for (bar, col) in bars {
            scene.fill(Fill::NonZero, t, col, None, &bar);
        }
        scene.pop_layer();
    }

    /// The engine-ready linear form after an edit, recording it as the new
    /// source so a subsequent [`set_source`] with the same value is a no-op.
    pub fn current_linear(&mut self) -> String {
        let s = engine_linear(&self.editor.to_linear());
        self.source.clone_from(&s);
        s
    }

    // -- input ---------------------------------------------------------------

    /// Handle a key press. Returns `true` if it changed the content (so the
    /// caller can persist + re-plot). Caret-only moves return `false`.
    pub fn handle_key(&mut self, key: &WKey, modifiers: &Modifiers) -> bool {
        let m = modifiers.state();
        let shift = m.shift_key();
        let ctrl = m.control_key() || m.super_key();
        match key {
            WKey::Named(NamedKey::ArrowLeft) => {
                if ctrl {
                    self.editor.move_word_left(shift);
                } else {
                    self.editor.move_left(shift);
                }
                false
            }
            WKey::Named(NamedKey::ArrowRight) => {
                if ctrl {
                    self.editor.move_word_right(shift);
                } else {
                    self.editor.move_right(shift);
                }
                false
            }
            WKey::Named(NamedKey::ArrowUp) => {
                self.editor.move_up();
                false
            }
            WKey::Named(NamedKey::ArrowDown) => {
                self.editor.move_down();
                false
            }
            WKey::Named(NamedKey::Home) => {
                self.editor.home(shift);
                false
            }
            WKey::Named(NamedKey::End) => {
                self.editor.end(shift);
                false
            }
            WKey::Named(NamedKey::Backspace) => {
                self.editor.backspace();
                true
            }
            WKey::Named(NamedKey::Delete) => {
                self.editor.delete();
                true
            }
            WKey::Named(NamedKey::Space) => {
                // Space exits the current box (GeoGebra) when inside one,
                // else is ignored (expressions have no literal spaces).
                self.editor.move_right(false);
                false
            }
            WKey::Character(s) if ctrl => match s.as_str() {
                "a" | "A" => {
                    self.editor.select_all();
                    false
                }
                "c" | "C" => {
                    if let Some(lin) = self.editor.selected_linear() {
                        ui::clipboard_copy(&lin);
                    }
                    false
                }
                "x" | "X" => {
                    if let Some(lin) = self.editor.selected_linear() {
                        ui::clipboard_copy(&lin);
                        self.editor.delete_selection();
                        return true;
                    }
                    false
                }
                "v" | "V" => {
                    if let Some(paste) = ui::clipboard_paste() {
                        let cleaned: String = paste.chars().filter(|c| !c.is_control()).collect();
                        if !cleaned.is_empty() {
                            self.editor.paste_linear(&cleaned);
                            return true;
                        }
                    }
                    false
                }
                _ => false,
            },
            WKey::Character(s) => {
                let mut changed = false;
                for ch in s.chars() {
                    if accept(ch) {
                        self.editor.type_char(normalize(ch));
                        changed = true;
                    }
                }
                changed
            }
            _ => false,
        }
    }

    /// Press at scene point `p`, hit-testing against the layout cached by the
    /// last [`draw`]/[`set_rect`]. Places the caret at the nearest gap, or
    /// selects a token on a double click. No-op if no layout is cached yet.
    pub fn on_press_cached(&mut self, p: Point, double: bool) {
        let origin = self.content_origin();
        let lx = p.x - origin.x;
        let ly = p.y - origin.y;
        let Some(layout) = self.layout.as_ref() else {
            return;
        };
        if let Some(g) = layout::nearest_gap(&layout.gaps, lx, ly) {
            let steps = g.steps.clone();
            let index = g.index;
            if double {
                self.editor.select_token_at(steps, index);
            } else {
                self.editor.caret.steps = steps;
                self.editor.caret.offset = index;
                self.editor.anchor = None;
                self.dragging = true;
            }
        }
    }

    /// Drag to scene point `p` while the button is held: extend the selection
    /// to the nearest gap in the caret's current row, against the cached
    /// layout.
    pub fn on_drag_cached(&mut self, p: Point) {
        if !self.dragging {
            return;
        }
        let origin = self.content_origin();
        let lx = p.x - origin.x;
        let ly = p.y - origin.y;
        let Some(layout) = self.layout.as_ref() else {
            return;
        };
        let steps = self.editor.caret.steps.clone();
        let nearest = layout
            .gaps
            .iter()
            .filter(|g| g.steps == steps)
            .min_by(|a, b| {
                let da = gap_cost(a, lx, ly);
                let db = gap_cost(b, lx, ly);
                da.partial_cmp(&db).unwrap_or(std::cmp::Ordering::Equal)
            });
        if let Some(g) = nearest {
            if self.editor.anchor.is_none() {
                self.editor.anchor = Some(self.editor.caret.offset);
            }
            self.editor.caret.offset = g.index;
        }
    }

    pub fn on_release(&mut self) {
        self.dragging = false;
    }

    pub fn contains(&self, p: Point) -> bool {
        self.rect.contains(p)
    }

    /// Height the laid-out content needs, measured against `tr` (rebuilding the
    /// layout if the content changed). Callers use this to GROW the hosting card
    /// to fit the formula up to [`CARD_MAX_H`] before handing the field its rect,
    /// so a taller formula makes its card taller instead of being clipped.
    pub fn content_height(&mut self, tr: &mut TextRenderer) -> f64 {
        self.relayout(tr);
        self.layout.as_ref().map_or(0.0, |l| l.height)
    }
}

/// Smallest inner (content-viewport) height a formula card uses. A short,
/// single-line formula (`x + 1`, `sin(x)`) sits in a card of this height so the
/// common case looks unchanged.
pub const CARD_MIN_H: f64 = 30.0;

/// Largest inner height a formula card grows to. It is generous on purpose: a
/// single fraction (`(x²+1)/(x−3)` ≈ 67 px) and a stacked `√` over superscripts
/// (the 3D default `sin(√(x²+y²))` ≈ 39 px) are shown *in full* — the card grows
/// to fit them rather than clipping. Only genuinely oversized content (a
/// fraction-over-fraction and deeper nesting) exceeds this height, at which point
/// the card stops growing and the formula becomes vertically scrollable within
/// it — never clipped behind the card edge.
pub const CARD_MAX_H: f64 = 96.0;

/// The inner (content-viewport) height a card should use for a formula whose
/// laid-out content is `content_h` tall: grow to fit, clamped to
/// `[CARD_MIN_H, CARD_MAX_H]`. When `content_h` exceeds [`CARD_MAX_H`] the
/// returned height is the max, and the field will report [`MathField::overflows`]
/// so the caller knows the formula scrolls within the card.
pub fn card_view_height(content_h: f64) -> f64 {
    content_h.clamp(CARD_MIN_H, CARD_MAX_H)
}

/// Editor `·` (middle dot) → engine `*`.
fn engine_linear(s: &str) -> String {
    s.replace('·', "*")
}

/// Engine `*` → editor `·`, so a string loaded from the CRDT renders with the
/// proper multiplication glyph.
fn editor_linear(s: &str) -> String {
    s.replace('*', "·")
}

fn gap_cost(g: &layout::Gap, px: f64, py: f64) -> f64 {
    let dy = if py < g.top {
        g.top - py
    } else if py > g.bottom {
        py - g.bottom
    } else {
        0.0
    };
    dy * 4.0 + (g.x - px).abs()
}

/// Characters the field accepts as input.
fn accept(ch: char) -> bool {
    ch.is_ascii_alphanumeric()
        || "+-*/^(),. %!·π√".contains(ch)
        || ch == '×'
        || ch == '÷'
        || ch == '−'
}

/// Normalize a few unicode inputs to the editor's canonical glyphs.
fn normalize(ch: char) -> char {
    match ch {
        '×' => '·',
        '÷' => '/',
        '−' => '-',
        'A'..='Z' => ch.to_ascii_lowercase(),
        other => other,
    }
}

#[cfg(test)]
mod tests;
