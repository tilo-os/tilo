//! In-memory model for the calculator. This is the render/interaction
//! mirror of the CRDT document (see `doc.rs`); state is authored here and
//! flushed into Automerge so undo/redo and live collaboration work.

use crate::engine::{self, Ctx};

/// Top-level app mode (segmented control in the header).
#[derive(Clone, Copy, PartialEq, Eq, Debug)]
pub enum Mode {
    Calc,
    Graph2d,
    Graph3d,
}

impl Mode {
    pub fn label(self) -> &'static str {
        match self {
            Mode::Calc => "Calculator",
            Mode::Graph2d => "Graph 2D",
            Mode::Graph3d => "Graph 3D",
        }
    }
    /// Condensed label for a narrow topbar where the full [`label`] won't fit.
    pub fn short_label(self) -> &'static str {
        match self {
            Mode::Calc => "Calc",
            Mode::Graph2d => "2D",
            Mode::Graph3d => "3D",
        }
    }
    pub fn all() -> [Mode; 3] {
        [Mode::Calc, Mode::Graph2d, Mode::Graph3d]
    }
    pub fn index(self) -> usize {
        match self {
            Mode::Calc => 0,
            Mode::Graph2d => 1,
            Mode::Graph3d => 2,
        }
    }
    pub fn from_index(i: usize) -> Mode {
        match i {
            1 => Mode::Graph2d,
            2 => Mode::Graph3d,
            _ => Mode::Calc,
        }
    }
}

/// One evaluated entry in the calculator history.
#[derive(Clone, Debug, PartialEq)]
pub struct HistoryEntry {
    pub expr: String,
    pub result: String,
}

/// A `y = f(x)` curve for the 2D plotter.
#[derive(Clone, Debug, PartialEq)]
pub struct PlotFn {
    pub expr: String,
    pub visible: bool,
}

/// 2D viewport: world-space center + pixels-per-unit zoom.
#[derive(Clone, Copy, Debug, PartialEq)]
pub struct View2d {
    pub cx: f64,
    pub cy: f64,
    pub scale: f64,
}

impl Default for View2d {
    fn default() -> Self {
        Self {
            cx: 0.0,
            cy: 0.0,
            scale: 64.0,
        }
    }
}

/// 3D viewport: orbit angles + zoom.
#[derive(Clone, Copy, Debug, PartialEq)]
pub struct View3d {
    pub yaw: f64,
    pub pitch: f64,
    pub zoom: f64,
}

impl Default for View3d {
    fn default() -> Self {
        Self {
            yaw: 0.62,
            pitch: 0.52,
            zoom: 1.0,
        }
    }
}

/// The whole calculator state.
#[derive(Clone, Debug, PartialEq)]
pub struct CalcModel {
    pub mode: Mode,
    pub deg: bool,
    pub expr: String,
    /// After `=`, the next value-key starts fresh; an operator continues.
    pub after_equals: bool,
    pub ans: f64,
    pub memory: f64,
    pub history: Vec<HistoryEntry>,
    pub funcs: Vec<PlotFn>,
    pub active_fn: usize,
    /// The Graph 3D surface list: each `PlotFn` is a `z = f(x, y)` surface,
    /// mirroring how `funcs` holds the 2D `y = f(x)` curves. Multiple surfaces
    /// render as separate, per-function-coloured sheets (visibility-toggleable).
    pub surfaces: Vec<PlotFn>,
    /// Active surface row in [`surfaces`] (the one the editor edits) — the 3D
    /// analogue of [`active_fn`].
    pub active_surface: usize,
    pub view2d: View2d,
    pub view3d: View3d,
}

impl Default for CalcModel {
    /// The live launch state: an empty calculator in Calc mode. Nothing is
    /// pre-plotted, no history, no memory — the app boots to a blank slate the
    /// user fills in. (A lived-in demo state lives behind [`CalcModel::seeded`],
    /// used only by the headless screenshot + tests.)
    fn default() -> Self {
        Self {
            mode: Mode::Calc,
            deg: false,
            expr: String::new(),
            after_equals: false,
            ans: 0.0,
            memory: 0.0,
            history: Vec::new(),
            funcs: Vec::new(),
            active_fn: 0,
            surfaces: Vec::new(),
            active_surface: 0,
            view2d: View2d::default(),
            view3d: View3d::default(),
        }
    }
}

/// The default `z = f(x, y)` surface a user gets when they first open Graph 3D
/// (a starter example to explore + edit, not restored user state).
pub const DEFAULT_SURFACE: &str = "sin(sqrt(x^2+y^2))";

impl CalcModel {
    /// Rich starting content for the headless `--shots` frame and tests — a
    /// populated, lived-in calculator + graphs. NEVER used by the live event
    /// loop (which boots empty via [`CalcModel::default`]).
    pub fn seeded() -> Self {
        let mut m = CalcModel {
            mode: Mode::Graph2d,
            expr: "sin(0.5)+cos(0.5)".to_string(),
            ans: 1.0,
            memory: 42.0,
            history: vec![
                HistoryEntry {
                    expr: "12*(4+3)".into(),
                    result: "84".into(),
                },
                HistoryEntry {
                    expr: "sqrt(2)".into(),
                    result: "1.4142135624".into(),
                },
                HistoryEntry {
                    expr: "5!".into(),
                    result: "120".into(),
                },
                HistoryEntry {
                    expr: "log(2,1024)".into(),
                    result: "10".into(),
                },
                HistoryEntry {
                    expr: "2^10".into(),
                    result: "1024".into(),
                },
            ],
            funcs: vec![
                PlotFn {
                    expr: "(x^2+1)/(x-3)".into(),
                    visible: true,
                },
                PlotFn {
                    expr: "0.25*x^2-2".into(),
                    visible: true,
                },
                PlotFn {
                    expr: "sqrt(x+6)".into(),
                    visible: true,
                },
                PlotFn {
                    expr: "sin(x)".into(),
                    visible: true,
                },
            ],
            active_fn: 0,
            // A lived-in 3D surface list — several `z = f(x, y)` sheets at
            // different heights so the Graph 3D shot shows multiple, distinctly
            // coloured surfaces (not a lone surface).
            surfaces: vec![
                PlotFn {
                    expr: DEFAULT_SURFACE.to_string(),
                    visible: true,
                },
                PlotFn {
                    expr: "0.05*(x^2+y^2)-3".into(),
                    visible: true,
                },
                PlotFn {
                    expr: "3-0.06*(x^2+y^2)".into(),
                    visible: true,
                },
            ],
            active_surface: 0,
            ..CalcModel::default()
        };
        // The headless screenshot picks which tab it captures via this hook;
        // unset (the live default) keeps the lived-in Graph 2D launch view.
        if let Some(want) = std::env::var_os("QOS_CALC_MODE") {
            m.mode = match want.to_string_lossy().as_ref() {
                "calc" | "calculator" => Mode::Calc,
                "graph3d" | "3d" => Mode::Graph3d,
                _ => Mode::Graph2d,
            };
        }
        // Shot-only: a single long function so the headless screenshot can show
        // a formula that overflows the fixed-height field and scrolls within it
        // (caret kept in view at the end) rather than resizing the row.
        if std::env::var_os("QOS_CALC_LONG_DEMO").is_some() {
            m.mode = Mode::Graph2d;
            m.funcs = vec![PlotFn {
                expr: "sin(x)+cos(2*x)+sin(3*x)+cos(4*x)+sin(5*x)+cos(6*x)+sin(7*x)".into(),
                visible: true,
            }];
            m.active_fn = 0;
        }
        // Screenshot-only: exercise the visible, truthful parse-error state.
        // The live app never injects this expression.
        if std::env::var_os("QOS_CALC_ERROR_DEMO").is_some() {
            m.apply_error_demo();
        }
        m
    }

    /// Configure the deterministic invalid-expression frame used only by the
    /// headless visual-review hook. Keeping it as a pure transition makes the
    /// fixture testable without changing global process environment.
    fn apply_error_demo(&mut self) {
        self.mode = Mode::Calc;
        self.expr = "sqrt(".into();
        self.after_equals = false;
    }

    /// Evaluation context derived from the current model.
    pub fn ctx(&self) -> Ctx {
        Ctx {
            deg: self.deg,
            ans: self.ans,
            mem: self.memory,
            ..Default::default()
        }
    }

    /// Live preview of the current expression (grey under the input).
    pub fn preview(&self) -> Option<String> {
        if self.expr.trim().is_empty() {
            return None;
        }
        engine::evaluate(&self.expr, &self.ctx())
            .ok()
            .map(engine::format_number)
    }

    /// Commit `=`: evaluate, push history, update Ans. Returns the committed
    /// [`HistoryEntry`] (a clone) so the caller can dispatch the matching
    /// [`CommitHistory`](crate::actions::CalculatorAction) action — the shared,
    /// replayable, undoable path the history list is mutated through. Returns
    /// `None` when there is nothing to commit (empty or unparseable expression),
    /// so no action is dispatched.
    pub fn commit_equals(&mut self) -> Option<HistoryEntry> {
        let trimmed = self.expr.trim().to_string();
        if trimmed.is_empty() {
            return None;
        }
        if let Ok(v) = engine::evaluate(&trimmed, &self.ctx()) {
            let result = engine::format_number(v);
            let entry = HistoryEntry {
                expr: trimmed,
                result: result.clone(),
            };
            self.history.insert(0, entry.clone());
            self.history.truncate(64);
            self.ans = v;
            self.expr = result;
            self.after_equals = true;
            Some(entry)
        } else {
            // Leave the expression intact; the result line shows the error.
            self.after_equals = false;
            None
        }
    }

    /// The currently-active 2D function expression, if any.
    pub fn active_expr(&self) -> Option<&str> {
        self.funcs.get(self.active_fn).map(|f| f.expr.as_str())
    }
}

/// A pressable key on the calculator pad.
#[derive(Clone, Debug)]
pub enum Key {
    Digit(char),
    Dot,
    DoubleZero,
    /// Insert a raw ASCII fragment at the caret (operators, `(`, `sin(`…).
    Ins(&'static str),
    /// Apply a unary wrap to the whole current expression.
    Wrap(&'static str, &'static str),
    Percent,
    ToggleSign,
    Equals,
    Clear,
    Backspace,
    Ans,
    MemAdd,
    MemSub,
    MemRecall,
    MemClear,
}

impl Key {
    /// Glyph shown on the keycap.
    pub fn label(&self) -> &'static str {
        match self {
            Key::Digit('0') => "0",
            Key::Digit('1') => "1",
            Key::Digit('2') => "2",
            Key::Digit('3') => "3",
            Key::Digit('4') => "4",
            Key::Digit('5') => "5",
            Key::Digit('6') => "6",
            Key::Digit('7') => "7",
            Key::Digit('8') => "8",
            Key::Digit('9') => "9",
            Key::Digit(_) => "?",
            Key::Dot => ".",
            Key::DoubleZero => "00",
            Key::Percent => "%",
            Key::ToggleSign => "±",
            Key::Equals => "=",
            Key::Clear => "AC",
            Key::Backspace => "⌫",
            Key::Ans => "ans",
            Key::MemAdd => "M+",
            Key::MemSub => "M−",
            Key::MemRecall => "MR",
            Key::MemClear => "MC",
            Key::Wrap(_, _) => "x²",
            Key::Ins(s) => match *s {
                "+" => "+",
                "-" => "−",
                "*" => "×",
                "/" => "÷",
                "^" => "xʸ",
                "(" => "(",
                ")" => ")",
                "," => ",",
                "sin(" => "sin",
                "cos(" => "cos",
                "tan(" => "tan",
                "asin(" => "asin",
                "acos(" => "acos",
                "atan(" => "atan",
                "ln(" => "ln",
                "log10(" => "log",
                "sqrt(" => "√",
                "exp(" => "eˣ",
                "1/(" => "1/x",
                "pi" => "π",
                "e" => "e",
                "mod(" => "mod",
                _ => s,
            },
        }
    }

    /// Visual category → keycap tint family.
    pub fn role(&self) -> KeyRole {
        match self {
            Key::Digit(_) | Key::Dot | Key::DoubleZero => KeyRole::Digit,
            Key::Equals => KeyRole::Accent,
            Key::Clear | Key::Backspace => KeyRole::Warm,
            Key::Ins("+" | "-" | "*" | "/") => KeyRole::Operator,
            _ => KeyRole::Function,
        }
    }
}

/// Tint family for a keycap, resolved against the theme at draw time.
#[derive(Clone, Copy, PartialEq, Eq)]
pub enum KeyRole {
    Digit,
    Operator,
    Function,
    Accent,
    Warm,
}

/// The full 6-column scientific keypad. Kept for back-compat and used by the
/// [`KeypadLayout::Scientific`] variant. Row-major; cells are dense.
pub const KEYPAD_COLS: usize = 6;

pub fn keypad() -> Vec<Key> {
    KeypadLayout::Scientific.keys()
}

/// How dense the on-screen keypad is, chosen from the available body area so
/// the calculator stays usable from a phone-narrow strip up to a wide window.
///
/// The layouts are strictly nested supersets — every key on a smaller layout
/// is also present (in the same relative place) on a larger one — so the pad
/// grows extra columns/rows of functions outward as the window widens without
/// the core number pad ever jumping around. A "quick calculation" user always
/// sees the digits, the four basic operators, `=`, `AC` and `⌫` in the same
/// spot regardless of size, so responsiveness never gets in the way.
#[derive(Clone, Copy, PartialEq, Eq, Debug)]
pub enum KeypadLayout {
    /// Phone-narrow: a 4-column essentials pad (digits, `+ − × ÷`, `=`, a few
    /// staples). No scientific column.
    Compact,
    /// Default desktop: 5 columns — essentials plus the common scientific keys
    /// (trig, powers, roots, π/e).
    Standard,
    /// Wide window: the full 6-column scientific pad with every function key.
    Scientific,
}

impl KeypadLayout {
    /// Choose a layout from the available keypad area `width` (in logical px).
    /// The breakpoints are by width because the pad grows horizontally; the
    /// thresholds bake in the per-column width the keys need to stay tappable.
    ///
    /// * `< 460 px`  → [`Compact`](Self::Compact)
    /// * `< 680 px`  → [`Standard`](Self::Standard)
    /// * `>= 680 px` → [`Scientific`](Self::Scientific)
    pub fn for_width(width: f64) -> Self {
        if width < 460.0 {
            KeypadLayout::Compact
        } else if width < 680.0 {
            KeypadLayout::Standard
        } else {
            KeypadLayout::Scientific
        }
    }

    /// Columns in this layout's grid.
    pub fn cols(self) -> usize {
        match self {
            KeypadLayout::Compact => 4,
            KeypadLayout::Standard => 5,
            KeypadLayout::Scientific => 6,
        }
    }

    /// The row-major key list for this layout. Each layout is a dense grid of
    /// `cols()` columns.
    pub fn keys(self) -> Vec<Key> {
        match self {
            KeypadLayout::Compact => Self::compact_keys(),
            KeypadLayout::Standard => Self::standard_keys(),
            KeypadLayout::Scientific => Self::scientific_keys(),
        }
    }

    /// 4 cols × 6 rows — the everyday essentials.
    fn compact_keys() -> Vec<Key> {
        use Key::{Backspace, Clear, Digit, Dot, Equals, Ins};
        vec![
            Clear,
            Backspace,
            Ins("("),
            Ins(")"),
            Ins("sin("),
            Ins("cos("),
            Ins("^"),
            Ins("sqrt("),
            Digit('7'),
            Digit('8'),
            Digit('9'),
            Ins("/"),
            Digit('4'),
            Digit('5'),
            Digit('6'),
            Ins("*"),
            Digit('1'),
            Digit('2'),
            Digit('3'),
            Ins("-"),
            Digit('0'),
            Dot,
            Equals,
            Ins("+"),
        ]
    }

    /// 5 cols × 7 rows — essentials + common scientific keys.
    fn standard_keys() -> Vec<Key> {
        use Key::{
            Ans, Backspace, Clear, Digit, Dot, DoubleZero, Equals, Ins, Percent, ToggleSign, Wrap,
        };
        vec![
            Clear,
            Backspace,
            Ins("("),
            Ins(")"),
            Ins("!"),
            Ins("sin("),
            Ins("cos("),
            Ins("tan("),
            Ins("pi"),
            Ins("e"),
            Ins("ln("),
            Ins("^"),
            Ins("sqrt("),
            Percent,
            Ins("/"),
            Wrap("(", ")^2"),
            Ins("1/("),
            Digit('7'),
            Digit('8'),
            Digit('9'),
            Ins("*"),
            ToggleSign,
            Digit('4'),
            Digit('5'),
            Digit('6'),
            Ins("-"),
            Ans,
            Digit('1'),
            Digit('2'),
            Digit('3'),
            Ins("+"),
            DoubleZero,
            Digit('0'),
            Dot,
            Equals,
        ]
    }

    /// 6 cols × 7 rows — the full scientific pad.
    fn scientific_keys() -> Vec<Key> {
        use Key::{
            Ans, Backspace, Clear, Digit, Dot, DoubleZero, Equals, Ins, Percent, ToggleSign, Wrap,
        };
        vec![
            Clear,
            Backspace,
            Ins("("),
            Ins(")"),
            Ins("mod("),
            Ins("!"),
            Ins("sin("),
            Ins("cos("),
            Ins("tan("),
            Ins("pi"),
            Ins("e"),
            Percent,
            Ins("asin("),
            Ins("acos("),
            Ins("atan("),
            Ins("^"),
            Ins("sqrt("),
            Ins("/"),
            Ins("ln("),
            Ins("log10("),
            Digit('7'),
            Digit('8'),
            Digit('9'),
            Ins("*"),
            Ins("exp("),
            Ins("1/("),
            Digit('4'),
            Digit('5'),
            Digit('6'),
            Ins("-"),
            Wrap("(", ")^2"),
            ToggleSign,
            Digit('1'),
            Digit('2'),
            Digit('3'),
            Ins("+"),
            DoubleZero,
            Ans,
            Digit('0'),
            Dot,
            Ins(","),
            Equals,
        ]
    }
}

/// Apply a key press to the model (calculator mode).
pub fn apply_key(m: &mut CalcModel, key: &Key) {
    match key {
        Key::Clear => {
            m.expr.clear();
            m.after_equals = false;
        }
        Key::Backspace => {
            m.after_equals = false;
            // Pop one token-ish chunk: a trailing `name(` deletes whole.
            pop_token(&mut m.expr);
        }
        Key::Equals => {
            m.commit_equals();
        }
        Key::ToggleSign => {
            if m.expr.trim().is_empty() {
                m.expr = "-".into();
            } else if m.expr.starts_with('-') {
                m.expr.remove(0);
            } else {
                m.expr = format!("-({})", m.expr);
            }
            m.after_equals = false;
        }
        Key::Percent => {
            m.expr.push('%');
            m.after_equals = false;
        }
        Key::Ans => start_value(m, "ans"),
        Key::Digit(c) => {
            let s = c.to_string();
            start_value(m, &s);
        }
        Key::Dot => start_value(m, "."),
        Key::DoubleZero => start_value(m, "00"),
        Key::Ins(s) => {
            // Operators + postfix/closers continue from a committed result;
            // value-starters (`(`, `sin(`, `pi`, …) begin fresh after `=`.
            let continues = matches!(*s, "+" | "-" | "*" | "/" | "^" | "!" | ")" | ",");
            if continues {
                m.after_equals = false;
                m.expr.push_str(s);
            } else {
                start_value(m, s);
            }
        }
        Key::Wrap(pre, post) => {
            if m.expr.trim().is_empty() {
                // Nothing to wrap.
            } else {
                m.expr = format!("{pre}{}{post}", m.expr);
            }
            m.after_equals = false;
        }
        Key::MemAdd => {
            if let Ok(v) = engine::evaluate(&m.expr, &m.ctx()) {
                m.memory += v;
            }
        }
        Key::MemSub => {
            if let Ok(v) = engine::evaluate(&m.expr, &m.ctx()) {
                m.memory -= v;
            }
        }
        Key::MemRecall => start_value(m, &engine::format_number(m.memory)),
        Key::MemClear => m.memory = 0.0,
    }
}

/// Route a typed character through the calculator (keyboard entry).
pub fn type_char(m: &mut CalcModel, ch: char) {
    match ch {
        '0'..='9' => apply_key(m, &Key::Digit(ch)),
        '.' => apply_key(m, &Key::Dot),
        '+' => apply_key(m, &Key::Ins("+")),
        '-' => apply_key(m, &Key::Ins("-")),
        '*' => apply_key(m, &Key::Ins("*")),
        '/' => apply_key(m, &Key::Ins("/")),
        '^' => apply_key(m, &Key::Ins("^")),
        '(' => apply_key(m, &Key::Ins("(")),
        ')' => apply_key(m, &Key::Ins(")")),
        ',' => apply_key(m, &Key::Ins(",")),
        '!' => apply_key(m, &Key::Ins("!")),
        '%' => apply_key(m, &Key::Percent),
        '=' => apply_key(m, &Key::Equals),
        c if c.is_ascii_alphabetic() => start_value(m, &c.to_ascii_lowercase().to_string()),
        _ => {}
    }
}

/// Insert a "value" fragment, clearing a just-committed result first.
fn start_value(m: &mut CalcModel, s: &str) {
    if m.after_equals {
        m.expr.clear();
        m.after_equals = false;
    }
    m.expr.push_str(s);
}

/// Delete one trailing logical token from `expr`.
fn pop_token(expr: &mut String) {
    if expr.is_empty() {
        return;
    }
    // If it ends with `name(`, drop the whole identifier + paren.
    if expr.ends_with('(') {
        expr.pop();
        while let Some(c) = expr.chars().last() {
            if c.is_ascii_alphanumeric() || c == '_' {
                expr.pop();
            } else {
                break;
            }
        }
        return;
    }
    expr.pop();
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    #[allow(
        clippy::float_cmp,
        reason = "2+3 is exactly 5 in f64; an approximate compare would stop \
                  proving that `=` stores the evaluated value verbatim"
    )]
    fn equals_pushes_history_and_sets_ans() {
        let mut m = CalcModel {
            expr: "2+3".into(),
            ..CalcModel::default()
        };
        m.commit_equals();
        assert_eq!(m.ans, 5.0);
        assert_eq!(m.history[0].result, "5");
        assert_eq!(m.expr, "5");
        assert!(m.after_equals);
    }

    #[test]
    fn digit_after_equals_starts_fresh() {
        let mut m = CalcModel {
            expr: "5".into(),
            after_equals: true,
            ..CalcModel::default()
        };
        apply_key(&mut m, &Key::Digit('7'));
        assert_eq!(m.expr, "7");
    }

    #[test]
    fn operator_after_equals_continues() {
        let mut m = CalcModel {
            expr: "5".into(),
            after_equals: true,
            ..CalcModel::default()
        };
        apply_key(&mut m, &Key::Ins("+"));
        assert_eq!(m.expr, "5+");
    }

    #[test]
    fn error_demo_is_calc_only_and_guarantees_a_renderable_parse_error() {
        let mut m = CalcModel::seeded();
        m.after_equals = true;
        m.apply_error_demo();

        assert_eq!(m.mode, Mode::Calc);
        assert_eq!(m.expr, "sqrt(");
        assert!(!m.after_equals);
        assert!(engine::evaluate(&m.expr, &m.ctx()).is_err());
    }

    #[test]
    fn backspace_drops_function_name() {
        let mut m = CalcModel {
            expr: "2+sin(".into(),
            ..CalcModel::default()
        };
        apply_key(&mut m, &Key::Backspace);
        assert_eq!(m.expr, "2+");
    }

    #[test]
    #[allow(
        clippy::float_cmp,
        reason = "10 + 10 is exact in f64; the point of the test is the exact \
                  accumulated total"
    )]
    fn memory_add_accumulates() {
        let mut m = CalcModel {
            expr: "10".into(),
            ..CalcModel::default()
        };
        apply_key(&mut m, &Key::MemAdd);
        apply_key(&mut m, &Key::MemAdd);
        assert_eq!(m.memory, 20.0);
    }

    #[test]
    fn keypad_is_full_grid() {
        assert_eq!(keypad().len() % KEYPAD_COLS, 0);
    }

    #[test]
    fn every_keypad_layout_is_a_dense_grid() {
        for layout in [
            KeypadLayout::Compact,
            KeypadLayout::Standard,
            KeypadLayout::Scientific,
        ] {
            assert_eq!(
                layout.keys().len() % layout.cols(),
                0,
                "{layout:?} keys must tile its column count exactly"
            );
        }
    }

    #[test]
    fn keypad_breakpoints_pick_expected_layout() {
        assert_eq!(KeypadLayout::for_width(380.0), KeypadLayout::Compact);
        assert_eq!(KeypadLayout::for_width(560.0), KeypadLayout::Standard);
        assert_eq!(KeypadLayout::for_width(900.0), KeypadLayout::Scientific);
        // wider layouts have at least as many columns
        assert!(KeypadLayout::Compact.cols() < KeypadLayout::Standard.cols());
        assert!(KeypadLayout::Standard.cols() < KeypadLayout::Scientific.cols());
    }

    #[test]
    fn every_layout_keeps_the_quick_calc_essentials() {
        // A "quick calculation" user must always find the digits, the four
        // basic operators and `=` regardless of breakpoint.
        for layout in [
            KeypadLayout::Compact,
            KeypadLayout::Standard,
            KeypadLayout::Scientific,
        ] {
            let keys = layout.keys();
            for d in '0'..='9' {
                assert!(
                    keys.iter().any(|k| matches!(k, Key::Digit(c) if *c == d)),
                    "{layout:?} missing digit {d}"
                );
            }
            for op in ["+", "-", "*", "/"] {
                assert!(
                    keys.iter().any(|k| matches!(k, Key::Ins(s) if *s == op)),
                    "{layout:?} missing operator {op}"
                );
            }
            assert!(
                keys.iter().any(|k| matches!(k, Key::Equals)),
                "{layout:?} missing ="
            );
            assert!(
                keys.iter().any(|k| matches!(k, Key::Clear)),
                "{layout:?} missing AC"
            );
            assert!(
                keys.iter().any(|k| matches!(k, Key::Backspace)),
                "{layout:?} missing ⌫"
            );
        }
    }
}
