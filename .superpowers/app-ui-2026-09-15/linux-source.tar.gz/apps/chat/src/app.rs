//! Root widget for the chat app.
//!
//! [`ChatApp`] owns the CRDT-derived snapshot (workspaces / channels /
//! users / messages / drafts), the per-peer view state (active channel,
//! open thread, call state, composer caret), and one real
//! [`ui::widget::VideoPlayer`] used as the host call tile. It does its own
//! manual layout: the five regions (workspace rail, channel sidebar,
//! channel header, message timeline, composer) plus floating layers
//! (thread panel, emoji picker, edit-history popover, call huddle /
//! expanded overlay) are computed from `self.rect` each frame, and every
//! clickable area is recorded into `self.hits` for the next event.
//!
//! Convergent state lives in the Automerge document; this widget is a
//! projection + an input router, in keeping with the toolkit's
//! "state lives in the CRDT" contract.

use std::collections::{HashMap, HashSet};
use std::sync::mpsc::{Receiver, SyncSender};

use automerge::{AutoCommit, ObjId};
use taffy::style_helpers::percent;
use taffy::{LengthPercentageAuto, NodeId, Position, Size, Style, TaffyTree};
use vello::Scene;
use vello::kurbo::{Affine, Point, Rect};
use winit::event::WindowEvent;

use ui::ColorCompat;
use ui::Widget;
use ui::permissions::PermissionContext;
use ui::presence::PresenceCtx;
use ui::text_render::TextRenderer;
use ui::theme::Theme;
use ui::widget::{TextInput, TooltipHost, VideoPlayer};

use crate::actions::{self, ChatAction};
use crate::call::{CallState, SoundEngine};
use crate::doc::ChatDoc;
use crate::identity::LocalIdentity;
use crate::media::MediaEngine;
use crate::model::{self, Channel, Id, Message, User, Workspace};
use crate::permissions::ChatPermissions;
use crate::responsive::{FlapMode, FlapState, LEFT_BREAKPOINT, RIGHT_BREAKPOINT};

// --- Fixed chrome metrics (logical px) ------------------------------------
pub(crate) const RAIL_W: f64 = 68.0;
pub(crate) const SIDE_W: f64 = 248.0;
pub(crate) const HEADER_H: f64 = 60.0;
pub(crate) const THREAD_W: f64 = 360.0;
pub(crate) const COMPOSER_MIN_H: f64 = 76.0;
pub(crate) const COMPOSER_MAX_H: f64 = 200.0;
pub(crate) const AVATAR: f64 = 40.0;

// --- Floating call huddle home placement (fractions of the window) --------
// The docked huddle's resting video rect before the user drags it. The
// VideoPlayer's taffy node and the surrounding chrome derive from this so
// they stay aligned; the drag offset is applied on top in `apply_layout`.
// (The expanded overlay instead tiles the host into a responsive grid — see
// `overlay_tiles` — so it has no fixed fraction.)
pub(crate) const HUDDLE_VIDEO: (f64, f64, f64, f64) = (0.505, 0.300, 0.250, 0.230);

/// Which composer currently owns keystrokes.
#[derive(Clone, Copy, Debug, PartialEq, Eq)]
pub(crate) enum Focus {
    Main,
    Thread,
}

/// A right-click context menu over a channel or category row, or the
/// inline rename editor it can open.
#[derive(Clone, Debug)]
pub(crate) struct ContextMenu {
    pub target: MenuTarget,
    pub anchor: Point,
    pub items: Vec<MenuAction>,
}

/// What a context menu / create flow acts on.
#[derive(Clone, Debug, PartialEq, Eq)]
pub(crate) enum MenuTarget {
    Channel(Id),
    Category(Id),
    /// One of your own messages — the action menu offers Edit.
    Message(Id),
    /// The workspace background / the sidebar's "+" — create affordances.
    #[allow(
        dead_code,
        reason = "legacy CRDT scope selection remains testable for wire compatibility; production navigation uses Inbox and CurrentContext"
    )]
    Workspace(Id),
}

/// The structural actions reachable from a context menu. The **first**
/// channel action is also what a left-swipe on the row resolves to, so the
/// gesture and the menu can never drift (swipe⇔menu parity).
#[derive(Clone, Copy, Debug, PartialEq, Eq)]
pub(crate) enum MenuAction {
    Rename,
    Delete,
    MoveUp,
    MoveDown,
    NewChannelHere,
    NewVoiceChannelHere,
    NewCategory,
    ToggleCollapse,
    /// Archive / unarchive a channel — hides it from the sidebar (reversible
    /// from Ctrl+K). Dispatches [`ChatAction::ArchiveChannel`](crate::actions::ChatAction).
    Archive,
    /// Load one of your own messages into the inline editor.
    EditMessage,
    /// Pin / unpin one of your own messages (shared truth every peer sees).
    PinMessage,
    /// Delete one of your own messages.
    DeleteMessage,
}

impl MenuAction {
    pub fn label(self) -> &'static str {
        match self {
            MenuAction::Rename => "Rename",
            MenuAction::Delete => "Delete",
            MenuAction::MoveUp => "Move up",
            MenuAction::MoveDown => "Move down",
            MenuAction::NewChannelHere => "New text channel",
            MenuAction::NewVoiceChannelHere => "New voice channel",
            MenuAction::NewCategory => "New category",
            MenuAction::ToggleCollapse => "Collapse / expand",
            MenuAction::Archive => "Archive / unarchive",
            MenuAction::EditMessage => "Edit message",
            MenuAction::PinMessage => "Pin / unpin",
            MenuAction::DeleteMessage => "Delete message",
        }
    }
    pub fn is_destructive(self) -> bool {
        matches!(self, MenuAction::Delete | MenuAction::DeleteMessage)
    }
    /// Menu items for a channel row, in order. The first (`Delete`) is the
    /// swipe-left action.
    pub fn for_channel() -> [MenuAction; 5] {
        [
            MenuAction::Delete,
            MenuAction::Archive,
            MenuAction::Rename,
            MenuAction::MoveUp,
            MenuAction::MoveDown,
        ]
    }
    /// Menu items for a category row.
    pub fn for_category() -> [MenuAction; 5] {
        [
            MenuAction::NewChannelHere,
            MenuAction::NewVoiceChannelHere,
            MenuAction::Rename,
            MenuAction::ToggleCollapse,
            MenuAction::Delete,
        ]
    }
    /// The action a swipe-left on a channel row resolves to.
    pub fn channel_swipe_left() -> MenuAction {
        Self::for_channel()[0]
    }
    /// Menu items for one of your own messages.
    pub fn for_message() -> [MenuAction; 3] {
        [
            MenuAction::EditMessage,
            MenuAction::PinMessage,
            MenuAction::DeleteMessage,
        ]
    }
}

/// An in-progress swipe on a channel row (mirrors the context-menu primary
/// action on release).
#[derive(Clone, Copy, Debug)]
pub(crate) struct RowSwipe {
    pub channel_index: usize,
    pub origin: Point,
    pub current: Point,
}

/// The bounded worker's result. File I/O and header sniffing happen before
/// this crosses back to the UI thread; the only UI-thread write is the
/// canonical qdoc descriptor + `SendMessage` action in `sync`.
pub(crate) enum AttachmentImportResult {
    Ready {
        token: u64,
        name: String,
        blob: String,
        size: u64,
        width: u32,
        height: u32,
        video: bool,
    },
    Failed {
        token: u64,
        reason: String,
    },
}

/// The picker enumerates files off-thread too: even metadata on a mounted or
/// hostile workspace must not stall the composer click.
pub(crate) enum AttachmentPickerResult {
    Ready {
        generation: u64,
        entries: Vec<crate::picker::PickEntry>,
    },
    Failed {
        generation: u64,
        reason: String,
    },
}

#[derive(Clone, Debug)]
pub(crate) struct AttachmentImportPending {
    pub token: u64,
    pub channel: Id,
    pub author: Id,
}

impl RowSwipe {
    pub fn dx(&self) -> f64 {
        (self.origin.x - self.current.x).max(0.0)
    }
}

/// Leftward travel (px) past which a row swipe commits its delete action.
pub(crate) const SWIPE_COMMIT_DX: f64 = 88.0;

/// Everything the user can click. Recorded during `draw`, resolved on the
/// next mouse-press.
#[derive(Clone, Debug)]
pub(crate) enum Hit {
    /// Open the cross-workspace conversation inbox. This is navigation, not a
    /// second kind of qOS workspace.
    Inbox,
    /// Return from Inbox to channels belonging to the active qOS workspace.
    CurrentContext,
    Channel(Id),
    /// A voice-channel member chip in the sidebar — clicking joins the call.
    VoiceChannel(Id),
    /// Toggle a category's collapsed state.
    CategoryToggle(Id),
    /// Execute a context-menu / create action.
    MenuAction {
        target: MenuTarget,
        action: MenuAction,
    },
    /// The "+" create-channel button on a category header.
    AddChannel {
        workspace: Id,
        category: Id,
    },
    /// The "+" create-category button in the sidebar header.
    AddCategory(Id),
    /// Focus/place the caret in the inline structural rename field.
    FocusRename,
    Reaction {
        msg: Id,
        emoji: String,
    },
    AddReaction {
        msg: Id,
        anchor: Point,
    },
    OpenThread(Id),
    EditHistory {
        msg: Id,
        anchor: Point,
    },
    /// Right-click target over one of your own messages — opens the message
    /// action menu (Edit). Left-click on it is a no-op.
    MessageMenu {
        msg: Id,
    },
    /// Commit the inline message editor to the CRDT.
    EditSave,
    /// Discard the inline message editor without writing.
    EditCancel,
    /// Focus/place the caret in the inline message editor.
    FocusEdit,
    EmojiChoice(String),
    FocusMain,
    FocusThread,
    Send,
    ComposerEmoji(Point),
    /// Open the workspace file picker to share an attachment.
    Attach,
    /// Pick a specific file (by path) from the open attachment picker.
    AttachPick(String),
    StartCall,
    CloseThread,
    /// Grab the floating call overlay to drag it (records the press point).
    CallDragHandle,
    /// Toggle the participant list expand/collapse in the overlay.
    CallParticipantsToggle,
    CallMute,
    CallDeafen,
    CallAudioOnly,
    /// Internal start/stop seam for a restored or remote-mediated screen
    /// share. The shipped call chrome does not expose it until production has
    /// a real `PipeWire` capture producer.
    #[allow(
        dead_code,
        reason = "kept for defensive stop handling and the tested screen-share transport seam"
    )]
    CallShareScreen,
    CallExpand,
    CallLeave,
    /// Toggle the left flap (rail + channel sidebar).
    ToggleLeftFlap,
    /// Toggle the right flap (members / thread).
    ToggleRightFlap,
    Dismiss, // click on a scrim closes the top-most popover
}

impl Hit {
    pub(crate) fn semantic_id(&self) -> String {
        match self {
            Self::Inbox => "chat.inbox".into(),
            Self::CurrentContext => "chat.current-context".into(),
            Self::Channel(id) => format!("chat.channel:{id}"),
            Self::VoiceChannel(id) => format!("chat.voice-channel:{id}"),
            Self::CategoryToggle(id) => format!("chat.category-toggle:{id}"),
            Self::AddChannel {
                workspace,
                category,
            } => format!("chat.add-channel:{workspace}:{category}"),
            Self::AddCategory(id) => format!("chat.add-category:{id}"),
            Self::FocusMain => "chat.composer".into(),
            Self::FocusThread => "chat.thread-composer".into(),
            Self::FocusRename => "chat.rename".into(),
            Self::FocusEdit => "chat.message-edit".into(),
            Self::Send => "chat.send".into(),
            Self::ComposerEmoji(_) => "chat.composer-emoji".into(),
            Self::Attach => "chat.attach".into(),
            Self::AttachPick(path) => format!("chat.attach-pick:{path}"),
            Self::StartCall => "chat.start-call".into(),
            Self::ToggleLeftFlap => "chat.toggle-navigation".into(),
            Self::ToggleRightFlap => "chat.toggle-details".into(),
            Self::OpenThread(id) => format!("chat.open-thread:{id}"),
            Self::CloseThread => "chat.close-thread".into(),
            Self::Reaction { msg, emoji } => format!("chat.reaction:{msg}:{emoji}"),
            Self::AddReaction { msg, .. } => format!("chat.add-reaction:{msg}"),
            Self::EmojiChoice(emoji) => format!("chat.emoji-choice:{emoji}"),
            Self::EditHistory { msg, .. } => format!("chat.edit-history:{msg}"),
            Self::EditSave => "chat.edit-save".into(),
            Self::EditCancel => "chat.edit-cancel".into(),
            Self::CallMute => "chat.call-mute".into(),
            Self::CallDeafen => "chat.call-deafen".into(),
            Self::CallAudioOnly => "chat.call-audio-only".into(),
            Self::CallShareScreen => "chat.call-share-screen".into(),
            Self::CallParticipantsToggle => "chat.call-participants".into(),
            Self::CallExpand => "chat.call-expand".into(),
            Self::CallLeave => "chat.call-leave".into(),
            other => format!("chat.control:{other:?}"),
        }
    }
}

/// One sampled motion value owns the call huddle's participant reveal. The
/// panel silhouette, controls, hit regions, compositor presentation and native
/// window allocation all read this same value, so a content-driven resize can
/// never leave those layers a frame apart.
#[derive(Debug)]
pub(crate) struct CallChromeMotion {
    transition: ui::Transition,
    target_open: bool,
    initialized: bool,
    pub(crate) sampled: f32,
    pub(crate) animating: bool,
    /// Deterministic visual-review hook; production leaves this `None`.
    pinned: Option<f32>,
}

impl Default for CallChromeMotion {
    fn default() -> Self {
        Self {
            transition: ui::Transition::open(),
            target_open: true,
            initialized: false,
            sampled: 1.0,
            animating: false,
            pinned: None,
        }
    }
}

impl CallChromeMotion {
    pub(crate) fn reconcile(&mut self, open: bool, theme: &Theme) {
        if let Some(value) = self.pinned {
            self.sampled = value;
            self.animating = false;
            return;
        }
        if !self.initialized {
            self.transition = if open {
                ui::Transition::open()
            } else {
                ui::Transition::closed()
            };
            self.target_open = open;
            self.initialized = true;
        } else if open != self.target_open {
            let spring = theme.tokens.motion.springs.subtle;
            self.transition.set_open(
                open,
                if theme.reduce_motion {
                    std::time::Duration::ZERO
                } else {
                    theme.tokens.motion.durations.base()
                },
                ui::Curve::Spring {
                    stiffness: spring.stiffness,
                    damping: spring.damping,
                    mass: spring.mass,
                },
            );
            self.target_open = open;
        }
        let now = std::time::Instant::now();
        self.sampled = self.transition.value(now);
        self.animating = self.transition.is_animating(now);
    }

    pub(crate) fn reset(&mut self) {
        if self.pinned.is_none() {
            self.initialized = false;
            self.animating = false;
        }
    }

    pub(crate) fn pin_for_visual_review(&mut self, value: f32) {
        self.pinned = Some(value.clamp(0.0, 1.0));
        self.sampled = self.pinned.unwrap_or(0.0);
        self.animating = false;
    }
}

#[cfg(test)]
mod call_chrome_motion_tests {
    use super::CallChromeMotion;

    #[test]
    fn reduced_motion_snaps_the_same_geometry_driver_to_its_target() {
        let mut motion = CallChromeMotion::default();
        motion.reconcile(true, &ui::theme::Theme::dark());
        motion.reconcile(false, &ui::theme::Theme::dark().with_reduce_motion(true));
        assert_eq!(motion.sampled, 0.0);
        assert!(!motion.animating);
    }

    #[test]
    fn visual_review_can_pin_a_true_mid_morph_geometry() {
        let mut motion = CallChromeMotion::default();
        motion.pin_for_visual_review(0.5);
        motion.reconcile(false, &ui::theme::Theme::dark());
        assert_eq!(motion.sampled, 0.5);
        assert!(!motion.animating);
    }
}

/// The whole app's mutable state.
#[allow(
    clippy::struct_excessive_bools,
    reason = "the bools split across unrelated concerns (attachment-picker/emoji-popover open flags, layout/render bookkeeping, and --shots-only staging), so grouping them would need a real design pass rather than a mechanical lint fix"
)]
pub struct ChatApp {
    // CRDT projection (rebuilt every sync / after a mutation).
    pub(crate) workspaces: Vec<Workspace>,
    pub(crate) channels: Vec<Channel>,
    pub(crate) categories: Vec<crate::model::Category>,
    /// People evidenced in the active chat workspace: the local person plus
    /// authors, reactors, mentioned people, and voice participants in that
    /// workspace's channels. The backing document's `users` map is a global
    /// directory, so exposing it directly here would make people from another
    /// workspace appear in this workspace's People/call chrome.
    pub(crate) users: Vec<User>,
    pub(crate) messages: Vec<Message>,
    /// Whole-document snapshots used by global search. The visible `messages`
    /// and `users` remain workspace-scoped projections for rendering.
    pub(crate) search_messages: Vec<Message>,
    pub(crate) search_users: Vec<User>,
    /// Voice membership per channel in the active workspace (cached from the
    /// CRDT each reload so the sidebar can show presence without re-reading).
    pub(crate) voice_members: HashMap<Id, Vec<crate::model::VoiceMember>>,
    /// Cached plain text of the focused drafts, mirrored from the composer
    /// widgets each `reload`. Kept only so the composer's auto-grow height
    /// (`composer_height`) and the tests can read the draft without reaching
    /// into the widget; the editable source of truth is the `TextInput`.
    pub(crate) draft_main: String,
    pub(crate) draft_thread: String,

    /// The message composers — shared multiline [`TextInput`]s (Enter sends,
    /// Shift+Enter inserts a newline) so the composer gets real caret,
    /// selection, clipboard (Ctrl+C/V/X), focus ring, a11y, and theming for
    /// free instead of a hand-rolled `String` + caret index. One per surface:
    /// the main timeline and the open thread. Both are local-mode; each
    /// keystroke is written back into the per-channel/thread draft `Text` in
    /// the CRDT (diff-spliced) so a draft stays collaborative + persistent.
    pub(crate) composer_main: TextInput,
    pub(crate) composer_thread: TextInput,

    // Per-peer view state.
    pub(crate) active_ws: Id,
    /// The qOS workspace Chat was opened in. Inbox may temporarily display a
    /// conversation sourced from another workspace; this anchor lets the
    /// person return to their contextual channels without changing OS state.
    pub(crate) context_ws: Id,
    /// Inbox is a cross-workspace navigation surface, deliberately distinct
    /// from the contextual channel list and from the CRDT's legacy grouping.
    pub(crate) inbox_open: bool,
    pub(crate) active_channel: Id,
    pub(crate) focus: Focus,
    pub(crate) scroll: f64,
    pub(crate) thread_open: Option<Id>,
    pub(crate) revealed_message: Option<Id>,
    pub(crate) revealed_person: Option<Id>,
    pub(crate) emoji_open: bool,
    pub(crate) emoji_target: Option<Id>,
    pub(crate) emoji_anchor: Point,
    pub(crate) history_open: Option<Id>,
    pub(crate) history_anchor: Point,
    /// Your own message currently being edited. The shared multiline input
    /// owns its working text, caret, selection and IME composition until Save
    /// writes through [`ChatDoc::edit_message`].
    pub(crate) editing: Option<Id>,
    pub(crate) edit_input: TextInput,

    // Attachment picker (browses the shared workspace for a file to share).
    pub(crate) attach_open: bool,
    pub(crate) attach_entries: Vec<crate::picker::PickEntry>,
    /// Exactly one import may run at a time. This is a deliberate resource
    /// bound: selecting another file while one is reading is refused rather
    /// than creating unbounded reader threads and byte buffers.
    pub(crate) attachment_pending: Option<AttachmentImportPending>,
    pub(crate) attachment_next_token: u64,
    pub(crate) attachment_result_tx: SyncSender<AttachmentImportResult>,
    pub(crate) attachment_result_rx: Receiver<AttachmentImportResult>,
    /// A settled import outcome for the picker/status UI and accessibility.
    pub(crate) attachment_status: Option<String>,
    pub(crate) attachment_picker_pending: Option<u64>,
    pub(crate) attachment_picker_generation: u64,
    pub(crate) attachment_picker_result_tx: SyncSender<AttachmentPickerResult>,
    pub(crate) attachment_picker_result_rx: Receiver<AttachmentPickerResult>,

    // Structure editing.
    pub(crate) menu: Option<ContextMenu>,
    /// Channel/category currently being renamed. The shared single-line input
    /// owns the transient working name; structural CRDT policy stays here.
    pub(crate) rename: Option<MenuTarget>,
    pub(crate) rename_input: TextInput,
    pub(crate) swipe: Option<RowSwipe>,

    // Call state.
    pub(crate) call: CallState,
    pub(crate) call_chrome_motion: CallChromeMotion,
    pub(crate) pending_floating: Option<ui::floating_surface::FloatingSurfaceRequest>,
    /// Authoritative combined-output bounds supplied by the shell. Standalone
    /// app/test hosts leave this empty and fall back to the app rect.
    pub(crate) floating_surface_bounds: Rect,

    // Responsive flaps.
    pub(crate) left_flap: FlapState,
    pub(crate) right_flap: FlapState,
    pub(crate) left_mode: FlapMode,
    pub(crate) right_mode: FlapMode,

    // The local peer's identity: how this peer authors messages, reactions,
    // voice membership, and its own read watermark in the shared document.
    // Distinct + stable per real peer (see [`crate::identity`]) so genuine
    // multi-participant chat attributes and de-duplicates correctly.
    pub(crate) me: LocalIdentity,

    // The room's answer for who everybody is, refreshed every frame from
    // presence (see `adopt_room`). A peer never writes its own name into
    // this map — only what the room says about a participant lands here.
    pub(crate) room_names: HashMap<Id, String>,
    pub(crate) room_colors: HashMap<Id, (u8, u8, u8)>,

    // Ids this session authored under before the room told it which
    // participant it is. See `adopt_own_participant`: what was already said
    // under one of these is still this person, so their own earlier lines go
    // on reading "You" rather than turning into a stranger mid-scroll.
    pub(crate) former_ids: Vec<Id>,

    // Engines (call sounds + media transport).
    pub(crate) sound: SoundEngine,
    pub(crate) media: MediaEngine,

    // The OS permission gate: routes channel participation + file-embed
    // hydration through the toolkit's permission model. Refreshed from the
    // `PermissionContext` the compositor passes into `draw`.
    pub(crate) perms: ChatPermissions,

    // Framework-owned action dispatch: every doc-mutating affordance (Send, a
    // reaction, the channel/message context menus, the Ctrl+K palette) routes
    // through this one field. It brackets the undo boundary, encodes under
    // `CHAT_ACTION_TYPE`, and applies through the executor so a peer replays the
    // byte-identical change. See [`crate::actions`].
    pub(crate) actions: ui::ActionHost,

    // Persistence (None for ephemeral / `--shots` instances).

    // Background image loader/cache for attachment thumbnails (decodes off
    // the UI thread; real bytes come from the FUSE mount).
    pub(crate) images: ui::ImageStore,

    // Layout + render caches.
    pub(crate) rect: Rect,
    root_node: Option<NodeId>,
    video_node: Option<NodeId>,
    pub(crate) video: VideoPlayer,
    pub(crate) hits: Vec<(Rect, Hit)>,
    /// Ordinal in `keyboard_targets()`. Derived from the current hit inventory
    /// so Tab and assistive focus traverse the same controls a pointer can use.
    pub(crate) keyboard_target: Option<usize>,
    pub(crate) last_mouse: Point,
    /// One shared tooltip controller for Chat's immediate-mode controls. This
    /// gives icon-only buttons and elided header text the same dwell behaviour
    /// as toolkit widgets without allocating a tooltip per hit region.
    pub(crate) tooltips: TooltipHost,
    /// The live call control beneath the pointer. Kept as render-only state so
    /// attached and shell-owned copies share the same hover treatment without
    /// duplicating a second native-window control implementation.
    pub(crate) call_hovered: Option<Hit>,
    relayout: bool,
    /// True while either flap is mid-slide — drives `needs_animation_frame`
    /// so the loop keeps ticking only during the transition, then idles.
    flap_animating: bool,
    /// `--shots` only: seed the real minimal starter instead of the demo, so
    /// the honest first-run empty state can be captured.
    shot_starter: bool,
    /// `--shots` only: a draft to stage into the main composer so a screenshot
    /// can show the composer mid-compose (caret + wrapped text). `None` in every
    /// live/interactive path, so production is unaffected.
    shot_composer_draft: Option<String>,
    /// True for the live binary (`ChatApp::new`). A live instance always seeds
    /// the honest empty starter and never the fabricated demo workspace — even
    /// when nothing is persisting behind it. Only the ephemeral `--shots`/test
    /// instances (`new_ephemeral`) leave this `false` and may stage the rich
    /// demo.
    pub(crate) is_live: bool,

    /// Latest decoded RGBA frame per remote peer id, shown in that peer's call
    /// tile (camera or screen-share). Populated only by the live media pump; in
    /// the default build it stays empty, so a tile shows the honest placeholder
    /// until a real decoded frame arrives — it never fabricates a picture.
    pub(crate) remote_frames: HashMap<String, vello::peniko::ImageData>,

    /// Latest decoded RGBA **screen-share** frame per remote peer id, kept
    /// separate from their camera frame so a peer can share their screen and
    /// keep their camera on at once — the screen fills the featured stage tile,
    /// the camera stays in that peer's filmstrip cell. Populated only by the
    /// live media pump; empty in the default build, where the featured tile
    /// shows the honest "connecting" placeholder rather than a fabricated feed.
    pub(crate) remote_screens: HashMap<String, vello::peniko::ImageData>,

    /// The screen-capture source seam. Consulted before a share starts so the
    /// real xdg-desktop-portal `ScreenCast` flow (behind `live-media`) can be
    /// swapped for an injected fake in tests. The default [`SystemPortal`]
    /// returns `None` in the default build — honest gating, never a faked share.
    pub(crate) portal: Box<dyn crate::call::ScreenPortal>,

    // Live capture/encode/playback pipelines — present only under `live-media`
    // and only while in a call. All `None`/empty until the call opens a device;
    // torn down when the call ends or a device is unavailable (honest silence).
    #[cfg(feature = "live-media")]
    mic: Option<crate::audio::MicCapture>,
    #[cfg(feature = "live-media")]
    speaker: Option<crate::audio::SpeakerPlayback>,
    #[cfg(feature = "live-media")]
    camera: Option<crate::video::CameraCapture>,
    // Camera encode reuses the shared qOS video stack's bare H.264 encoder
    // (raw NALUs: the local self-preview feeds them to `ui`'s VideoPlayer,
    // and they publish as the camera track). No second in-app codec.
    #[cfg(feature = "live-media")]
    cam_encoder: Option<qos_callstream::H264Encoder>,
    #[cfg(feature = "live-media")]
    screen: Option<crate::video::ScreenCapture>,
    // Screen-share encode + framing runs the shared stack's throttle +
    // encoder → `SurfaceFrame` sender seam — the same composition the
    // compositor's `SharedFlatpakSession` performs for a Wayland surface.
    #[cfg(feature = "live-media")]
    screen_session: Option<qos_callstream::VideoStreamSender>,
    // Remote **camera** decoders (raw-NALU H.264 → RGBA), keyed by sender.
    #[cfg(feature = "live-media")]
    remote_decoders: HashMap<String, qos_callstream::H264Decoder>,
    // Remote **screen-share** receivers (reframe + decode) → featured tile,
    // keyed by sender. The receive half of the shared stack.
    #[cfg(feature = "live-media")]
    remote_screen_rx: HashMap<String, qos_callstream::VideoStreamReceiver>,
    /// Highest accepted sequence per remote sender + track. The transport is
    /// deliberately lossy under pressure; rejecting late frames here prevents
    /// a delayed packet from visibly rewinding a peer's camera or screen.
    #[cfg(feature = "live-media")]
    remote_media_seq: HashMap<(String, crate::media::TrackKind), u64>,
    #[cfg(feature = "live-media")]
    media_seq: u64,
    /// Terminal local media-publish outcome. Kept visible until the call is
    /// reset so sequence exhaustion is never an invisible early return.
    pub(crate) media_error: Option<String>,
    /// A capture-side terminal error has changed the share bit outside an
    /// input event. `sync` owns the corresponding small canonical action so
    /// collaborators do not retain a stale featured-stage reservation.
    screen_share_needs_sync: bool,
    legacy_migration_attempted: bool,
}

impl Default for ChatApp {
    fn default() -> Self {
        Self::new()
    }
}

impl ChatApp {
    /// The live instance: resolves this peer's real identity. The document
    /// itself is loaded and written by `app-state` (see `main`), so nothing
    /// here touches disk. The resolved identity is what makes two running
    /// instances genuinely different participants rather than two "`u_me"s`
    /// colliding.
    pub fn new() -> Self {
        let mut app = Self::bare();
        app.is_live = true;
        app.me = LocalIdentity::resolve();
        // The live binary uses the real transport (a bound iroh endpoint on a
        // real session; the simulator otherwise). Tests/`--shots` keep the
        // deterministic local bus from `bare`.
        app.media = MediaEngine::new();
        // Author the local view state under the real identity from the start so
        // nothing is attributed to the demo `u_me`.
        app.active_ws.clear();
        app.context_ws.clear();
        app.active_channel.clear();
        app.thread_open = None;
        app
    }

    /// A non-persistent instance for `--shots` / tests: never reads or
    /// writes disk, so a screenshot run can't clobber a real workspace.
    pub fn new_ephemeral() -> Self {
        Self::bare()
    }

    #[allow(
        clippy::too_many_lines,
        reason = "the complete app state is deliberately initialized together so bounded channels and their lifecycles cannot drift"
    )]
    fn bare() -> Self {
        // The host call tile is a real VideoPlayer with no frame until a live
        // capture feeds one; there is no synthesised stand-in. Its honest
        // "camera off" state is painted over the empty surface.
        let video = VideoPlayer::new();
        let (attachment_result_tx, attachment_result_rx) = std::sync::mpsc::sync_channel(1);
        let (attachment_picker_result_tx, attachment_picker_result_rx) =
            std::sync::mpsc::sync_channel(1);
        Self {
            workspaces: Vec::new(),
            channels: Vec::new(),
            categories: Vec::new(),
            users: Vec::new(),
            messages: Vec::new(),
            search_messages: Vec::new(),
            search_users: Vec::new(),
            voice_members: HashMap::new(),
            draft_main: String::new(),
            draft_thread: String::new(),
            composer_main: Self::new_composer(),
            composer_thread: Self::new_composer(),
            active_ws: "ws_acme".into(),
            context_ws: "ws_acme".into(),
            inbox_open: false,
            active_channel: "c_crit".into(),
            focus: Focus::Main,
            scroll: 0.0,
            thread_open: Some("m_concept".into()),
            revealed_message: None,
            revealed_person: None,
            emoji_open: false,
            emoji_target: None,
            emoji_anchor: Point::ZERO,
            history_open: None,
            history_anchor: Point::ZERO,
            editing: None,
            edit_input: Self::new_message_editor(),
            attach_open: false,
            attach_entries: Vec::new(),
            attachment_pending: None,
            attachment_next_token: 0,
            attachment_result_tx,
            attachment_result_rx,
            attachment_status: None,
            attachment_picker_pending: None,
            attachment_picker_generation: 0,
            attachment_picker_result_tx,
            attachment_picker_result_rx,
            menu: None,
            rename: None,
            rename_input: Self::new_rename_input(),
            swipe: None,
            call: CallState::default(),
            call_chrome_motion: CallChromeMotion::default(),
            pending_floating: None,
            floating_surface_bounds: Rect::ZERO,
            left_flap: FlapState::open_when_docked(),
            right_flap: FlapState::closed_by_default(),
            left_mode: FlapMode::Docked,
            right_mode: FlapMode::Docked,
            me: LocalIdentity::demo(),
            room_names: HashMap::new(),
            room_colors: HashMap::new(),
            former_ids: Vec::new(),
            sound: SoundEngine::new(),
            // Default to the deterministic local bus; the live binary
            // (`ChatApp::new`) upgrades to the real transport. This keeps
            // `--shots`/tests from binding a real iroh endpoint per instance.
            media: MediaEngine::simulated(),
            perms: ChatPermissions::permissive(),
            actions: ui::ActionHost::new(),
            images: ui::ImageStore::new(&crate::images::fetcher()),
            rect: Rect::ZERO,
            root_node: None,
            video_node: None,
            video,
            hits: Vec::new(),
            keyboard_target: None,
            last_mouse: Point::ZERO,
            call_hovered: None,
            tooltips: TooltipHost::new(),
            relayout: false,
            flap_animating: false,
            shot_starter: false,
            shot_composer_draft: None,
            is_live: false,
            remote_frames: HashMap::new(),
            remote_screens: HashMap::new(),
            portal: Box::new(crate::call::SystemPortal),
            #[cfg(feature = "live-media")]
            mic: None,
            #[cfg(feature = "live-media")]
            speaker: None,
            #[cfg(feature = "live-media")]
            camera: None,
            #[cfg(feature = "live-media")]
            cam_encoder: None,
            #[cfg(feature = "live-media")]
            screen: None,
            #[cfg(feature = "live-media")]
            screen_session: None,
            #[cfg(feature = "live-media")]
            remote_decoders: HashMap::new(),
            #[cfg(feature = "live-media")]
            remote_screen_rx: HashMap::new(),
            #[cfg(feature = "live-media")]
            remote_media_seq: HashMap::new(),
            #[cfg(feature = "live-media")]
            media_seq: 0,
            media_error: None,
            screen_share_needs_sync: false,
            legacy_migration_attempted: false,
        }
    }

    /// Whether a call action is permitted, routed through the real OS
    /// permission gate for the active workspace. A View-only / ungranted peer
    /// is blocked from join/speak/camera/screen-share; leaving is always
    /// allowed so a downgraded peer can drop out.
    pub(crate) fn call_allows(&self, action: crate::call::CallAction) -> bool {
        self.perms.allows(action)
    }

    /// Whether the local peer may post / react / start a call in the active
    /// workspace (an Edit grant). The permissive default allows; a restricted
    /// context gates writes while still letting the peer read.
    pub(crate) fn can_participate(&self) -> bool {
        self.perms.can_participate()
    }

    /// Whether the local peer may hydrate + render an attachment blob. An
    /// ungranted embed shows a locked card and never requests shared bytes.
    pub(crate) fn embed_allowed(&self, blob: &str) -> bool {
        self.perms.can_embed(blob)
    }

    // --- action dispatch ----------------------------------------------------

    /// Dispatch one [`ChatAction`] — the single CRDT-mutation path shared by the
    /// on-screen affordances and the Ctrl+K palette. Delegates to the framework's
    /// [`ActionHost`](ui::ActionHost), which brackets the undo boundary and applies
    /// the action through the executor (a pinned actor + committed change, so it
    /// replays byte-identically on peers), exactly as the palette does. The
    /// in-memory projection is reconciled from the document by the caller's
    /// `reload`. This app supplies only its domain: the action and its type.
    pub(crate) fn perform_action(&mut self, doc: &mut AutoCommit, action: &ChatAction) {
        self.actions.dispatch_with_context(
            doc,
            actions::CHAT_ACTION_TYPE,
            action,
            actions::history_context(action),
        );
    }

    /// The last [`EncodedAction`](qos_actions::EncodedAction) an on-screen
    /// affordance dispatched, for the affordance == [`ActionSpec`](qos_actions::ActionSpec)
    /// covenant test: a control and its Ctrl+K entry must build the identical action.
    #[cfg(test)]
    pub(crate) fn last_dispatched(&self) -> Option<&qos_actions::EncodedAction> {
        self.actions.last_dispatched()
    }

    /// The context Ctrl+K needs to build Chat's resource tree: the active
    /// workspace, its channels (including archived, so they can be unarchived from
    /// the palette), the open channel, and that channel's messages. Derived
    /// entirely from the projection the document already holds.
    pub(crate) fn chat_resource_ctx(&self) -> actions::ChatResourceCtx {
        let workspace_name = self
            .workspaces
            .iter()
            .find(|w| w.id == self.active_ws)
            .map(|w| w.name.clone())
            .unwrap_or_default();
        let mut channels: Vec<&Channel> = self
            .channels
            .iter()
            .filter(|c| c.workspace == self.active_ws)
            .collect();
        channels.sort_by_key(|c| c.order);
        let channels = channels
            .into_iter()
            .map(|c| actions::ChannelResource {
                id: c.id.clone(),
                name: c.name.clone(),
                kind: c.kind,
                archived: c.archived,
            })
            .collect();
        let messages = self
            .messages
            .iter()
            .map(|m| actions::MessageResource {
                id: m.id.clone(),
                label: self.message_resource_label(m),
                pinned: m.pinned,
                parent: m.parent.clone(),
            })
            .collect();
        actions::ChatResourceCtx {
            me: self.me.id.clone(),
            workspace_id: self.active_ws.clone(),
            workspace_name,
            channels,
            active_channel: self.active_channel.clone(),
            messages,
            participants: self.participants(),
        }
    }

    /// Build the reaction action a click on `msg`/`emoji` should dispatch,
    /// deciding add-vs-remove from the currently-loaded state at authoring time.
    /// A toggle is a presentation decision; the resulting action is a pure,
    /// idempotent add or remove — the single source of truth both the reaction
    /// chip and the emoji picker resolve to.
    pub(crate) fn reaction_toggle_action(&self, msg: &str, emoji: &str) -> ChatAction {
        let reacting = self.message(msg).is_some_and(|m| {
            m.reactions
                .iter()
                .any(|r| r.emoji == emoji && r.reacted_by(&self.me.id))
        });
        if reacting {
            actions::remove_reaction_action(&self.active_channel, msg, emoji, &self.me.id)
        } else {
            actions::add_reaction_action(&self.active_channel, msg, emoji, &self.me.id)
        }
    }

    /// A palette label for a message resource: the author's name and a short
    /// snippet of the body (or the attachment name for a media-only post).
    fn message_resource_label(&self, m: &Message) -> String {
        let author = self.user_name(&m.author);
        let snippet: String = if m.text.trim().is_empty() {
            m.attachment
                .as_ref()
                .map_or_else(|| "(no text)".to_string(), |a| a.name().to_string())
        } else {
            m.text.trim().chars().take(40).collect()
        };
        format!("{author}: {snippet}")
    }

    /// Stage a named scenario for a headless screenshot against the ephemeral
    /// demo workspace. The default is an ordinary reading/conversation frame;
    /// collaboration states are explicit so a capture does not teach a floating
    /// call as Chat's resting state.
    #[allow(
        clippy::too_many_lines,
        reason = "the screenshot scenario dispatcher keeps each named visual contract explicit and adjacent"
    )]
    pub fn seed_shot_scenario(&mut self, scenario: &str) {
        match scenario {
            "narrow" => {
                // Overlay-collapsed conversation: both flaps closed, no thread,
                // no floating call — the clean single-column reading state.
                self.left_flap.snap(false);
                self.right_flap.snap(false);
                self.thread_open = None;
                self.call = CallState::default();
            }
            "compact" => {
                // Medium window: docked channel list, conversation reflowed,
                // members/thread summoned on demand (not forced open), no call.
                self.thread_open = None;
                self.right_flap.snap(false);
                self.call = CallState::default();
            }
            "people" => {
                self.thread_open = None;
                self.right_flap.snap(true);
                self.call = CallState::default();
            }
            "thread-narrow" => {
                self.thread_open = Some("m_concept".into());
                self.right_flap.snap(true);
                self.call = CallState::default();
            }
            "collaboration" => {
                self.thread_open = Some("m_concept".into());
                self.right_flap.open();
                self.call.join("c_huddle");
            }
            "starter" => {
                // The real first-run empty workspace (no demo content).
                self.shot_starter = true;
                self.thread_open = None;
                self.call = CallState::default();
            }
            "context" => {
                self.menu = Some(ContextMenu {
                    target: MenuTarget::Channel("c_frontend".into()),
                    anchor: Point::new(240.0, 230.0),
                    items: MenuAction::for_channel().to_vec(),
                });
            }
            "call" => {
                // The expanded full-window call overlay against the demo
                // huddle (host + three remotes), so the tile grid and the
                // wrapped controls bar can be captured headless at any width.
                self.right_flap.snap(false);
                self.thread_open = None;
                self.call.join("c_huddle");
                self.call.expanded = true;
            }
            "floating-call-attached"
            | "floating-call"
            | "floating-call-hover"
            | "floating-call-returning"
            | "floating-call-returned" => {
                // The after-layout shot hook stages the production ownership
                // edge once app-local coordinates are authoritative. All
                // three frames use the real live huddle renderer.
                self.right_flap.snap(false);
                self.thread_open = None;
                self.call.join("c_huddle");
                self.call.expanded = false;
            }
            "share" => {
                // The expanded call while screen-sharing: the featured screen
                // tile fills the stage above the participant filmstrip, and the
                // controls bar shows the active "Stop share". Local share is
                // staged directly (the same `call.sharing` flag the real toggle
                // sets on a portal grant) so the presentation layout renders
                // headless without a portal or capture device.
                self.right_flap.snap(false);
                self.thread_open = None;
                self.call.join("c_huddle");
                self.call.expanded = true;
                self.call.sharing = true;
            }
            "attach" => {
                // Show the workspace file picker with real, decodable
                // thumbnails (the demo scheme drives the same decode path a
                // projected FUSE image would). Ephemeral shot only.
                self.thread_open = None;
                self.right_flap.snap(false);
                self.call = CallState::default();
                self.attach_entries = vec![
                    crate::picker::PickEntry {
                        path: crate::images::DEMO_CALL_GRID.into(),
                        name: "call-overlay-v3.png".into(),
                        size: 84_992,
                        is_video: false,
                    },
                    crate::picker::PickEntry {
                        path: crate::images::DEMO_SHARED_SHOT.into(),
                        name: "design-handoff.png".into(),
                        size: 132_480,
                        is_video: false,
                    },
                ];
                self.attach_open = true;
            }
            "attach-loading" => {
                self.seed_shot_scenario("attach");
                // This mirrors the actual asynchronous picker state rather
                // than a hand-painted status string: no entries are usable
                // until the worker's generation-checked reply settles.
                self.attach_entries.clear();
                self.attachment_picker_pending = Some(0);
                self.attachment_status = Some("Loading attachments…".into());
            }
            "attach-error" => {
                self.seed_shot_scenario("attach");
                self.attachment_status =
                    Some("Attachment import failed: file is unavailable".into());
            }
            "edit" => {
                // The inline message editor open on your own last message,
                // with an earlier message still carrying the static "(edited)"
                // marker — the whole edit story in one frame. Ephemeral shot
                // only: at seed time the messages aren't loaded yet, so the
                // working text is staged directly in the same shared input the
                // live Edit action uses.
                self.right_flap.snap(false);
                self.thread_open = None;
                self.call = CallState::default();
                let text = "That's the one. Starting a huddle to walk through the grid — jump in. Moving it to 3pm so the west-coast folks can make it.";
                self.edit_input.set_text(text);
                self.edit_input.set_cursor_pos(text.len());
                self.editing = Some("m_me2".into());
                self.focus = Focus::Main;
                self.set_composer_focus();
            }
            "composer" => {
                // The composer mid-compose: a multi-line draft with the caret,
                // so the shared TextInput's text + caret + focus ring can be
                // graded. Thread/call closed to keep the composer prominent.
                self.right_flap.snap(false);
                self.thread_open = None;
                self.call = CallState::default();
                self.focus = Focus::Main;
                self.shot_composer_draft = Some(
                    "Shipping the composer on the shared TextInput — real caret, \
                     selection, and Ctrl+C/V now.\nEnter sends, Shift+Enter for a new line."
                        .to_string()
                        + "\nPlease check teh adress",
                );
            }
            "msgmenu" => {
                // The right-click action menu over one of your own messages,
                // offering Edit — the discoverable entry point to editing.
                self.right_flap.snap(false);
                self.thread_open = None;
                self.call = CallState::default();
                self.menu = Some(ContextMenu {
                    target: MenuTarget::Message("m_me2".into()),
                    anchor: Point::new(360.0, 300.0),
                    items: MenuAction::for_message().to_vec(),
                });
            }
            _ => {
                self.thread_open = None;
                self.right_flap.snap(false);
                self.call = CallState::default();
            }
        }
    }

    /// Headless visual-review hook for the real shell → app call handoff.
    ///
    /// This runs after layout so the same `FloatingPlacement` methods used by
    /// pointer input and the `Suspended` host reply see authoritative app and
    /// desktop coordinate spaces. The `returning` and `returned` frames land
    /// on identical geometry on opposite sides of the ownership boundary.
    #[doc(hidden)]
    pub fn debug_stage_floating_call_for_shot(&mut self, scenario: &str) {
        if !scenario.starts_with("floating-call") {
            return;
        }

        if scenario == "floating-call-attached" {
            self.call.placement.pin_handoff_for_visual_review(1_000);
            return;
        }

        // A live drag seeds `preferred_size` from the current call tile before
        // crossing the app edge. Derive this staged desktop rect the same way;
        // hard-coding a different size would manufacture a return-time resize
        // that the production pointer path never performs.
        let detached_size = self.call_video_rect().size();
        self.call.placement.set_preferred_size(detached_size);
        let detached = Rect::from_origin_size(Point::new(760.0, 300.0), detached_size);
        self.call.placement.detach_to_desktop(detached);
        self.call.placement.set_desktop_transfer_covered(true);
        self.call.placement.confirm_desktop_adoption();

        if scenario == "floating-call-hover" {
            self.call_hovered = Some(Hit::CallLeave);
        }

        if let Some(permille) = scenario
            .strip_prefix("floating-call-collapse-")
            .and_then(|value| value.parse::<u16>().ok())
        {
            self.call.participants_expanded = false;
            self.call_chrome_motion
                .pin_for_visual_review(1.0 - f32::from(permille.min(1_000)) / 1_000.0);
        }

        if matches!(
            scenario,
            "floating-call-returning" | "floating-call-returned"
        ) {
            let pointer = Point::new(detached.center().x, detached.y0 - 18.0);
            self.call
                .placement
                .begin_drag(pointer, self.rect, self.desktop_floating_bounds());
            let _ = self.call.placement.update_drag(
                Point::new(720.0, 210.0),
                self.rect,
                self.desktop_floating_bounds(),
            );
        }

        if scenario == "floating-call-returned" {
            let id = format!("chat-call:{}", self.call.channel);
            <Self as Widget>::on_floating_surface_host_message(
                self,
                &ui::floating_surface::FloatingSurfaceHostMessage::Suspended { id },
            );
        }

        // Make the screenshots on either side of shell ownership directly
        // comparable: steady detached state is relaxed; both return frames
        // show the same restrained midpoint deformation.
        let handoff_phase = if matches!(
            scenario,
            "floating-call-returning" | "floating-call-returned"
        ) {
            500
        } else {
            1_000
        };
        self.call
            .placement
            .pin_handoff_for_visual_review(handoff_phase);
    }

    /// The live media pump: run once per frame while the engine is live. Pulls
    /// captured microphone/camera/screen media, encodes it and publishes it over
    /// the transport, then decodes and plays whatever arrived from peers. Every
    /// device/track honours the call permission gate; when a device is absent
    /// the corresponding pipeline is simply `None` and that medium stays silent.
    #[cfg(feature = "live-media")]
    fn pump_media(&mut self) {
        if !self.call.active {
            self.pump_media_reset();
            return;
        }
        let me = self.me.id.clone();
        self.pump_mic(&me);
        self.pump_camera(&me);
        self.pump_screen(&me);
        self.pump_receive(&me);
    }

    /// Release all devices + remote state between calls.
    #[cfg(feature = "live-media")]
    fn pump_media_reset(&mut self) {
        self.mic = None;
        self.speaker = None;
        self.camera = None;
        self.cam_encoder = None;
        self.screen = None;
        self.screen_session = None;
        self.remote_decoders.clear();
        self.remote_screen_rx.clear();
        self.remote_media_seq.clear();
        self.remote_frames.clear();
        self.remote_screens.clear();
        // A new call is a fresh local stream. Remote receivers recognize the
        // first seq=0/pts=0 object as the corresponding stream reset.
        self.media_seq = 0;
        self.media_error = None;
    }

    /// Microphone → Opus → publish (only while transmitting).
    #[cfg(feature = "live-media")]
    fn pump_mic(&mut self, me: &str) {
        use crate::call::CallAction;
        use crate::media::TrackKind;
        use std::time::Duration;

        let transmit =
            !self.call.muted && !self.call.deafened && self.call_allows(CallAction::Speak);
        if !transmit {
            self.mic = None;
            return;
        }
        if self.mic.is_none() {
            self.mic = crate::audio::MicCapture::new();
        }
        let packets = self
            .mic
            .as_mut()
            .map(super::audio::MicCapture::poll)
            .unwrap_or_default();
        for pkt in packets {
            let pts = Duration::from_millis(self.media_seq.saturating_mul(20));
            if !self.send_media_frame(me, TrackKind::Audio, pts, pkt) {
                return;
            }
        }
    }

    /// Camera → H.264 → local preview + publish (only with camera on).
    #[cfg(feature = "live-media")]
    fn pump_camera(&mut self, me: &str) {
        use crate::call::CallAction;
        use crate::media::TrackKind;
        use std::time::Duration;

        let camera_on = !self.call.audio_only && self.call_allows(CallAction::Camera);
        if !camera_on {
            self.camera = None;
            self.cam_encoder = None;
            return;
        }
        if self.camera.is_none() {
            self.camera =
                crate::video::CameraCapture::new(crate::video::DEFAULT_W, crate::video::DEFAULT_H);
            // Camera encode reuses the shared stack's H.264 encoder.
            self.cam_encoder = qos_callstream::H264Encoder::new(
                crate::video::DEFAULT_W,
                crate::video::DEFAULT_H,
                crate::video::DEFAULT_FPS,
            )
            .ok();
        }
        let nalus = match (self.camera.as_mut(), self.cam_encoder.as_mut()) {
            (Some(cam), Some(enc)) => cam.poll().map(|rgba| enc.encode(&rgba).unwrap_or_default()),
            _ => None,
        };
        let Some(nalus) = nalus else {
            return;
        };
        if nalus.is_empty() {
            return;
        }
        // Feed the host tile's VideoPlayer so this peer sees its own
        // camera (the surface yields its placeholder to a real frame).
        self.video.feed_frame(&nalus);
        let pts = Duration::from_millis(self.media_seq.saturating_mul(33));
        let _ = self.send_media_frame(me, TrackKind::Video, pts, nalus);
    }

    /// Screen capture → shared stack (throttle + encode → `SurfaceFrame`) →
    /// publish (started via `share_screen`). The `VideoStreamSender` seam
    /// does the throttling + encode + framing, so a returned `Some` is
    /// already a wire-ready, rate-capped frame.
    #[cfg(feature = "live-media")]
    fn pump_screen(&mut self, me: &str) {
        use crate::media::TrackKind;
        use std::time::Duration;

        let screen_result = match (self.screen.as_mut(), self.screen_session.as_mut()) {
            (Some(scr), Some(session)) => scr
                .poll()
                .map(|rgba| session.offer_frame(&rgba, std::time::Instant::now())),
            _ => None,
        };
        let Some(result) = screen_result else {
            return;
        };
        let wire = match result {
            Ok(Some(wire)) => wire,
            Ok(None) => return,
            Err(error) => {
                self.stop_screen_for_error(&error);
                return;
            }
        };
        let pts = Duration::from_millis(self.media_seq.saturating_mul(33));
        let _ = self.send_media_frame(me, TrackKind::Screen, pts, wire);
    }

    /// Submit one already-encoded frame. Transport queue pressure is expected
    /// for real-time media and is deliberately a non-fatal drop. A frame that
    /// can never fit Chat's object contract is different: report it once and
    /// stop that producer instead of attempting (and silently losing) it on
    /// every frame.
    #[cfg(feature = "live-media")]
    fn send_media_frame(
        &mut self,
        me: &str,
        kind: crate::media::TrackKind,
        pts: std::time::Duration,
        payload: Vec<u8>,
    ) -> bool {
        if payload.len() > crate::media::MAX_MEDIA_PAYLOAD {
            self.stop_unrepresentable_media_track(kind, payload.len());
            return false;
        }
        let Some(seq) = self.next_media_seq() else {
            return false;
        };
        // `false` here is a bounded, ordinary transport rejection (usually a
        // full realtime queue). Do not turn transient backpressure into a
        // terminal call failure.
        let _ = self.media.transport_mut().send(crate::media::MediaObject {
            sender: me.to_string(),
            kind,
            seq,
            pts,
            payload,
        });
        true
    }

    #[cfg(feature = "live-media")]
    fn stop_unrepresentable_media_track(&mut self, kind: crate::media::TrackKind, bytes: usize) {
        let label = match kind {
            crate::media::TrackKind::Audio => "Microphone",
            crate::media::TrackKind::Video => "Camera",
            crate::media::TrackKind::Screen => "Screen sharing",
        };
        self.media_error = Some(format!(
            "{label} stopped: encoded frame ({bytes} bytes) exceeds Chat's {} byte media limit",
            crate::media::MAX_MEDIA_PAYLOAD
        ));
        self.media.transport_mut().unpublish(kind);
        match kind {
            crate::media::TrackKind::Audio => self.mic = None,
            crate::media::TrackKind::Video => {
                self.camera = None;
                self.cam_encoder = None;
            }
            crate::media::TrackKind::Screen => {
                self.call.sharing = false;
                self.release_screen();
                self.screen_share_needs_sync = true;
            }
        }
    }

    #[cfg(feature = "live-media")]
    fn stop_screen_for_error(&mut self, error: &qos_callstream::FrameError) {
        self.media_error = Some(format!("Screen sharing stopped: {error}"));
        self.call.sharing = false;
        self.release_screen();
        self.screen_share_needs_sync = true;
    }

    /// Receive: decode + play whatever arrived from peers.
    #[cfg(feature = "live-media")]
    fn pump_receive(&mut self, me: &str) {
        use crate::media::TrackKind;

        let objs = self.media.transport_mut().poll();
        for o in objs {
            if o.sender == me {
                continue;
            }
            let sequence_key = (o.sender.clone(), o.kind);
            // A peer that rejoined starts a new stream at 0. This explicit
            // zero timestamp reset is accepted while ordinary late/reordered
            // frames still fail closed.
            let reset = o.seq == 0 && o.pts.is_zero();
            if !reset
                && self
                    .remote_media_seq
                    .get(&sequence_key)
                    .is_some_and(|seen| o.seq <= *seen)
            {
                continue;
            }
            self.remote_media_seq.insert(sequence_key, o.seq);
            match o.kind {
                TrackKind::Audio => {
                    if !self.call.deafened {
                        if self.speaker.is_none() {
                            self.speaker = crate::audio::SpeakerPlayback::new();
                        }
                        if let Some(sp) = self.speaker.as_mut() {
                            sp.play(&o.payload);
                        }
                    }
                }
                TrackKind::Video => {
                    // Remote camera: a raw-NALU H.264 stream decoded through
                    // the shared stack's decoder → the peer's filmstrip cell.
                    let frame = self
                        .remote_decoders
                        .entry(o.sender.clone())
                        .or_default()
                        .decode(&o.payload);
                    if let Some(frame) = frame {
                        self.remote_frames
                            .insert(o.sender.clone(), rgba_to_image(&frame));
                    }
                }
                TrackKind::Screen => {
                    // Remote screen-share: reframe + decode through the shared
                    // stack's receiver (the same `SurfaceFrame` framing the
                    // compositor's PeerView consumes) → the featured stage tile.
                    let frames = self
                        .remote_screen_rx
                        .entry(o.sender.clone())
                        .or_default()
                        .push(&o.payload);
                    if let Some(frame) = frames.last() {
                        self.remote_screens
                            .insert(o.sender.clone(), rgba_to_image(frame));
                    }
                }
            }
        }
    }

    #[cfg(feature = "live-media")]
    fn next_media_seq(&mut self) -> Option<u64> {
        let s = self.media_seq;
        let Some(next) = self.media_seq.checked_add(1) else {
            self.media_error = Some(
                "Media stopped: stream sequence limit reached. Leave and rejoin to restart it."
                    .into(),
            );
            for kind in [
                crate::media::TrackKind::Audio,
                crate::media::TrackKind::Video,
                crate::media::TrackKind::Screen,
            ] {
                self.media.transport_mut().unpublish(kind);
            }
            if self.call.sharing {
                self.call.sharing = false;
                self.release_screen();
                self.screen_share_needs_sync = true;
            }
            return None;
        };
        self.media_seq = next;
        Some(s)
    }

    /// Acquire a screen-share source through the portal seam: check the
    /// `ShareScreen` permission, then ask [`self.portal`](Self) for a source
    /// (the real xdg-desktop-portal `ScreenCast` picker behind `live-media`; an
    /// honest `None` in the default build; an injected fake in tests). On a
    /// grant, open the `PipeWire` capture + a shared-stack video sender and
    /// publish the screen track (behind `live-media`) and return `true`.
    /// Returns `false` — never fabricating a share — when permission is denied
    /// or the portal grants nothing. The caller flips `call.sharing` + the
    /// shared voice membership.
    ///
    /// The source selection stays the xdg-desktop-portal `ScreenCast` picker;
    /// the encode + framing route through [`qos_callstream::VideoStreamSender`]
    /// — the same throttle+encoder+`SurfaceFrame` composition the compositor's
    /// `SharedFlatpakSession` performs — instead of a second in-app codec.
    #[cfg_attr(
        not(feature = "live-media"),
        allow(
            clippy::needless_pass_by_ref_mut,
            reason = "live-media mutates capture state; the default build keeps the same call API"
        )
    )]
    pub(crate) fn acquire_screen(&mut self) -> bool {
        if !self.call_allows(crate::call::CallAction::ShareScreen) {
            return false;
        }
        let Some(src) = self.portal.request() else {
            return false;
        };
        #[cfg(all(feature = "live-media", not(test)))]
        {
            if let Some(scr) = crate::video::ScreenCapture::new(src.node, src.width, src.height) {
                self.screen = Some(scr);
                self.screen_session = qos_callstream::VideoStreamSender::new(
                    src.width,
                    src.height,
                    crate::video::DEFAULT_FPS,
                )
                .ok();
                self.media
                    .transport_mut()
                    .publish(crate::media::TrackKind::Screen);
            }
        }
        #[cfg(all(feature = "live-media", test))]
        {
            // A fake portal source has no real PipeWire node. Tests still use
            // the production sender/transport contract, but must never block
            // opening a host device merely to verify the shared call state.
            self.screen_session = qos_callstream::VideoStreamSender::new(
                src.width,
                src.height,
                crate::video::DEFAULT_FPS,
            )
            .ok();
            self.media
                .transport_mut()
                .publish(crate::media::TrackKind::Screen);
        }
        let _ = src;
        true
    }

    /// Whether this peer is currently sharing its screen — the shared-truth
    /// flag used by the featured tile and transport tests. True only after the
    /// portal granted a source (see [`Self::acquire_screen`]).
    #[allow(
        dead_code,
        reason = "queried by transport tests while the production capture control is hidden"
    )]
    pub(crate) fn sharing_screen(&self) -> bool {
        self.call.sharing
    }

    /// Tear down the local screen capture and stop publishing the screen track.
    /// The caller clears `call.sharing` + the shared voice membership.
    #[cfg_attr(
        not(feature = "live-media"),
        allow(
            clippy::needless_pass_by_ref_mut,
            clippy::unused_self,
            reason = "live-media tears down capture state; the default build keeps the same call API"
        )
    )]
    pub(crate) fn release_screen(&mut self) {
        #[cfg(feature = "live-media")]
        {
            self.screen = None;
            self.screen_session = None;
            self.media
                .transport_mut()
                .unpublish(crate::media::TrackKind::Screen);
        }
    }

    // --- model lookups ----------------------------------------------------
    pub(crate) fn user(&self, id: &str) -> Option<&User> {
        self.users.iter().find(|u| u.id == id)
    }

    /// Take the room's view of the participants off the presence store.
    ///
    /// Called once per frame from `draw_with_presence`. The presence store is
    /// seeded from `CollabEvent::Context` — the broker's roster snapshot — so a
    /// name here is the room's answer, arrived over the same transport as the
    /// messages. Nothing a peer says about itself reaches this map.
    ///
    /// The room's answer **replaces** what was held rather than merging into
    /// it. Merging is how a peer who has gone keeps a name and a colour on
    /// everyone else's screen for the rest of the session: presence forgets
    /// them on leave, and anything downstream that only ever learned would go
    /// on offering a departed participant in the `@` picker and painting their
    /// colour behind a mention.
    pub fn adopt_room(&mut self, presence: &PresenceCtx) {
        self.adopt_own_participant(presence);
        self.room_names.retain(|id, _| {
            presence
                .names
                .contains_key(&ui::permissions::UserId(id.clone()))
        });
        self.room_colors.retain(|id, _| {
            presence
                .names
                .contains_key(&ui::permissions::UserId(id.clone()))
        });
        for (id, name) in &presence.names {
            let name = name.trim();
            if name.is_empty() {
                continue;
            }
            self.room_names.insert(id.0.clone(), name.to_string());
            // A colour is the same kind of answer: assigned per room so two
            // people never collide, and shared with the caret pill and cursor.
            self.room_colors
                .insert(id.0.clone(), presence.color_for(id));
        }
    }

    /// Take the room's answer to "which of these participants am I".
    ///
    /// A chat author has to live in the id space the roster is keyed by,
    /// because resolving an author's name *is* a lookup in that roster.
    /// [`LocalIdentity::resolve`](crate::identity::LocalIdentity::resolve)
    /// mints an id from the signing key, while every other machine addresses
    /// this participant however the broker's roster spells it — the only
    /// spelling that appears in a roster. Authoring under the local mint
    /// alone means every remote message resolves to nobody and renders
    /// unnamed, permanently, on every screen but the sender's.
    ///
    /// A session with no room has neither an id nor a name to adopt, and
    /// keeps what it resolved for itself: there is no room-wide address to
    /// be had, and nobody else is looking.
    fn adopt_own_participant(&mut self, presence: &PresenceCtx) {
        if let Some(room_id) = presence.self_id()
            && room_id.0 != self.me.id
        {
            let former = std::mem::replace(&mut self.me.id, room_id.0.clone());
            // The colour is derived from the id, so it moves with it —
            // otherwise this peer's caret and its avatar disagree.
            self.me.color_idx = crate::identity::color_index_for(room_id.0.as_bytes());
            // What was already said under the old id is still this person: a
            // message records who spoke, and rewriting authorship after the
            // fact to tidy an id would be editing history. Remembering the id
            // instead keeps "You" beside their own earlier lines.
            if !self.former_ids.contains(&former) {
                self.former_ids.push(former);
            }
        }
        if let Some(name) = presence.self_name()
            && name != self.me.name
        {
            self.me.name = name.to_string();
            self.me.initials = crate::identity::initials_for(name);
        }
    }

    /// Whether `id` is this session's own participant, including any id it
    /// authored under before the room named it.
    pub(crate) fn is_me(&self, id: &str) -> bool {
        id == self.me.id || self.former_ids.iter().any(|f| f == id)
    }

    /// What to call `id`: the room's answer first, the document's stored name
    /// as an offline fallback, and the raw id last so a label is never blank.
    ///
    /// The precedence is the point. A client that could name itself would be
    /// telling every other peer what to call it, and two peers disagreeing
    /// about a third's name is a difference nobody can settle. So the room
    /// answers, and a peer only ever supplies its id.
    pub fn display_name(&self, id: &str) -> String {
        if let Some(n) = self.room_names.get(id)
            && !n.trim().is_empty()
        {
            return n.clone();
        }
        if let Some(u) = self.users.iter().find(|u| u.id == id)
            && !u.name.trim().is_empty()
        {
            return u.name.clone();
        }
        // Your own name, which this had no way to reach until the room named
        // it: `me` is not necessarily a row in `users`, which is built from
        // the room document, and a room this peer has not spoken in has
        // never heard of it.
        if self.is_me(id) && !self.me.name.trim().is_empty() {
            return self.me.name.clone();
        }
        id.to_string()
    }

    /// What to call `id` on screen, with "You" for this session's own
    /// participant and an honest placeholder for someone the room has not
    /// named yet — nobody is ever shown their raw routing id.
    pub(crate) fn user_name(&self, id: &str) -> String {
        // `is_me` rather than a bare comparison: a peer that has adopted the
        // room's address for itself still wrote its earlier lines under the
        // id it resolved at startup, and those are still its own.
        if self.is_me(id) {
            return "You".to_string();
        }
        let named = self.display_name(id);
        if named != id && !named.trim().is_empty() {
            return named;
        }
        format!("Someone ({})", Self::unnamed_tag(id))
    }

    /// Enough of an unresolved id to tell two unnamed people apart.
    ///
    /// The tail rather than the head: these ids share a `peer@` prefix and
    /// differ in their digits, so the first characters are the ones that
    /// carry no information.
    fn unnamed_tag(id: &str) -> String {
        let body = id.rsplit(['@', ':']).next().unwrap_or(id);
        let tail: String = body
            .chars()
            .rev()
            .take(4)
            .collect::<Vec<_>>()
            .into_iter()
            .rev()
            .collect();
        if tail.is_empty() {
            id.to_string()
        } else {
            tail
        }
    }

    /// The avatar monogram for `id`, derived from whatever the room calls them
    /// so the letter never disagrees with the name beside it.
    pub fn initials_for(&self, id: &str) -> String {
        let name = self.display_name(id);
        let s = ui::widget::Avatar::initials_for_name(&name);
        if s.is_empty() {
            name.chars()
                .next()
                .map(|c| c.to_uppercase().to_string())
                .unwrap_or_default()
        } else {
            s
        }
    }

    /// The participant's own colour, in the shared presence vocabulary: the
    /// room's assignment when it made one, otherwise the system-wide
    /// per-user colour every other surface derives the same way.
    pub fn participant_color(&self, id: &str) -> (u8, u8, u8) {
        self.room_colors
            .get(id)
            .copied()
            .unwrap_or_else(|| ui::presence::user_color(id))
    }

    /// Everyone the `@` picker can offer: the document's own users, plus
    /// anyone the room is talking about who has not yet written themselves
    /// into it.
    pub fn participants(&self) -> Vec<crate::mention::Participant> {
        let mut out: Vec<crate::mention::Participant> = self
            .users
            .iter()
            .map(|u| crate::mention::Participant {
                id: u.id.clone(),
                name: self.display_name(&u.id),
                is_agent: u.is_agent,
            })
            .collect();
        for id in self.room_names.keys() {
            if !out.iter().any(|p| &p.id == id) {
                out.push(crate::mention::Participant {
                    id: id.clone(),
                    name: self.display_name(id),
                    is_agent: false,
                });
            }
        }
        out.sort_by(|a, b| a.name.cmp(&b.name));
        out
    }

    pub(crate) fn channel(&self, id: &str) -> Option<&Channel> {
        self.channels.iter().find(|c| c.id == id)
    }
    pub(crate) fn message(&self, id: &str) -> Option<&Message> {
        self.messages.iter().find(|m| m.id == id)
    }

    /// Channels in the active workspace, ordered. Archived channels are hidden
    /// from the sidebar (they stay in the document and are reachable via Ctrl+K).
    pub(crate) fn ws_channels(&self) -> Vec<&Channel> {
        let mut v: Vec<&Channel> = self
            .channels
            .iter()
            .filter(|c| c.workspace == self.active_ws && !c.archived)
            .collect();
        v.sort_by_key(|c| c.order);
        v
    }

    /// Categories in the active workspace, ordered.
    pub(crate) fn ws_categories(&self) -> Vec<&crate::model::Category> {
        let mut v: Vec<&crate::model::Category> = self
            .categories
            .iter()
            .filter(|c| c.workspace == self.active_ws)
            .collect();
        v.sort_by_key(|c| c.order);
        v
    }

    pub(crate) fn category(&self, id: &str) -> Option<&crate::model::Category> {
        self.categories.iter().find(|c| c.id == id)
    }

    /// Cached voice members of `channel` (empty when nobody is connected).
    pub(crate) fn voice_in(&self, channel: &str) -> &[crate::model::VoiceMember] {
        self.voice_members
            .get(channel)
            .map_or(&[], std::vec::Vec::as_slice)
    }

    /// The media routing for the current call, chosen from the live participant
    /// count: peer-to-peer below the mesh threshold, host-relay above it. A
    /// call transparently promotes from P2P to host-based as people join.
    pub(crate) fn call_session(&self) -> crate::model::CallSession {
        crate::model::CallSession::select(self.voice_in(&self.call.channel).len().max(1))
    }

    /// Channels in `category` within the active workspace, ordered. Archived
    /// channels are hidden from the sidebar.
    pub(crate) fn category_channels(&self, category: &str) -> Vec<&Channel> {
        let mut v: Vec<&Channel> = self
            .channels
            .iter()
            .filter(|c| c.workspace == self.active_ws && c.category == category && !c.archived)
            .collect();
        v.sort_by_key(|c| c.order);
        v
    }

    /// Build a composer `TextInput`: multiline (Enter sends, Shift+Enter adds a
    /// newline), plain chrome (the composer draws its own rounded box around the
    /// text), sized to match the surrounding chat body.
    fn new_composer() -> TextInput {
        let mut t = TextInput::local()
            .multiline(true)
            .with_enter_submits(true)
            .with_font_size(15.0);
        t.set_plain_chrome(true);
        t
    }

    /// A local working copy for editing a sent message. It deliberately stays
    /// unbound until Save so peers never observe half-finished revisions.
    fn new_message_editor() -> TextInput {
        TextInput::local()
            .multiline(true)
            .with_enter_submits(true)
            .with_plain_chrome()
            .with_font_size(15.0)
    }

    /// A single-line local field for channel/category names. The host commits
    /// the trimmed value through the target-specific CRDT action on submit.
    fn new_rename_input() -> TextInput {
        TextInput::local()
            .with_enter_submits(true)
            .with_plain_chrome()
            .with_font_size(13.0)
    }

    /// The composer for the surface the user is typing in.
    pub(crate) fn focused_composer(&self) -> &TextInput {
        match self.focus {
            Focus::Thread if self.thread_open.is_some() => &self.composer_thread,
            _ => &self.composer_main,
        }
    }

    pub(crate) fn focused_composer_mut(&mut self) -> &mut TextInput {
        match self.focus {
            Focus::Thread if self.thread_open.is_some() => &mut self.composer_thread,
            _ => &mut self.composer_main,
        }
    }

    /// Point keyboard focus at the composer for the current surface — but only
    /// when no inline editor / rename is capturing input. Idempotent; called
    /// from `reload` and after any focus change.
    pub(crate) fn set_composer_focus(&mut self) {
        let editing = self.editing.is_some() || self.rename.is_some();
        let main = matches!(self.focus, Focus::Main) && !editing;
        let thread = matches!(self.focus, Focus::Thread) && self.thread_open.is_some() && !editing;
        ui::Widget::set_focus(&mut self.composer_main, main);
        ui::Widget::set_focus(&mut self.composer_thread, thread);
        ui::Widget::set_focus(&mut self.edit_input, self.editing.is_some());
        ui::Widget::set_focus(&mut self.rename_input, self.rename.is_some());
    }

    pub(crate) fn thread_draft_key(&self) -> Option<String> {
        self.thread_open
            .as_ref()
            .map(|p| format!("{}::t::{}", self.active_channel, p))
    }

    /// Rebuild the snapshot from the CRDT. Called at the tail of `sync` and
    /// after every mutation so `draw` always reflects the latest document.
    pub(crate) fn reload(&mut self, doc: &AutoCommit) {
        self.workspaces = ChatDoc::list_workspaces(doc);
        self.channels = ChatDoc::list_channels(doc);
        self.categories = ChatDoc::list_categories(doc);
        if !self.workspaces.iter().any(|w| w.id == self.context_ws)
            && let Some(context) = self
                .workspaces
                .iter()
                .find(|w| w.id == self.active_ws)
                .or_else(|| self.workspaces.first())
        {
            self.context_ws = context.id.clone();
        }
        // Keep the active channel valid (e.g. after a workspace switch).
        if self
            .channel(&self.active_channel)
            .map(|c| c.workspace.clone())
            != Some(self.active_ws.clone())
            && let Some(first) = self
                .ws_channels()
                .into_iter()
                .find(|c| c.kind == model::ChannelKind::Text)
                .map(|c| c.id.clone())
        {
            self.active_channel = first;
        }
        // Unread is per-peer derived state, not stored: the channel in view is
        // always read (0); every other channel shows its top-level messages
        // beyond this peer's read watermark. The watermark itself is advanced
        // by `mark_active_read` while a channel is viewed / on open.
        for c in &mut self.channels {
            c.unread = if c.id == self.active_channel {
                0
            } else {
                ChatDoc::unread_count(doc, &c.id, &self.me.id)
            };
        }
        self.messages = ChatDoc::list_messages(doc, &self.active_channel);
        self.search_messages = self
            .channels
            .iter()
            .flat_map(|channel| ChatDoc::list_messages(doc, &channel.id))
            .collect();
        self.search_users = ChatDoc::list_users(doc);
        // Cache voice membership for this workspace only. The document's
        // channel list is global, so filtering here is as important as it is
        // for the People projection below: a huddle elsewhere is not a huddle
        // in the workspace currently on screen.
        self.voice_members.clear();
        for ch in self
            .channels
            .iter()
            .filter(|c| c.workspace == self.active_ws && c.kind == model::ChannelKind::Voice)
        {
            let members = ChatDoc::list_voice_members(doc, &ch.id);
            if !members.is_empty() {
                self.voice_members.insert(ch.id.clone(), members);
            }
        }
        self.users = self.workspace_people(doc);
        // Load the per-surface drafts from the CRDT into the composer widgets.
        // `set_text` is a no-op when the value is unchanged, so this preserves
        // the caret/selection while typing (the draft we just wrote back equals
        // the widget's value) and only reloads when the surface actually
        // changed (a channel/thread switch), where a caret reset is correct.
        self.draft_main = ChatDoc::draft_text(doc, &self.active_channel);
        self.composer_main.set_text(&self.draft_main);
        let ch_name = self
            .channel(&self.active_channel)
            .map(|c| c.name.clone())
            .unwrap_or_default();
        self.composer_main
            .set_placeholder(&format!("Message #{ch_name}"));
        self.composer_main
            .set_local_author(Some(self.me.id.clone()));
        self.draft_thread = match self.thread_draft_key() {
            Some(k) => ChatDoc::draft_text(doc, &k),
            None => String::new(),
        };
        self.composer_thread.set_text(&self.draft_thread);
        self.composer_thread.set_placeholder("Reply…");
        self.composer_thread
            .set_local_author(Some(self.me.id.clone()));
        // `--shots` only: stage a mid-compose draft into the main composer so a
        // screenshot shows real text + caret. Never set in a live/interactive
        // run, so this is inert in production.
        if let Some(draft) = self.shot_composer_draft.clone() {
            self.composer_main.set_text(&draft);
            self.composer_main.set_cursor_pos(draft.len());
            self.draft_main = draft;
        }
        self.set_composer_focus();
    }

    /// Project the document-global identity directory onto evidence local to
    /// the active chat workspace. Membership is not stored separately in this
    /// document, so claiming every known identity is "in" the selected
    /// workspace would be dishonest. Channel activity and voice membership
    /// are durable, workspace-owned evidence; the local identity is included
    /// so a brand-new workspace remains a valid one-person surface.
    fn workspace_people(&self, doc: &AutoCommit) -> Vec<User> {
        let mut ids: HashSet<Id> = HashSet::from([self.me.id.clone()]);
        ids.extend(self.former_ids.iter().cloned());

        for channel in self
            .channels
            .iter()
            .filter(|channel| channel.workspace == self.active_ws)
        {
            for message in ChatDoc::list_messages(doc, &channel.id) {
                ids.insert(message.author);
                for reaction in message.reactions {
                    ids.extend(reaction.users);
                }
                ids.extend(message.mentions.into_iter().map(|mention| mention.user));
            }
        }
        for members in self.voice_members.values() {
            ids.extend(members.iter().map(|member| member.user.clone()));
        }

        let mut people: Vec<_> = ChatDoc::list_users(doc)
            .into_iter()
            .filter(|user| ids.contains(&user.id))
            .collect();
        if !people.iter().any(|user| self.is_me(&user.id)) {
            people.push(User {
                id: self.me.id.clone(),
                name: self.me.name.clone(),
                initials: self.me.initials.clone(),
                color_idx: self.me.color_idx,
                status: model::Presence::Online,
                is_agent: false,
            });
        }
        people.sort_by(|left, right| {
            left.name
                .cmp(&right.name)
                .then_with(|| left.id.cmp(&right.id))
        });
        people
    }

    /// Advance the local read watermark for the channel currently in view so
    /// its unread badge stays cleared and doesn't reappear once the user
    /// navigates away. Idempotent (a no-op when nothing new arrived), so it is
    /// safe to call every frame.
    pub(crate) fn mark_active_read(&mut self, doc: &mut AutoCommit) {
        if self.active_channel.is_empty() {
            return;
        }
        let count = ChatDoc::top_level_count(doc, &self.active_channel) as i64;
        if count <= ChatDoc::read_watermark(doc, &self.active_channel, &self.me.id) {
            return;
        }
        // Read state is a durable collaboration fact.  It is authored through
        // the same action host as palette "Mark as read", not a side write
        // that peers/history cannot account for.  The carried count makes the
        // replay independent of messages arriving after the person viewed it.
        let action = actions::mark_read_action(&self.active_channel, &self.me.id, count);
        self.perform_action(doc, &action);
        if let Some(channel) = self
            .channels
            .iter_mut()
            .find(|channel| channel.id == self.active_channel)
        {
            channel.unread = 0;
        }
    }

    fn reveal_workspace_resource(&mut self, workspace: String) -> Result<(), String> {
        if !self.workspaces.iter().any(|item| item.id == workspace) {
            return Err("workspace no longer exists".into());
        }
        self.active_ws = workspace;
        self.active_channel.clear();
        self.inbox_open = false;
        self.thread_open = None;
        self.revealed_message = None;
        self.revealed_person = None;
        self.scroll = 0.0;
        self.focus = Focus::Main;
        Ok(())
    }

    fn reveal_category_resource(
        &mut self,
        workspace: String,
        category: &str,
    ) -> Result<(), String> {
        let Some(category_id) = self
            .categories
            .iter()
            .find(|item| item.id == category && item.workspace == workspace)
            .map(|item| item.id.clone())
        else {
            return Err("category no longer exists".into());
        };
        self.active_ws = workspace;
        self.active_channel = self
            .channels
            .iter()
            .filter(|channel| {
                channel.workspace == self.active_ws
                    && channel.category == category_id
                    && channel.kind == model::ChannelKind::Text
            })
            .min_by_key(|channel| channel.order)
            .map_or_else(String::new, |channel| channel.id.clone());
        self.inbox_open = false;
        self.thread_open = None;
        self.revealed_message = None;
        self.revealed_person = None;
        self.scroll = 0.0;
        self.focus = Focus::Main;
        Ok(())
    }

    /// The members roster shown in the right flap when no thread is open: every
    /// user in the workspace paired with the voice channel they're currently in
    /// (if any). Sorted in-call first, then by presence, then by name. Real
    /// projection of the shared user list + voice membership — no placeholders.
    pub(crate) fn roster_rows(&self) -> Vec<(User, Option<String>)> {
        // user id → the name of the voice channel they're connected to.
        let mut in_voice: HashMap<&str, String> = HashMap::new();
        for (ch_id, members) in &self.voice_members {
            let ch_name = self
                .channel(ch_id)
                .map_or_else(|| ch_id.clone(), |c| c.name.clone());
            for m in members {
                in_voice.insert(m.user.as_str(), ch_name.clone());
            }
        }
        let mut rows: Vec<(User, Option<String>)> = self
            .users
            .iter()
            .cloned()
            .map(|u| {
                let voice = in_voice.get(u.id.as_str()).cloned();
                (u, voice)
            })
            .collect();
        let rank = |u: &User, voice: &Option<String>| -> u8 {
            if voice.is_some() {
                0
            } else {
                match u.status {
                    crate::model::Presence::Online => 1,
                    crate::model::Presence::Idle => 2,
                    crate::model::Presence::Dnd => 3,
                    crate::model::Presence::Offline => 4,
                }
            }
        };
        rows.sort_by(|a, b| {
            rank(&a.0, &a.1)
                .cmp(&rank(&b.0, &b.1))
                .then_with(|| a.0.name.cmp(&b.0.name))
        });
        rows
    }

    /// Whether this workspace has somebody besides the local participant. An
    /// agent is still a collaborator (and should surface collaboration
    /// controls), but it is never counted or labelled as a person.
    pub(crate) fn has_other_collaborator(&self) -> bool {
        self.users.iter().any(|u| !self.is_me(&u.id))
    }

    /// The roster's public destination name. `People` is precise when every
    /// entry is human; once an agent is present, `Collaborators` accurately
    /// covers both and the row itself keeps the agent visibly typed.
    pub(crate) fn roster_label(&self) -> &'static str {
        if self.users.iter().any(|u| u.is_agent) {
            "Collaborators"
        } else {
            "People"
        }
    }

    // --- responsive flap geometry ----------------------------------------
    //
    // Each flap's *physical* pane width is fixed; what changes with the mode
    // is whether the content is inset by it (docked) or whether the pane
    // floats over the content behind a scrim (overlay). The eased `slide`
    // animates the float in/out.

    /// Total width occupied by the left navigation pane (rail + sidebar).
    pub(crate) fn left_pane_w() -> f64 {
        RAIL_W + SIDE_W
    }

    /// True when the left flap currently shows (docked, or revealed overlay).
    pub(crate) fn left_flap_open(&self) -> bool {
        self.left_flap.is_open(self.left_mode)
    }
    /// True when the right flap (members / thread) currently shows.
    pub(crate) fn right_flap_open(&self) -> bool {
        self.right_flap.is_open(self.right_mode)
    }

    /// X where the left pane currently starts. In overlay mode it slides in
    /// from off the left edge as `reveal` rises.
    pub(crate) fn left_pane_x0(&self) -> f64 {
        match self.left_mode {
            FlapMode::Docked => self.rect.x0,
            FlapMode::Overlay => {
                self.rect.x0 - Self::left_pane_w() * (1.0 - self.left_flap.slide())
            }
        }
    }

    /// X where the right pane currently starts (its left edge).
    pub(crate) fn right_pane_x0(&self) -> f64 {
        let w = THREAD_W;
        match self.right_mode {
            FlapMode::Docked => self.rect.x1 - w,
            FlapMode::Overlay => self.rect.x1 - w * self.right_flap.slide(),
        }
    }

    // --- region geometry --------------------------------------------------
    pub(crate) fn rail_rect(&self) -> Rect {
        let x0 = self.left_pane_x0();
        Rect::new(x0, self.rect.y0, x0 + RAIL_W, self.rect.y1)
    }
    pub(crate) fn sidebar_rect(&self) -> Rect {
        let x0 = self.left_pane_x0() + RAIL_W;
        Rect::new(x0, self.rect.y0, x0 + SIDE_W, self.rect.y1)
    }
    /// Right edge of the centre column. In docked mode it yields room to a
    /// revealed right flap; in overlay mode the content spans full width and
    /// the flap floats over it.
    pub(crate) fn center_right(&self) -> f64 {
        if self.right_mode == FlapMode::Docked && self.right_flap_open() {
            self.rect.x1 - THREAD_W
        } else {
            self.rect.x1
        }
    }
    pub(crate) fn center_left(&self) -> f64 {
        if self.left_mode == FlapMode::Docked && self.left_flap_open() {
            self.rect.x0 + Self::left_pane_w()
        } else {
            // Overlay (or hidden docked): content reclaims the pane width;
            // leave room for the floating flap toggle button.
            self.rect.x0
        }
    }
    pub(crate) fn header_rect(&self) -> Rect {
        Rect::new(
            self.center_left(),
            self.rect.y0,
            self.center_right(),
            self.rect.y0 + HEADER_H,
        )
    }
    pub(crate) fn composer_height(&self, tr: &mut TextRenderer) -> f64 {
        let w = (self.center_right() - self.center_left() - 48.0).max(40.0) as f32;
        let (_, h) = tr.measure(self.draft_main.as_str(), 15.0, Some(w));
        (COMPOSER_MIN_H + (f64::from(h) - 19.0).max(0.0)).clamp(COMPOSER_MIN_H, COMPOSER_MAX_H)
    }
    pub(crate) fn composer_rect(&self, tr: &mut TextRenderer) -> Rect {
        let h = self.composer_height(tr);
        Rect::new(
            self.center_left() + 14.0,
            self.rect.y1 - h - 12.0,
            self.center_right() - 14.0,
            self.rect.y1 - 12.0,
        )
    }
    pub(crate) fn messages_rect(&self, tr: &mut TextRenderer) -> Rect {
        let composer = self.composer_rect(tr);
        Rect::new(
            self.center_left(),
            self.rect.y0 + HEADER_H,
            self.center_right(),
            composer.y0 - 6.0,
        )
    }
    pub(crate) fn thread_rect(&self) -> Rect {
        // A thread is content, not a secondary sidebar. On a narrow window it
        // becomes the pushed detail view rather than a cramped popover.
        if self.right_mode == FlapMode::Overlay && self.thread_open.is_some() {
            return self.rect;
        }
        let x0 = self.right_pane_x0();
        Rect::new(x0, self.rect.y0, x0 + THREAD_W, self.rect.y1)
    }

    /// Resolve flap modes from the current width and advance their eased
    /// reveals. Called once per frame at the top of `draw`. Returns true
    /// while either flap is still animating (so the host keeps redrawing).
    pub(crate) fn reconcile_flaps(&mut self) -> bool {
        let w = self.rect.width();
        // Ignore a degenerate pre-layout frame: resolving the flap mode from a
        // zero width would snap it to the overlay default before the real
        // window size is known. Wait for a genuine allocation so the first
        // reconcile lands on the actual breakpoint.
        if w < 1.0 {
            return false;
        }
        self.left_mode = FlapMode::from_width(w, LEFT_BREAKPOINT);
        self.right_mode = FlapMode::from_width(w, RIGHT_BREAKPOINT);
        self.left_flap.reconcile(self.left_mode);
        self.right_flap.reconcile(self.right_mode);
        let a = self.left_flap.tick(self.left_mode);
        let b = self.right_flap.tick(self.right_mode);
        self.flap_animating = a || b;
        a || b
    }

    /// Keep the active workspace / channel / thread pointing at something that
    /// exists — used after seeding a fresh (real) starter whose ids differ
    /// from the demo defaults, and after any structural delete. Returns true
    /// when the active workspace changed (the caller must reload so the
    /// channel + message lists refresh).
    pub(crate) fn ensure_selection(&mut self) -> bool {
        let mut ws_changed = false;
        if !self.workspaces.iter().any(|w| w.id == self.active_ws)
            && let Some(first) = self.workspaces.first()
        {
            self.active_ws = first.id.clone();
            self.context_ws = first.id.clone();
            self.active_channel.clear();
            ws_changed = true;
        }
        // Drop a stale open thread whose parent isn't in this workspace.
        if let Some(t) = self.thread_open.clone()
            && self.message(&t).is_none()
        {
            self.thread_open = None;
            if self.focus == Focus::Thread {
                self.focus = Focus::Main;
            }
        }
        ws_changed
    }

    /// Synchronously warm the attachment-image cache for the current channel,
    /// blocking briefly so a single offscreen `--shots` frame paints the real
    /// decoded images. Never call this on the live UI thread — there the store
    /// loads in the background and surfaces on a later frame.
    pub fn prewarm_images(&self) {
        // `self.messages` already holds every message in the active channel,
        // including threaded replies and the thread parent, so one pass covers
        // the timeline and the open thread panel.
        for m in &self.messages {
            if let Some(crate::model::Attachment::Image { blob, .. }) = &m.attachment {
                // Never hydrate the bytes of an embed this peer isn't granted.
                if self.embed_allowed(blob) {
                    let _ = self.images.get(&crate::images::blob_key(blob));
                }
            }
        }
        // Also warm any thumbnails visible in an open attachment picker.
        for e in &self.attach_entries {
            let _ = self.images.get(&e.key());
        }
        self.images
            .block_until_idle(std::time::Duration::from_secs(3));
    }

    /// The host-tile video rect for the current call mode, including the
    /// dragged overlay offset (docked huddle only — the expanded grid is
    /// anchored). The single source of truth for both the `VideoPlayer` node
    /// placement and the surrounding call chrome.
    pub(crate) fn call_video_rect(&self) -> Rect {
        if self.call.expanded {
            // The host is the first cell of the responsive participant grid,
            // so the tile (and the VideoPlayer surface beneath it) fills its
            // share of the surface at every width — never a fixed fraction
            // that leaves the rest of the overlay empty.
            self.overlay_host_rect()
        } else {
            self.call
                .placement
                .rect(self.rect, self.desktop_floating_bounds())
        }
    }

    pub(crate) fn desktop_floating_bounds(&self) -> Rect {
        if self.floating_surface_bounds.area() > 0.0 {
            self.floating_surface_bounds
        } else {
            self.rect
        }
    }

    pub(crate) fn push_hit(hits: &mut Vec<(Rect, Hit)>, rect: Rect, hit: Hit) {
        hits.push((rect, hit));
    }

    /// Pointer, keyboard and assistive technology all derive from this one
    /// immediate-mode control inventory. Purely decorative/scrim targets stay
    /// out; every included row has a useful spoken name and an activation path.
    #[allow(
        clippy::too_many_lines,
        reason = "one exhaustive semantic mapping keeps pointer, keyboard and assistive labels from drifting into separate inventories"
    )]
    pub(crate) fn semantic_hits_from(
        &self,
        hits: &[(Rect, Hit)],
    ) -> Vec<(Rect, Hit, String, ui::a11y::Role, bool)> {
        use ui::a11y::Role;

        hits.iter()
            .filter_map(|(rect, hit)| {
                let (name, role, selected) = match hit {
                    Hit::Inbox => {
                        let unread: u32 = self.channels.iter().map(|channel| channel.unread).sum();
                        let suffix = if unread == 0 {
                            String::new()
                        } else {
                            format!(", {unread} unread")
                        };
                        (format!("Inbox{suffix}"), Role::Tab, self.inbox_open)
                    }
                    Hit::CurrentContext => {
                        let name = self
                            .workspaces
                            .iter()
                            .find(|workspace| workspace.id == self.context_ws)
                            .map_or("Current workspace", |workspace| workspace.name.as_str());
                        (
                            format!("{name} channels, current workspace"),
                            Role::Tab,
                            !self.inbox_open,
                        )
                    }
                    Hit::Channel(id) | Hit::VoiceChannel(id) => {
                        let channel = self.channel(id)?;
                        let source = self
                            .workspaces
                            .iter()
                            .find(|workspace| workspace.id == channel.workspace)
                            .map_or("qOS workspace", |workspace| workspace.name.as_str());
                        let unread = if channel.unread == 0 {
                            String::new()
                        } else {
                            format!(", {} unread", channel.unread)
                        };
                        let context = if self.inbox_open {
                            format!(", from {source}")
                        } else {
                            String::new()
                        };
                        (
                            format!("{} {}{context}{unread}", channel.kind.glyph(), channel.name),
                            Role::ListItem,
                            channel.id == self.active_channel,
                        )
                    }
                    Hit::CategoryToggle(id) => {
                        let category = self.categories.iter().find(|category| category.id == *id);
                        let name = category.map_or("category", |category| category.name.as_str());
                        let collapsed = category.is_some_and(|category| category.collapsed);
                        (
                            format!("{} {name}", if collapsed { "Expand" } else { "Collapse" }),
                            Role::ToggleButton,
                            !collapsed,
                        )
                    }
                    Hit::AddChannel { .. } => ("Add channel".into(), Role::Button, false),
                    Hit::AddCategory(_) => ("Add category".into(), Role::Button, false),
                    Hit::FocusRename => ("Rename field".into(), Role::TextInput, false),
                    Hit::FocusEdit => ("Edit message".into(), Role::MultilineTextInput, false),
                    Hit::FocusMain => ("Message composer".into(), Role::MultilineTextInput, false),
                    Hit::FocusThread => (
                        "Thread reply composer".into(),
                        Role::MultilineTextInput,
                        false,
                    ),
                    Hit::Send => ("Send message".into(), Role::Button, false),
                    Hit::ComposerEmoji(_) => ("Insert emoji".into(), Role::Button, false),
                    Hit::Attach => ("Attach a workspace file".into(), Role::Button, false),
                    Hit::AttachPick(path) => (
                        format!(
                            "Attach {}",
                            std::path::Path::new(path)
                                .file_name()
                                .and_then(std::ffi::OsStr::to_str)
                                .unwrap_or(path)
                        ),
                        Role::Button,
                        false,
                    ),
                    Hit::StartCall => ("Start or open call".into(), Role::Button, false),
                    Hit::ToggleLeftFlap => {
                        ("Show conversation navigation".into(), Role::Button, false)
                    }
                    Hit::ToggleRightFlap => ("Show people or thread".into(), Role::Button, false),
                    Hit::OpenThread(_) => ("Open message thread".into(), Role::Button, false),
                    Hit::CloseThread => ("Close thread".into(), Role::Button, false),
                    Hit::Reaction { msg, emoji } => {
                        let mine = self
                            .message(msg)
                            .and_then(|message| {
                                message
                                    .reactions
                                    .iter()
                                    .find(|reaction| reaction.emoji == *emoji)
                            })
                            .is_some_and(|reaction| reaction.reacted_by(&self.me.id));
                        (
                            format!("{} {} reaction", if mine { "Remove" } else { "Add" }, emoji),
                            Role::ToggleButton,
                            mine,
                        )
                    }
                    Hit::AddReaction { .. } => ("Add reaction".into(), Role::Button, false),
                    Hit::EmojiChoice(emoji) => (format!("Choose {emoji}"), Role::Button, false),
                    Hit::EditHistory { .. } => ("Show edit history".into(), Role::Button, false),
                    Hit::EditSave => ("Save message edit".into(), Role::Button, false),
                    Hit::EditCancel => ("Cancel message edit".into(), Role::Button, false),
                    Hit::CallMute => (
                        "Mute microphone".into(),
                        Role::ToggleButton,
                        self.call.muted,
                    ),
                    Hit::CallDeafen => (
                        "Deafen call audio".into(),
                        Role::ToggleButton,
                        self.call.deafened,
                    ),
                    Hit::CallAudioOnly => (
                        "Turn camera off".into(),
                        Role::ToggleButton,
                        self.call.audio_only,
                    ),
                    Hit::CallShareScreen => {
                        ("Share screen".into(), Role::ToggleButton, self.call.sharing)
                    }
                    Hit::CallParticipantsToggle => (
                        "Show call participants".into(),
                        Role::ToggleButton,
                        self.call.participants_expanded,
                    ),
                    Hit::CallExpand => (
                        "Expand or restore call".into(),
                        Role::Button,
                        self.call.expanded,
                    ),
                    Hit::CallLeave => ("Leave call".into(), Role::Button, false),
                    _ => return None,
                };
                Some((*rect, hit.clone(), name, role, selected))
            })
            .collect()
    }

    pub(crate) fn semantic_hits(&self) -> Vec<(Rect, Hit, String, ui::a11y::Role, bool)> {
        Self::deduplicate_semantic_hits(self.semantic_hits_from(&self.hits))
    }

    pub(crate) fn hover_tooltip_target(&self, point: Point) -> Option<(Rect, String)> {
        if let Some((rect, hit)) = self.hits.iter().rev().find(|(rect, hit)| {
            rect.contains(point)
                && matches!(
                    hit,
                    Hit::Inbox
                        | Hit::CurrentContext
                        | Hit::ToggleLeftFlap
                        | Hit::ToggleRightFlap
                        | Hit::Attach
                        | Hit::Send
                        | Hit::ComposerEmoji(_)
                        | Hit::AddReaction { .. }
                )
        }) && let Some((_, _, label, _, _)) = self
            .semantic_hits_from(&[(*rect, hit.clone())])
            .into_iter()
            .next()
        {
            return Some((*rect, label));
        }
        // Do not let the broad title region lend its text to a labelled
        // control layered above it (for example the Call button).
        if self
            .hits
            .iter()
            .rev()
            .any(|(rect, hit)| rect.contains(point) && !matches!(hit, Hit::Dismiss))
        {
            return None;
        }
        let header = self.header_rect();
        if header.contains(point)
            && let Some(channel) = self.channel(&self.active_channel)
        {
            let mut label = format!("{} {}", channel.kind.glyph(), channel.name);
            if !channel.topic.trim().is_empty() {
                label.push_str(" — ");
                label.push_str(channel.topic.trim());
            }
            return Some((header, label));
        }
        None
    }

    /// A semantic target names an operation, not a particular paint pass. A
    /// message can appear in both timeline and thread briefly; exporting one
    /// retained node keeps that operation's target unambiguous.
    fn deduplicate_semantic_hits(
        hits: Vec<(Rect, Hit, String, ui::a11y::Role, bool)>,
    ) -> Vec<(Rect, Hit, String, ui::a11y::Role, bool)> {
        let mut targets = std::collections::HashSet::new();
        hits.into_iter()
            .filter(|(_, hit, ..)| targets.insert(hit.semantic_id()))
            .collect()
    }
}

/// Compute an absolute rect from window-relative fractions.
pub(crate) fn frac_rect(win: Rect, f: (f64, f64, f64, f64)) -> Rect {
    let x0 = win.x0 + f.0 * win.width();
    let y0 = win.y0 + f.1 * win.height();
    Rect::new(x0, y0, x0 + f.2 * win.width(), y0 + f.3 * win.height())
}

fn chat_navigation_kind(kind: qos_actions::OperationKind) -> Result<bool, String> {
    match kind {
        qos_actions::OperationKind::Document => Ok(false),
        qos_actions::OperationKind::View => Ok(true),
        qos_actions::OperationKind::Effect => {
            Err("Chat navigation requires a View operation".into())
        }
    }
}

impl Widget for ChatApp {
    fn sync(&mut self, doc: &mut AutoCommit, _path: &ObjId) {
        if self.is_live {
            // Live instance. `app-state` has already restored the previous
            // session's document by now, so an unseeded document really is a
            // first run: scaffold a real, empty starter workspace for this
            // user — never the demo.
            // Keyed off `is_live` (not on whether anything persisted) so a
            // live run with no data dir still gets the honest empty starter
            // rather than the demo.
            if !ChatDoc::is_seeded(doc) {
                ChatDoc::seed_starter(doc, &self.me.id, &self.me.name, &self.me.initials);
            }
            // Announce this peer into the shared roster so every other
            // participant sees its real name/colour — whether we seeded the
            // workspace or adopted a peer's shared document. Guarded so it
            // writes once and doesn't churn the doc (which would spam empty
            // collab deltas) on subsequent frames.
            if ChatDoc::ensure_user(
                doc,
                &self.me.id,
                &self.me.name,
                &self.me.initials,
                self.me.color_idx,
                model::Presence::Online,
            ) {}
        } else if self.shot_starter {
            // `--shots` capture of the honest first-run empty workspace.
            ChatDoc::seed_starter(doc, &self.me.id, &self.me.name, &self.me.initials);
        } else {
            // Ephemeral `--shots`/test instance: the rich demo workspace.
            ChatDoc::seed_if_empty(doc);
        }
        if !self.legacy_migration_attempted {
            ChatDoc::migrate_legacy_attachment_paths(doc);
            self.legacy_migration_attempted = true;
        }
        if self.screen_share_needs_sync {
            self.sync_local_sharing(doc);
            self.screen_share_needs_sync = false;
            self.request_relayout();
        }
        self.settle_attachment_picker();
        self.settle_attachment_import(doc);
        self.reload(doc);
        if self.ensure_selection() {
            // Re-picking the workspace changes which channels/messages apply.
            self.reload(doc);
        }
        // The channel in view is read: advance its watermark (no-op when
        // nothing new arrived) so its unread badge stays cleared.
        self.mark_active_read(doc);
        // While in a call, keep the media signalling handshake current: dial
        // any peer that has joined since the last frame (idempotent).
        if self.call.active {
            self.connect_call_peers(doc);
        }
        // Move real media: capture mic/camera/screen → encode → publish, and
        // decode/play whatever arrived from peers. No-op without `live-media`.
        #[cfg(feature = "live-media")]
        self.pump_media();
    }

    fn build_layout(
        &mut self,
        taffy: &mut TaffyTree<()>,
        _theme: &Theme,
        node_map: &mut HashMap<NodeId, *mut dyn Widget>,
    ) -> NodeId {
        // The host video tile is an absolute leaf. In the docked huddle it
        // sits at a *fractional* home (sized correctly even before `self.rect`
        // is known); the dragged overlay offset is applied as an origin shift
        // in `apply_layout`. In the expanded overlay it instead tracks the
        // first cell of the responsive participant grid so the surface fills
        // its share at every width. That cell depends on the window size, so
        // it is expressed in absolute px derived from the last known
        // `self.rect`; before any layout pass the rect is empty, in which case
        // the node collapses to zero size (nothing to paint) and the next
        // frame — once the real size is known — positions it exactly.
        let video_style = if self.call.expanded {
            let host = self.call_video_rect();
            let (left, top, w, h) = if host.width() > 1.0 && host.height() > 1.0 {
                (
                    (host.x0 - self.rect.x0) as f32,
                    (host.y0 - self.rect.y0) as f32,
                    host.width() as f32,
                    host.height() as f32,
                )
            } else {
                (0.0, 0.0, 0.0, 0.0)
            };
            Style {
                position: Position::Absolute,
                inset: taffy::Rect {
                    left: taffy::style_helpers::length(left),
                    top: taffy::style_helpers::length(top),
                    right: LengthPercentageAuto::auto(),
                    bottom: LengthPercentageAuto::auto(),
                },
                size: Size {
                    width: taffy::style_helpers::length(w),
                    height: taffy::style_helpers::length(h),
                },
                ..Default::default()
            }
        } else {
            let f = HUDDLE_VIDEO;
            Style {
                position: Position::Absolute,
                inset: taffy::Rect {
                    left: percent(f.0 as f32),
                    top: percent(f.1 as f32),
                    right: LengthPercentageAuto::auto(),
                    bottom: LengthPercentageAuto::auto(),
                },
                size: Size {
                    width: percent(f.2 as f32),
                    height: percent(f.3 as f32),
                },
                ..Default::default()
            }
        };
        // `new_leaf` on a freshly created tree never fails.
        #[allow(clippy::unwrap_used, reason = "new_leaf on a fresh tree cannot fail")]
        let video_node = taffy.new_leaf(video_style).unwrap();
        node_map.insert(video_node, &raw mut self.video as *mut dyn Widget);
        self.video_node = Some(video_node);

        // `new_with_children` only fails when a child belongs to a different
        // tree; `video_node` was just built in this one above.
        #[allow(
            clippy::unwrap_used,
            reason = "video_node was just created in this same tree"
        )]
        let root = taffy
            .new_with_children(
                Style {
                    size: Size {
                        width: percent(1.0_f32),
                        height: percent(1.0_f32),
                    },
                    ..Default::default()
                },
                &[video_node],
            )
            .unwrap();
        node_map.insert(root, std::ptr::from_mut::<dyn Widget>(self));
        self.root_node = Some(root);
        root
    }

    fn apply_layout(&mut self, taffy: &TaffyTree<()>, node: NodeId, origin: Point) {
        let Ok(layout) = taffy.layout(node) else {
            return;
        };
        self.rect = Rect::new(
            origin.x + f64::from(layout.location.x),
            origin.y + f64::from(layout.location.y),
            origin.x + f64::from(layout.location.x) + f64::from(layout.size.width),
            origin.y + f64::from(layout.location.y) + f64::from(layout.size.height),
        );
        if !self.call.expanded {
            let lower_chrome = self.huddle_attached_lower_chrome();
            self.call
                .placement
                .set_preferred_size(frac_rect(self.rect, HUDDLE_VIDEO).size());
            self.call
                .placement
                .set_attached_chrome([12.0, 40.0, 12.0, lower_chrome]);
        }
        if let Some(vn) = self.video_node {
            // The docked tile's taffy node retains its responsive fractional
            // size, while the shared floating placement owns its actual
            // origin. Offset the node's origin so its resolved local location
            // lands exactly on that shared rect.
            let off = if self.call.expanded {
                Point::new(self.rect.x0, self.rect.y0)
            } else {
                let desired = self.call_video_rect();
                let video_layout = taffy.layout(vn).copied().unwrap_or_default();
                Point::new(
                    desired.x0 - f64::from(video_layout.location.x),
                    desired.y0 - f64::from(video_layout.location.y),
                )
            };
            self.video.apply_layout(taffy, vn, off);
        }
    }

    fn draw(
        &mut self,
        scene: &mut Scene,
        tf: Affine,
        tr: &mut TextRenderer,
        theme: &Theme,
        presence: &PresenceCtx,
    ) {
        // Resolve flap modes + advance their eased reveals for this frame.
        self.reconcile_flaps();
        self.reconcile_huddle_motion(theme);
        self.tooltips.tick(std::time::Instant::now());

        let mut hits: Vec<(Rect, Hit)> = Vec::new();
        let c = &theme.tokens.colors;

        // Base canvas.
        crate::paint::fill_rect(scene, tf, self.rect, c.surfaces.base);

        // Header + conversation occupy the centre column.
        self.draw_header(scene, tf, tr, theme, &mut hits);
        let msg_area = self.messages_rect(tr);
        crate::paint::push_clip(scene, tf, msg_area);
        self.draw_messages(scene, tf, tr, theme, presence, msg_area, &mut hits);
        scene.pop_layer();
        self.draw_composer(scene, tf, tr, theme, presence, &mut hits);

        // Right flap (members / thread). In overlay mode a scrim dims the
        // content behind the floating panel.
        if self.right_mode == FlapMode::Overlay && self.right_flap.reveal() > 0.001 {
            let a = (self.right_flap.reveal() * 0.55) as f32;
            crate::paint::fill_rect(
                scene,
                tf,
                self.rect,
                c.surfaces.overlay.with_alpha_factor(a),
            );
            ChatApp::push_hit(&mut hits, self.rect, Hit::Dismiss);
        }
        if self.right_flap_open() || self.right_flap.reveal() > 0.001 {
            // The right flap is "members / thread": it shows the open thread
            // when one is up, otherwise the workspace members roster (so the
            // "👥 N" pill always reveals a real panel, never a blank column).
            if self.thread_open.is_some() {
                self.draw_thread(scene, tf, tr, theme, presence, &mut hits);
            } else {
                self.draw_members(scene, tf, tr, theme, &mut hits);
            }
        }

        // Left flap (rail + channel sidebar). Overlay scrim first.
        if self.left_mode == FlapMode::Overlay && self.left_flap.reveal() > 0.001 {
            let a = (self.left_flap.reveal() * 0.55) as f32;
            crate::paint::fill_rect(
                scene,
                tf,
                self.rect,
                c.surfaces.overlay.with_alpha_factor(a),
            );
            ChatApp::push_hit(&mut hits, self.rect, Hit::Dismiss);
        }
        if self.left_flap_open() || self.left_flap.reveal() > 0.001 {
            self.draw_rail(scene, tf, tr, theme, &mut hits);
            self.draw_sidebar(scene, tf, tr, theme, presence, &mut hits);
        }

        // Flap toggle buttons (hamburger / members) float over the header in
        // overlay mode (or whenever a flap is hidden).
        self.draw_flap_toggles(scene, tf, tr, theme, &mut hits);

        // Call layers. The host tile is a real VideoPlayer; with no live
        // capture feeding it (there is no camera here) it paints an honest
        // "camera off" placeholder rather than any fabricated frame.
        // The host tile's VideoPlayer surface is painted only once a real
        // capture has fed it a frame; otherwise the honest "camera off"
        // placeholder (drawn from live geometry) fully covers the host tile. The
        // guard also avoids the surface node — whose taffy geometry lags a beat
        // behind `self.rect` on a single headless `--shots` frame — painting a
        // stray mark at its stale origin before the placeholder lands.
        let host_has_frame = self.video.latest_frame().is_some();
        if self.call.active && self.call.expanded {
            self.draw_call_overlay_bg(scene, tf, tr, theme);
            if host_has_frame {
                self.video.draw(scene, tf, tr, theme, presence);
            }
            self.draw_host_camera_off(scene, tf, tr, theme);
            self.draw_call_overlay_fg(scene, tf, tr, theme, &mut hits);
        } else if self.call.active
            && ((!self.call.placement.is_return_pending()
                && matches!(
                    self.call.placement.attachment(),
                    ui::floating_surface::Attachment::App { .. }
                ))
                || !self.call.placement.is_desktop_covered())
        {
            self.draw_live_huddle(scene, tf, tr, theme, presence, &mut hits);
        }

        // Top-most popovers.
        if let Some(menu) = self.menu.clone() {
            self.draw_context_menu(scene, tf, tr, theme, &menu, &mut hits);
        }
        if self.emoji_open {
            self.draw_emoji_picker(scene, tf, tr, theme, &mut hits);
        }
        if self.history_open.is_some() {
            self.draw_history_popover(scene, tf, tr, theme, &mut hits);
        }
        if self.attach_open {
            self.draw_attach_picker(scene, tf, tr, theme, &mut hits);
        }

        // Immediate-mode keyboard focus needs a visible counterpart. The ring
        // is painted last so it remains legible on rail, sidebar and popovers.
        let semantic = Self::deduplicate_semantic_hits(self.semantic_hits_from(&hits));
        if let Some(index) = self.keyboard_target {
            if let Some((rect, ..)) = semantic.get(index) {
                crate::paint::stroke_round(scene, tf, *rect, 9.0, c.accent[7], 2.0);
            } else {
                self.keyboard_target = None;
            }
        }

        if let Some((label, anchor)) = self.tooltips.visible() {
            ui::widget::tooltip::draw_hover_tooltip(scene, tf, tr, theme, anchor, label, self.rect);
        }

        self.hits = hits;
    }

    fn draw_with_presence(
        &mut self,
        scene: &mut Scene,
        tf: Affine,
        tr: &mut TextRenderer,
        theme: &Theme,
        presence: &PresenceCtx,
        permissions: &PermissionContext,
    ) {
        // Adopt the OS-provided permission context so channel participation and
        // file-embed hydration are gated by the real grant policy (the
        // compositor hands each app its context here every frame).
        self.perms = ChatPermissions::from_context(permissions.clone());
        // Adopt the room's answer for who everybody is. Names and colours are
        // the room's to give: they arrive on the collaboration context stream
        // and land in the presence store, and this is the one door an app has
        // onto that store. Taken before `draw` so the same frame that learns a
        // name paints it.
        self.adopt_room(presence);
        // Root spans the whole window — always paint.
        self.draw(scene, tf, tr, theme, presence);
    }

    fn handle_event(
        &mut self,
        event: &WindowEvent,
        scale_factor: f64,
        modifiers: &winit::event::Modifiers,
        state: &mut AutoCommit,
        _path: &ObjId,
        handled: &mut bool,
        _focus_target: &mut Option<NodeId>,
        _node_id: NodeId,
        _taffy: &TaffyTree<()>,
    ) {
        self.dispatch_event(event, scale_factor, *modifiers, state, handled);
    }

    /// The resource tree Chat currently has open — the active workspace, its
    /// channels, and the open channel's messages — each exporting the actions
    /// Ctrl+K offers. Delegates to the [`ResourceProvider`](qos_actions::ResourceProvider)
    /// impl in [`crate::actions`], the same builder the affordance covenant tests
    /// drive. Recomputed each frame; empty until a workspace is selected.
    fn resources(&self, doc: &AutoCommit) -> Vec<qos_actions::Resource> {
        <Self as qos_actions::ResourceProvider>::resources(self, doc)
    }

    fn resource(&self, doc: &AutoCommit, id: &str) -> Option<qos_actions::Resource> {
        <Self as qos_actions::ResourceProvider>::resource(self, doc, id)
    }

    fn accessibility(&self) -> Option<ui::a11y::AccessNode> {
        use ui::a11y::{AccessNode, AccessState, Role};

        let controls = self
            .semantic_hits()
            .into_iter()
            .enumerate()
            .map(|(index, (rect, hit, name, role, selected))| {
                let mut state = AccessState::new()
                    .focusable(true)
                    .focused(self.keyboard_target == Some(index));
                if matches!(role, Role::Tab | Role::ListItem) {
                    state = state.selected(selected);
                }
                if matches!(role, Role::ToggleButton) {
                    state = state.checked(selected);
                }
                let mut node = AccessNode::new(role)
                    .with_name(name)
                    .with_state(state)
                    .with_bounds(rect)
                    .with_key(index as u64)
                    .with_action_target(hit.semantic_id());
                let input = match hit {
                    Hit::FocusMain => Some(&self.composer_main),
                    Hit::FocusThread => Some(&self.composer_thread),
                    Hit::FocusRename => Some(&self.rename_input),
                    Hit::FocusEdit => Some(&self.edit_input),
                    _ => None,
                };
                if let Some(input) = input {
                    let (anchor, focus) = input
                        .selection_range_public()
                        .unwrap_or_else(|| (input.cursor_pos(), input.cursor_pos()));
                    node = node
                        .with_value(input.value())
                        .with_text_selection(anchor, focus);
                }
                node
            })
            .collect();

        let conversation = self
            .messages
            .iter()
            .filter(|message| message.parent.is_none())
            .map(|message| {
                let author = self
                    .user(&message.author)
                    .map_or("Unknown person", |user| user.name.as_str());
                AccessNode::new(Role::ListItem)
                    .with_name(format!("{author}: {}", message.text))
                    .with_hashed_key((&message.id, "message"))
            })
            .collect();
        let conversation = AccessNode::new(Role::List)
            .with_name("Messages")
            .with_children(conversation)
            .with_hashed_key("message-list");

        let mut children: Vec<AccessNode> = controls;
        if let Some(channel) = self.channel(&self.active_channel) {
            let mut heading = AccessNode::new(Role::Heading { level: 1 })
                .with_name(format!("{} {}", channel.kind.glyph(), channel.name))
                .with_bounds(self.header_rect())
                .with_hashed_key(("conversation-heading", &channel.id));
            if !channel.topic.trim().is_empty() {
                // The desktop header deliberately elides the topic before the
                // member/call cluster, and narrow layouts may omit it entirely.
                // Keep the complete string available to screen readers.
                heading = heading.with_description(channel.topic.clone());
            }
            children.push(heading);
        }
        children.push(conversation);
        Some(
            AccessNode::new(Role::Group)
                .with_name("Chat")
                .with_description(if self.inbox_open {
                    "Inbox: conversations across qOS workspaces"
                } else {
                    "Channels in the current qOS workspace"
                })
                .with_children(children),
        )
    }

    fn synthetic_accessibility_rect(&self, path: &[usize]) -> Option<Rect> {
        let [index] = path else {
            return None;
        };
        self.semantic_hits().get(*index).map(|(rect, ..)| *rect)
    }

    fn focus_synthetic_accessibility(&mut self, path: &[usize]) -> bool {
        let [index] = path else {
            return false;
        };
        if *index >= self.semantic_hits().len() {
            return false;
        }
        self.keyboard_target = Some(*index);
        true
    }

    /// Semantic targets are the same inventory used by pointer and Tab/Enter
    /// input. Keeping this adapter at the widget boundary prevents an
    /// assistive-technology activation from taking a separate, untracked
    /// mutation path: `on_hit` builds the same `ChatAction` and delegates it
    /// to `ActionHost` for history and collaboration.
    fn perform_semantic_action(
        &mut self,
        target: &str,
        action: &ui::a11y::Action,
        state: &mut AutoCommit,
        path: &ObjId,
    ) -> bool {
        let hit = self
            .semantic_hits()
            .into_iter()
            .find_map(|(_, hit, ..)| (hit.semantic_id() == target).then_some(hit));
        let Some(hit) = hit else {
            return false;
        };
        // These immediate-mode editors are real TextInputs, even though their
        // chrome is painted by Chat. Preserve their truthful text semantics:
        // focus goes through the same focus route as a click, values remain a
        // local draft until Send/Save, and selections stay inside the toolkit
        // editor rather than becoming a second text model.
        if matches!(
            hit,
            Hit::FocusMain | Hit::FocusThread | Hit::FocusRename | Hit::FocusEdit
        ) {
            use ui::a11y::Action;

            match action {
                Action::Focus | Action::Activate => {
                    self.on_hit(hit, state);
                    return true;
                }
                Action::SetValue(_) | Action::SetSelection { .. } => match hit {
                    Hit::FocusMain => {
                        self.focus = Focus::Main;
                        if !ui::Widget::perform_action(&mut self.composer_main, action, state, path)
                        {
                            return false;
                        }
                        ChatDoc::set_draft(state, &self.active_channel, self.composer_main.value());
                        self.reload(state);
                    }
                    Hit::FocusThread => {
                        let Some(key) = self.thread_draft_key() else {
                            return false;
                        };
                        self.focus = Focus::Thread;
                        if !ui::Widget::perform_action(
                            &mut self.composer_thread,
                            action,
                            state,
                            path,
                        ) {
                            return false;
                        }
                        ChatDoc::set_draft(state, &key, self.composer_thread.value());
                        self.reload(state);
                    }
                    Hit::FocusRename => {
                        if self.rename.is_none() {
                            return false;
                        }
                        if !ui::Widget::perform_action(&mut self.rename_input, action, state, path)
                        {
                            return false;
                        }
                    }
                    Hit::FocusEdit => {
                        if self.editing.is_none() {
                            return false;
                        }
                        if !ui::Widget::perform_action(&mut self.edit_input, action, state, path) {
                            return false;
                        }
                    }
                    _ => return false,
                },
                _ => return false,
            }
            self.set_composer_focus();
            return true;
        }
        if !matches!(
            action,
            ui::a11y::Action::Activate | ui::a11y::Action::ToggleCheck
        ) {
            return false;
        }
        self.on_hit(hit, state);
        true
    }

    /// Hand the host the heads captured before an on-screen affordance dispatched
    /// its action, so it records exactly one undo boundary bracketing the event —
    /// the same path a Ctrl+K palette dispatch takes.
    fn take_committed_action(&mut self) -> Option<Vec<automerge::ChangeHash>> {
        self.actions.take_committed()
    }

    /// Fold conversations, full-text messages, and people into global search.
    /// Every result names an exported `View` action; there is no app-private
    /// activation path.
    fn search_providers(&self) -> Vec<Box<dyn ui::search::SearchProvider>> {
        vec![Box::new(crate::search_provider::ChatSearchProvider::new(
            &self.categories,
            &self.channels,
            &self.workspaces,
            &self.search_messages,
            &self.search_users,
        ))]
    }

    fn local_resource_operation_handlers(&self) -> &'static [&'static str] {
        &[crate::actions::CHAT_OPERATION_TYPE]
    }

    #[allow(
        clippy::too_many_lines,
        reason = "one exhaustive operation dispatcher preserves the resource contract at a single boundary"
    )]
    fn invoke_resource_operation(
        &mut self,
        kind: qos_actions::OperationKind,
        type_id: &str,
        payload: &[u8],
        doc: &AutoCommit,
        _path: &ObjId,
    ) -> Result<bool, String> {
        let Some(operation) = crate::actions::decode_operation(type_id, payload)? else {
            return Ok(false);
        };
        match &operation {
            crate::actions::ChatOperation::ImportAttachment { .. } => {
                if kind != qos_actions::OperationKind::Effect {
                    return Err("attachment import requires an Effect operation".into());
                }
            }
            _ if !chat_navigation_kind(kind)? => return Ok(false),
            _ => {}
        }
        match operation {
            crate::actions::ChatOperation::OpenWorkspace { workspace } => {
                self.reveal_workspace_resource(workspace)?;
            }
            crate::actions::ChatOperation::OpenChannel { workspace, channel } => {
                if !self
                    .channels
                    .iter()
                    .any(|item| item.id == channel && item.workspace == workspace)
                {
                    return Err("conversation no longer exists".into());
                }
                self.active_ws = workspace;
                self.active_channel = channel;
                self.inbox_open = false;
                self.thread_open = None;
                self.revealed_message = None;
                self.revealed_person = None;
                self.scroll = 0.0;
                self.focus = Focus::Main;
            }
            crate::actions::ChatOperation::OpenCategory {
                workspace,
                category,
            } => self.reveal_category_resource(workspace, &category)?,
            crate::actions::ChatOperation::RevealMessage {
                workspace,
                channel,
                message,
                parent,
            } => {
                if !self
                    .channels
                    .iter()
                    .any(|item| item.id == channel && item.workspace == workspace)
                {
                    return Err("conversation no longer exists".into());
                }
                if !ChatDoc::list_messages(doc, &channel)
                    .iter()
                    .any(|item| item.id == message)
                {
                    return Err("message no longer exists".into());
                }
                self.active_ws = workspace;
                self.active_channel = channel;
                self.inbox_open = false;
                self.thread_open = parent;
                self.revealed_message = Some(message);
                self.revealed_person = None;
                self.scroll = 0.0;
                self.focus = if self.thread_open.is_some() {
                    Focus::Thread
                } else {
                    Focus::Main
                };
                if self.thread_open.is_some() {
                    self.right_flap.open();
                }
            }
            crate::actions::ChatOperation::OpenPerson { user } => {
                if !ChatDoc::list_users(doc).iter().any(|item| item.id == user) {
                    return Err("person no longer exists".into());
                }
                // Prefer the current workspace when it already evidences this
                // person; otherwise open the first workspace where they wrote.
                if !self.users.iter().any(|item| item.id == user)
                    && let Some(channel) = self.channels.iter().find(|channel| {
                        ChatDoc::list_messages(doc, &channel.id)
                            .iter()
                            .any(|message| {
                                message.author == user
                                    || message.mentions.iter().any(|mention| mention.user == user)
                                    || message
                                        .reactions
                                        .iter()
                                        .any(|reaction| reaction.users.iter().any(|id| id == &user))
                            })
                    })
                {
                    self.active_ws = channel.workspace.clone();
                    self.active_channel = channel.id.clone();
                }
                self.inbox_open = false;
                self.thread_open = None;
                self.revealed_message = None;
                self.revealed_person = Some(user);
                self.focus = Focus::Main;
                self.right_flap.open();
            }
            crate::actions::ChatOperation::ImportAttachment { channel, path } => {
                if path.is_empty() {
                    return Err("attachment path is empty".into());
                }
                if !self.channels.iter().any(|item| item.id == channel) {
                    return Err("conversation no longer exists".into());
                }
                if !self.begin_attachment_import_into(&channel, std::path::Path::new(&path)) {
                    return Err("attachment import was not accepted".into());
                }
            }
        }
        Ok(true)
    }

    fn name(&self) -> &'static str {
        "ChatApp"
    }

    fn get_rect(&self) -> Rect {
        self.rect
    }

    fn take_structure_dirty(&mut self) -> bool {
        std::mem::take(&mut self.relayout)
    }

    /// Keep the loop ticking only while something is actually moving: a flap
    /// mid-slide, an overlay being dragged, or attachment images still
    /// decoding in the background. A live-but-static call does **not** force
    /// continuous redraws (the roster/rings are static), so an idle call
    /// no longer pins a core.
    fn needs_animation_frame(&self) -> bool {
        self.flap_animating
            || self.call_chrome_motion.animating
            || self.call.placement.is_dragging()
            || self.call.placement.is_handoff_animating()
            || self.tooltips.needs_frame()
            || !self.images.is_idle()
    }

    fn wants_pointer_capture(&self) -> bool {
        self.call.placement.is_dragging()
    }

    fn take_floating_surface_request(
        &mut self,
    ) -> Option<ui::floating_surface::FloatingSurfaceRequest> {
        self.pending_floating.take()
    }

    fn draw_floating_surfaces(
        &mut self,
        scene: &mut Scene,
        transform: Affine,
        text_renderer: &mut TextRenderer,
        theme: &Theme,
        presence: &PresenceCtx,
    ) {
        if !self.call.active
            || self.call.expanded
            || (!self.call.placement.is_return_pending()
                && !matches!(
                    self.call.placement.attachment(),
                    ui::floating_surface::Attachment::Desktop { .. }
                ))
        {
            return;
        }
        let mut hits = Vec::new();
        self.draw_live_huddle(scene, transform, text_renderer, theme, presence, &mut hits);
        self.hits.extend(hits);
    }

    fn floating_surface_presentations(
        &self,
    ) -> Vec<ui::floating_surface::FloatingSurfacePresentation> {
        let returning_to_app = self.call.placement.is_return_pending();
        if !self.call.active
            || self.call.expanded
            || (!returning_to_app
                && !matches!(
                    self.call.placement.attachment(),
                    ui::floating_surface::Attachment::Desktop { .. }
                ))
        {
            return Vec::new();
        }
        vec![ui::floating_surface::FloatingSurfacePresentation {
            id: format!("chat-call:{}", self.call.channel),
            content_rect: self.call_video_rect(),
            window_rect: self.huddle_panel().inflate(8.0, 8.0),
            returning_to_app,
        }]
    }

    fn active_floating_surface_ids(&self) -> Vec<String> {
        self.call
            .active
            .then(|| format!("chat-call:{}", self.call.channel))
            .into_iter()
            .collect()
    }

    fn set_floating_surface_bounds(&mut self, bounds: Rect) {
        self.floating_surface_bounds = bounds;
    }

    fn on_floating_surface_host_message(
        &mut self,
        message: &ui::floating_surface::FloatingSurfaceHostMessage,
    ) {
        let id = format!("chat-call:{}", self.call.channel);
        if let ui::floating_surface::FloatingSurfaceHostMessage::PrepareSurface {
            id: request_id,
            content_rect,
            transfer_covered,
            coordinate_offset,
            ..
        } = message
            && request_id == &id
            && let Ok(rect) = ui::floating_surface::protocol_rect(*content_rect)
        {
            self.call.placement.prepare_desktop_rect_with_offset(
                rect,
                vello::kurbo::Vec2::new(coordinate_offset[0], coordinate_offset[1]),
            );
            self.call
                .placement
                .set_desktop_transfer_covered(*transfer_covered);
            return;
        }
        if let ui::floating_surface::FloatingSurfaceHostMessage::Adopted {
            id: request_id,
            rect,
        } = message
            && request_id == &id
            && ui::floating_surface::protocol_rect(*rect).is_ok()
        {
            self.call.placement.confirm_desktop_adoption();
            return;
        }
        if matches!(
            message,
            ui::floating_surface::FloatingSurfaceHostMessage::Reattach { id: request_id }
                | ui::floating_surface::FloatingSurfaceHostMessage::Closed { id: request_id }
                if request_id == &id
        ) {
            let app = self.rect;
            let desktop = self.desktop_floating_bounds();
            self.call.placement.reattach_to_app(app, desktop);
            return;
        }
        if matches!(
            message,
            ui::floating_surface::FloatingSurfaceHostMessage::Suspended { id: request_id }
                if request_id == &id
        ) {
            self.call.placement.confirm_app_adoption(self.rect);
        }
    }

    fn needs_redraw(&self) -> bool {
        true
    }
}

impl ChatApp {
    /// The one rendering path for a docked or shell-presented huddle. The
    /// shell calls this exact method after ownership transfer, so video,
    /// participants, controls and hit regions remain live without duplication.
    fn draw_live_huddle(
        &mut self,
        scene: &mut Scene,
        transform: Affine,
        text_renderer: &mut TextRenderer,
        theme: &Theme,
        presence: &PresenceCtx,
        hits: &mut Vec<(Rect, Hit)>,
    ) {
        // The app copy, transfer proxy and native shell surface all pass
        // through this one presentation transform. Applying the handoff
        // flourish in an ownership-specific caller made the first app-owned
        // frame lose its soft deformation even though its geometry matched.
        let transform = self.call.placement.presentation_transform(
            transform,
            self.huddle_panel(),
            theme.reduce_motion,
        );
        self.draw_huddle_bg(scene, transform, text_renderer, theme, hits);
        if self.video.latest_frame().is_some() {
            self.video
                .draw(scene, transform, text_renderer, theme, presence);
        }
        self.draw_host_camera_off(scene, transform, text_renderer, theme);
        self.draw_huddle_fg(scene, transform, text_renderer, theme, hits);
    }

    /// Flag a taffy rebuild (kept for parity; the video rect is now set in
    /// `apply_layout` so most state changes don't need it, but call expand
    /// still requests a clean relayout).
    pub(crate) fn request_relayout(&mut self) {
        self.relayout = true;
    }
}

/// Wrap a decoded RGBA frame as a `peniko` image for painting into a call tile.
#[cfg(feature = "live-media")]
fn rgba_to_image(frame: &qos_callstream::DecodedFrame) -> vello::peniko::ImageData {
    use vello::peniko::{Blob, ImageAlphaType, ImageData, ImageFormat};
    ImageData {
        data: Blob::new(std::sync::Arc::new(frame.rgba.clone())),
        format: ImageFormat::Rgba8,
        alpha_type: ImageAlphaType::Alpha,
        width: frame.width,
        height: frame.height,
    }
}

/// Screen-share reuse proof: a remote peer's screen frame, encoded through the
/// shared qOS video-streaming stack, must travel the real receive path into
/// the featured-tile map. Gated on `live-media` because the video stack (and
/// the featured-tile decode) only compile there — the default/`--shots` build
/// carries no codec and shows the honest placeholder.
#[cfg(all(test, feature = "live-media"))]
mod screenshare_reuse_tests {
    use super::*;
    use crate::media::{MediaEngine, MediaObject, TrackKind};
    use qos_callstream::VideoStreamSender;
    use std::time::{Duration, Instant};

    fn gradient(width: u32, height: u32) -> Vec<u8> {
        let mut out = Vec::with_capacity((width * height * 4) as usize);
        for y in 0..height {
            for x in 0..width {
                out.extend_from_slice(&[
                    ((x * 255) / width.max(1)) as u8,
                    ((y * 255) / height.max(1)) as u8,
                    128,
                    255,
                ]);
            }
        }
        out
    }

    /// A remote screen-share frame encoded on the shared `VideoStreamSender`
    /// (throttle + H.264 + `SurfaceFrame` framing), delivered as a
    /// `TrackKind::Screen` `MediaObject`, must decode through the app's real
    /// `pump_media` receive path and land in `remote_screens` — the featured
    /// stage tile. This asserts on the production receive path (the same
    /// `VideoStreamReceiver` + decoder the app runs), proving a decoded frame
    /// reaches the tile with no second in-app codec.
    #[test]
    fn remote_screen_share_frame_reaches_the_featured_tile() {
        const W: u32 = 96;
        const H: u32 = 64;

        let mut app = ChatApp::new_ephemeral();
        // Deterministic in-process loopback transport; no network/devices.
        app.media = MediaEngine::simulated();
        app.call.active = true;
        app.call.audio_only = true; // no camera capture in the pump
        app.call.muted = true; // no mic capture in the pump

        // A remote peer encodes a screen frame through the SHARED stack.
        let mut sender = VideoStreamSender::new(W, H, 30).expect("shared-stack sender");
        let wire = sender
            .offer_frame(&gradient(W, H), Instant::now())
            .expect("shared sender accepts the frame")
            .expect("throttle admits the first frame + encoder emits a NALU");
        app.media.transport_mut().send(MediaObject {
            sender: "u_remote".into(),
            kind: TrackKind::Screen,
            seq: 0,
            pts: Duration::from_millis(0),
            payload: wire,
        });

        // Honest gating: nothing in the tile until a real frame is pumped.
        assert!(
            app.remote_screens.is_empty(),
            "no fabricated featured-tile frame before the pump"
        );

        app.pump_media();

        let img = app
            .remote_screens
            .get("u_remote")
            .expect("the decoded screen frame reached the featured tile");
        assert_eq!(
            (img.width, img.height),
            (W, H),
            "featured-tile image carries the decoded frame's dimensions"
        );
    }

    #[test]
    fn screen_stream_error_is_visible_and_unpublishes_the_track() {
        let mut app = ChatApp::new_ephemeral();
        app.call.sharing = true;
        app.screen_session = VideoStreamSender::new(96, 64, 30).ok();
        app.media.transport_mut().publish(TrackKind::Screen);

        app.stop_screen_for_error(&qos_callstream::FrameError::SequenceExhausted);

        assert!(!app.call.sharing);
        assert!(app.screen_session.is_none());
        assert!(
            app.media_error
                .as_deref()
                .is_some_and(|message| message.contains("sequence space exhausted"))
        );
    }

    #[test]
    fn oversized_screen_object_stops_the_track_instead_of_silent_transport_drop() {
        use crate::media::{MAX_MEDIA_PAYLOAD, TrackKind};
        use std::time::Duration;

        let mut app = ChatApp::new_ephemeral();
        app.call.sharing = true;
        app.screen_session = VideoStreamSender::new(96, 64, 30).ok();
        app.media.transport_mut().publish(TrackKind::Screen);

        assert!(!app.send_media_frame(
            "u_me",
            TrackKind::Screen,
            Duration::ZERO,
            vec![0; MAX_MEDIA_PAYLOAD + 1],
        ));
        assert!(!app.call.sharing);
        assert!(app.screen_session.is_none());
        assert!(app.screen_share_needs_sync);
        assert!(
            app.media_error
                .as_deref()
                .is_some_and(|message| message.contains("media limit"))
        );
    }
}

#[cfg(test)]
mod identity_on_screen {
    use super::*;

    fn user(id: &str, is_agent: bool) -> User {
        User {
            id: id.into(),
            name: id.into(),
            initials: "U".into(),
            color_idx: 0,
            status: crate::model::Presence::Online,
            is_agent,
        }
    }

    #[test]
    fn roster_vocabulary_never_calls_an_agent_a_person() {
        let mut app = ChatApp::new_ephemeral();
        app.users = vec![user("u_me", false), user("u_scribe", true)];
        assert!(
            app.has_other_collaborator(),
            "the agent is another collaborator"
        );
        assert_eq!(app.roster_label(), "Collaborators");

        app.users = vec![user("u_me", false), user("u_aria", false)];
        assert_eq!(app.roster_label(), "People");
    }

    /// Nobody is ever shown the token the system uses to route to them.
    ///
    /// A participant id is `peer@9007495404254172154` — a hash of a public
    /// key. It appeared beside messages and in the roster whenever the room
    /// had not named somebody yet, which is most of the time a peer has just
    /// arrived. It is not a name; it is the thing a name resolves from.
    #[test]
    fn an_unnamed_participant_is_not_shown_their_routing_token() {
        let app = ChatApp::new_ephemeral();
        let stranger = "peer@9007495404254172154";
        let shown = app.user_name(stranger);
        assert!(
            !shown.contains("9007495404254172154"),
            "the id leaked onto the screen as `{shown}`"
        );
        assert!(
            shown.starts_with("Someone"),
            "an unnamed peer should read as somebody unnamed, got `{shown}`"
        );
        assert!(
            shown.contains("2154"),
            "two unnamed peers have to be distinguishable, got `{shown}`"
        );
    }

    /// You have a name, and this process knows it.
    ///
    /// `LocalIdentity::resolve` derives one at startup and puts it on
    /// `me`. `display_name` consulted the room document and the roster
    /// and neither knows you until you have spoken, so the one name that
    /// was certain was the one it fell through on — and a person saw
    /// their own routing hash in the roster and in the `@` picker.
    ///
    /// This is what "referred to as You" rests on: second-person is a
    /// rendering choice, not a substitute for having a name.
    #[test]
    fn your_own_name_is_known_before_the_room_has_heard_of_you() {
        let mut app = ChatApp::new_ephemeral();
        app.me.name = "Quinten".to_string();
        app.users.clear();
        app.room_names.clear();
        assert_eq!(
            app.display_name(&app.me.id.clone()),
            "Quinten",
            "the name this process worked out for itself must be reachable",
        );
    }

    /// And you are "You".
    ///
    /// Reading your own id — or your own name — back at you is how a chat
    /// tells you it does not know who you are.
    #[test]
    fn the_person_reading_the_screen_is_you() {
        let app = ChatApp::new_ephemeral();
        let me = app.me.id.clone();
        assert_eq!(app.user_name(&me), "You");
    }
}
