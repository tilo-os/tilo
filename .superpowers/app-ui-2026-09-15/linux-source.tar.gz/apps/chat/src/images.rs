//! Attachment image loading for the chat surface.
//!
//! Image attachments are painted through the shared [`ui::ImageStore`], which
//! fetches + decodes + caches off the UI thread and hands back a GPU-ready
//! `peniko::ImageData` on a later frame. This module supplies the injected
//! [`ui::Fetcher`]: the transport that turns an attachment's blob key into raw
//! encoded bytes.
//!
//! Chat images are qdoc content-addressed blobs, not peer-local file paths.
//! The qdoc store asks the collaboration transport on a miss; this fetcher
//! runs on `ImageStore` worker threads and returns only already-verified bytes.
//!
//! The one non-filesystem case is the `qos-demo://` scheme used only by the
//! ephemeral `--shots`/demo seed: it synthesises a real PNG in memory so the
//! offline screenshot drives the exact same decode+cache+paint path a real
//! FUSE image would, without shipping binary fixtures or touching the network.

use std::io::Cursor;
use std::sync::Arc;

use ui::Fetcher;

/// URL scheme for the synthesised demo attachment thumbnails. Only the
/// ephemeral demo seed emits these; live attachments use qdoc hashes.
pub const DEMO_SCHEME: &str = "qos-demo://";
/// Prefix used for qdoc content hashes when they are handed to `ImageStore`.
pub const BLOB_SCHEME: &str = "qos-blob://";

pub fn blob_key(hash: &str) -> String {
    if hash.starts_with(DEMO_SCHEME) {
        hash.to_string()
    } else {
        format!("{BLOB_SCHEME}{hash}")
    }
}

/// A believable "call overlay mockup" attachment for the demo conversation.
pub const DEMO_CALL_GRID: &str = "qos-demo://call-grid";
/// A believable "shared screenshot" attachment for the demo `+` action.
pub const DEMO_SHARED_SHOT: &str = "qos-demo://shared-shot";

/// The fetcher injected into the app's [`ui::ImageStore`]. Reads verified qdoc
/// blob bytes or synthesises a PNG for the demo scheme. Runs on the store's
/// background worker threads.
pub fn fetcher() -> Fetcher {
    Arc::new(|key: &str| {
        if let Some(id) = key.strip_prefix(DEMO_SCHEME) {
            return synth_demo_png(id);
        }
        key.strip_prefix(BLOB_SCHEME)
            .and_then(qdoc::blobstore::get)
            .filter(|b| !b.is_empty())
    })
}

// ---------------------------------------------------------------------------
// Demo thumbnail synthesis (shots / ephemeral only)
// ---------------------------------------------------------------------------

/// Encode a real PNG for a demo attachment id, or `None` for an unknown id.
fn synth_demo_png(id: &str) -> Option<Vec<u8>> {
    let (w, h, buf) = match id {
        "call-grid" => call_grid(),
        "shared-shot" => shared_shot(),
        _ => return None,
    };
    encode_png(w, h, buf)
}

fn encode_png(w: u32, h: u32, rgba: Vec<u8>) -> Option<Vec<u8>> {
    let img = image::RgbaImage::from_raw(w, h, rgba)?;
    let mut out = Cursor::new(Vec::new());
    image::DynamicImage::ImageRgba8(img)
        .write_to(&mut out, image::ImageFormat::Png)
        .ok()?;
    Some(out.into_inner())
}

/// A tidy 2×2 call grid mockup: dark canvas, four participant tiles, the
/// top-left one lit as the active speaker. Reads unmistakably as a rendered
/// design frame rather than a flat gradient.
fn call_grid() -> (u32, u32, Vec<u8>) {
    let (w, h) = (640u32, 360u32);
    let mut c = Canvas::new(w, h);
    c.vgradient([26, 28, 38], [17, 18, 26]);

    let margin = 26.0;
    let gap = 16.0;
    let tw = (f64::from(w) - 2.0 * margin - gap) / 2.0;
    let th = (f64::from(h) - 2.0 * margin - gap) / 2.0;
    let tiles = [
        (margin, margin, [58, 74, 120], [120, 158, 255], true),
        (
            margin + tw + gap,
            margin,
            [70, 60, 96],
            [176, 150, 244],
            false,
        ),
        (
            margin,
            margin + th + gap,
            [54, 84, 84],
            [120, 214, 200],
            false,
        ),
        (
            margin + tw + gap,
            margin + th + gap,
            [92, 72, 66],
            [240, 178, 150],
            false,
        ),
    ];
    for (x, y, base, accent, active) in tiles {
        let r = Rectf { x, y, w: tw, h: th };
        c.round_rect(r, 12.0, base);
        // A camera "surface" sheen across the upper half.
        c.round_rect(
            Rectf {
                x,
                y,
                w: tw,
                h: th * 0.5,
            },
            12.0,
            lighten(base, 18),
        );
        // Centred avatar disc.
        let cx = x + tw * 0.5;
        let cy = y + th * 0.46;
        c.disc(cx, cy, th * 0.24, accent);
        c.disc(cx, cy, th * 0.24 - 6.0, lighten(accent, 26));
        // Name plate.
        c.round_rect(
            Rectf {
                x: x + 12.0,
                y: y + th - 30.0,
                w: tw * 0.44,
                h: 18.0,
            },
            6.0,
            [12, 13, 18],
        );
        if active {
            c.stroke_round(r, 12.0, [88, 214, 140], 3.0);
        }
    }
    (w, h, c.into_rgba())
}

/// A "shared screenshot" attachment: a light document window with a header
/// bar and a few content rows — clearly a captured UI, not a gradient.
fn shared_shot() -> (u32, u32, Vec<u8>) {
    let (w, h) = (620u32, 400u32);
    let mut c = Canvas::new(w, h);
    c.vgradient([32, 34, 44], [22, 23, 31]);
    let card = Rectf {
        x: 28.0,
        y: 28.0,
        w: f64::from(w) - 56.0,
        h: f64::from(h) - 56.0,
    };
    c.round_rect(card, 16.0, [244, 245, 248]);
    // Header bar.
    c.round_rect(
        Rectf {
            x: card.x,
            y: card.y,
            w: card.w,
            h: 46.0,
        },
        16.0,
        [94, 122, 232],
    );
    for i in 0..3 {
        c.disc(
            card.x + 22.0 + f64::from(i) * 20.0,
            card.y + 23.0,
            6.0,
            [255, 255, 255],
        );
    }
    // Content rows.
    let mut ry = card.y + 74.0;
    for i in 0..6 {
        let rw = card.w * if i % 3 == 0 { 0.82 } else { 0.62 };
        c.round_rect(
            Rectf {
                x: card.x + 24.0,
                y: ry,
                w: rw,
                h: 16.0,
            },
            5.0,
            [212, 216, 224],
        );
        if i % 3 == 0 {
            c.round_rect(
                Rectf {
                    x: card.x + 24.0,
                    y: ry,
                    w: 90.0,
                    h: 16.0,
                },
                5.0,
                [126, 150, 240],
            );
        }
        ry += 38.0;
    }
    (w, h, c.into_rgba())
}

// ---------------------------------------------------------------------------
// Tiny software raster canvas (enough for the two demo thumbnails)
// ---------------------------------------------------------------------------

#[derive(Clone, Copy)]
struct Rectf {
    x: f64,
    y: f64,
    w: f64,
    h: f64,
}

struct Canvas {
    w: u32,
    h: u32,
    px: Vec<u8>,
}

impl Canvas {
    fn new(w: u32, h: u32) -> Self {
        Self {
            w,
            h,
            px: vec![0u8; (w * h * 4) as usize],
        }
    }

    fn blend(&mut self, x: i32, y: i32, rgb: [u8; 3], a: f64) {
        if x < 0 || y < 0 || x >= self.w as i32 || y >= self.h as i32 || a <= 0.0 {
            return;
        }
        let i = ((y as u32 * self.w + x as u32) * 4) as usize;
        let a = a.clamp(0.0, 1.0);
        let Some(px) = self.px.get_mut(i..i + 4) else {
            return;
        };
        for (dst, src) in px.iter_mut().zip(rgb) {
            *dst = (f64::from(src) * a + f64::from(*dst) * (1.0 - a)) as u8;
        }
        if let Some(alpha) = self.px.get_mut(i + 3) {
            *alpha = 255;
        }
    }

    fn vgradient(&mut self, top: [u8; 3], bottom: [u8; 3]) {
        for y in 0..self.h {
            let t = f64::from(y) / f64::from(self.h.max(1) - 1);
            let rgb = [
                lerp(top[0], bottom[0], t),
                lerp(top[1], bottom[1], t),
                lerp(top[2], bottom[2], t),
            ];
            for x in 0..self.w {
                self.blend(x as i32, y as i32, rgb, 1.0);
            }
        }
    }

    /// Filled rounded rectangle with anti-aliased corners.
    fn round_rect(&mut self, r: Rectf, radius: f64, rgb: [u8; 3]) {
        let rad = radius.min(r.w * 0.5).min(r.h * 0.5).max(0.0);
        let x0 = r.x.floor() as i32;
        let y0 = r.y.floor() as i32;
        let x1 = (r.x + r.w).ceil() as i32;
        let y1 = (r.y + r.h).ceil() as i32;
        for y in y0..y1 {
            for x in x0..x1 {
                let a = Self::round_coverage(r, rad, f64::from(x) + 0.5, f64::from(y) + 0.5);
                self.blend(x, y, rgb, a);
            }
        }
    }

    fn stroke_round(&mut self, r: Rectf, radius: f64, rgb: [u8; 3], width: f64) {
        let rad = radius.min(r.w * 0.5).min(r.h * 0.5).max(0.0);
        let inner = Rectf {
            x: r.x + width,
            y: r.y + width,
            w: r.w - 2.0 * width,
            h: r.h - 2.0 * width,
        };
        let x0 = r.x.floor() as i32;
        let y0 = r.y.floor() as i32;
        let x1 = (r.x + r.w).ceil() as i32;
        let y1 = (r.y + r.h).ceil() as i32;
        for y in y0..y1 {
            for x in x0..x1 {
                let fx = f64::from(x) + 0.5;
                let fy = f64::from(y) + 0.5;
                let outer = Self::round_coverage(r, rad, fx, fy);
                let hole = Self::round_coverage(inner, (rad - width).max(0.0), fx, fy);
                self.blend(x, y, rgb, (outer - hole).max(0.0));
            }
        }
    }

    /// Coverage (0..1) of a point inside a rounded rect, softened at edges.
    fn round_coverage(r: Rectf, rad: f64, px: f64, py: f64) -> f64 {
        // Distance outside the rounded rectangle (0 inside).
        let dx = (r.x + rad - px).max(px - (r.x + r.w - rad)).max(0.0);
        let dy = (r.y + rad - py).max(py - (r.y + r.h - rad)).max(0.0);
        // Straight edges (outside the corner boxes).
        let inside_x = px >= r.x && px <= r.x + r.w;
        let inside_y = py >= r.y && py <= r.y + r.h;
        if !inside_x || !inside_y {
            return 0.0;
        }
        if dx == 0.0 || dy == 0.0 {
            return 1.0;
        }
        let d = (dx * dx + dy * dy).sqrt();
        (rad + 0.5 - d).clamp(0.0, 1.0)
    }

    fn disc(&mut self, cx: f64, cy: f64, rad: f64, rgb: [u8; 3]) {
        let x0 = (cx - rad).floor() as i32;
        let y0 = (cy - rad).floor() as i32;
        let x1 = (cx + rad).ceil() as i32;
        let y1 = (cy + rad).ceil() as i32;
        for y in y0..y1 {
            for x in x0..x1 {
                let d =
                    ((f64::from(x) + 0.5 - cx).powi(2) + (f64::from(y) + 0.5 - cy).powi(2)).sqrt();
                self.blend(x, y, rgb, (rad + 0.5 - d).clamp(0.0, 1.0));
            }
        }
    }

    fn into_rgba(self) -> Vec<u8> {
        self.px
    }
}

fn lerp(a: u8, b: u8, t: f64) -> u8 {
    (f64::from(a) + (f64::from(b) - f64::from(a)) * t) as u8
}

fn lighten(rgb: [u8; 3], by: i32) -> [u8; 3] {
    [
        (i32::from(rgb[0]) + by).clamp(0, 255) as u8,
        (i32::from(rgb[1]) + by).clamp(0, 255) as u8,
        (i32::from(rgb[2]) + by).clamp(0, 255) as u8,
    ]
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn demo_scheme_synthesises_decodable_png() {
        let bytes = fetcher()(DEMO_CALL_GRID).expect("demo image bytes");
        // Must be a real PNG the ui ImageStore can decode.
        let img = image::load_from_memory(&bytes).expect("valid png");
        assert!(img.width() > 0 && img.height() > 0);
        assert!(fetcher()(DEMO_SHARED_SHOT).is_some());
    }

    #[test]
    fn missing_file_is_none_not_panic() {
        assert!(fetcher()("/var/workspace/does/not/exist.png").is_none());
        assert!(fetcher()("qos-demo://unknown").is_none());
    }
}
