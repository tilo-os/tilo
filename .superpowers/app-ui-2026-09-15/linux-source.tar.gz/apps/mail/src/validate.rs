//! Account **test-before-save**: before an account is persisted, its
//! credentials are actually exercised — an IMAP login and an SMTP handshake —
//! and the account is only saved if both succeed. A specific error is surfaced
//! otherwise.
//!
//! ## Injectable transport
//! The check runs through the [`ProbeTransport`] trait, so the state machine is
//! testable without a network: a mock returns canned success/failure. The real
//! network probe ([`LiveProbe`]) is compiled only under `live`. The default
//! (offline) build uses [`OfflineProbe`], which reports success without opening
//! a socket so `--shots` and the headless tests can still save an account.

use crate::model::AccountConfig;

/// The connection probe seam. Implementors attempt the two round-trips that
/// prove an account works.
pub trait ProbeTransport {
    /// Attempt an IMAP `LOGIN` (or `AUTHENTICATE XOAUTH2`) to the account's
    /// incoming server. `Ok(())` on a successful greeting + auth.
    ///
    /// # Errors
    ///
    /// Returns the server's or transport's reason when the connection,
    /// TLS handshake, or authentication fails.
    fn imap_login(&self, cfg: &AccountConfig) -> Result<(), String>;
    /// Attempt an SMTP connect + `EHLO` (+ `AUTH`) to the outgoing server.
    ///
    /// # Errors
    ///
    /// Returns the server's or transport's reason when the connection,
    /// TLS handshake, or authentication fails.
    fn smtp_handshake(&self, cfg: &AccountConfig) -> Result<(), String>;
}

/// The outcome of a validation attempt. Drives the setup sheet: `Ok` persists,
/// `Failed` keeps the sheet open with the message shown.
#[derive(Clone, Debug, PartialEq, Eq)]
pub enum ValidationState {
    /// The config itself is incomplete (before any network is touched).
    Invalid(String),
    /// Both IMAP and SMTP succeeded — safe to persist.
    Ok,
    /// A round-trip failed; carries a specific, user-facing reason.
    Failed(String),
}

impl ValidationState {
    /// Whether this outcome should persist the account.
    pub fn persisted(&self) -> bool {
        matches!(self, ValidationState::Ok)
    }

    /// The user-facing message for a non-Ok outcome (empty for `Ok`).
    pub fn message(&self) -> String {
        match self {
            ValidationState::Ok => String::new(),
            ValidationState::Invalid(m) | ValidationState::Failed(m) => m.clone(),
        }
    }
}

/// Run the full check: config-level validation first (no network), then IMAP,
/// then SMTP. Short-circuits on the first failure so the user sees the most
/// upstream problem.
pub fn validate_account<T: ProbeTransport + ?Sized>(
    cfg: &AccountConfig,
    transport: &T,
) -> ValidationState {
    if let Some((_, msg)) = cfg.validate().into_iter().next() {
        return ValidationState::Invalid(msg);
    }
    if let Err(e) = transport.imap_login(cfg) {
        return ValidationState::Failed(format!("IMAP login failed: {e}"));
    }
    if let Err(e) = transport.smtp_handshake(cfg) {
        return ValidationState::Failed(format!("SMTP handshake failed: {e}"));
    }
    ValidationState::Ok
}

/// Classify a raw connection/transport error string into a specific,
/// user-facing reason. Pure + dependency-free so it is compiled and tested in
/// every build; the live IMAP/SMTP paths and the account probe both funnel
/// their errors through it, so a "connection refused" reads the same whether it
/// came from a fetch or a save-time check.
pub fn classify_conn_failure(detail: &str) -> String {
    let d = detail.to_ascii_lowercase();
    // Auth first: a 535 / "authentication failed" is more specific than the
    // generic transport keywords that might co-occur in the message.
    if d.contains("535")
        || d.contains("authenticationfailed")
        || d.contains("authentication failed")
        || d.contains("invalid credentials")
        || d.contains("auth")
            && (d.contains("fail")
                || d.contains("reject")
                || d.contains("denied")
                || d.contains("invalid"))
        || d.contains("login failed")
        || d.contains("[authenticationfailed]")
    {
        return "authentication failed — check the username and password".into();
    }
    if d.contains("certificate")
        || d.contains("tls")
        || d.contains("handshake")
        || d.contains("self-signed")
        || d.contains("ssl")
    {
        return "TLS/certificate error — the server's certificate wasn't trusted".into();
    }
    if d.contains("refused") {
        return "connection refused — check the host and port".into();
    }
    if d.contains("timed out") || d.contains("timeout") {
        return "connection timed out — the server didn't respond".into();
    }
    if d.contains("dns")
        || d.contains("lookup")
        || d.contains("resolve")
        || d.contains("name or service not known")
        || d.contains("not known")
        || d.contains("no such host")
    {
        return "host not found — check the server address".into();
    }
    if d.contains("unreachable") || d.contains("network is unreachable") {
        return "network unreachable — check your connection".into();
    }
    // Preserve the underlying detail rather than swallowing it.
    format!("connection failed: {detail}")
}

/// The offline probe used by the default build / `--shots`: it never opens a
/// socket and reports success, so an account can still be saved without a
/// network. (Config-level validation in [`validate_account`] still runs.)
pub struct OfflineProbe;

impl ProbeTransport for OfflineProbe {
    fn imap_login(&self, _cfg: &AccountConfig) -> Result<(), String> {
        Ok(())
    }
    fn smtp_handshake(&self, _cfg: &AccountConfig) -> Result<(), String> {
        Ok(())
    }
}

/// The live network probe: a real IMAP login + SMTP handshake. Compiled only
/// under `live` so the default build doesn't pull the TLS/async stack.
#[cfg(feature = "live")]
pub struct LiveProbe;

#[cfg(feature = "live")]
impl ProbeTransport for LiveProbe {
    fn imap_login(&self, cfg: &AccountConfig) -> Result<(), String> {
        // async-imap: TCP+TLS to cfg.imap_host:cfg.imap_port, read the greeting,
        // LOGIN (or AUTHENTICATE XOAUTH2 when cfg.auth == OAuth), LOGOUT.
        // A connect/auth error maps to Err(reason).
        live_probe::imap_login(cfg)
    }
    fn smtp_handshake(&self, cfg: &AccountConfig) -> Result<(), String> {
        // lettre: connect to cfg.smtp_host:cfg.smtp_port, EHLO, STARTTLS /
        // implicit TLS per cfg.smtp_tls, AUTH, then RSET/QUIT without sending.
        live_probe::smtp_handshake(cfg)
    }
}

#[cfg(feature = "live")]
mod live_probe {
    use std::sync::Arc;

    use super::{AccountConfig, classify_conn_failure};
    use crate::model::AuthMethod;

    /// Run `fut` to completion on a short-lived current-thread runtime. The
    /// probe is called from the synchronous UI-save path, so it owns its
    /// runtime rather than assuming one exists.
    ///
    /// # Panics
    /// Panics if the OS refuses a single current-thread tokio runtime. The
    /// probe cannot report "your account works" without actually running the
    /// round-trips, so there is no honest value to return here.
    #[allow(
        clippy::expect_used,
        reason = "without a runtime the probe cannot perform the round-trips it exists to perform; reporting a validation result anyway would be a lie about the account"
    )]
    fn block_on<F: std::future::Future>(fut: F) -> F::Output {
        tokio::runtime::Builder::new_current_thread()
            .enable_all()
            .build()
            .expect("probe runtime")
            .block_on(fut)
    }

    /// # Panics
    /// Never in practice: the bundled ring provider always advertises the
    /// default protocol versions.
    #[allow(
        clippy::expect_used,
        reason = "the bundled ring provider always supports the default protocol versions; a TLS config with no usable version is not something the probe can degrade to"
    )]
    fn tls_config() -> Arc<rustls::ClientConfig> {
        let mut roots = rustls::RootCertStore::empty();
        roots.extend(webpki_roots::TLS_SERVER_ROOTS.iter().cloned());
        let cfg = rustls::ClientConfig::builder_with_provider(Arc::new(
            rustls::crypto::ring::default_provider(),
        ))
        .with_safe_default_protocol_versions()
        .expect("rustls default protocol versions")
        .with_root_certificates(roots)
        .with_no_client_auth();
        Arc::new(cfg)
    }

    /// The access token / password to present. Mirrors the engine's resolution:
    /// a password from the config, or an OAuth token read from the vault.
    fn creds(cfg: &AccountConfig) -> Result<(String, Option<String>), String> {
        let user = if cfg.username.trim().is_empty() {
            cfg.email.clone()
        } else {
            cfg.username.clone()
        };
        match cfg.auth {
            AuthMethod::Password => {
                if cfg.password.is_empty() {
                    return Err("enter a password to verify the account".into());
                }
                Ok((user, None))
            }
            AuthMethod::OAuth => {
                let token = oauth_access_token(&cfg.email)?;
                Ok((user, Some(token)))
            }
        }
    }

    /// Read the OAuth access token for the account from the vault (it is sealed
    /// there by the sign-in flow before the account is saved).
    fn oauth_access_token(email: &str) -> Result<String, String> {
        let vault = accounts::SecretVault::open();
        let secret = vault
            .get(&accounts::AccountId::from(email.to_string()))
            .ok_or("sign in first — no OAuth token stored yet")?;
        let tokens = crate::oauth::tokens_from_secret(&secret)
            .ok_or("stored credential is not an OAuth token")?;
        if tokens.access_token.is_empty() {
            return Err("stored OAuth token is empty; sign in again".into());
        }
        Ok(tokens.access_token)
    }

    pub fn imap_login(cfg: &AccountConfig) -> Result<(), String> {
        if cfg.imap_host.trim().is_empty() {
            return Err("no IMAP host".into());
        }
        let (user, token) = creds(cfg)?;
        let tls = tls_config();
        block_on(async move {
            let host = cfg.imap_host.trim();
            let port = if cfg.imap_port == 0 {
                993
            } else {
                cfg.imap_port
            };
            let tcp = tokio::net::TcpStream::connect((host, port))
                .await
                .map_err(|e| classify_conn_failure(&e.to_string()))?;
            let connector = tokio_rustls::TlsConnector::from(tls);
            let server_name = rustls::pki_types::ServerName::try_from(host.to_string())
                .map_err(|e| format!("invalid IMAP host name: {e}"))?;
            let stream = connector
                .connect(server_name, tcp)
                .await
                .map_err(|e| classify_conn_failure(&e.to_string()))?;
            let client = async_imap::Client::new(stream);
            let mut session = match token {
                Some(access) => {
                    let auth = XOAuth2 {
                        user: user.clone(),
                        token: access,
                    };
                    client
                        .authenticate("XOAUTH2", auth)
                        .await
                        .map_err(|(e, _)| classify_conn_failure(&e.to_string()))?
                }
                None => client
                    .login(&user, &cfg.password)
                    .await
                    .map_err(|(e, _)| classify_conn_failure(&e.to_string()))?,
            };
            // A successful SELECT proves the session is usable, not just that
            // the greeting arrived.
            session
                .select("INBOX")
                .await
                .map_err(|e| classify_conn_failure(&e.to_string()))?;
            let _ = session.logout().await;
            Ok::<(), String>(())
        })
    }

    /// async-imap `XOAUTH2` authenticator (raw SASL string; async-imap base64s).
    struct XOAuth2 {
        user: String,
        token: String,
    }
    impl async_imap::Authenticator for XOAuth2 {
        type Response = String;
        fn process(&mut self, _challenge: &[u8]) -> Self::Response {
            format!("user={}\x01auth=Bearer {}\x01\x01", self.user, self.token)
        }
    }

    pub fn smtp_handshake(cfg: &AccountConfig) -> Result<(), String> {
        use lettre::transport::smtp::authentication::Credentials;
        use lettre::{AsyncSmtpTransport, Tokio1Executor};

        if cfg.smtp_host.trim().is_empty() {
            return Err("no SMTP host".into());
        }
        let host = cfg.smtp_host.trim();
        let port = if cfg.smtp_port == 0 {
            465
        } else {
            cfg.smtp_port
        };
        let (user, token) = creds(cfg)?;
        block_on(async move {
            let builder = if port == 465 {
                AsyncSmtpTransport::<Tokio1Executor>::relay(host)
            } else {
                AsyncSmtpTransport::<Tokio1Executor>::starttls_relay(host)
            }
            .map_err(|e| classify_conn_failure(&e.to_string()))?;
            let secret = token.unwrap_or_else(|| cfg.password.clone());
            let mailer: AsyncSmtpTransport<Tokio1Executor> = builder
                .port(port)
                .credentials(Credentials::new(user, secret))
                .build();
            // test_connection performs connect + EHLO (+ TLS upgrade), proving
            // the outgoing server is reachable and speaks the negotiated
            // security. Credential validity is proven authoritatively by the
            // IMAP login above (SMTP has no no-op AUTH probe).
            match mailer.test_connection().await {
                Ok(true) => Ok(()),
                Ok(false) => Err("SMTP server did not accept the connection".into()),
                Err(e) => Err(classify_conn_failure(&e.to_string())),
            }
        })
    }
}

#[cfg(test)]
mod tests {
    use super::*;

    fn good_cfg() -> AccountConfig {
        AccountConfig {
            email: "me@host.example".into(),
            username: "me@host.example".into(),
            imap_host: "imap.host.example".into(),
            smtp_host: "smtp.host.example".into(),
            ..Default::default()
        }
    }

    /// A programmable probe for the state-machine tests.
    struct MockProbe {
        imap: Result<(), String>,
        smtp: Result<(), String>,
    }
    impl ProbeTransport for MockProbe {
        fn imap_login(&self, _cfg: &AccountConfig) -> Result<(), String> {
            self.imap.clone()
        }
        fn smtp_handshake(&self, _cfg: &AccountConfig) -> Result<(), String> {
            self.smtp.clone()
        }
    }

    #[test]
    fn both_succeed_yields_ok_and_persists() {
        let st = validate_account(
            &good_cfg(),
            &MockProbe {
                imap: Ok(()),
                smtp: Ok(()),
            },
        );
        assert_eq!(st, ValidationState::Ok);
        assert!(
            st.persisted(),
            "a fully-successful check persists the account"
        );
    }

    #[test]
    fn imap_failure_does_not_persist_and_reports_imap() {
        let st = validate_account(
            &good_cfg(),
            &MockProbe {
                imap: Err("auth rejected (535)".into()),
                smtp: Ok(()),
            },
        );
        assert!(
            !st.persisted(),
            "an IMAP failure must not persist the account"
        );
        assert!(
            st.message().contains("IMAP"),
            "error names the failing stage: {}",
            st.message()
        );
        assert!(st.message().contains("535"));
    }

    #[test]
    fn smtp_failure_does_not_persist_and_reports_smtp() {
        let st = validate_account(
            &good_cfg(),
            &MockProbe {
                imap: Ok(()),
                smtp: Err("connection refused".into()),
            },
        );
        assert!(!st.persisted());
        assert!(st.message().contains("SMTP"), "{}", st.message());
    }

    #[test]
    fn invalid_config_short_circuits_before_network() {
        // A blank IMAP host is a config error; the probe must never be reached.
        struct PanicProbe;
        // Panicking IS the assertion here: the test proves the probe is never
        // reached, so returning Err instead would let a regression that does
        // call it pass silently.
        #[allow(
            clippy::panic_in_result_fn,
            reason = "the panic is the assertion — an Err return would let a regression that reaches the probe pass silently"
        )]
        impl ProbeTransport for PanicProbe {
            fn imap_login(&self, _cfg: &AccountConfig) -> Result<(), String> {
                panic!("probe reached despite invalid config");
            }
            fn smtp_handshake(&self, _cfg: &AccountConfig) -> Result<(), String> {
                panic!("probe reached despite invalid config");
            }
        }
        let mut cfg = good_cfg();
        cfg.imap_host.clear();
        let st = validate_account(&cfg, &PanicProbe);
        assert!(matches!(st, ValidationState::Invalid(_)));
        assert!(!st.persisted());
    }

    #[test]
    fn offline_probe_reports_success() {
        let st = validate_account(&good_cfg(), &OfflineProbe);
        assert_eq!(
            st,
            ValidationState::Ok,
            "offline probe lets an account save"
        );
    }

    #[test]
    fn classify_maps_real_transport_errors_to_specific_reasons() {
        // Auth: the exact IMAP tagged-NO an server sends on bad credentials.
        assert!(
            classify_conn_failure("[AUTHENTICATIONFAILED] Invalid credentials")
                .contains("authentication failed")
        );
        assert!(
            classify_conn_failure("535 5.7.8 Username and Password not accepted")
                .contains("authentication failed")
        );
        // Connection refused (nothing listening on the port).
        assert!(
            classify_conn_failure("Connection refused (os error 111)")
                .contains("connection refused")
        );
        // DNS failure.
        assert!(
            classify_conn_failure(
                "failed to lookup address information: Name or service not known"
            )
            .contains("host not found")
        );
        // TLS/certificate.
        assert!(
            classify_conn_failure("invalid peer certificate: UnknownIssuer")
                .contains("TLS/certificate")
        );
        // Timeout.
        assert!(classify_conn_failure("connection timed out").contains("timed out"));
        // Unknown → the underlying detail is preserved, not swallowed.
        let unknown = classify_conn_failure("some novel failure mode");
        assert!(unknown.contains("some novel failure mode"), "{unknown}");
    }

    #[test]
    fn classify_prioritises_auth_over_generic_transport_words() {
        // A message that mentions both a socket concept and auth must classify
        // as auth (the more actionable, specific cause).
        let msg = "AUTHENTICATE failed: login rejected";
        assert!(
            classify_conn_failure(msg).contains("authentication failed"),
            "{}",
            classify_conn_failure(msg)
        );
    }
}
