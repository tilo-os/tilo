//! `MailApp` — the root widget.
//!
//! It composes the HIG §1 navigation primitive [`ui::widget::NavShell`] with a
//! genuine three-panel layout —
//!
//! ```text
//! [ sidebar (accounts + folders) | list (overview) | message (detail) ]
//! ```
//!
//! Wide: all three abreast, only the sidebar collapses (via the shell's own
//! chevron/hamburger — never an `X`). Narrow: the sidebar becomes an overlay
//! drawer, the list is full-screen, and opening a message slides the detail in
//! from the right with a Back affordance. The shell owns the breakpoint,
//! collapse/push animations, the scrim, and Back/Esc routing; the three
//! [`Pane`]s (all sharing one [`MailState`]) supply the content and raise
//! [`Intent`]s for cross-pane effects.
//!
//! On top of the shell the app layers the transient overlays it owns directly:
//! the movable [`ComposeWindow`], the row context menu, the account-setup
//! sheet, and a status toast.
//!
//! The live app loads a real [`AccountStore`] and drives the account
//! [`crate::engine`] worker (IMAP fetch / SMTP submit; a network-free stub by
//! default). It does **not** fabricate a sample mailbox — an unconfigured
//! account shows an empty state. The bundled sample corpus is used only by the
//! hermetic `--shots` / test constructors.

use std::collections::HashMap;
use std::sync::Arc;

use automerge::{AutoCommit, ObjId};
use taffy::{Dimension, NodeId, Size as TSize, Style, TaffyTree};
use vello::Scene;
use vello::kurbo::{Affine, Point, Rect, RoundedRect};
use vello::peniko::{Color, Fill};
use winit::event::{ElementState, KeyEvent, MouseButton, WindowEvent};
use winit::keyboard::{Key, NamedKey};

use ui::ImageStore;
use ui::color_compat::ColorCompat;
use ui::icons::Icon;
use ui::permissions::PermissionContext;
use ui::presence::PresenceCtx;
use ui::text_render::{TextRenderer, TextWeight};
use ui::theme::Theme;
use ui::widget::toast::{ToastAnchor, ToastCard, ToastKind, paint_transient};
use ui::widget::{EmptyState, NavPane, NavShell, TextInput, Toggle, ToggleFace, Widget};

use crate::account::{Account, AccountStore};
use crate::compose::{ComposeAction, ComposeWindow};
use crate::doc::MailDoc;
use crate::draw::{fill_rect, fill_round, stroke_round};
use crate::engine::{EngineEvent, EngineRequest, EngineRequestId, EngineRequestKind};
use crate::model::{
    AccountConfig, Addr, Attachment, ComposeFormat, Draft, Folder, Message, MessageId,
};
use crate::pane::{Pane, Role};
use crate::state::{CtxAction, Intent, MailState, Shared};
use crate::util::format_absolute;

/// Width (logical px) at/above which the shell is wide (docked sidebar +
/// three panes abreast); below it the sidebar is an overlay drawer and the
/// content is a single push page. Shared with the [`NavShell`].
const BREAKPOINT: f64 = 860.0;
const SIDEBAR_W: f64 = 260.0;
const OVERVIEW_W: f64 = 340.0;
/// How often the app auto-refreshes the current folder from the server while in
/// use. Checked each active frame; a manual refresh (the `r` shortcut) forces
/// one immediately regardless.
const AUTO_REFRESH_MIN: i64 = 5;
/// How long a status toast ("Synced N messages", "Account saved", …) stays on
/// screen before it fades out on its own, like any normal transient toast.
const TOAST_TTL: std::time::Duration = std::time::Duration::from_millis(3500);

/// An open row context menu.
struct ContextMenu {
    target: MessageId,
    pos: Point,
    items: Vec<CtxAction>,
}

/// A hit region in one of the app-owned overlays (setup sheet / context menu /
/// first-run onboarding).
#[derive(Clone)]
enum OverlayHit {
    SetupField(usize),
    ToggleImapTls,
    ToggleSmtpTls,
    SetupSave,
    CancelSetup,
    /// Remove the account being edited (only shown when editing an existing one).
    RemoveAccount,
    CtxItem(usize),
    /// Pick the account's sign-in method (password vs OAuth).
    AuthPassword,
    AuthOAuth,
    /// Trigger the OAuth authorization flow for the detected provider.
    OAuthSignIn,
}

/// The engine worker channel pair (live app only).
struct EngineHandle {
    tx: std::sync::mpsc::Sender<EngineRequest>,
    rx: std::sync::mpsc::Receiver<EngineEvent>,
}

/// A locally-authored message waiting for a real SMTP acknowledgement.  It is
/// deliberately kept out of Sent until the server accepts it: treating MIME
/// serialization as delivery makes an offline fallback (and a rejected SMTP
/// send) look like mail was sent.
struct PendingSend {
    request_id: EngineRequestId,
    message: Message,
    edited_draft: Option<MessageId>,
}

/// Where account add / edit / remove is persisted.
///
/// Only the **live** app may write the user's real account store
/// (`$XDG_CONFIG_HOME/qos/accounts/`). The sample / `--shots` / test
/// constructors target a throwaway sandbox directory instead, so exercising the
/// save flow (or a test that adds an account) can never leak fabricated demo
/// accounts into the real store. The historic leak — `you@qos.example`,
/// `you@hooli.example`, `new@host.example` appearing pre-configured in the live
/// app — was exactly this: a test that drove the save path wrote the bundled
/// sample store to the real config root.
#[derive(Clone)]
enum AccountsPersist {
    /// The real per-user config root — live app only.
    Real,
    /// A throwaway directory, removed when the app is dropped. The `TempDir`
    /// guard owns the directory's lifetime.
    Sandbox(Arc<tempfile::TempDir>),
    /// No writable sandbox could be created — persistence is a silent no-op.
    /// A safe fallback that still never touches the real store.
    Disabled,
}

impl AccountsPersist {
    /// A fresh throwaway sandbox for the sample / shots / test constructors.
    /// Falls back to [`AccountsPersist::Disabled`] (never [`AccountsPersist::Real`])
    /// if a temp dir cannot be created, so sample mode can never reach the real
    /// store.
    fn sandbox() -> Self {
        match tempfile::Builder::new()
            .prefix("qos-mail-sample-")
            .tempdir()
        {
            Ok(dir) => AccountsPersist::Sandbox(Arc::new(dir)),
            Err(_) => AccountsPersist::Disabled,
        }
    }

    /// Persist `accounts` to the target this variant names.
    fn persist(&self, accounts: &AccountStore) -> std::io::Result<()> {
        match self {
            AccountsPersist::Real => accounts.persist(),
            AccountsPersist::Sandbox(dir) => accounts.persist_in(dir.path()),
            AccountsPersist::Disabled => Ok(()),
        }
    }

    /// The device-local preference lives beside the account store, but outside
    /// its shared account schema. It is never a collaborative document field.
    fn load_compose_format(&self) -> ComposeFormat {
        let Some(path) = self.local_preferences_path() else {
            return ComposeFormat::Html;
        };
        std::fs::read(path)
            .ok()
            .and_then(|bytes| serde_json::from_slice::<LocalPreferences>(&bytes).ok())
            .map_or(ComposeFormat::Html, |prefs| {
                ComposeFormat::from_key(&prefs.compose_format)
            })
    }

    fn persist_compose_format(&self, format: ComposeFormat) -> std::io::Result<()> {
        let Some(path) = self.local_preferences_path() else {
            return Ok(());
        };
        if let Some(parent) = path.parent() {
            std::fs::create_dir_all(parent)?;
        }
        let bytes = serde_json::to_vec(&LocalPreferences {
            compose_format: format.as_key().to_string(),
        })
        .map_err(std::io::Error::other)?;
        std::fs::write(path, bytes)
    }

    fn local_preferences_path(&self) -> Option<std::path::PathBuf> {
        let root = match self {
            AccountsPersist::Real => accounts::config_root(),
            AccountsPersist::Sandbox(dir) => Some(dir.path().to_path_buf()),
            AccountsPersist::Disabled => None,
        }?;
        Some(root.join("mail-local.json"))
    }
}

/// Device-local Mail preferences. Kept deliberately small and separate from
/// the shared account payload: a peer must never adopt another window's
/// composer mode just because it received mailbox changes.
#[derive(serde::Deserialize, serde::Serialize)]
struct LocalPreferences {
    compose_format: String,
}

#[allow(
    clippy::struct_excessive_bools,
    reason = "the bools split across three unrelated concerns (shell layout flags, the setup-sheet's own transient UI state, and engine-request bookkeeping); grouping them would need a real design pass (e.g. a SetupSheetState sub-struct), left for a follow-up rather than forced here"
)]
pub struct MailApp {
    shared: Shared,
    /// One retained catalogue per mailbox revision. Palette providers clone
    /// this Arc-backed handle; typing never rebuilds the loaded-mail index.
    mail_search_provider: crate::search_provider::MailSearchProvider,
    nav: NavShell,
    /// Retained first-run surface so the primary action uses the shared
    /// pointer, focus, keyboard and accessibility contract.
    first_run: EmptyState,
    first_run_node: Option<NodeId>,
    compose: ComposeWindow,
    /// The Drafts-folder message the open composer is editing, if any. On save
    /// the same message is updated (not duplicated); on send it is removed.
    editing_draft: Option<MessageId>,
    context_menu: Option<ContextMenu>,

    // account-setup sheet (Settings owns this in production; offered in-app too)
    setup_open: bool,
    setup_inputs: Vec<TextInput>,
    setup_imap_tls: bool,
    setup_smtp_tls: bool,
    setup_editing: Option<usize>,
    setup_focus: Option<usize>,
    /// The account's chosen sign-in method in the setup sheet.
    setup_auth: crate::model::AuthMethod,
    /// The OAuth provider detected from the typed email domain, if any.
    setup_provider: Option<crate::oauth::OAuthProvider>,
    /// The most recent validation message from a save attempt (shown inline in
    /// the sheet); cleared when the sheet is (re)opened.
    setup_error: Option<String>,

    engine: Option<EngineHandle>,
    pending_send: Option<PendingSend>,
    /// Where account changes persist. The live app targets the real user config
    /// root; the sample / shots / test constructors target a throwaway sandbox
    /// so they can never write into the real account store.
    accounts_persist: AccountsPersist,
    /// The device-local account id last flushed to [`AccountsPersist`]. Pane,
    /// accessibility, and resource operations all select through `MailState`,
    /// so observing the id here gives every selection path one persistence
    /// boundary without leaking that preference into Automerge.
    persisted_active_account: Option<String>,
    /// Last format persisted to this device-local preference store. This lets
    /// format toggles save immediately without rewriting disk at every close.
    persisted_compose_format: ComposeFormat,
    connect_requested: bool,
    /// True between posting a connect/fetch and receiving its result, so the
    /// app only keeps polling the worker while a reply is outstanding (it fully
    /// idles otherwise instead of busy-looping). `pending_engine_requests`
    /// rather than an event-derived boolean is the source of truth: a connect
    /// can emit several events, while successful IMAP writes emit none besides
    /// their terminal worker acknowledgement.
    awaiting_engine: bool,
    pending_engine_requests: HashMap<EngineRequestId, EngineRequestKind>,
    /// The one refresh invocation currently owned by the resource-operation
    /// host.  It remains occupied until the host has polled its terminal
    /// update, so a subsequent refresh cannot overwrite an unobserved result.
    resource_refresh_invocation: Option<(EngineRequestId, qos_actions::InvocationId)>,
    resource_refresh_result: Option<qos_actions::InvocationUpdate>,
    /// Wall-clock minute of the last automatic inbox refresh, so periodic sync
    /// fires at most once per [`AUTO_REFRESH_MIN`] while the app is in use.
    last_auto_refresh_min: i64,

    /// The status text currently being shown as a toast, and the instant it
    /// should auto-dismiss. Any code path may set `shared.status`; the app
    /// notices the change each frame, (re)arms the deadline, and clears the
    /// status once [`TOAST_TTL`] elapses — so a "Synced N messages" toast fades
    /// on its own instead of lingering forever.
    toast_text: Option<String>,
    toast_deadline: Option<std::time::Instant>,

    overlay_hits: Vec<(Rect, OverlayHit)>,
    rect: Rect,
    /// The shell's reveal flap starts fully open (its docked default); the
    /// first real layout snaps it to the resting state for the current width so
    /// a narrow launch doesn't flash the drawer open before easing it closed.
    first_layout: bool,
    dirty: bool,
}

impl MailApp {
    /// The hermetic constructor used by `--shots` and tests: the bundled
    /// sample corpus, no engine, deterministic "now".
    pub fn new_sample() -> Self {
        let shared = MailState::shared(MailState::new_sample(avatar_store_offline()));
        Self::assemble(shared, None, AccountsPersist::sandbox())
    }

    /// The live constructor: a real account list loaded from disk and the
    /// engine worker spawned. No fabricated messages.
    pub fn new_live() -> Self {
        let accounts = load_account_store();
        let shared = MailState::shared(MailState::new_live(accounts, avatar_store()));
        let (tx, rx) = crate::engine::spawn();
        // Only the live app writes the user's real account store.
        Self::assemble(shared, Some(EngineHandle { tx, rx }), AccountsPersist::Real)
    }

    /// A first-run constructor with no configured account and no engine —
    /// renders the onboarding / welcome screen. Used by the `firstrun` shot.
    /// Persists to a throwaway sandbox (never the real store) so a driven
    /// add-account in this mode stays hermetic.
    pub fn new_first_run() -> Self {
        let shared = MailState::shared(MailState::new_live(
            AccountStore::new(),
            avatar_store_offline(),
        ));
        Self::assemble(shared, None, AccountsPersist::sandbox())
    }

    fn assemble(
        shared: Shared,
        engine: Option<EngineHandle>,
        accounts_persist: AccountsPersist,
    ) -> Self {
        let mail_search_provider = {
            let state = shared.borrow();
            crate::search_provider::MailSearchProvider::new(&state.mailbox)
        };
        let sidebar = Pane::boxed(Role::Sidebar, shared.clone());
        let overview = Pane::boxed(Role::List, shared.clone());
        let detail = Pane::boxed(Role::Reader, shared.clone());
        let nav = NavShell::new(overview, detail)
            .with_sidebar(sidebar)
            .with_breakpoint(BREAKPOINT)
            .with_sidebar_width(SIDEBAR_W)
            .with_overview_width(OVERVIEW_W);

        let (cfg, persisted_active_account) = {
            let state = shared.borrow();
            (
                state.accounts.active_config(),
                state
                    .accounts
                    .active_account()
                    .map(|account| account.id.clone()),
            )
        };
        let compose_format = accounts_persist.load_compose_format();
        Self {
            shared,
            mail_search_provider,
            nav,
            first_run: EmptyState::new("Welcome to Mail")
                .with_icon(Icon::Mail)
                .with_message("Add your email account to start reading and sending mail.")
                .with_action("Add account")
                .with_action_id("mail.add-account"),
            first_run_node: None,
            compose: ComposeWindow::new(compose_format),
            editing_draft: None,
            context_menu: None,
            setup_open: false,
            setup_inputs: build_setup_inputs(&cfg),
            setup_imap_tls: cfg.imap_tls,
            setup_smtp_tls: cfg.smtp_tls,
            setup_editing: None,
            setup_focus: None,
            setup_auth: cfg.auth,
            setup_provider: None,
            setup_error: None,
            engine,
            pending_send: None,
            accounts_persist,
            persisted_active_account,
            persisted_compose_format: compose_format,
            connect_requested: false,
            awaiting_engine: false,
            pending_engine_requests: HashMap::new(),
            resource_refresh_invocation: None,
            resource_refresh_result: None,
            last_auto_refresh_min: 0,
            toast_text: None,
            toast_deadline: None,
            overlay_hits: Vec::new(),
            rect: Rect::ZERO,
            first_layout: true,
            dirty: true,
        }
    }

    // ---- `--shots` priming ------------------------------------------------

    /// Open the composer with a representative HTML draft (compose shot).
    pub fn prime_compose_shot(&mut self) {
        self.compose.open_demo();
        self.dirty = true;
    }

    /// Push the detail pane in and snap it (narrow "reading a message" shot).
    pub fn prime_detail_shot(&mut self) {
        self.nav.show_detail();
        self.nav.snap();
        self.dirty = true;
    }

    /// Open an unread sample message through the same explicit read-state
    /// neutral path that agents and Ctrl+K use, so visual review covers the
    /// persistent preview indicator rather than relying only on a unit test.
    pub fn prime_preview_shot(&mut self) {
        let id = self
            .shared
            .borrow()
            .mailbox
            .messages_in(Folder::Inbox)
            .into_iter()
            .find_map(|message| (!message.read).then_some(message.id));
        if let Some(id) = id {
            self.shared.borrow_mut().preview_message(id);
            self.process_intents();
        }
        self.dirty = true;
    }

    /// Put the list in an active, non-empty search state. This is deliberately
    /// seeded through the same shared query state used by type-ahead rather
    /// than fabricating a separate search-only data path.
    pub fn prime_search_shot(&mut self) {
        let mut st = self.shared.borrow_mut();
        st.search = "spatial".into();
        st.search_focused = true;
        st.selected = st.list_rows().first().map(|(id, _)| *id);
        st.dirty = true;
        drop(st);
        self.dirty = true;
    }

    /// Open the account-setup sheet (setup shot).
    pub fn prime_setup_shot(&mut self) {
        let active = self.shared.borrow().accounts.active;
        self.open_setup_edit(Some(active));
    }

    /// Open a blank "Add account" sheet with an email typed + servers
    /// autofilled, so the shot shows the add flow with single-border fields.
    pub fn prime_setup_add_shot(&mut self) {
        self.open_setup_edit(None);
        self.set_setup_input(0, "Grace Hopper");
        self.set_setup_input(1, "grace@fastmail.com");
        self.maybe_autofill();
        // Land focus on a server field so the single-border focus ring shows.
        self.focus_setup(Some(4));
    }

    /// Open a blank "Add account" sheet with a Gmail address — which presets to
    /// OAuth — so the shot shows the OAuth sign-in flow.
    pub fn prime_setup_oauth_shot(&mut self) {
        self.open_setup_edit(None);
        self.set_setup_input(0, "Grace Hopper");
        self.set_setup_input(1, "grace.hopper@gmail.com");
        self.maybe_autofill();
        self.focus_setup(Some(1));
    }

    /// Select the bundled HTML newsletter so the reader renders it through the
    /// sandboxed `WebView` (HTML-mail shot). Also demonstrates the filled-star
    /// action (the newsletter is starred).
    pub fn prime_html_mail_shot(&mut self) {
        let id = {
            let st = self.shared.borrow();
            st.mailbox
                .messages
                .values()
                .find(|m| m.from.email == "news@weekly.qos.example")
                .map(|m| m.id)
        };
        if let Some(id) = id {
            let mut doc = AutoCommit::new();
            self.shared.borrow_mut().select_message(&mut doc, id);
            self.process_intents();
        }
        self.dirty = true;
    }

    /// A configured mailbox before any messages have arrived.
    pub fn prime_empty_shot(&mut self) {
        let mut st = self.shared.borrow_mut();
        let account = st.mailbox.account.clone();
        st.mailbox = crate::model::Mailbox::new(account);
        st.selected = None;
        st.folder = Folder::Inbox;
        st.dirty = true;
        drop(st);
        self.dirty = true;
    }

    /// A real in-flight sync indication over cached mail.
    pub fn prime_loading_shot(&mut self) {
        self.awaiting_engine = true;
        self.shared.borrow_mut().status = Some("Syncing Inbox…".into());
        self.dirty = true;
    }

    /// Queue one worker request and account for it exactly once.  Every engine
    /// backend emits a matching `EngineEvent::Completed` after handling the
    /// request, including successful flag/move/purge writes.
    fn post_engine(&mut self, request: EngineRequest) -> Option<EngineRequestId> {
        let Some(engine) = &self.engine else {
            return None;
        };
        let request_id = request.request_id();
        let request_kind = request.kind();
        if engine.tx.send(request).is_err() {
            self.shared.borrow_mut().status = Some("Mail worker is unavailable".into());
            self.dirty = true;
            return None;
        }
        self.pending_engine_requests
            .insert(request_id, request_kind);
        self.awaiting_engine = true;
        Some(request_id)
    }

    /// Accept only events that match a request still pending in this app. A
    /// worker event is untrusted transport input: a malformed, delayed, or
    /// out-of-order result must not update a different operation's UI state.
    fn expects_engine_event(&self, request_id: EngineRequestId, kind: EngineRequestKind) -> bool {
        self.pending_engine_requests.get(&request_id) == Some(&kind)
    }

    /// Cached mail remains usable while connectivity is unavailable.
    pub fn prime_offline_shot(&mut self) {
        self.shared.borrow_mut().status = Some("You’re offline · Showing downloaded mail".into());
        self.dirty = true;
    }

    /// A recoverable account error: the configuration stays open and editable.
    pub fn prime_error_shot(&mut self) {
        self.prime_setup_add_shot();
        self.setup_error = Some(
            "Couldn’t connect to IMAP. Check the server, port, and TLS settings, then try again."
                .into(),
        );
        self.dirty = true;
    }

    /// Open the sidebar overlay drawer and snap it (narrow drawer shot).
    pub fn prime_drawer_shot(&mut self) {
        self.nav.open_sidebar();
        self.nav.snap_sidebar(true);
        self.dirty = true;
    }

    // ---- nav layout -------------------------------------------------------

    fn publish_shell_flags(&self) {
        let narrow = self.rect.width() < BREAKPOINT;
        let detail = self.nav.is_detail_shown();
        let sidebar_open = self.nav.is_sidebar_open();
        let mut st = self.shared.borrow_mut();
        st.narrow = narrow;
        st.detail_pushed = detail;
        st.sidebar_open = sidebar_open;
    }

    /// Lay the shell out into the app's rect via a throwaway sub-taffy, the
    /// same shape the offscreen renderer uses for the whole tree.
    fn layout_nav(&mut self) {
        self.publish_shell_flags();
        let (w, h) = (self.rect.width() as f32, self.rect.height() as f32);
        let theme = Theme::dark();
        let mut taffy: TaffyTree<()> = TaffyTree::new();
        let mut map: HashMap<NodeId, *mut dyn Widget> = HashMap::new();
        let child = self.nav.build_layout(&mut taffy, &theme, &mut map);
        let Ok(root) = taffy.new_with_children(
            Style {
                size: TSize {
                    width: Dimension::length(w),
                    height: Dimension::length(h),
                },
                ..Default::default()
            },
            &[child],
        ) else {
            // The tree was just created and holds a single freshly-built
            // child, so this can't realistically fail — but skip the layout
            // pass rather than panic if the taffy internals ever surprise us.
            return;
        };
        let mut tr = TextRenderer::new();
        let measure_map = map.clone();
        let _ = taffy.compute_layout_with_measure(
            root,
            TSize {
                width: taffy::AvailableSpace::Definite(w),
                height: taffy::AvailableSpace::Definite(h),
            },
            |known, available, node_id, _, _| {
                if let Some(&ptr) = measure_map.get(&node_id) {
                    unsafe { (*ptr).measure(known, available, &mut tr) }
                } else {
                    TSize::ZERO
                }
            },
        );
        self.nav
            .apply_layout(&taffy, child, Point::new(self.rect.x0, self.rect.y0));
        // Resolve the shell to its resting state for this width on the first
        // layout (no entry animation), then re-place the children with the
        // settled rects so a single frame renders deterministically.
        if self.first_layout {
            self.nav.snap();
            self.first_layout = false;
            self.publish_shell_flags();
            self.nav
                .apply_layout(&taffy, child, Point::new(self.rect.x0, self.rect.y0));
        }
        // Compose + overlays sit within the whole app rect.
        self.compose.layout(self.rect);
        self.rebuild_overlay_hits();
    }

    // ---- intent processing ------------------------------------------------

    /// The message currently selected, if any. Lets a test observe where a
    /// Ctrl+K activation navigated.
    pub fn selected_message(&self) -> Option<crate::model::MessageId> {
        self.shared.borrow().selected
    }

    fn process_intents(&mut self) {
        let intents = self.shared.borrow_mut().take_intents();
        for intent in intents {
            match intent {
                Intent::ShowDetail => self.nav.show_detail(),
                Intent::ShowOverview => self.nav.show_overview(),
                Intent::CloseDrawer => self.nav.close_sidebar(),
                Intent::Compose => {
                    self.editing_draft = None;
                    self.compose.open_blank();
                    self.context_menu = None;
                }
                Intent::Reply(id) => self.open_reply(id),
                Intent::ReplyAll(id) => self.open_reply_all(id),
                Intent::Forward(id) => self.open_forward(id),
                Intent::EditDraft(id) => self.open_draft(id),
                Intent::ContextMenu(id, pt) => {
                    let items = self.shared.borrow().context_items_for(id);
                    self.context_menu = Some(ContextMenu {
                        target: id,
                        pos: pt,
                        items,
                    });
                }
                Intent::Settings(idx) => self.open_setup_edit(idx),
                Intent::Engine(req) => {
                    self.post_engine(req);
                }
                Intent::Toast(msg) => self.shared.borrow_mut().status = Some(msg),
            }
        }
        self.dirty = true;
    }

    fn reply_subject(msg: &Message) -> String {
        if msg.subject.to_ascii_lowercase().starts_with("re:") {
            msg.subject.clone()
        } else {
            format!("Re: {}", msg.subject)
        }
    }

    fn reply_quote(msg: &Message) -> String {
        format!(
            "\n\nOn {}, {} wrote:\n> {}",
            format_absolute(msg.timestamp_min),
            msg.from.display(),
            msg.snippet()
        )
    }

    fn open_reply(&mut self, id: MessageId) {
        let Some(msg) = self.shared.borrow().mailbox.get(id).cloned() else {
            return;
        };
        self.editing_draft = None;
        let subj = Self::reply_subject(&msg);
        let quote = Self::reply_quote(&msg);
        self.compose.open_reply(&msg.from.rfc5322(), &subj, &quote);
        self.context_menu = None;
        self.dirty = true;
    }

    /// Reply to everyone: the original sender in `To`, and every other original
    /// recipient (To + Cc, minus ourselves and the sender) in `Cc`.
    fn open_reply_all(&mut self, id: MessageId) {
        let (msg, my_email) = {
            let st = self.shared.borrow();
            match st.mailbox.get(id).cloned() {
                Some(m) => (m, st.accounts.active_config().email.to_ascii_lowercase()),
                None => return,
            }
        };
        self.editing_draft = None;
        let subj = Self::reply_subject(&msg);
        let quote = Self::reply_quote(&msg);
        let sender = msg.from.email.to_ascii_lowercase();
        let mut cc: Vec<String> = Vec::new();
        for a in msg.to.iter().chain(msg.cc.iter()) {
            let e = a.email.to_ascii_lowercase();
            if e == my_email || e == sender || e.is_empty() {
                continue;
            }
            if cc
                .iter()
                .any(|existing| existing.eq_ignore_ascii_case(&a.rfc5322()))
            {
                continue;
            }
            cc.push(a.rfc5322());
        }
        self.compose
            .open_reply_all(&msg.from.rfc5322(), &cc.join(", "), &subj, &quote);
        self.context_menu = None;
        self.dirty = true;
    }

    /// Reopen a Drafts-folder message in the composer for further editing.
    fn open_draft(&mut self, id: MessageId) {
        let draft = match self.shared.borrow().mailbox.get(id) {
            Some(m) => draft_from_message(m),
            None => return,
        };
        self.editing_draft = Some(id);
        self.compose.open_with_draft(&draft);
        self.context_menu = None;
        self.dirty = true;
    }

    fn open_forward(&mut self, id: MessageId) {
        let Some(msg) = self.shared.borrow().mailbox.get(id).cloned() else {
            return;
        };
        self.editing_draft = None;
        let subj = format!("Fwd: {}", msg.thread_subject());
        let quote = format!(
            "\n\n---------- Forwarded message ----------\nFrom: {}\nSubject: {}\n\n{}",
            msg.from.rfc5322(),
            msg.subject,
            msg.body
        );
        self.compose.open_reply("", &subj, &quote);
        self.context_menu = None;
        self.dirty = true;
    }

    fn send_compose(&mut self, _doc: &mut AutoCommit) {
        self.persist_compose_format_if_changed();
        if self.pending_send.is_some() {
            self.shared.borrow_mut().status = Some("Message is still sending…".into());
            return;
        }
        let draft = self.compose.to_draft();
        let acct = self.shared.borrow().accounts.active_config();
        if acct.email.trim().is_empty() {
            self.shared.borrow_mut().status =
                Some("Add a sending account before sending this message".into());
            self.dirty = true;
            return;
        }
        if self.engine.is_none() {
            self.shared.borrow_mut().status =
                Some("Sending is unavailable in this offline preview; save a draft instead".into());
            self.dirty = true;
            return;
        }
        let from = Addr::new(acct.display_name.clone(), acct.email.clone());
        match crate::transport::build_mime(&from, &draft) {
            Ok(_) => {
                let to = crate::transport::parse_addr_list(&draft.to);
                let now = self.shared.borrow().now_min;
                let msg = Message {
                    id: uuid::Uuid::new_v4(),
                    rfc_message_id: None,
                    in_reply_to: None,
                    from,
                    to,
                    cc: crate::transport::parse_addr_list(&draft.cc),
                    subject: draft.subject.clone(),
                    body: draft.body.clone(),
                    html_body: draft.html_body.clone(),
                    attachments: draft
                        .attachments
                        .iter()
                        .map(|p| attachment_meta(p))
                        .collect(),
                    timestamp_min: now,
                    read: true,
                    starred: false,
                    folder: Folder::Sent,
                    labels: Vec::new(),
                };
                let Some(request_id) = self.post_engine(EngineRequest::send(acct, Box::new(draft)))
                else {
                    return;
                };
                self.pending_send = Some(PendingSend {
                    request_id,
                    message: msg,
                    edited_draft: self.editing_draft,
                });
                self.shared.borrow_mut().status = Some("Sending…".into());
            }
            Err(e) => self.shared.borrow_mut().status = Some(format!("Send failed: {e}")),
        }
        self.dirty = true;
    }

    fn save_compose_draft(&mut self, doc: &mut AutoCommit) {
        let draft = self.compose.to_draft();
        // Persist the draft as an action (survives a crash / syncs to peers /
        // one undo boundary) …
        self.shared.borrow_mut().save_draft(doc, &draft);
        // … and materialise it as a real, visible message in the Drafts folder
        // so it can be found and reopened — not a write-only slot.
        let id = self.upsert_draft_message(doc, &draft);
        self.editing_draft = Some(id);
        self.shared.borrow_mut().status = Some("Draft saved to Drafts".into());
        self.compose.close();
        self.persist_compose_format_if_changed();
        self.dirty = true;
    }

    /// Insert (or, when editing an existing draft, update in place) a Drafts
    /// folder message reflecting `draft`, and return its id.
    fn upsert_draft_message(&self, doc: &mut AutoCommit, draft: &Draft) -> MessageId {
        let (from, now) = {
            let st = self.shared.borrow();
            let acct = st.accounts.active_config();
            (Addr::new(acct.display_name.clone(), acct.email), st.now_min)
        };
        let id = self.editing_draft.unwrap_or_else(uuid::Uuid::new_v4);
        let msg = Message {
            id,
            rfc_message_id: None,
            in_reply_to: None,
            from,
            to: crate::transport::parse_addr_list(&draft.to),
            cc: crate::transport::parse_addr_list(&draft.cc),
            subject: if draft.subject.trim().is_empty() {
                "(no subject)".into()
            } else {
                draft.subject.clone()
            },
            body: draft.body.clone(),
            html_body: draft.html_body.clone(),
            attachments: draft
                .attachments
                .iter()
                .map(|p| attachment_meta(p))
                .collect(),
            timestamp_min: now,
            read: true,
            starred: false,
            folder: Folder::Drafts,
            labels: Vec::new(),
        };
        {
            let mut st = self.shared.borrow_mut();
            st.mailbox.insert(msg);
            // The durable draft action already carries the user-authored
            // content. This is only a local Drafts projection, so register its
            // target without manufacturing flag writes outside an action.
            MailDoc::register_message(doc, &id.to_string());
        }
        id
    }

    // ---- account-setup sheet ---------------------------------------------

    fn open_setup_edit(&mut self, idx: Option<usize>) {
        let cfg = match idx {
            Some(i) => self
                .shared
                .borrow()
                .accounts
                .accounts
                .get(i)
                .map(|a| a.config.clone())
                .unwrap_or_default(),
            None => AccountConfig::default(),
        };
        self.setup_editing = idx;
        self.setup_inputs = build_setup_inputs(&cfg);
        self.setup_imap_tls = cfg.imap_tls;
        self.setup_smtp_tls = cfg.smtp_tls;
        self.setup_auth = cfg.auth;
        self.setup_provider = cfg
            .email
            .split_once('@')
            .and_then(|(_, d)| crate::oauth::OAuthProvider::from_domain(d));
        self.setup_error = None;
        self.setup_open = true;
        self.focus_setup(Some(1));
        self.context_menu = None;
        self.dirty = true;
    }

    fn close_setup(&mut self) {
        self.setup_open = false;
        self.setup_error = None;
        self.focus_setup(None);
        self.dirty = true;
    }

    /// Whether the app is at first run (no account configured) and should show
    /// the onboarding screen rather than an empty mailbox.
    fn is_first_run(&self) -> bool {
        self.shared.borrow().accounts.is_empty() && !self.setup_open
    }

    /// The ordered field indices the Tab key walks. The password field is
    /// dropped from the order when the account uses OAuth (there is no
    /// password to type).
    fn setup_tab_order(&self) -> Vec<usize> {
        let mut order = vec![0usize, 1, 2];
        if self.setup_auth == crate::model::AuthMethod::Password {
            order.push(3);
        }
        order.extend([4, 5, 6, 7]);
        order
    }

    /// Advance focus to the next (`+1`) / previous (`-1`) setup field, wrapping.
    fn focus_setup_step(&mut self, delta: i32) {
        let order = self.setup_tab_order();
        let cur = self
            .setup_focus
            .and_then(|f| order.iter().position(|&i| i == f))
            .unwrap_or(0) as i32;
        let n = order.len() as i32;
        let next = (((cur + delta) % n + n) % n) as usize;
        let Some(&next_field) = order.get(next) else {
            // `next` is always in `0..order.len()` by construction; bail
            // rather than panic if that invariant is ever violated.
            return;
        };
        // Leaving the email field triggers autoconfig, same as a click-away.
        let leaving_email = self.setup_focus == Some(1) && next_field != 1;
        self.focus_setup(Some(next_field));
        if leaving_email {
            self.maybe_autofill();
        }
    }

    fn focus_setup(&mut self, which: Option<usize>) {
        self.setup_focus = which;
        for (i, inp) in self.setup_inputs.iter_mut().enumerate() {
            inp.set_focus(which == Some(i));
        }
        self.dirty = true;
    }

    /// One of the fixed setup-sheet fields, addressed by its position in
    /// [`build_setup_inputs`] (0 = display name, 1 = email, 2 = username,
    /// 3 = password, 4 = IMAP host, 5 = IMAP port, 6 = SMTP host, 7 = SMTP
    /// port). `None` only if the input list is ever shorter than that fixed
    /// layout; every caller treats it as a no-op read/write rather than a
    /// panic.
    fn setup_input(&self, i: usize) -> Option<&TextInput> {
        self.setup_inputs.get(i)
    }

    fn setup_input_mut(&mut self, i: usize) -> Option<&mut TextInput> {
        self.setup_inputs.get_mut(i)
    }

    /// Set field `i`'s text, a silent no-op if the index is out of range.
    fn set_setup_input(&mut self, i: usize, text: &str) {
        if let Some(inp) = self.setup_input_mut(i) {
            inp.set_text(text);
        }
    }

    /// Lay field `i` out into `rect`, a silent no-op if the index is out of
    /// range.
    fn layout_setup_input(&mut self, i: usize, rect: Rect) {
        if let Some(inp) = self.setup_input_mut(i) {
            inp.apply_layout_external(rect);
        }
    }

    /// Lay out the IMAP and SMTP server rows (host | port | TLS toggle) of
    /// the setup sheet, starting at `y`, and register their hit regions.
    /// Part of [`Self::rebuild_overlay_hits`].
    fn layout_server_rows(&mut self, fx: f64, rx: f64, mut y: f64, field_h: f64) {
        let port_w = 60.0;
        let tls_w = 58.0;
        let host_w = (rx - fx) - 12.0 - port_w - 12.0 - tls_w;

        let imap_host = Rect::new(fx, y, fx + host_w, y + field_h);
        self.layout_setup_input(4, imap_host);
        self.overlay_hits
            .push((imap_host, OverlayHit::SetupField(4)));
        let port_imap = Rect::new(
            imap_host.x1 + 12.0,
            y,
            imap_host.x1 + 12.0 + port_w,
            y + field_h,
        );
        self.layout_setup_input(5, port_imap);
        self.overlay_hits
            .push((port_imap, OverlayHit::SetupField(5)));
        let imap_tls = Rect::new(port_imap.x1 + 12.0, y, rx, y + field_h);
        self.overlay_hits
            .push((imap_tls, OverlayHit::ToggleImapTls));
        y += field_h + 12.0;

        let smtp_host = Rect::new(fx, y, fx + host_w, y + field_h);
        self.layout_setup_input(6, smtp_host);
        self.overlay_hits
            .push((smtp_host, OverlayHit::SetupField(6)));
        let port_smtp = Rect::new(
            smtp_host.x1 + 12.0,
            y,
            smtp_host.x1 + 12.0 + port_w,
            y + field_h,
        );
        self.layout_setup_input(7, port_smtp);
        self.overlay_hits
            .push((port_smtp, OverlayHit::SetupField(7)));
        let smtp_tls = Rect::new(port_smtp.x1 + 12.0, y, rx, y + field_h);
        self.overlay_hits
            .push((smtp_tls, OverlayHit::ToggleSmtpTls));
    }

    fn read_setup_config(&self) -> AccountConfig {
        let g = |i: usize| {
            self.setup_input(i)
                .map(|inp| inp.value().to_string())
                .unwrap_or_default()
        };
        AccountConfig {
            display_name: g(0),
            email: g(1),
            username: g(2),
            // An OAuth account authenticates with a vault-sealed token, never a
            // password — keep the field empty so persist doesn't overwrite the
            // sealed token with a password secret.
            password: if self.setup_auth == crate::model::AuthMethod::OAuth {
                String::new()
            } else {
                g(3)
            },
            imap_host: g(4),
            imap_port: g(5).trim().parse().unwrap_or(993),
            smtp_host: g(6),
            smtp_port: g(7).trim().parse().unwrap_or(465),
            imap_tls: self.setup_imap_tls,
            smtp_tls: self.setup_smtp_tls,
            auth: self.setup_auth,
        }
    }

    /// Fill IMAP/SMTP hosts + ports from the typed email when focus leaves the
    /// email field (and again on save). Consults the network Mozilla autoconfig
    /// lookup for unknown domains under `live`; the built-in provider table
    /// covers the common providers instantly and offline.
    fn maybe_autofill(&mut self) {
        self.apply_autofill(true);
    }

    /// The instant, network-free fill applied as the address is typed: it uses
    /// only the built-in provider table (see [`crate::autoconfig::builtin_autoconfig`]),
    /// so `me@gmail.com` pre-fills the Gmail servers the moment it's complete —
    /// without waiting for a focus change or opening a socket. Unknown domains
    /// are left for the focus-leave/save pass to discover over the network.
    fn maybe_autofill_live_typing(&mut self) {
        self.apply_autofill(false);
    }

    /// Fill IMAP/SMTP host/port/TLS from the typed email when the host fields
    /// are still blank, and detect the provider so Gmail/Outlook preset to
    /// OAuth. Resolution order: the built-in provider table first (instant,
    /// offline), then — only when `network` and nothing matched — the real
    /// Mozilla autoconfig lookup (`live`), then the generic heuristic.
    fn apply_autofill(&mut self, network: bool) {
        let email = self
            .setup_input(1)
            .map(|inp| inp.value().trim().to_string())
            .unwrap_or_default();
        if !email.contains('@') {
            return;
        }
        let domain = email
            .split_once('@')
            .map(|(_, d)| d.to_string())
            .unwrap_or_default();

        // Provider detection → OAuth for the providers that block passwords.
        self.setup_provider = crate::oauth::OAuthProvider::from_domain(&domain);
        if self.setup_provider.is_some() {
            self.setup_auth = crate::model::AuthMethod::OAuth;
        }

        let imap_blank = self
            .setup_input(4)
            .is_none_or(|inp| inp.value().trim().is_empty());
        let smtp_blank = self
            .setup_input(6)
            .is_none_or(|inp| inp.value().trim().is_empty());
        if !imap_blank && !smtp_blank {
            self.dirty = true;
            return;
        }

        let mut cfg = AccountConfig {
            email: email.clone(),
            username: self
                .setup_input(2)
                .map(|inp| inp.value().to_string())
                .unwrap_or_default(),
            display_name: self
                .setup_input(0)
                .map(|inp| inp.value().to_string())
                .unwrap_or_default(),
            auth: self.setup_auth,
            ..Default::default()
        };
        // Built-in table first (instant, offline). Network discovery only for
        // domains it doesn't cover, and only on the focus-leave/save pass.
        if let Some(ac) = crate::autoconfig::builtin_autoconfig(&domain) {
            ac.apply_to(&mut cfg);
        } else if network {
            match autoconfig_lookup(&email) {
                Some(ac) => ac.apply_to(&mut cfg),
                None => {
                    cfg.autofill_from_email();
                }
            }
        } else {
            cfg.autofill_from_email();
        }
        // The provider table fills only the connection fields; default the
        // identity fields from the address (username = the email, display name =
        // its local part) so a table-filled account is immediately savable.
        if cfg.username.trim().is_empty() {
            cfg.username.clone_from(&email);
        }
        if cfg.display_name.trim().is_empty()
            && let Some((local, _)) = email.split_once('@')
        {
            cfg.display_name = local.to_string();
        }

        if imap_blank {
            self.set_setup_input(4, &cfg.imap_host);
            self.set_setup_input(5, &cfg.imap_port.to_string());
            self.setup_imap_tls = cfg.imap_tls;
        }
        if smtp_blank {
            self.set_setup_input(6, &cfg.smtp_host);
            self.set_setup_input(7, &cfg.smtp_port.to_string());
            self.setup_smtp_tls = cfg.smtp_tls;
        }
        if self
            .setup_input(2)
            .is_some_and(|inp| inp.value().trim().is_empty())
        {
            self.set_setup_input(2, &cfg.username);
        }
        if self
            .setup_input(0)
            .is_some_and(|inp| inp.value().trim().is_empty())
        {
            self.set_setup_input(0, &cfg.display_name);
        }
        // Autoconfig may have upgraded the auth method (OAuth2 in the XML).
        self.setup_auth = cfg.auth;
        self.dirty = true;
    }

    fn save_setup(&mut self, doc: &mut AutoCommit) {
        self.save_setup_with(doc, &default_probe());
    }

    /// Save the account, but only after its credentials pass a live IMAP login
    /// and SMTP handshake through `probe`. On failure the sheet stays open with
    /// a specific error; on success the account is persisted and connected. The
    /// `probe` seam makes the persist-on-success / keep-on-failure behaviour
    /// unit-testable without a network.
    fn save_setup_with(
        &mut self,
        _doc: &mut AutoCommit,
        probe: &dyn crate::validate::ProbeTransport,
    ) {
        self.maybe_autofill();
        let cfg = self.read_setup_config();
        let outcome = crate::validate::validate_account(&cfg, probe);
        if !outcome.persisted() {
            let msg = outcome.message();
            self.setup_error = Some(msg.clone());
            self.shared.borrow_mut().status = Some(msg);
            self.dirty = true;
            return;
        }
        self.setup_error = None;
        {
            let mut st = self.shared.borrow_mut();
            let mut account = match self.setup_editing.and_then(|i| st.accounts.accounts.get(i)) {
                Some(existing) => {
                    let mut a = existing.clone();
                    a.config = cfg.clone();
                    a
                }
                None => Account::new(cfg.clone()),
            };
            account.id = if cfg.email.is_empty() {
                account.id
            } else {
                cfg.email.clone()
            };
            st.accounts.upsert(account);
            // Persist to the shared on-disk store + vault so the account (and
            // its password) survive a restart. Routed through `accounts_persist`
            // so sample / shots / test builds never touch the real store.
            match self.accounts_persist.persist(&st.accounts) {
                Ok(()) => st.status = Some("Account saved".into()),
                Err(e) => st.status = Some(format!("Saved, but could not write to disk: {e}")),
            }
            self.persisted_active_account = st
                .accounts
                .active_account()
                .map(|account| account.id.clone());
        }
        // Connect + fetch the freshly-saved account through the engine.
        self.post_engine(EngineRequest::connect(cfg.clone()));
        self.post_engine(EngineRequest::fetch(cfg, Folder::Inbox));
        self.close_setup();
    }

    /// Remove the account currently being edited, persist the removal to disk
    /// (dropping it from the shared store + purging its vault secret), and close
    /// the sheet. A no-op on the add flow (no editing target).
    fn remove_editing_account(&mut self, _doc: &mut AutoCommit) {
        let Some(idx) = self.setup_editing else {
            return;
        };
        {
            let mut st = self.shared.borrow_mut();
            let Some(id) = st.accounts.accounts.get(idx).map(|a| a.id.clone()) else {
                return;
            };
            st.accounts.remove(&id);
            match self.accounts_persist.persist(&st.accounts) {
                Ok(()) => st.status = Some("Account removed".into()),
                Err(e) => st.status = Some(format!("Removed, but could not write to disk: {e}")),
            }
            // The removed account's mailbox is no longer relevant; clear it so a
            // stale inbox doesn't linger. A fresh connect repopulates from the
            // new active account.
            st.mailbox = crate::model::Mailbox::new(st.accounts.active_config());
            st.selected = None;
            self.persisted_active_account = st
                .accounts
                .active_account()
                .map(|account| account.id.clone());
        }
        self.connect_requested = false;
        self.close_setup();
        self.dirty = true;
    }

    /// Begin the OAuth authorization-code + PKCE flow for the detected
    /// provider. The engine worker runs the real flow (bind the loopback
    /// redirect, open the browser, capture the code, exchange it, seal the
    /// tokens in the vault); this posts the request and shows progress. Surfaces
    /// a clear note when a registered client id has not been provisioned (the
    /// flow can't complete without one).
    fn start_oauth(&mut self) {
        let email = self
            .setup_input(1)
            .map(|inp| inp.value().trim().to_string())
            .unwrap_or_default();
        let Some(provider) = self.setup_provider else {
            self.shared.borrow_mut().status =
                Some("Enter a Gmail or Outlook address to sign in".into());
            self.dirty = true;
            return;
        };
        if email.is_empty() {
            self.shared.borrow_mut().status = Some("Enter your email address first".into());
            self.dirty = true;
            return;
        }
        if provider.client_id().is_none() {
            self.setup_error = Some(format!(
                "{} sign-in isn’t available here yet. Choose Password to continue with an app password.",
                provider.label()
            ));
            self.dirty = true;
            return;
        }
        match self.engine.as_ref() {
            Some(_) => {
                self.post_engine(EngineRequest::oauth_authorize(
                    email.clone(),
                    provider,
                    email,
                ));
                self.setup_error = None;
                self.shared.borrow_mut().status = Some(format!(
                    "Opening {} sign-in in your browser…",
                    provider.label()
                ));
            }
            None => {
                self.shared.borrow_mut().status =
                    Some("Sign-in isn't available in this mode".into());
            }
        }
        self.dirty = true;
    }

    fn overlay_panel_rect(&self) -> Rect {
        let r = self.rect;
        let w = 660.0_f64.min(r.width() - 48.0);
        // The first-run welcome is shorter than the taller account form.
        let target_h: f64 = if self.setup_open { 500.0 } else { 440.0 };
        let h = target_h.min(r.height() - 48.0);
        let cx = f64::midpoint(r.x0, r.x1);
        let y0 = r.y0 + (r.height() - h) / 2.0;
        Rect::new(cx - w / 2.0, y0, cx + w / 2.0, y0 + h)
    }

    fn rebuild_overlay_hits(&mut self) {
        self.overlay_hits.clear();
        if self.setup_open {
            let p = self.overlay_panel_rect();
            let pad = 26.0;
            let lx = p.x0 + pad;
            let rx = p.x1 - pad;
            let field_h = 34.0;
            let label_w = 120.0;
            let fx = lx + label_w; // field left edge
            let mut y = p.y0 + 76.0;

            // Identity fields: Display name (0), Email (1), Username (2).
            for i in [0usize, 1, 2] {
                let fr = Rect::new(fx, y, rx, y + field_h);
                self.layout_setup_input(i, fr);
                self.overlay_hits.push((fr, OverlayHit::SetupField(i)));
                y += field_h + 12.0;
            }

            // Sign-in method pills.
            let pill_w = 104.0;
            let pw_pill = Rect::new(fx, y, fx + pill_w, y + field_h);
            let oauth_pill =
                Rect::new(fx + pill_w + 10.0, y, fx + pill_w * 2.0 + 10.0, y + field_h);
            self.overlay_hits.push((pw_pill, OverlayHit::AuthPassword));
            self.overlay_hits.push((oauth_pill, OverlayHit::AuthOAuth));
            y += field_h + 12.0;

            // Password field (3) OR the OAuth sign-in button.
            if self.setup_auth == crate::model::AuthMethod::Password {
                let fr = Rect::new(fx, y, rx, y + field_h);
                self.layout_setup_input(3, fr);
                self.overlay_hits.push((fr, OverlayHit::SetupField(3)));
            } else {
                let btn = Rect::new(fx, y, fx + 240.0, y + field_h + 4.0);
                self.overlay_hits.push((btn, OverlayHit::OAuthSignIn));
            }
            y += field_h + 20.0;

            // Server rows: host | port | TLS.
            self.layout_server_rows(fx, rx, y, field_h);

            let by = p.y1 - 54.0;
            self.overlay_hits.push((
                Rect::new(lx, by, lx + 168.0, by + 38.0),
                OverlayHit::SetupSave,
            ));
            self.overlay_hits.push((
                Rect::new(rx - 92.0, by, rx, by + 38.0),
                OverlayHit::CancelSetup,
            ));
            // A destructive "Remove" affordance, only when editing an existing
            // account (never on the add flow).
            if self.setup_editing.is_some() {
                self.overlay_hits.push((
                    Rect::new(lx + 180.0, by, lx + 300.0, by + 38.0),
                    OverlayHit::RemoveAccount,
                ));
            }
        }
        if let Some(menu) = &self.context_menu {
            let mr = context_menu_rect(menu, self.rect);
            let mut y = mr.y0 + 6.0;
            for (i, _a) in menu.items.iter().enumerate() {
                self.overlay_hits
                    .push((Rect::new(mr.x0, y, mr.x1, y + 28.0), OverlayHit::CtxItem(i)));
                y += 28.0;
            }
        }
    }

    // ---- sync / refresh ---------------------------------------------------

    /// Post a fetch of the currently-viewed folder for the active account, and
    /// show a syncing indicator. Used by the manual-refresh shortcut and the
    /// periodic auto-refresh. A no-op with no account or no engine.
    fn refresh_active_folder(&mut self) -> Option<EngineRequestId> {
        let (account, folder) = {
            let st = self.shared.borrow();
            (st.accounts.active_config(), st.folder)
        };
        if account.email.is_empty() {
            return None;
        }
        if self.engine.is_some() {
            let account_id = account.email.clone();
            let request_id = self.post_engine(EngineRequest::fetch(account, folder))?;
            report_account_sync(
                &account_id,
                accounts::AccountSyncHealth::Syncing,
                false,
                Some("Checking mail"),
            );
            self.last_auto_refresh_min = self.shared.borrow().now_min;
            self.shared.borrow_mut().status = Some("Syncing…".into());
            self.dirty = true;
            return Some(request_id);
        }
        None
    }

    /// Fire a periodic refresh if enough wall-clock time has elapsed since the
    /// last one and no request is already outstanding. Checked once per active
    /// frame in `sync` (so it fires during use); a fully-idle session refreshes
    /// on the next interaction rather than waking the CPU on a timer.
    fn maybe_auto_refresh(&mut self) {
        if self.awaiting_engine || self.engine.is_none() {
            return;
        }
        let (now, has_account) = {
            let st = self.shared.borrow();
            (st.now_min, !st.accounts.is_empty())
        };
        if !has_account {
            return;
        }
        if self.last_auto_refresh_min == 0 {
            // Seed the clock on the first frame so the initial connect fetch
            // isn't immediately followed by a redundant refresh.
            self.last_auto_refresh_min = now;
            return;
        }
        if now - self.last_auto_refresh_min >= AUTO_REFRESH_MIN {
            let _ = self.refresh_active_folder();
        }
    }

    // ---- transient status toast ------------------------------------------

    /// Notice a newly-set status toast, arm its dismiss deadline, and clear the
    /// status once the deadline passes. Parameterised on `now` so the timing is
    /// unit-testable without a real sleep.
    fn expire_toast_at(&mut self, now: std::time::Instant) {
        let current = self.shared.borrow().status.clone();
        if current != self.toast_text {
            // The status changed (or was cleared): (re)arm the timer.
            self.toast_text.clone_from(&current);
            self.toast_deadline = current.as_ref().map(|_| now + TOAST_TTL);
        }
        if let Some(deadline) = self.toast_deadline
            && now >= deadline
        {
            let mut st = self.shared.borrow_mut();
            st.status = None;
            st.dirty = true;
            self.toast_text = None;
            self.toast_deadline = None;
        }
    }

    /// Whether a toast is currently on screen and still counting down — used to
    /// keep the frame pump alive so the auto-dismiss fires even with no input.
    fn toast_pending(&self) -> bool {
        self.toast_deadline.is_some()
    }

    // ---- engine drain -----------------------------------------------------

    #[allow(
        clippy::too_many_lines,
        reason = "the engine drain is one ordered lifecycle reducer over every EngineEvent variant; splitting it would scatter the shared settlement and dirty-state transitions"
    )]
    fn drain_engine(&mut self, doc: &mut AutoCommit) {
        let Some(h) = &self.engine else { return };
        let mut events = Vec::new();
        while let Ok(ev) = h.rx.try_recv() {
            events.push(ev);
        }
        if events.is_empty() {
            return;
        }
        {
            let mut st = self.shared.borrow_mut();
            for ev in events {
                match ev {
                    EngineEvent::Connected {
                        request_id,
                        account_id,
                    } if self.expects_engine_event(request_id, EngineRequestKind::Connect) => {
                        st.status = Some(format!("Connected {account_id}"));
                        report_account_sync(
                            &account_id,
                            accounts::AccountSyncHealth::Syncing,
                            false,
                            Some("Connected; fetching mail"),
                        );
                    }
                    EngineEvent::Folders {
                        request_id,
                        folders,
                        ..
                    } if self.expects_engine_event(request_id, EngineRequestKind::Connect) => {
                        // The fixed system-folder set drives the sidebar; log the
                        // server's advertised set for visibility.
                        tracing::info!(count = folders.len(), "mail: server folders listed");
                    }
                    EngineEvent::Fetched {
                        request_id,
                        account_id,
                        folder,
                        messages,
                    } if self.expects_engine_event(request_id, EngineRequestKind::Fetch) => {
                        let count = messages.len();
                        for m in messages {
                            MailDoc::ingest_message_flags(doc, &m);
                            st.mailbox.insert(m);
                        }
                        if st.folder == folder && st.selected.is_none() {
                            st.selected = st
                                .current_threads()
                                .first()
                                .and_then(|t| t.message_ids.last().copied());
                        }
                        st.status = Some(if count == 0 {
                            format!("{} up to date", folder.title())
                        } else {
                            format!("Synced {count} messages")
                        });
                        report_account_sync(
                            &account_id,
                            accounts::AccountSyncHealth::Healthy,
                            true,
                            Some("Mail is up to date"),
                        );
                        if self
                            .resource_refresh_invocation
                            .is_some_and(|(pending, _)| pending == request_id)
                            && let Some((_, invocation)) = self.resource_refresh_invocation
                        {
                            self.resource_refresh_result =
                                Some(qos_actions::InvocationUpdate::Succeeded {
                                    invocation,
                                    output: qos_actions::ActionOutput::default(),
                                });
                        }
                    }
                    EngineEvent::Sent {
                        request_id,
                        wire_bytes,
                    } if self.expects_engine_event(request_id, EngineRequestKind::Send) => {
                        if self
                            .pending_send
                            .as_ref()
                            .is_some_and(|pending| pending.request_id == request_id)
                            && let Some(pending) = self.pending_send.take()
                        {
                            // A message joins Sent only after SMTP has
                            // accepted its bytes. If this was an edited draft,
                            // remove that draft at the same point; failures
                            // leave the composer and draft intact for retry.
                            if let Some(draft_id) = pending.edited_draft {
                                st.mailbox.messages.remove(&draft_id);
                                st.mailbox
                                    .order
                                    .retain(|message_id| *message_id != draft_id);
                            }
                            MailDoc::ingest_message_flags(doc, &pending.message);
                            st.mailbox.insert(pending.message);
                            self.editing_draft = None;
                            self.compose.close();
                            st.status = Some(format!("Delivered ({wire_bytes} bytes)"));
                        }
                    }
                    EngineEvent::Authorized {
                        request_id,
                        account_id,
                    } if self
                        .expects_engine_event(request_id, EngineRequestKind::OAuthAuthorize) =>
                    {
                        // Tokens are sealed in the vault under the email; the
                        // account (saved with that email as its id) reads them
                        // at connect time.
                        st.status = Some(format!("Signed in as {account_id}"));
                        report_account_sync(
                            &account_id,
                            accounts::AccountSyncHealth::Healthy,
                            true,
                            Some("Signed in"),
                        );
                    }
                    EngineEvent::Error {
                        request_id,
                        kind,
                        context,
                        message,
                    } if self.expects_engine_event(request_id, kind) => {
                        // Surface the specific failure so a fetch never fails
                        // silently into an empty inbox.
                        st.status = Some(format!("{context}: {message}"));
                        let account_id = st.accounts.active_config().email;
                        let lower = format!("{context} {message}").to_ascii_lowercase();
                        let health = if ["auth", "login", "password", "oauth", "credential"]
                            .iter()
                            .any(|needle| lower.contains(needle))
                        {
                            accounts::AccountSyncHealth::NeedsAuthentication
                        } else {
                            accounts::AccountSyncHealth::Error
                        };
                        report_account_sync(
                            &account_id,
                            health,
                            false,
                            Some(&format!("{context}: {message}")),
                        );
                        if self
                            .pending_send
                            .as_ref()
                            .is_some_and(|pending| pending.request_id == request_id)
                        {
                            // Keep the compose surface open and its contents
                            // untouched. A failed SMTP round trip is not a
                            // sent message and must remain recoverable.
                            self.pending_send = None;
                        }
                        if self
                            .resource_refresh_invocation
                            .is_some_and(|(pending, _)| pending == request_id)
                            && let Some((_, invocation)) = self.resource_refresh_invocation
                        {
                            self.resource_refresh_result =
                                Some(qos_actions::InvocationUpdate::Failed {
                                    invocation,
                                    error: qos_actions::ActionFailure {
                                        code: "mail.refresh_failed".into(),
                                        message: format!("{context}: {message}"),
                                        details: None,
                                        retryable: true,
                                    },
                                });
                        }
                    }
                    EngineEvent::Completed { request_id, kind }
                        if self.expects_engine_event(request_id, kind) =>
                    {
                        // Completion is independent from the preceding UI
                        // event. Successful IMAP writes have no payload event
                        // at all, while Connect emits both Connected and
                        // Folders, so only this acknowledgement may settle a
                        // queued request.
                        self.pending_engine_requests.remove(&request_id);
                    }
                    ignored => {
                        tracing::warn!(request_id = %ignored.request_id(), "mail: ignoring unmatched or wrong-kind engine event");
                    }
                }
            }
            st.dirty = true;
        }
        self.awaiting_engine = !self.pending_engine_requests.is_empty();
    }

    /// Register the locally hydrated corpus before actions target it. This is
    /// external ingestion, not a user mutation: it never writes flags from a
    /// presentation cache into the collaborative document.
    fn register_hydrated_messages(&self, doc: &mut AutoCommit) {
        let st = self.shared.borrow();
        let ids: Vec<_> = st.mailbox.messages.keys().copied().collect();
        for id in ids {
            if let Some(message) = st.mailbox.get(id) {
                MailDoc::ingest_message_flags(doc, message);
            }
        }
    }

    /// Flush an active-account change to the device-local shared account store.
    /// This runs after every input path (pane pointer/keyboard, accessibility,
    /// or canonical resource operation) has selected an account. It never
    /// touches the Automerge document.
    fn persist_active_account_if_changed(&mut self) {
        let (active, accounts) = {
            let state = self.shared.borrow();
            (
                state
                    .accounts
                    .active_account()
                    .map(|account| account.id.clone()),
                state.accounts.clone(),
            )
        };
        if active == self.persisted_active_account {
            return;
        }
        match self.accounts_persist.persist(&accounts) {
            Ok(()) => self.persisted_active_account = active,
            Err(error) => {
                self.shared.borrow_mut().status = Some(format!(
                    "Selected account, but could not save that preference: {error}"
                ));
            }
        }
    }

    /// Persist the compose mode on this device only. The caller invokes this
    /// at every format-changing or composer lifecycle boundary; the retained
    /// value makes unchanged close/save/send paths a no-op.
    fn persist_compose_format_if_changed(&mut self) {
        let format = self.compose.format();
        if format == self.persisted_compose_format {
            return;
        }
        match self.accounts_persist.persist_compose_format(format) {
            Ok(()) => self.persisted_compose_format = format,
            Err(error) => {
                self.shared.borrow_mut().status = Some(format!(
                    "Compose format changed, but could not save that preference: {error}"
                ));
            }
        }
    }

    /// Apply collaborative domain state to the local hydrated corpus. Folder,
    /// selection, search, and composer format remain local to this window.
    fn hydrate_domain_state(&self, doc: &mut AutoCommit) {
        {
            let mut st = self.shared.borrow_mut();
            MailDoc::apply_flags(doc, &mut st.mailbox);
        }
        // A persisted draft becomes a local Drafts projection, but does not
        // force another collaborator's composer open.
        let draft = MailDoc::load_draft(doc);
        if !draft.to.is_empty() || !draft.subject.is_empty() || !draft.body.is_empty() {
            self.upsert_draft_message(doc, &draft);
        }
    }

    /// The context the Ctrl+K resource tree is built from: the account label, the
    /// open folder and its messages, the user's local-folder registry, and
    /// whether a draft is in progress. Everything is read from state the document
    /// already holds; nothing is fabricated. See [`crate::actions`].
    pub(crate) fn mail_resource_ctx(&self, doc: &AutoCommit) -> crate::actions::MailResourceCtx {
        let st = self.shared.borrow();
        let mailbox_label = {
            let cfg = st.accounts.active_config();
            if cfg.email.is_empty() {
                "Mailbox".to_string()
            } else {
                cfg.email
            }
        };
        let current_folder = st.folder;
        let accounts = st
            .accounts
            .accounts
            .iter()
            .enumerate()
            .map(|(index, account)| {
                (
                    account.id.clone(),
                    account.label().to_string(),
                    st.accounts.active == index,
                )
            })
            .collect();
        // `messages_in` is the single folder projection shared with the list;
        // importantly it includes the virtual Starred folder.  Give each row
        // the anchor from that same projection so resource/history identities
        // stay independent of user-editable subjects.
        let thread_ids: HashMap<_, _> = st
            .mailbox
            .threads_in(current_folder)
            .into_iter()
            .flat_map(|thread| {
                let anchor = thread.id;
                thread
                    .message_ids
                    .into_iter()
                    .map(move |id| (id, anchor.clone()))
            })
            .collect();
        let messages = st
            .mailbox
            .messages_in(current_folder)
            .into_iter()
            .take(crate::actions::OPEN_MESSAGE_LIMIT)
            .map(|message| {
                let mut row = crate::actions::message_row(message);
                if let Some(thread_id) = thread_ids.get(&message.id) {
                    row.thread_id.clone_from(thread_id);
                }
                row
            })
            .collect();
        let custom_folders = MailDoc::list_folders(doc);
        let draft = MailDoc::load_draft(doc);
        let has_draft = !draft.to.is_empty() || !draft.subject.is_empty() || !draft.body.is_empty();
        let can_sync = self.engine.is_some() && mailbox_label != "Mailbox";
        crate::actions::MailResourceCtx {
            mailbox_label,
            current_folder,
            accounts,
            messages,
            custom_folders,
            has_draft,
            can_sync,
        }
    }

    /// Materialise one message resource row on demand. The public resource
    /// tree deliberately carries only a bounded current-folder prefix, but a
    /// stable message id must still resolve for agents and search activation.
    pub(crate) fn resource_message_row(&self, id: &str) -> Option<crate::actions::MessageRow> {
        self.shared
            .borrow()
            .mailbox
            .messages
            .values()
            .find(|message| message.id.to_string() == id)
            .map(crate::actions::message_row)
    }

    /// Lazily materialise a bounded thread resource by its stable key. This
    /// keeps every loaded thread addressable even when the open-resource tree
    /// only carries the first `OPEN_MESSAGE_LIMIT` messages.
    pub(crate) fn resource_thread_rows(
        &self,
        stable: &str,
    ) -> Option<(String, Vec<crate::actions::MessageRow>)> {
        let (folder_raw, anchor_raw) = stable.split_once(':')?;
        let folder = Folder::from_key(folder_raw)?;
        if anchor_raw.is_empty() {
            return None;
        }
        let state = self.shared.borrow();
        let thread = state
            .mailbox
            .threads_in(folder)
            .into_iter()
            .find(|thread| thread.id == anchor_raw)?;
        let subject = thread.subject;
        Some((
            subject,
            thread
                .message_ids
                .into_iter()
                .filter_map(|id| state.mailbox.get(id))
                .take(crate::actions::OPEN_MESSAGE_LIMIT)
                .map(crate::actions::message_row)
                .collect(),
        ))
    }

    // ---- drawing the app-owned overlays ----------------------------------

    fn draw_context_menu(
        &self,
        scene: &mut Scene,
        t: Affine,
        tr: &mut TextRenderer,
        theme: &Theme,
    ) {
        let Some(menu) = &self.context_menu else {
            return;
        };
        let c = &theme.tokens.colors;
        let mr = context_menu_rect(menu, self.rect);
        scene.fill(
            Fill::NonZero,
            t,
            Color::from_rgba8(0, 0, 0, 80),
            None,
            &RoundedRect::from_rect(
                Rect::new(mr.x0 + 1.0, mr.y0 + 3.0, mr.x1 + 1.0, mr.y1 + 4.0),
                10.0,
            ),
        );
        fill_round(scene, t, mr, 10.0, c.surfaces.raised);
        stroke_round(
            scene,
            t,
            mr,
            10.0,
            1.0,
            ui::tokens::colors::Colors::hairline_on(c.surfaces.raised, 26),
        );
        let (read, starred) = self
            .shared
            .borrow()
            .mailbox
            .get(menu.target)
            .map_or((false, false), |m| (m.read, m.starred));
        let last_mouse = self.shared.borrow().last_mouse;
        let mut y = mr.y0 + 6.0;
        for a in &menu.items {
            let item = Rect::new(mr.x0, y, mr.x1, y + 28.0);
            if item.contains(last_mouse) {
                fill_round(
                    scene,
                    t,
                    Rect::new(item.x0 + 4.0, item.y0 + 1.0, item.x1 - 4.0, item.y1 - 1.0),
                    6.0,
                    c.lift(0.72),
                );
            }
            let danger = matches!(a, CtxAction::Delete);
            let col = if danger {
                c.semantic.danger
            } else {
                c.text_primary
            };
            tr.draw_text(
                scene,
                &a.label(read, starred),
                12.5,
                col,
                t * Affine::translate((mr.x0 + 14.0, y + 7.0)),
                None,
            );
            y += 28.0;
        }
    }

    fn draw_setup(
        &mut self,
        scene: &mut Scene,
        t: Affine,
        tr: &mut TextRenderer,
        theme: &Theme,
        presence: &PresenceCtx,
    ) {
        if !self.setup_open {
            return;
        }
        let c = &theme.tokens.colors;
        fill_rect(scene, t, self.rect, c.surfaces.overlay);
        let p = self.overlay_panel_rect();
        // Soft drop shadow so the sheet floats above the dimmed mailbox.
        scene.fill(
            Fill::NonZero,
            t,
            Color::from_rgba8(0, 0, 0, 90),
            None,
            &RoundedRect::from_rect(Rect::new(p.x0, p.y0 + 6.0, p.x1, p.y1 + 10.0), 16.0),
        );
        fill_round(scene, t, p, 16.0, c.surfaces.raised);
        stroke_round(
            scene,
            t,
            p,
            16.0,
            1.0,
            ui::tokens::colors::Colors::hairline_on(c.surfaces.raised, 26),
        );
        let pad = 26.0;
        let lx = p.x0 + pad;
        let last_mouse = self.shared.borrow().last_mouse;
        // Editing reads as scoped to a specific account (its address as the
        // subtitle); adding is its own clearly-separate flow.
        let editing_email = self.setup_editing.and_then(|i| {
            let st = self.shared.borrow();
            st.accounts.accounts.get(i).map(|a| {
                if a.config.email.is_empty() {
                    a.label().to_string()
                } else {
                    a.config.email.clone()
                }
            })
        });
        let (heading, subtitle) = match &editing_email {
            Some(email) => ("Account settings", email.clone()),
            None => (
                "Add account",
                "Enter your email — server details fill in automatically.".to_string(),
            ),
        };
        tr.draw_text_weighted(
            scene,
            heading,
            17.0,
            c.text_primary,
            t * Affine::translate((lx, p.y0 + 20.0)),
            None,
            TextWeight::Bold,
        );
        tr.draw_text(
            scene,
            &subtitle,
            11.5,
            c.text_dim,
            t * Affine::translate((lx, p.y0 + 44.0)),
            None,
        );

        let smtp_row_bottom = self.draw_setup_fields(scene, t, tr, theme, presence, p, lx);
        self.draw_setup_auth_method(scene, t, tr, theme, lx, last_mouse);
        self.draw_setup_tls_toggles(scene, t, tr, theme);
        self.draw_setup_footer(scene, t, tr, theme, lx, last_mouse, smtp_row_bottom);
    }

    /// The identity + server fields (left-column labels, the "Port" caption,
    /// and each [`TextInput`]'s own drawing). Part of [`Self::draw_setup`];
    /// returns the bottom edge of the SMTP-host row, which the footer's
    /// autoconfig hint sits just below.
    #[allow(
        clippy::too_many_arguments,
        reason = "each parameter is a distinct piece of already-computed layout/state the fields draw with; bundling them into a context struct would just move the same count into a field list"
    )]
    fn draw_setup_fields(
        &mut self,
        scene: &mut Scene,
        t: Affine,
        tr: &mut TextRenderer,
        theme: &Theme,
        presence: &PresenceCtx,
        p: Rect,
        lx: f64,
    ) -> f64 {
        let c = &theme.tokens.colors;
        let labels = [
            "Display name",
            "Email",
            "Username",
            "Password",
            "IMAP host",
            "",
            "SMTP host",
            "",
        ];
        let cfg_errs: std::collections::HashSet<&str> = self
            .read_setup_config()
            .validate()
            .into_iter()
            .map(|(k, _)| k)
            .collect();
        let err_for = |i: usize| match i {
            1 => cfg_errs.contains("email"),
            2 => cfg_errs.contains("username"),
            4 => cfg_errs.contains("imap_host"),
            6 => cfg_errs.contains("smtp_host"),
            _ => false,
        };

        // Field labels (left column). The single border + focus ring is drawn
        // by each TextInput itself — no second app-drawn border stacks on top.
        let mut shown: Vec<usize> = Vec::new();
        let mut smtp_row_bottom = p.y0;
        for (rect, hit) in &self.overlay_hits {
            let OverlayHit::SetupField(i) = hit else {
                continue;
            };
            let i = *i;
            shown.push(i);
            if i == 6 {
                smtp_row_bottom = rect.y1;
            }
            if let Some(label) = labels.get(i).filter(|l| !l.is_empty()) {
                let col = if err_for(i) {
                    c.semantic.danger
                } else {
                    c.text_dim
                };
                tr.draw_text(
                    scene,
                    label,
                    12.5,
                    col,
                    t * Affine::translate((lx, rect.y0 + 9.0)),
                    None,
                );
            }
            if i == 5 {
                tr.draw_text(
                    scene,
                    "Port",
                    11.0,
                    c.text_dim,
                    t * Affine::translate((rect.x0, rect.y0 - 15.0)),
                    None,
                );
            }
        }
        for i in shown {
            if let Some(inp) = self.setup_inputs.get_mut(i) {
                inp.draw(scene, t, tr, theme, presence);
            }
        }
        smtp_row_bottom
    }

    /// The sign-in method pills (Password / OAuth) and, in place of the
    /// password field, the OAuth sign-in button. Part of [`Self::draw_setup`].
    fn draw_setup_auth_method(
        &self,
        scene: &mut Scene,
        t: Affine,
        tr: &mut TextRenderer,
        theme: &Theme,
        lx: f64,
        last_mouse: Point,
    ) {
        self.draw_setup_auth_pills(scene, t, tr, theme, lx, last_mouse);
        self.draw_setup_oauth_button(scene, t, tr, theme, last_mouse);
    }

    /// The sign-in method pills (Password / OAuth) and their "Sign-in"
    /// label. Part of [`Self::draw_setup_auth_method`].
    fn draw_setup_auth_pills(
        &self,
        scene: &mut Scene,
        t: Affine,
        tr: &mut TextRenderer,
        theme: &Theme,
        lx: f64,
        last_mouse: Point,
    ) {
        let c = &theme.tokens.colors;
        // Sign-in method pills + label.
        for (rect, hit) in &self.overlay_hits {
            let (label, active) = match hit {
                OverlayHit::AuthPassword => (
                    "Password",
                    self.setup_auth == crate::model::AuthMethod::Password,
                ),
                OverlayHit::AuthOAuth => {
                    ("OAuth", self.setup_auth == crate::model::AuthMethod::OAuth)
                }
                _ => continue,
            };
            if matches!(hit, OverlayHit::AuthPassword) {
                tr.draw_text(
                    scene,
                    "Sign-in",
                    12.5,
                    c.text_dim,
                    t * Affine::translate((lx, rect.y0 + 9.0)),
                    None,
                );
            }
            let hov = rect.contains(last_mouse);
            let bg = if active {
                c.accent[5].with_alpha_factor(0.22)
            } else if hov {
                c.lift(0.72)
            } else {
                c.lift(0.35)
            };
            fill_round(scene, t, *rect, 8.0, bg);
            stroke_round(
                scene,
                t,
                *rect,
                8.0,
                1.0,
                if active {
                    c.accent[5]
                } else {
                    ui::tokens::colors::Colors::hairline_on(c.surfaces.raised, 26)
                },
            );
            let col = if active { c.text_primary } else { c.neutral[7] };
            let (w, _) = tr.measure_weighted(label, 12.5, None, TextWeight::Medium);
            tr.draw_text_weighted(
                scene,
                label,
                12.5,
                col,
                t * Affine::translate((
                    f64::midpoint(rect.x0, rect.x1) - f64::from(w) / 2.0,
                    rect.y0 + 9.0,
                )),
                None,
                TextWeight::Medium,
            );
        }
    }

    /// The OAuth sign-in button shown in place of the password field, with
    /// its client-id availability note. Part of
    /// [`Self::draw_setup_auth_method`].
    fn draw_setup_oauth_button(
        &self,
        scene: &mut Scene,
        t: Affine,
        tr: &mut TextRenderer,
        theme: &Theme,
        last_mouse: Point,
    ) {
        let c = &theme.tokens.colors;
        // OAuth sign-in button (shown in place of the password field).
        for (rect, hit) in &self.overlay_hits {
            if !matches!(hit, OverlayHit::OAuthSignIn) {
                continue;
            }
            let prov = self
                .setup_provider
                .map_or("your provider", super::oauth::OAuthProvider::label);
            let hov = rect.contains(last_mouse);
            fill_round(
                scene,
                t,
                *rect,
                9.0,
                if hov { c.accent[4] } else { c.accent[5] },
            );
            let label = format!("Sign in with {prov}");
            tr.draw_text_weighted(
                scene,
                &label,
                13.0,
                Color::WHITE,
                t * Affine::translate((rect.x0 + 16.0, rect.y0 + 11.0)),
                None,
                TextWeight::Semibold,
            );
            // Deployment details never belong in an account form. If this
            // installation has no OAuth client, explain the usable alternative
            // in user language and leave the Password choice directly above.
            let has_client = self
                .setup_provider
                .and_then(super::oauth::OAuthProvider::client_id)
                .is_some();
            let note = if has_client {
                "Opens your browser to authorize (OAuth2 + PKCE).".to_string()
            } else {
                "Not available in this installation · Password sign-in is available.".to_string()
            };
            tr.draw_text(
                scene,
                &note,
                10.5,
                c.text_dim,
                t * Affine::translate((rect.x1 + 12.0, rect.y0 + 12.0)),
                None,
            );
        }
    }

    /// The IMAP/SMTP TLS toggle switches. Part of [`Self::draw_setup`].
    fn draw_setup_tls_toggles(
        &self,
        scene: &mut Scene,
        t: Affine,
        tr: &mut TextRenderer,
        theme: &Theme,
    ) {
        let c = &theme.tokens.colors;
        let last_mouse = self.shared.borrow().last_mouse;
        for (rect, hit) in &self.overlay_hits {
            let (on, label) = match hit {
                OverlayHit::ToggleImapTls => (self.setup_imap_tls, "TLS"),
                OverlayHit::ToggleSmtpTls => (self.setup_smtp_tls, "TLS"),
                _ => continue,
            };
            let pill = Rect::new(rect.x0, rect.y0 + 6.0, rect.x0 + 40.0, rect.y0 + 28.0);
            Toggle::paint(
                scene,
                t,
                theme,
                &ToggleFace::new(pill, on).hovered(rect.contains(last_mouse)),
            );
            tr.draw_text(
                scene,
                label,
                12.0,
                c.neutral[8],
                t * Affine::translate((pill.x1 + 8.0, rect.y0 + 10.0)),
                None,
            );
        }
    }

    /// The autoconfig/validation hint line and the Save / Cancel / Remove
    /// buttons at the bottom of the sheet. Part of [`Self::draw_setup`].
    #[allow(
        clippy::too_many_arguments,
        reason = "each parameter is a distinct piece of already-computed layout/state the footer draws with; bundling them into a context struct would just move the same count into a field list"
    )]
    fn draw_setup_footer(
        &self,
        scene: &mut Scene,
        t: Affine,
        tr: &mut TextRenderer,
        theme: &Theme,
        lx: f64,
        last_mouse: Point,
        smtp_row_bottom: f64,
    ) {
        self.draw_setup_autoconfig_hint(scene, t, tr, theme, lx, smtp_row_bottom);
        self.draw_setup_footer_buttons(scene, t, tr, theme, last_mouse);
    }

    /// The autoconfig hint / validation message between the server rows and
    /// the button row. Part of [`Self::draw_setup_footer`].
    fn draw_setup_autoconfig_hint(
        &self,
        scene: &mut Scene,
        t: Affine,
        tr: &mut TextRenderer,
        theme: &Theme,
        lx: f64,
        smtp_row_bottom: f64,
    ) {
        let c = &theme.tokens.colors;
        let hint_y = smtp_row_bottom + 18.0;
        if let Some(msg) = &self.setup_error {
            Icon::Ban.draw(
                scene,
                t,
                Rect::new(lx, hint_y - 1.0, lx + 15.0, hint_y + 14.0),
                c.semantic.danger,
            );
            tr.draw_text(
                scene,
                msg,
                11.5,
                c.semantic.danger,
                t * Affine::translate((lx + 22.0, hint_y + 1.0)),
                None,
            );
        } else {
            Icon::Check.draw(
                scene,
                t,
                Rect::new(lx, hint_y - 1.0, lx + 15.0, hint_y + 14.0),
                c.semantic.success,
            );
            tr.draw_text(
                scene,
                "Credentials are verified before the account is saved.",
                11.5,
                c.text_dim,
                t * Affine::translate((lx + 22.0, hint_y + 1.0)),
                None,
            );
        }
    }

    /// The Save / Cancel / Remove buttons at the bottom of the setup sheet.
    /// Part of [`Self::draw_setup_footer`].
    fn draw_setup_footer_buttons(
        &self,
        scene: &mut Scene,
        t: Affine,
        tr: &mut TextRenderer,
        theme: &Theme,
        last_mouse: Point,
    ) {
        let c = &theme.tokens.colors;
        // Save / Cancel.
        for (rect, hit) in &self.overlay_hits {
            match hit {
                OverlayHit::SetupSave => {
                    let hov = rect.contains(last_mouse);
                    fill_round(
                        scene,
                        t,
                        *rect,
                        9.0,
                        if hov { c.accent[4] } else { c.accent[5] },
                    );
                    let label = "Save & verify";
                    let (w, _) = tr.measure_weighted(label, 13.5, None, TextWeight::Semibold);
                    tr.draw_text_weighted(
                        scene,
                        label,
                        13.5,
                        Color::WHITE,
                        t * Affine::translate((
                            f64::midpoint(rect.x0, rect.x1) - f64::from(w) / 2.0,
                            rect.y0 + 11.0,
                        )),
                        None,
                        TextWeight::Semibold,
                    );
                }
                OverlayHit::CancelSetup => {
                    let hov = rect.contains(last_mouse);
                    fill_round(
                        scene,
                        t,
                        *rect,
                        9.0,
                        if hov { c.lift(0.72) } else { c.lift(0.35) },
                    );
                    let (w, _) = tr.measure("Cancel", 13.0, None);
                    tr.draw_text(
                        scene,
                        "Cancel",
                        13.0,
                        c.neutral[8],
                        t * Affine::translate((
                            f64::midpoint(rect.x0, rect.x1) - f64::from(w) / 2.0,
                            rect.y0 + 11.0,
                        )),
                        None,
                    );
                }
                OverlayHit::RemoveAccount => {
                    let hov = rect.contains(last_mouse);
                    fill_round(
                        scene,
                        t,
                        *rect,
                        9.0,
                        if hov {
                            c.semantic.danger.with_alpha_factor(0.22)
                        } else {
                            c.lift(0.35)
                        },
                    );
                    stroke_round(
                        scene,
                        t,
                        *rect,
                        9.0,
                        1.0,
                        c.semantic.danger.with_alpha_factor(0.5),
                    );
                    let (w, _) = tr.measure("Remove", 13.0, None);
                    tr.draw_text(
                        scene,
                        "Remove",
                        13.0,
                        c.semantic.danger,
                        t * Affine::translate((
                            f64::midpoint(rect.x0, rect.x1) - f64::from(w) / 2.0,
                            rect.y0 + 11.0,
                        )),
                        None,
                    );
                }
                _ => {}
            }
        }
    }

    fn draw_status(&self, scene: &mut Scene, t: Affine, tr: &mut TextRenderer, theme: &Theme) {
        let st = self.shared.borrow();
        let Some(msg) = &st.status else { return };
        let lower = msg.to_ascii_lowercase();
        let kind = if lower.contains("failed")
            || lower.contains("couldn’t")
            || lower.contains("couldn't")
            || lower.contains("error")
        {
            ToastKind::Error
        } else if lower.contains("offline") || lower.contains("isn't available") {
            ToastKind::Warning
        } else if lower.contains("sync")
            || lower.contains("connecting")
            || lower.contains("opening")
        {
            ToastKind::Info
        } else {
            ToastKind::Success
        };
        paint_transient(
            scene,
            t,
            tr,
            theme,
            self.rect,
            ToastAnchor::BottomRight,
            &ToastCard::new(msg, kind),
        );
    }

    // ---- test / probe accessors ------------------------------------------

    /// The content pane currently fronted (for tests / probes).
    pub fn nav_pane(&self) -> NavPane {
        self.nav.pane()
    }

    #[cfg(test)]
    fn layout_for_test(&mut self, w: f64, h: f64) {
        self.rect = Rect::new(0.0, 0.0, w, h);
        self.first_run.apply_layout_external(self.rect);
        self.layout_nav();
    }

    /// The directory account changes persist into: the real per-user config
    /// root for the live app, or a throwaway sandbox for the sample / shots /
    /// test constructors. `None` when persistence is disabled. Tests use this to
    /// prove sample mode never resolves the real store path.
    #[cfg(test)]
    fn accounts_persist_root(&self) -> Option<std::path::PathBuf> {
        match &self.accounts_persist {
            AccountsPersist::Real => accounts::config_root(),
            AccountsPersist::Sandbox(dir) => Some(dir.path().to_path_buf()),
            AccountsPersist::Disabled => None,
        }
    }
}

fn build_setup_inputs(cfg: &AccountConfig) -> Vec<TextInput> {
    vec![
        TextInput::local()
            .with_kind(ui::widget::TextInputKind::Name)
            .with_initial_value(&cfg.display_name)
            .with_placeholder("Your name"),
        TextInput::local()
            .with_kind(ui::widget::TextInputKind::Email)
            .with_initial_value(&cfg.email)
            .with_placeholder("you@example.com"),
        TextInput::local()
            .with_kind(ui::widget::TextInputKind::Username)
            .with_initial_value(&cfg.username)
            .with_placeholder("Usually your email"),
        TextInput::local()
            .with_kind(ui::widget::TextInputKind::Password)
            .with_initial_value(&cfg.password)
            .with_secret(true)
            .with_placeholder("Account password"),
        TextInput::local()
            .with_kind(ui::widget::TextInputKind::Url)
            .with_initial_value(&cfg.imap_host)
            .with_placeholder("imap.example.com"),
        TextInput::local()
            .with_kind(ui::widget::TextInputKind::Number)
            .with_initial_value(&cfg.imap_port.to_string()),
        TextInput::local()
            .with_kind(ui::widget::TextInputKind::Url)
            .with_initial_value(&cfg.smtp_host)
            .with_placeholder("smtp.example.com"),
        TextInput::local()
            .with_kind(ui::widget::TextInputKind::Number)
            .with_initial_value(&cfg.smtp_port.to_string()),
    ]
}

fn context_menu_rect(menu: &ContextMenu, bounds: Rect) -> Rect {
    let w = 210.0;
    let h = 6.0 + menu.items.len() as f64 * 28.0 + 6.0;
    let x0 = menu.pos.x.min(bounds.x1 - w - 8.0).max(bounds.x0 + 4.0);
    let y0 = menu.pos.y.min(bounds.y1 - h - 8.0).max(bounds.y0 + 4.0);
    Rect::new(x0, y0, x0 + w, y0 + h)
}

/// Metadata-only [`Attachment`] for a staged file path: real basename + real
/// size when the file can be stat'd (never fabricated bytes; the bytes are read
/// from the path at send time by `transport::build_mime`).
fn attachment_meta(path: &str) -> Attachment {
    let name = crate::model::attachment_display_name(path).to_string();
    let mime = crate::transport::mime_from_filename(&name).to_string();
    let size = std::fs::metadata(path).map_or(0, |m| m.len());
    Attachment::projected(name, mime, size)
}

/// Reconstruct an editable [`Draft`] from a Drafts-folder message.
fn draft_from_message(m: &Message) -> Draft {
    let join = |addrs: &[Addr]| {
        addrs
            .iter()
            .map(super::model::Addr::rfc5322)
            .collect::<Vec<_>>()
            .join(", ")
    };
    Draft {
        to: join(&m.to),
        cc: join(&m.cc),
        bcc: String::new(),
        subject: if m.subject == "(no subject)" {
            String::new()
        } else {
            m.subject.clone()
        },
        body: m.body.clone(),
        html_body: None,
        attachments: Vec::new(),
        in_reply_to: None,
    }
}

/// Load the account list from the shared canonical store
/// (`$XDG_CONFIG_HOME/qos/accounts/`), hydrating each password from the
/// encrypted vault. An empty store when nothing is configured yet.
fn load_account_store() -> AccountStore {
    AccountStore::load()
}

fn report_account_sync(
    account_id: &str,
    health: accounts::AccountSyncHealth,
    _success: bool,
    _message: Option<&str>,
) {
    if account_id.trim().is_empty() {
        return;
    }
    let reporter = accounts::AccountSyncReporter::new(account_id.to_string());
    let persisted = match health {
        accounts::AccountSyncHealth::Never | accounts::AccountSyncHealth::Syncing => {
            reporter.started()
        }
        accounts::AccountSyncHealth::Healthy => reporter.succeeded(),
        accounts::AccountSyncHealth::Offline => reporter.offline(),
        accounts::AccountSyncHealth::NeedsAuthentication => reporter.needs_authentication(),
        accounts::AccountSyncHealth::Error => reporter.failed(),
    };
    if let Err(error) = persisted {
        tracing::warn!(%error, account = account_id, "mail: could not persist sync status");
    }
}

/// The shared image store used for sender avatars in the **live** app: fetches
/// real Gravatar images over HTTP when built with `live` (the default).
pub fn avatar_store() -> ImageStore {
    ImageStore::new(&avatar_fetcher())
}

/// The avatar store for the hermetic paths — `--shots`, the sample corpus, and
/// tests. It is wired to a no-op fetcher **regardless of the `live` feature**,
/// so a headless render never opens a socket to gravatar.com even though the
/// live fetcher is now compiled in by default; avatars render as initials. This
/// is the runtime half of "features compile the live code in; the runtime mode
/// decides live vs sample".
pub fn avatar_store_offline() -> ImageStore {
    ImageStore::new(&noop_avatar_fetcher())
}

/// A fetcher that never touches the network — the hermetic default.
fn noop_avatar_fetcher() -> ui::Fetcher {
    std::sync::Arc::new(|_url: &str| None)
}

/// Real Gravatar HTTP under `--features live` (default); a no-op otherwise so a
/// build without `live` never opens a socket (avatars then render as initials).
#[cfg(feature = "live")]
fn avatar_fetcher() -> ui::Fetcher {
    use std::sync::{Arc, OnceLock};
    static CLIENT: OnceLock<reqwest::blocking::Client> = OnceLock::new();
    Arc::new(|url: &str| {
        let client = CLIENT.get_or_init(|| {
            reqwest::blocking::Client::builder()
                .timeout(std::time::Duration::from_secs(8))
                .user_agent("qOS Mail")
                .build()
                .unwrap_or_default()
        });
        let resp = client.get(url).send().ok()?;
        if !resp.status().is_success() {
            return None;
        }
        let bytes = resp.bytes().ok()?;
        if bytes.is_empty() || bytes.len() > 2 * 1024 * 1024 {
            return None;
        }
        Some(bytes.to_vec())
    })
}

#[cfg(not(feature = "live"))]
fn avatar_fetcher() -> ui::Fetcher {
    noop_avatar_fetcher()
}

/// The account-verification probe used on save. A real IMAP login + SMTP
/// handshake under `--features live`; a no-op offline probe otherwise, so
/// `--shots` and headless tests still persist an account after the config-level
/// checks pass.
#[cfg(feature = "live")]
fn default_probe() -> crate::validate::LiveProbe {
    crate::validate::LiveProbe
}
#[cfg(not(feature = "live"))]
fn default_probe() -> crate::validate::OfflineProbe {
    crate::validate::OfflineProbe
}

/// Mozilla autoconfig discovery for a typed email. Real HTTP under
/// `--features live`; `None` offline (the caller falls back to the heuristic).
#[cfg(feature = "live")]
fn autoconfig_lookup(email: &str) -> Option<crate::autoconfig::Autoconfig> {
    crate::autoconfig::discover(email)
}
#[cfg(not(feature = "live"))]
fn autoconfig_lookup(_email: &str) -> Option<crate::autoconfig::Autoconfig> {
    None
}

// =============================== Widget impl ===============================

impl MailApp {
    /// Step 1 of [`Widget::handle_event`]: the compose window is modal while
    /// open — route the event to it, act on whatever [`ComposeAction`] it
    /// raised, and report whether it consumed the event.
    #[allow(
        clippy::too_many_arguments,
        reason = "mirrors Widget::handle_event's own parameter list, which is fixed by the shared framework contract (see the trait doc)"
    )]
    fn handle_compose_modal(
        &mut self,
        event: &WindowEvent,
        scale_factor: f64,
        modifiers: winit::event::Modifiers,
        state: &mut AutoCommit,
        path: &ObjId,
        node_id: NodeId,
        taffy: &TaffyTree<()>,
    ) -> bool {
        let format_before = self.compose.format();
        let (consumed, action) =
            self.compose
                .handle_event(event, scale_factor, &modifiers, state, path, node_id, taffy);
        let lifecycle_boundary = !matches!(&action, ComposeAction::None);
        match action {
            ComposeAction::Send => self.send_compose(state),
            ComposeAction::SaveDraft => self.save_compose_draft(state),
            ComposeAction::Close => {
                self.dirty = true;
            }
            ComposeAction::None => {}
        }
        if lifecycle_boundary || self.compose.format() != format_before {
            self.persist_compose_format_if_changed();
        }
        consumed
    }

    /// Step 3 of [`Widget::handle_event`]: while the row context menu is open,
    /// a click either activates the item under it or dismisses the menu.
    fn handle_context_menu_click(&mut self, pt: Point, state: &mut AutoCommit) {
        self.rebuild_overlay_hits();
        let item = self
            .overlay_hits
            .iter()
            .rev()
            .find(|(rc, h)| matches!(h, OverlayHit::CtxItem(_)) && rc.contains(pt))
            .cloned();
        if let Some((_, OverlayHit::CtxItem(i))) = item {
            if let Some(menu) = self.context_menu.take()
                && let Some(action) = menu.items.get(i).copied()
            {
                self.shared
                    .borrow_mut()
                    .apply_message_action(state, menu.target, action);
                self.process_intents();
            }
        } else {
            self.context_menu = None;
        }
    }
}

impl Widget for MailApp {
    fn local_resource_operation_handlers(&self) -> &'static [&'static str] {
        &[crate::actions::MAIL_OPERATION_TYPE]
    }

    fn sync(&mut self, state: &mut AutoCommit, path: &ObjId) {
        if self.first_run.take_action() {
            self.open_setup_edit(None);
        }
        // Drain any engine results first so freshly-fetched messages are present
        // before layout/draw.
        self.drain_engine(state);
        // Fade out a transient status toast once its lifetime elapses.
        self.expire_toast_at(std::time::Instant::now());

        let mem_seeded = self.shared.borrow().seeded;
        if mem_seeded {
            self.hydrate_domain_state(state);
        } else {
            self.register_hydrated_messages(state);
            self.hydrate_domain_state(state);
            // Live: kick off a connect + inbox fetch for the active account.
            let has_accounts = !self.shared.borrow().accounts.is_empty();
            if self.engine.is_some() && has_accounts && !self.connect_requested {
                let cfg = self.shared.borrow().accounts.active_config();
                if self.engine.is_some() {
                    self.post_engine(EngineRequest::connect(cfg.clone()));
                    self.post_engine(EngineRequest::fetch(cfg, Folder::Inbox));
                    self.shared.borrow_mut().status = Some("Syncing…".into());
                }
                self.connect_requested = true;
            }
            self.shared.borrow_mut().seeded = true;
        }
        // Live app: advance the wall clock (relative timestamps + the periodic
        // refresh cadence read it) and fire a periodic refresh when due. The
        // sample/`--shots` path pins `now_min`, so this only runs live.
        if self.engine.is_some() {
            self.shared.borrow_mut().now_min = crate::state::now_minutes();
            self.maybe_auto_refresh();
        }
        self.persist_active_account_if_changed();
        self.mail_search_provider
            .refresh(&self.shared.borrow().mailbox);
        self.nav.sync(state, path);
    }

    /// Publish the open mailbox + its folders/messages so the host's Ctrl+K
    /// action palette scopes to them. Delegates to the
    /// [`ResourceProvider`](qos_actions::ResourceProvider) impl in
    /// [`crate::actions`].
    fn resources(&self, doc: &AutoCommit) -> Vec<qos_actions::Resource> {
        <Self as qos_actions::ResourceProvider>::resources(self, doc)
    }

    fn action_directory_resource_page(
        &self,
        doc: &AutoCommit,
        cursor: &[u8],
        max_results: usize,
    ) -> Option<ui::widget::ActionDirectoryResourcePage> {
        Some(ui::widget::ActionDirectoryResourcePage {
            resources: (cursor.is_empty() && max_results > 0)
                .then(|| crate::actions::mailbox_root(&self.mail_resource_ctx(doc)))
                .into_iter()
                .collect(),
            next_cursor: Vec::new(),
            exhausted: true,
        })
    }

    fn resource(&self, doc: &AutoCommit, id: &str) -> Option<qos_actions::Resource> {
        <Self as qos_actions::ResourceProvider>::resource(self, doc, id)
    }

    #[allow(
        clippy::too_many_lines,
        reason = "the resource-operation door intentionally keeps every Mail effect and view arm together, so their validation and canonical routing can be audited as one contract"
    )]
    fn invoke_resource_operation(
        &mut self,
        kind: qos_actions::OperationKind,
        type_id: &str,
        payload: &[u8],
        doc: &AutoCommit,
        _path: &ObjId,
    ) -> Result<bool, String> {
        let Some(operation) = crate::actions::decode_operation(type_id, payload)? else {
            return Ok(false);
        };
        match (kind, operation) {
            (
                qos_actions::OperationKind::Effect,
                crate::actions::MailOperation::RefreshCurrentFolder,
            ) => {
                if self.engine.is_none() {
                    return Err("no connected mail account is available".into());
                }
                let _ = self.refresh_active_folder();
            }
            (
                qos_actions::OperationKind::View,
                crate::actions::MailOperation::RevealFolder { folder },
            ) => {
                let Some(folder) = Folder::from_key(&folder) else {
                    return Err("folder no longer exists".into());
                };
                self.shared.borrow_mut().reveal_folder(folder);
                self.process_intents();
            }
            (
                qos_actions::OperationKind::View,
                crate::actions::MailOperation::RevealAccount { id },
            ) => {
                let Some(index) = self
                    .shared
                    .borrow()
                    .accounts
                    .accounts
                    .iter()
                    .position(|account| account.id == id)
                else {
                    return Err("account no longer exists".into());
                };
                let mut st = self.shared.borrow_mut();
                st.accounts.set_active(index);
                st.reveal_folder(Folder::Inbox);
                drop(st);
                self.process_intents();
            }
            (
                qos_actions::OperationKind::View,
                crate::actions::MailOperation::RevealMessage { id: _ },
            ) => {
                return Err("Open message must use the admitted mutable operation path".into());
            }
            (
                qos_actions::OperationKind::View,
                crate::actions::MailOperation::InspectMessage { id },
            ) => {
                let id = id
                    .parse::<crate::model::MessageId>()
                    .map_err(|_| "invalid message id")?;
                if !self.shared.borrow_mut().preview_message(id) {
                    return Err("message is no longer loaded".into());
                }
                self.shared.borrow_mut().status =
                    Some("Previewing without changing this message’s read state".into());
                self.process_intents();
            }
            (qos_actions::OperationKind::View, crate::actions::MailOperation::RevealDraft) => {
                let draft = MailDoc::load_draft(doc);
                self.compose.open_with_draft(&draft);
                self.editing_draft = None;
                self.dirty = true;
            }
            (
                qos_actions::OperationKind::Effect,
                crate::actions::MailOperation::SaveAttachment { message_id, index },
            ) => {
                let id = message_id
                    .parse::<MessageId>()
                    .map_err(|_| "invalid message id")?;
                let attachment = self
                    .shared
                    .borrow()
                    .mailbox
                    .get(id)
                    .and_then(|message| message.attachments.get(index))
                    .cloned()
                    .ok_or("attachment is no longer loaded")?;
                if !attachment.is_downloadable() {
                    return Err("attachment content is not downloaded yet".into());
                }
                let path = crate::util::save_download(&attachment.filename, &attachment.content)
                    .map_err(|error| format!("couldn’t save {}: {error}", attachment.filename))?;
                self.shared.borrow_mut().status = Some(format!(
                    "Saved {} to {}",
                    attachment.filename,
                    path.display()
                ));
                self.dirty = true;
            }
            _ => return Ok(false),
        }
        Ok(true)
    }

    fn start_resource_operation(
        &mut self,
        invocation: qos_actions::InvocationId,
        kind: qos_actions::OperationKind,
        type_id: &str,
        payload: &[u8],
        doc: &AutoCommit,
        path: &ObjId,
    ) -> Result<Option<ui::widget::ResourceOperationStart>, String> {
        if kind != qos_actions::OperationKind::Effect
            || type_id != crate::actions::MAIL_OPERATION_TYPE
        {
            return Ok(None);
        }
        let operation = crate::actions::decode_operation(type_id, payload)?;
        if matches!(
            operation,
            Some(crate::actions::MailOperation::SaveAttachment { .. })
        ) {
            if !self.invoke_resource_operation(kind, type_id, payload, doc, path)? {
                return Ok(None);
            }
            return Ok(Some(ui::widget::ResourceOperationStart::Completed(
                qos_actions::ActionOutput::default(),
            )));
        }
        if self.resource_refresh_invocation.is_some() || self.awaiting_engine {
            return Err("a mail operation is already running".into());
        }
        if matches!(
            operation,
            Some(crate::actions::MailOperation::RefreshCurrentFolder)
        ) {
            let request_id = self
                .refresh_active_folder()
                .ok_or_else(|| "mail refresh could not be queued".to_string())?;
            self.resource_refresh_invocation = Some((request_id, invocation));
            return Ok(Some(ui::widget::ResourceOperationStart::Accepted));
        }
        if !self.invoke_resource_operation(kind, type_id, payload, doc, path)? {
            return Ok(None);
        }
        if !self.awaiting_engine {
            return Err("mail refresh could not be queued".into());
        }
        Ok(None)
    }

    /// Admit the compound normal-open operation at the one framework boundary
    /// allowed to mutate the document.  The view transition and its canonical
    /// `SetRead` action are therefore one explicit Open interaction, never a
    /// deferred consequence of rendering or navigation.  Preview deliberately
    /// stays on the read-only operation route above.
    fn start_resource_operation_with_document(
        &mut self,
        invocation: qos_actions::InvocationId,
        kind: qos_actions::OperationKind,
        type_id: &str,
        payload: &[u8],
        doc: &mut AutoCommit,
        path: &ObjId,
    ) -> Result<Option<ui::widget::ResourceOperationStart>, String> {
        let operation = crate::actions::decode_operation(type_id, payload)?;
        if kind == qos_actions::OperationKind::View
            && let Some(crate::actions::MailOperation::RevealMessage { id }) = operation
        {
            let id = id.parse::<MessageId>().map_err(|_| "invalid message id")?;
            if !self.shared.borrow_mut().open_message(doc, id) {
                return Err("message is no longer loaded".into());
            }
            self.process_intents();
            return Ok(Some(ui::widget::ResourceOperationStart::Completed(
                qos_actions::ActionOutput::default(),
            )));
        }
        self.start_resource_operation(invocation, kind, type_id, payload, doc, path)
    }

    fn poll_resource_operation(
        &mut self,
        invocation: qos_actions::InvocationId,
        _cancellation_requested: bool,
        _doc: &AutoCommit,
        _path: &ObjId,
    ) -> Option<qos_actions::InvocationUpdate> {
        if self
            .resource_refresh_result
            .as_ref()
            .is_some_and(|update| update.invocation() == invocation)
        {
            self.resource_refresh_invocation = None;
            self.resource_refresh_result.take()
        } else {
            None
        }
    }

    /// Hand the host the heads captured before an on-screen affordance dispatched
    /// its mail action, so it records one undo boundary bracketing it (the same
    /// `record_committed_action` path a Ctrl+K dispatch takes). Rising-edge:
    /// cleared on read.
    fn take_committed_action(&mut self) -> Option<Vec<automerge::ChangeHash>> {
        self.shared.borrow_mut().take_committed_action()
    }

    /// Fold the mailbox into the unified Ctrl+K palette: a snapshot
    /// [`MailSearchProvider`](crate::search_provider::MailSearchProvider) makes
    /// every already-loaded message findable there by subject / sender / body,
    /// alongside the actions the app exports. The provider never touches the
    /// IMAP engine, so a Ctrl+K query stays synchronous.
    fn search_providers(&self) -> Vec<Box<dyn ui::search::SearchProvider>> {
        self.mail_search_provider
            .refresh(&self.shared.borrow().mailbox);
        vec![Box::new(self.mail_search_provider.clone())]
    }

    fn build_layout(
        &mut self,
        taffy: &mut TaffyTree<()>,
        theme: &Theme,
        node_map: &mut HashMap<NodeId, *mut dyn Widget>,
    ) -> NodeId {
        // `Widget::build_layout` returns a bare `NodeId`, so the retained
        // first-run child and its full-size parent are inserted together.
        let first_run_node = self.first_run.build_layout(taffy, theme, node_map);
        let style = Style {
            size: TSize {
                width: Dimension::percent(1.0),
                height: Dimension::percent(1.0),
            },
            ..Default::default()
        };
        let node = match taffy.new_with_children(style, &[first_run_node]) {
            Ok(node) => node,
            Err(error) => {
                // Keep the valid retained child as the root for this frame. The
                // onboarding surface remains usable and the next rebuild may
                // retry, instead of aborting the whole Mail process.
                tracing::error!(%error, "mail: failed to create root layout node");
                self.first_run_node = Some(first_run_node);
                return first_run_node;
            }
        };
        node_map.insert(node, std::ptr::from_mut::<dyn Widget>(self));
        self.first_run_node = Some(first_run_node);
        node
    }

    fn apply_layout(&mut self, taffy: &TaffyTree<()>, node: NodeId, origin: Point) {
        // `node` is the id this same widget inserted into this exact tree in
        // `build_layout` earlier in the same frame (the five-pass contract
        // guarantees layout was computed for it by now), so `layout` cannot
        // fail here in practice; `apply_layout`'s `()` return leaves no error
        // path, and that signature is shared framework-wide.
        #[allow(
            clippy::unwrap_used,
            reason = "node was inserted into this tree by this widget's own build_layout earlier in the same frame; Widget::apply_layout's Result-free signature is shared by every implementor and out of this crate's scope to change"
        )]
        let l = taffy.layout(node).unwrap();
        self.rect = Rect::new(
            origin.x + f64::from(l.location.x),
            origin.y + f64::from(l.location.y),
            origin.x + f64::from(l.location.x) + f64::from(l.size.width),
            origin.y + f64::from(l.location.y) + f64::from(l.size.height),
        );
        if let Some(first_run_node) = self.first_run_node {
            self.first_run.apply_layout(taffy, first_run_node, origin);
            self.first_run.apply_layout_external(self.rect);
        }
        self.layout_nav();
    }

    fn draw(
        &mut self,
        scene: &mut Scene,
        t: Affine,
        tr: &mut TextRenderer,
        theme: &Theme,
        presence: &PresenceCtx,
    ) {
        self.draw_with_presence(
            scene,
            t,
            tr,
            theme,
            presence,
            &PermissionContext::permissive(),
        );
    }

    fn draw_with_presence(
        &mut self,
        scene: &mut Scene,
        t: Affine,
        tr: &mut TextRenderer,
        theme: &Theme,
        presence: &PresenceCtx,
        permissions: &PermissionContext,
    ) {
        let c = &theme.tokens.colors;
        fill_rect(scene, t, self.rect, c.surfaces.base);
        // The navigation shell (sidebar + list + reader) draws itself, its
        // dividers, the collapse/back affordance, and the drawer scrim.
        self.nav
            .draw_with_presence(scene, t, tr, theme, presence, permissions);
        // First-run onboarding covers the (empty) mailbox until an account is
        // added. This is the shared retained component, not a painted lookalike.
        if self.is_first_run() {
            fill_rect(scene, t, self.rect, c.surfaces.base);
            self.first_run.draw(scene, t, tr, theme, presence);
        }
        // App-owned overlays on top.
        self.compose.draw(scene, t, tr, theme, presence);
        self.compose.draw_inputs(scene, t, tr, theme, presence);
        self.draw_setup(scene, t, tr, theme, presence);
        self.draw_context_menu(scene, t, tr, theme);
        self.draw_status(scene, t, tr, theme);
    }

    #[allow(
        clippy::too_many_lines,
        reason = "this is the widget's ordered modal event-routing lifecycle; splitting it would obscure the precedence between compose, onboarding, overlays, navigation, and global shortcuts"
    )]
    fn handle_event(
        &mut self,
        event: &WindowEvent,
        scale_factor: f64,
        modifiers: &winit::event::Modifiers,
        state: &mut AutoCommit,
        path: &ObjId,
        handled: &mut bool,
        focus_target: &mut Option<NodeId>,
        node_id: NodeId,
        taffy: &TaffyTree<()>,
    ) {
        if let WindowEvent::CursorMoved { position, .. } = event {
            let p = Point::new(position.x / scale_factor, position.y / scale_factor);
            self.shared.borrow_mut().last_mouse = p;
            self.dirty = true;
        }

        // 1) Compose window is modal while open.
        if self.compose.open
            && self.handle_compose_modal(
                event,
                scale_factor,
                *modifiers,
                state,
                path,
                node_id,
                taffy,
            )
        {
            *handled = true;
            self.dirty = true;
            return;
        }

        // 1.5) First-run onboarding is modal until an account exists. Its
        // shared empty-state child owns pointer, keyboard and AT activation.
        if self.is_first_run() {
            if let Some(first_run_node) = self.first_run_node {
                self.first_run.handle_event(
                    event,
                    scale_factor,
                    modifiers,
                    state,
                    path,
                    handled,
                    focus_target,
                    first_run_node,
                    taffy,
                );
            }
            if self.first_run.take_action() {
                self.open_setup_edit(None);
            }
            self.dirty = true;
            return;
        }

        // 2) Esc dismisses app-owned overlays first.
        if let WindowEvent::KeyboardInput {
            event:
                KeyEvent {
                    logical_key: Key::Named(NamedKey::Escape),
                    state: ElementState::Pressed,
                    ..
                },
            ..
        } = event
        {
            if self.context_menu.is_some() {
                self.context_menu = None;
                *handled = true;
                return;
            }
            if self.setup_open {
                self.close_setup();
                *handled = true;
                return;
            }
        }

        // 3) Context menu is modal: a click hits an item or dismisses.
        if self.context_menu.is_some()
            && let WindowEvent::MouseInput {
                state: ElementState::Pressed,
                button: MouseButton::Left,
                ..
            } = event
        {
            let pt = self.shared.borrow().last_mouse;
            self.handle_context_menu_click(pt, state);
            *handled = true;
            return;
        }

        // 4) Setup sheet is modal while open.
        if self.setup_open {
            self.handle_setup_event(
                event,
                scale_factor,
                *modifiers,
                state,
                path,
                handled,
                focus_target,
                node_id,
                taffy,
            );
            if *handled {
                self.dirty = true;
                return;
            }
        }

        // 5) Route to the navigation shell (affordance/scrim/Esc + the panes).
        self.nav.handle_event(
            event,
            scale_factor,
            modifiers,
            state,
            path,
            handled,
            focus_target,
            node_id,
            taffy,
        );
        // Panes raised intents; apply the cross-pane effects.
        self.process_intents();

        // 6) If nothing consumed it, apply global mailbox shortcuts.
        if !*handled {
            self.global_shortcuts(event, *modifiers, state, handled);
        }

        self.dirty = true;
    }

    fn name(&self) -> &'static str {
        "MailApp"
    }

    fn get_rect(&self) -> Rect {
        self.rect
    }

    fn children(&self) -> Vec<&dyn Widget> {
        if self.is_first_run() {
            vec![&self.first_run]
        } else {
            Vec::new()
        }
    }

    fn children_mut(&mut self) -> Vec<&mut (dyn Widget + '_)> {
        if self.is_first_run() {
            vec![&mut self.first_run]
        } else {
            Vec::new()
        }
    }

    fn cursor_shape(&self, point: Point) -> Option<winit::window::CursorIcon> {
        self.is_first_run()
            .then(|| self.first_run.cursor_shape(point))
            .flatten()
    }

    /// The mailbox is painted by three custom panes, so expose their actual
    /// visible composition here rather than leaving assistive technology with
    /// one opaque canvas.  This deliberately follows the shell's compact
    /// state: a narrow drawer hides the list, and a pushed reader hides both
    /// the list and drawer.  It also builds only from the loaded mailbox -- a
    /// live account with no fetched mail is described as empty, never filled
    /// with sample content.
    #[allow(
        clippy::too_many_lines,
        reason = "the synthetic mailbox tree keeps the sidebar, list, and reader state together so their responsive visibility remains auditable"
    )]
    fn accessibility(&self) -> Option<ui::a11y::AccessNode> {
        use ui::a11y::{AccessNode, AccessState, Politeness, Role};

        if self.compose.open {
            return Some(self.compose.accessibility_node());
        }
        if self.setup_open {
            let labels = [
                "Display name",
                "Email address",
                "Username",
                "Password",
                "IMAP server",
                "IMAP port",
                "SMTP server",
                "SMTP port",
            ];
            let mut controls: Vec<_> = labels
                .iter()
                .enumerate()
                .filter(|(index, _)| {
                    self.setup_auth == crate::model::AuthMethod::Password || *index != 3
                })
                .filter_map(|(index, label)| {
                    let input = self.setup_inputs.get(index)?;
                    let mut node = AccessNode::new(Role::TextInput)
                        .with_name(*label)
                        .with_action_target(format!("mail.setup:field:{index}"))
                        .with_state(AccessState {
                            focusable: true,
                            focused: self.setup_focus == Some(index),
                            protected: index == 3,
                            ..Default::default()
                        });
                    if index != 3 {
                        node = node.with_value(input.value());
                    }
                    if let Some(rect) = self.overlay_hits.iter().find_map(|(rect, hit)| {
                        matches!(hit, OverlayHit::SetupField(i) if *i == index).then_some(*rect)
                    }) {
                        node = node.with_bounds(rect);
                    }
                    Some(node)
                })
                .collect();
            controls.extend([
                AccessNode::new(Role::RadioButton)
                    .with_name("Password sign-in")
                    .with_action_target("mail.setup:auth-password")
                    .with_state(
                        AccessState::new()
                            .focusable(true)
                            .checked(self.setup_auth == crate::model::AuthMethod::Password),
                    ),
                AccessNode::new(Role::RadioButton)
                    .with_name("OAuth sign-in")
                    .with_action_target("mail.setup:auth-oauth")
                    .with_state(
                        AccessState::new()
                            .focusable(true)
                            .checked(self.setup_auth == crate::model::AuthMethod::OAuth),
                    ),
            ]);
            if self.setup_auth == crate::model::AuthMethod::OAuth {
                controls.push(
                    AccessNode::new(Role::Button)
                        .with_name("Sign in with provider")
                        .with_action_target("mail.setup:oauth-sign-in")
                        .with_state(AccessState::new().focusable(true)),
                );
            }
            controls.extend(vec![
                AccessNode::new(Role::ToggleButton)
                    .with_name("IMAP TLS")
                    .with_action_target("mail.setup:imap-tls")
                    .with_state(
                        AccessState::new()
                            .focusable(true)
                            .checked(self.setup_imap_tls),
                    ),
                AccessNode::new(Role::ToggleButton)
                    .with_name("SMTP TLS")
                    .with_action_target("mail.setup:smtp-tls")
                    .with_state(
                        AccessState::new()
                            .focusable(true)
                            .checked(self.setup_smtp_tls),
                    ),
                AccessNode::new(Role::Button)
                    .with_name("Save and verify")
                    .with_action_target("mail.setup:save")
                    .with_state(AccessState::new().focusable(true)),
                AccessNode::new(Role::Button)
                    .with_name("Cancel")
                    .with_action_target("mail.setup:cancel")
                    .with_state(AccessState::new().focusable(true)),
            ]);
            if self.setup_editing.is_some() {
                controls.push(
                    AccessNode::new(Role::Button)
                        .with_name("Remove account")
                        .with_action_target("mail.setup:remove")
                        .with_state(AccessState::new().focusable(true)),
                );
            }
            return Some(
                AccessNode::new(Role::Dialog)
                    .with_name("Mail account setup")
                    .with_bounds(self.overlay_panel_rect())
                    .with_state(AccessState::new().modal(true))
                    .with_children(controls),
            );
        }
        if self.is_first_run() {
            // `first_run` remains a real child widget, which supplies the
            // onboarding action and its existing activation path.
            return Some(AccessNode::new(Role::Window).with_name("Mail"));
        }

        let st = self.shared.borrow();
        let compact = st.narrow;
        let drawer_visible = !compact || st.sidebar_open;
        // The drawer is an overlay on compact layouts, so the covered message
        // list must not remain in the AT traversal while it is open.
        let overview_visible =
            !compact || (self.nav.pane() == NavPane::Overview && !st.sidebar_open);
        let reader_visible = !compact || (self.nav.pane() == NavPane::Detail && !st.sidebar_open);
        let mut children = Vec::new();

        if self.awaiting_engine {
            children.push(
                AccessNode::new(Role::Spinner)
                    .with_name("Syncing mail")
                    .with_state(AccessState::new().busy(true)),
            );
        }
        if let Some(status) = &st.status {
            children.push(
                AccessNode::new(Role::StaticText)
                    .with_name(status.clone())
                    .with_live(Politeness::Polite),
            );
        }

        if drawer_visible {
            let account_children = st
                .accounts
                .accounts
                .iter()
                .enumerate()
                .map(|(account_index, account)| {
                    let folders = if account.collapsed {
                        Vec::new()
                    } else {
                        AccountStore::folders_for(account)
                            .into_iter()
                            .map(|folder| {
                                AccessNode::new(Role::TreeItem)
                                    .with_name(folder.title())
                                    .with_action_target(format!(
                                        "mail.folder:{account_index}:{}",
                                        folder.as_key()
                                    ))
                                    .with_state(AccessState::new().focusable(true).selected(
                                        st.accounts.active == account_index && st.folder == folder,
                                    ))
                            })
                            .collect()
                    };
                    AccessNode::new(Role::TreeItem)
                        .with_name(account.label())
                        .with_action_target(format!("mail.account:{account_index}"))
                        .with_state(
                            AccessState::new()
                                .focusable(true)
                                .selected(st.accounts.active == account_index)
                                .expanded(!account.collapsed),
                        )
                        .with_children(folders)
                })
                .collect();
            children.push(
                AccessNode::new(Role::Tree)
                    .with_name("Mail folders")
                    .with_children(account_children),
            );
        }

        if overview_visible {
            let rows = st.list_rows();
            let total = rows.len();
            let message_children = rows
                .iter()
                .enumerate()
                .filter_map(|(index, (id, thread_len))| {
                    let message = st.mailbox.get(*id)?;
                    let sender = message.from.display();
                    let title = if message.folder == Folder::Drafts {
                        format!("Draft: {}", message.subject)
                    } else {
                        format!("{sender}: {}", message.subject)
                    };
                    let snippet = message.snippet();
                    let mut node = AccessNode::new(Role::ListItem)
                        .with_name(title)
                        .with_optional_value((!snippet.is_empty()).then_some(snippet))
                        .with_action_target(format!("mail.message:{id}"))
                        .with_position(index + 1, total)
                        .with_state(
                            AccessState::new()
                                .focusable(true)
                                .selected(st.selected == Some(*id)),
                        );
                    if *thread_len > 1 {
                        node = node.with_description(format!(
                            "{thread_len} messages in this conversation"
                        ));
                    }
                    Some(node)
                })
                .collect();
            let list_name = if st.search.trim().is_empty() {
                format!("{} messages", st.folder.title())
            } else {
                format!("Search results in {}", st.folder.title())
            };
            let mut list = AccessNode::new(Role::List)
                .with_name(list_name)
                .with_children(message_children);
            if total == 0 {
                let description = if st.search.trim().is_empty() {
                    format!("No messages in {}", st.folder.title())
                } else {
                    "No matching messages".to_string()
                };
                list = list.with_description(description);
            }
            children.push(list);
        }

        if reader_visible {
            let thread = st.selected_thread_messages();
            if let Some(current) = st.selected.and_then(|id| st.mailbox.get(id)) {
                let message_count = thread.len();
                let thread_children: Vec<_> = thread
                    .iter()
                    .map(|message| {
                        AccessNode::new(Role::Paragraph)
                            .with_name(format!("From {}", message.from.display()))
                            .with_value(message.body.clone())
                    })
                    .collect();
                children.push(
                    AccessNode::new(Role::Document)
                        .with_name(format!("Reading: {}", current.subject))
                        .with_description(format!(
                            "Current message from {}; {message_count} message{} in this conversation{}",
                            current.from.display(),
                            if message_count == 1 { "" } else { "s" },
                            if st.inspection == Some(current.id) {
                                "; previewing without changing its read state"
                            } else {
                                ""
                            },
                        ))
                        .with_children({
                            let mut reader_children = vec![
                                AccessNode::new(Role::Toolbar)
                                    .with_name("Message actions")
                                    .with_children([
                                        ("Reply", "reply"),
                                        ("Archive", "archive"),
                                        ("Delete", "delete"),
                                        ("Toggle star", "star"),
                                        ("Toggle read", "read"),
                                    ]
                                    .into_iter()
                                    .map(|(name, action)| {
                                        AccessNode::new(Role::Button)
                                            .with_name(name)
                                            .with_action_target(format!(
                                                "mail.reader:{}:{action}",
                                                current.id
                                            ))
                                            .with_state(AccessState::new().focusable(true))
                                    })
                                    .collect()),
                            ];
                            reader_children.extend(thread_children);
                            reader_children
                        }),
                );
            } else {
                children.push(
                    AccessNode::new(Role::Group)
                        .with_name("No conversation selected")
                        .with_description("Select a conversation to read"),
                );
            }
        }

        let composition = if compact {
            if st.sidebar_open {
                "folder drawer"
            } else if self.nav.pane() == NavPane::Detail {
                "reading pane"
            } else {
                "message list"
            }
        } else {
            "folders, message list, and reading pane"
        };
        Some(
            AccessNode::new(Role::Window)
                .with_name("Mail")
                .with_description(format!("Current view: {composition}"))
                .with_children(children),
        )
    }

    #[allow(
        clippy::too_many_lines,
        reason = "semantic targets stay centralized so keyboard and assistive-technology paths cannot drift from visible controls"
    )]
    fn perform_semantic_action(
        &mut self,
        target: &str,
        action: &ui::a11y::Action,
        state: &mut AutoCommit,
        _path: &ObjId,
    ) -> bool {
        use ui::a11y::Action;

        if let Some(control) = target.strip_prefix("mail.compose:") {
            if !self.compose.open {
                return false;
            }
            let format_before = self.compose.format();
            let compose_action = self.compose.perform_semantic_action(control, action);
            let lifecycle_boundary = !matches!(&compose_action, Some(ComposeAction::None));
            match compose_action {
                Some(ComposeAction::Send) => self.send_compose(state),
                Some(ComposeAction::SaveDraft) => self.save_compose_draft(state),
                Some(ComposeAction::Close) => {
                    self.dirty = true;
                }
                Some(ComposeAction::None) => {}
                None => return false,
            }
            if lifecycle_boundary || self.compose.format() != format_before {
                self.persist_compose_format_if_changed();
            }
            return true;
        }
        if let Some(control) = target.strip_prefix("mail.setup:") {
            if !self.setup_open {
                return false;
            }
            if let Some(raw) = control.strip_prefix("field:") {
                let Ok(index) = raw.parse::<usize>() else {
                    return false;
                };
                if index >= self.setup_inputs.len()
                    || (index == 3 && self.setup_auth != crate::model::AuthMethod::Password)
                {
                    return false;
                }
                match action {
                    Action::Focus | Action::Activate => self.focus_setup(Some(index)),
                    Action::SetValue(value) => {
                        self.set_setup_input(index, value);
                        if index == 1 {
                            self.maybe_autofill();
                        }
                    }
                    _ => return false,
                }
                self.dirty = true;
                return true;
            }
            match (control, action) {
                ("auth-password", Action::Activate | Action::ToggleCheck) => {
                    self.setup_auth = crate::model::AuthMethod::Password;
                }
                ("auth-oauth", Action::Activate | Action::ToggleCheck) => {
                    self.setup_auth = crate::model::AuthMethod::OAuth;
                }
                ("oauth-sign-in", Action::Activate) => self.start_oauth(),
                ("imap-tls", Action::Activate | Action::ToggleCheck) => {
                    self.setup_imap_tls = !self.setup_imap_tls;
                    self.set_setup_input(5, if self.setup_imap_tls { "993" } else { "143" });
                }
                ("smtp-tls", Action::Activate | Action::ToggleCheck) => {
                    self.setup_smtp_tls = !self.setup_smtp_tls;
                    self.set_setup_input(7, if self.setup_smtp_tls { "465" } else { "587" });
                }
                ("save", Action::Activate) => self.save_setup(state),
                ("cancel", Action::Activate) => self.close_setup(),
                ("remove", Action::Activate) if self.setup_editing.is_some() => {
                    self.remove_editing_account(state);
                }
                _ => return false,
            }
            self.dirty = true;
            return true;
        }
        if let Some(raw) = target.strip_prefix("mail.reader:") {
            if !matches!(action, Action::Activate) {
                return false;
            }
            let Some((message_raw, control)) = raw.split_once(':') else {
                return false;
            };
            let Ok(message) = message_raw.parse::<MessageId>() else {
                return false;
            };
            if self.shared.borrow().selected != Some(message) {
                return false;
            }
            let action = match control {
                "reply" => CtxAction::Reply,
                "archive" => CtxAction::Archive,
                "delete" => CtxAction::Delete,
                "star" => CtxAction::ToggleStar,
                "read" => CtxAction::ToggleRead,
                _ => return false,
            };
            self.shared
                .borrow_mut()
                .apply_message_action(state, message, action);
            self.process_intents();
            return true;
        }
        if let Some(raw) = target.strip_prefix("mail.account:") {
            let Ok(account_index) = raw.parse::<usize>() else {
                return false;
            };
            let mut st = self.shared.borrow_mut();
            let Some(account) = st.accounts.accounts.get(account_index) else {
                return false;
            };
            let collapsed = account.collapsed;
            match action {
                Action::Activate => {
                    st.set_active_account(account_index);
                    st.select_folder(state, Folder::Inbox);
                    st.push_intent(Intent::CloseDrawer);
                }
                Action::Expand if collapsed => {
                    st.toggle_account_collapsed(account_index);
                }
                Action::Collapse if !collapsed => {
                    st.toggle_account_collapsed(account_index);
                }
                _ => return false,
            }
            drop(st);
            self.process_intents();
            return true;
        }

        if let Some(raw) = target.strip_prefix("mail.folder:") {
            let Some((account_raw, folder_raw)) = raw.split_once(':') else {
                return false;
            };
            let (Ok(account_index), Some(folder)) =
                (account_raw.parse::<usize>(), Folder::from_key(folder_raw))
            else {
                return false;
            };
            if !matches!(action, Action::Activate) {
                return false;
            }
            let mut st = self.shared.borrow_mut();
            let Some(account) = st.accounts.accounts.get(account_index) else {
                return false;
            };
            if account.collapsed || !AccountStore::folders_for(account).contains(&folder) {
                return false;
            }
            st.set_active_account(account_index);
            st.select_folder(state, folder);
            st.push_intent(Intent::CloseDrawer);
            drop(st);
            self.process_intents();
            return true;
        }

        let Some(raw) = target.strip_prefix("mail.message:") else {
            return false;
        };
        if !matches!(action, Action::Activate) {
            return false;
        }
        let Ok(id) = raw.parse::<MessageId>() else {
            return false;
        };
        let mut st = self.shared.borrow_mut();
        // A stale accessibility row must not open a message that is no longer
        // visible in the current folder/search result.
        if !st.list_rows().iter().any(|(row_id, _)| *row_id == id) {
            return false;
        }
        let is_draft = st
            .mailbox
            .get(id)
            .is_some_and(|message| message.folder == Folder::Drafts);
        if is_draft {
            st.push_intent(Intent::EditDraft(id));
        } else {
            st.select_message(state, id);
        }
        drop(st);
        self.process_intents();
        true
    }

    fn modal_capture(&self) -> Option<Rect> {
        if self.compose.open {
            Some(self.compose.window_rect())
        } else if self.setup_open {
            Some(self.overlay_panel_rect())
        } else if self.is_first_run() {
            Some(self.rect)
        } else {
            None
        }
    }

    fn needs_redraw(&self) -> bool {
        self.dirty
            || self.shared.borrow().dirty
            || self.nav.needs_redraw()
            || self.compose.needs_redraw()
            || self.setup_inputs.iter().any(ui::Widget::needs_redraw)
    }

    fn needs_animation_frame(&self) -> bool {
        // Keep the event loop pumping frames while a worker request is in
        // flight so its result (a fetched batch, a send ack, an error) drains
        // and surfaces promptly instead of waiting for unrelated input, and
        // while a toast is counting down so it fades on time. Drops back to
        // idle the moment the reply settles and the toast clears.
        self.awaiting_engine || self.toast_pending() || self.nav.needs_animation_frame()
    }

    fn needs_idle_sync(&self) -> bool {
        // Keep syncing while a connect/fetch reply is outstanding or a toast is
        // still on screen (so `sync` can expire it), then idle rather than
        // busy-loop once results have arrived and the toast has cleared.
        self.awaiting_engine || self.toast_pending() || self.nav.needs_idle_sync()
    }

    fn mark_drawn(&mut self) {
        self.dirty = false;
        self.shared.borrow_mut().dirty = false;
        self.nav.mark_drawn();
        self.compose.mark_drawn();
        for i in &mut self.setup_inputs {
            i.mark_drawn();
        }
    }
}

impl MailApp {
    #[allow(clippy::too_many_arguments)]
    fn handle_setup_event(
        &mut self,
        event: &WindowEvent,
        scale_factor: f64,
        modifiers: winit::event::Modifiers,
        state: &mut AutoCommit,
        path: &ObjId,
        handled: &mut bool,
        focus_target: &mut Option<NodeId>,
        node_id: NodeId,
        taffy: &TaffyTree<()>,
    ) {
        // Keyboard: Tab/Shift+Tab move between fields, Enter advances (or
        // submits on the last field); everything else routes to the focused
        // field.
        if let WindowEvent::KeyboardInput {
            event:
                KeyEvent {
                    logical_key,
                    state: ElementState::Pressed,
                    ..
                },
            ..
        } = event
        {
            match logical_key {
                Key::Named(NamedKey::Tab) => {
                    let dir = if modifiers.state().shift_key() { -1 } else { 1 };
                    self.focus_setup_step(dir);
                    *handled = true;
                    return;
                }
                Key::Named(NamedKey::Enter) => {
                    let order = self.setup_tab_order();
                    let is_last = self.setup_focus.is_some_and(|f| order.last() == Some(&f));
                    if is_last {
                        self.save_setup(state);
                    } else {
                        self.focus_setup_step(1);
                    }
                    *handled = true;
                    return;
                }
                _ => {}
            }
        }
        if matches!(event, WindowEvent::KeyboardInput { .. }) {
            let focused = self.setup_focus;
            if let Some(i) = focused.and_then(|i| self.setup_inputs.get_mut(i)) {
                i.handle_event(
                    event,
                    scale_factor,
                    &modifiers,
                    state,
                    path,
                    handled,
                    focus_target,
                    node_id,
                    taffy,
                );
            }
            // Typing in the email field pre-fills the server settings from the
            // built-in provider table the instant the address is recognised —
            // the user rarely needs to touch the advanced fields.
            if focused == Some(1) {
                self.maybe_autofill_live_typing();
            }
            return;
        }
        if let WindowEvent::MouseInput {
            state: ElementState::Pressed,
            button: MouseButton::Left,
            ..
        } = event
        {
            let pt = self.shared.borrow().last_mouse;
            self.handle_setup_click(pt, state);
            *handled = true;
        }
    }

    /// The click-routing half of [`Self::handle_setup_event`]: a click at
    /// `pt` lands on a field / pill / toggle / button, or falls outside the
    /// panel and cancels the sheet. Every outcome counts as handled, which
    /// the caller sets unconditionally.
    fn handle_setup_click(&mut self, pt: Point, state: &mut AutoCommit) {
        self.rebuild_overlay_hits();
        let panel = self.overlay_panel_rect();
        let hit = self
            .overlay_hits
            .iter()
            .rev()
            .find(|(rc, _)| rc.contains(pt))
            .map(|(_, h)| h.clone());
        match hit {
            Some(OverlayHit::SetupField(i)) => {
                let leaving_email = self.setup_focus == Some(1) && i != 1;
                self.focus_setup(Some(i));
                if leaving_email {
                    self.maybe_autofill();
                }
            }
            Some(OverlayHit::AuthPassword) => {
                self.setup_auth = crate::model::AuthMethod::Password;
                self.dirty = true;
            }
            Some(OverlayHit::AuthOAuth) => {
                self.setup_auth = crate::model::AuthMethod::OAuth;
                self.dirty = true;
            }
            Some(OverlayHit::OAuthSignIn) => {
                self.start_oauth();
            }
            Some(OverlayHit::ToggleImapTls) => {
                self.setup_imap_tls = !self.setup_imap_tls;
                self.set_setup_input(5, if self.setup_imap_tls { "993" } else { "143" });
            }
            Some(OverlayHit::ToggleSmtpTls) => {
                self.setup_smtp_tls = !self.setup_smtp_tls;
                self.set_setup_input(7, if self.setup_smtp_tls { "465" } else { "587" });
            }
            Some(OverlayHit::SetupSave) => {
                self.save_setup(state);
            }
            Some(OverlayHit::RemoveAccount) => {
                self.remove_editing_account(state);
            }
            Some(OverlayHit::CancelSetup) => {
                self.close_setup();
            }
            _ => {
                // Click outside the panel cancels.
                if !panel.contains(pt) {
                    self.close_setup();
                }
            }
        }
    }

    fn global_shortcuts(
        &mut self,
        event: &WindowEvent,
        modifiers: winit::event::Modifiers,
        state: &mut AutoCommit,
        handled: &mut bool,
    ) {
        let search_focused = self.shared.borrow().search_focused;
        if search_focused {
            return;
        }
        let WindowEvent::KeyboardInput {
            event:
                KeyEvent {
                    logical_key,
                    state: ElementState::Pressed,
                    ..
                },
            ..
        } = event
        else {
            return;
        };
        let command = modifiers.state().control_key() || modifiers.state().super_key();
        // Bare letter shortcuts must never steal a platform/editor chord such
        // as Ctrl+C, Ctrl+S, or Alt+R. The focused widget gets first refusal;
        // this is the final safety net for commands addressed to the shell.
        let plain = !command && !modifiers.state().alt_key();
        let selected = self.shared.borrow().selected;
        match logical_key {
            Key::Character(ch) if plain && ch.eq_ignore_ascii_case("c") => {
                self.compose.open_blank();
                *handled = true;
            }
            Key::Character(ch)
                if (plain && ch == "/") || (command && ch.eq_ignore_ascii_case("f")) =>
            {
                self.shared.borrow_mut().focus_search_request = true;
                self.dirty = true;
                *handled = true;
            }
            Key::Named(NamedKey::F5) => {
                let _ = self.refresh_active_folder();
                *handled = true;
            }
            Key::Named(NamedKey::ArrowDown) => {
                self.shared.borrow_mut().move_selection(state, 1);
                *handled = true;
            }
            Key::Named(NamedKey::ArrowUp) => {
                self.shared.borrow_mut().move_selection(state, -1);
                *handled = true;
            }
            Key::Character(ch) if plain && ch.eq_ignore_ascii_case("e") => {
                if let Some(id) = selected {
                    self.shared
                        .borrow_mut()
                        .apply_message_action(state, id, CtxAction::Archive);
                    self.process_intents();
                    *handled = true;
                }
            }
            Key::Named(NamedKey::Delete | NamedKey::Backspace) if plain => {
                if let Some(id) = selected {
                    self.shared
                        .borrow_mut()
                        .apply_message_action(state, id, CtxAction::Delete);
                    self.process_intents();
                    *handled = true;
                }
            }
            Key::Character(ch) if plain && ch.eq_ignore_ascii_case("s") => {
                if let Some(id) = selected {
                    self.shared
                        .borrow_mut()
                        .apply_message_action(state, id, CtxAction::ToggleStar);
                    *handled = true;
                }
            }
            Key::Character(ch) if plain && ch.eq_ignore_ascii_case("r") => {
                if let Some(id) = selected {
                    self.shared.borrow_mut().push_intent(Intent::Reply(id));
                    self.process_intents();
                    *handled = true;
                }
            }
            Key::Character(ch) if plain && ch.eq_ignore_ascii_case("u") => {
                if let Some(id) = selected {
                    self.shared.borrow_mut().set_read(state, id, false);
                    *handled = true;
                }
            }
            _ => {}
        }
    }
}

#[cfg(test)]
mod tests {
    use super::*;
    use automerge::ReadDoc;
    use winit::event::{DeviceId, Modifiers};

    fn synth_device() -> DeviceId {
        unsafe { std::mem::zeroed() }
    }
    fn cursor_at(p: Point) -> WindowEvent {
        WindowEvent::CursorMoved {
            device_id: synth_device(),
            position: winit::dpi::PhysicalPosition::new(p.x, p.y),
        }
    }
    fn left_press() -> WindowEvent {
        WindowEvent::MouseInput {
            device_id: synth_device(),
            state: ElementState::Pressed,
            button: MouseButton::Left,
        }
    }
    fn esc_event() -> WindowEvent {
        named_key(NamedKey::Escape)
    }
    fn named_key(k: NamedKey) -> WindowEvent {
        let mut ev: KeyEvent = unsafe { std::mem::zeroed() };
        ev.logical_key = Key::Named(k);
        ev.physical_key = winit::keyboard::PhysicalKey::Unidentified(
            winit::keyboard::NativeKeyCode::Unidentified,
        );
        ev.location = winit::keyboard::KeyLocation::Standard;
        ev.state = ElementState::Pressed;
        ev.repeat = false;
        ev.text = None;
        WindowEvent::KeyboardInput {
            device_id: synth_device(),
            event: ev,
            is_synthetic: false,
        }
    }
    fn char_key(s: &str) -> WindowEvent {
        let mut ev: KeyEvent = unsafe { std::mem::zeroed() };
        ev.logical_key = Key::Character(s.into());
        ev.physical_key = winit::keyboard::PhysicalKey::Unidentified(
            winit::keyboard::NativeKeyCode::Unidentified,
        );
        ev.location = winit::keyboard::KeyLocation::Standard;
        ev.state = ElementState::Pressed;
        ev.repeat = false;
        ev.text = Some(s.into());
        WindowEvent::KeyboardInput {
            device_id: synth_device(),
            event: ev,
            is_synthetic: false,
        }
    }

    fn dispatch(app: &mut MailApp, ev: &WindowEvent, doc: &mut AutoCommit) -> bool {
        let mut taffy = TaffyTree::<()>::new();
        let node = taffy.new_leaf(Style::default()).unwrap();
        let mut handled = false;
        let mut focus = None;
        app.handle_event(
            ev,
            1.0,
            &Modifiers::default(),
            doc,
            &automerge::ROOT,
            &mut handled,
            &mut focus,
            node,
            &taffy,
        );
        handled
    }

    fn app() -> (MailApp, AutoCommit) {
        let mut app = MailApp::new_sample();
        let mut doc = AutoCommit::new();
        app.sync(&mut doc, &automerge::ROOT);
        (app, doc)
    }

    fn click_at(app: &mut MailApp, doc: &mut AutoCommit, p: Point) -> bool {
        dispatch(app, &cursor_at(p), doc);
        dispatch(app, &left_press(), doc)
    }

    #[test]
    fn starts_in_mailbox_with_a_selection() {
        let (app, _) = app();
        assert!(app.shared.borrow().selected.is_some());
        assert_eq!(app.shared.borrow().folder, Folder::Inbox);
    }

    #[test]
    fn wide_shows_three_panes_abreast() {
        let (mut app, _doc) = app();
        app.layout_for_test(1280.0, 800.0);
        assert!(
            app.nav.sidebar_rect().width() > 1.0,
            "docked sidebar present"
        );
        assert!(
            app.nav.overview_rect().x0 >= app.nav.sidebar_rect().x1 - 0.5,
            "list right of sidebar"
        );
        assert!(
            app.nav.detail_rect().x0 >= app.nav.overview_rect().x1 - 0.5,
            "reader right of list"
        );
    }

    /// The confirmed-defect verification: at a narrow width, opening a message
    /// pushes the detail pane; Back returns to the list.
    #[test]
    fn narrow_open_message_pushes_detail_then_back() {
        let (mut app, mut doc) = app();
        app.layout_for_test(560.0, 860.0);
        assert_eq!(app.nav_pane(), NavPane::Overview, "starts on the list");

        // Click the first list row (a message).
        let row_center = {
            let st = app.shared.borrow();
            let first = st.list_rows()[0].0;
            let _ = first;
            // First row sits just below the list header — measured from
            // where the shell actually puts the content, not from the pane
            // rect. In the narrow layout the sidebar chip floats over the
            // pane's top-left and the shell reserves a band for it, so the
            // content starts lower than the pane does; asking
            // `overview_rect()` here aimed the click into that band and hit
            // nothing.
            let content = app.nav.overview_content_rect();
            Point::new(
                content.x0 + 120.0,
                content.y0 + crate::draw::HEADER_H + crate::draw::LIST_ROW_H / 2.0,
            )
        };
        assert!(
            click_at(&mut app, &mut doc, row_center),
            "row click consumed"
        );
        app.layout_for_test(560.0, 860.0);
        assert_eq!(
            app.nav_pane(),
            NavPane::Detail,
            "opening a message pushes the detail"
        );
        assert!(app.shared.borrow().selected.is_some());

        // The Back affordance is present; clicking it returns to the overview.
        let back = app.nav.back_button_rect();
        assert!(
            back.width() > 0.0,
            "Back affordance shown while detail pushed"
        );
        assert!(
            click_at(&mut app, &mut doc, back.center()),
            "back click consumed"
        );
        assert_eq!(
            app.nav_pane(),
            NavPane::Overview,
            "Back returns to the list"
        );
    }

    #[test]
    fn accessibility_tracks_compact_panes_and_routes_mailbox_activation() {
        use ui::a11y::{Action, Role as A11yRole};

        let (mut app, mut doc) = app();
        app.layout_for_test(560.0, 860.0);

        let overview = app.accessibility().expect("mailbox semantics");
        assert!(
            overview
                .children
                .iter()
                .any(|node| node.role == A11yRole::List),
            "the compact overview exposes its visible message list"
        );
        assert!(
            !overview
                .children
                .iter()
                .any(|node| node.role == A11yRole::Tree || node.role == A11yRole::Document),
            "covered drawer and reader panes are omitted in compact overview"
        );
        let message_target = overview
            .children
            .iter()
            .find(|node| node.role == A11yRole::List)
            .and_then(|list| list.children.first())
            .and_then(|row| row.action_target.clone())
            .expect("visible message row has a stable activation target");

        assert!(app.perform_semantic_action(
            &message_target,
            &Action::Activate,
            &mut doc,
            &automerge::ROOT,
        ));
        assert_eq!(
            app.nav_pane(),
            NavPane::Detail,
            "semantic open pushes reader"
        );
        let reader = app.accessibility().expect("reader semantics");
        assert!(
            reader
                .children
                .iter()
                .any(|node| node.role == A11yRole::Document),
            "the pushed compact reader exposes the selected conversation"
        );
        assert!(
            !reader
                .children
                .iter()
                .any(|node| node.role == A11yRole::List),
            "the covered compact overview is absent from AT traversal"
        );

        app.layout_for_test(1280.0, 800.0);
        let wide = app.accessibility().expect("wide mailbox semantics");
        let archive_target = wide
            .children
            .iter()
            .find(|node| node.role == A11yRole::Tree)
            .and_then(|tree| tree.children.first())
            .and_then(|account| {
                account.children.iter().find_map(|folder| {
                    (folder.name.as_deref() == Some("Archive"))
                        .then(|| folder.action_target.clone())
                        .flatten()
                })
            })
            .expect("visible Archive folder has a stable activation target");
        assert!(app.perform_semantic_action(
            &archive_target,
            &Action::Activate,
            &mut doc,
            &automerge::ROOT,
        ));
        assert_eq!(
            app.shared.borrow().folder,
            Folder::Archive,
            "semantic folder activation uses the same selection state as the sidebar"
        );
    }

    #[test]
    fn accessibility_routes_reader_and_modal_controls_to_existing_actions() {
        use ui::a11y::{Action, Role as A11yRole};

        let (mut app, mut doc) = app();
        app.layout_for_test(1280.0, 800.0);
        let selected = app.shared.borrow().selected.expect("sample selection");
        let before_star = app.shared.borrow().mailbox.get(selected).unwrap().starred;
        let reader = app.accessibility().expect("reader semantics");
        let star_target = reader
            .children
            .iter()
            .find(|node| node.role == A11yRole::Document)
            .and_then(|document| document.children.first())
            .and_then(|toolbar| {
                toolbar
                    .children
                    .iter()
                    .find(|node| node.name.as_deref() == Some("Toggle star"))
            })
            .and_then(|button| button.action_target.clone())
            .expect("reader star control");
        assert!(app.perform_semantic_action(
            &star_target,
            &Action::Activate,
            &mut doc,
            &automerge::ROOT
        ));
        assert_eq!(
            app.shared.borrow().mailbox.get(selected).unwrap().starred,
            !before_star
        );
        let other = app
            .shared
            .borrow()
            .list_rows()
            .into_iter()
            .map(|(id, _)| id)
            .find(|id| *id != selected)
            .expect("second sample message");
        app.shared.borrow_mut().select_message(&mut doc, other);
        app.process_intents();
        assert!(
            !app.perform_semantic_action(
                &star_target,
                &Action::Activate,
                &mut doc,
                &automerge::ROOT
            ),
            "a stale reader control cannot operate a newly selected message"
        );

        app.compose.open_blank();
        let compose = app.accessibility().expect("compose dialog semantics");
        assert_eq!(compose.role, A11yRole::Dialog);
        assert!(compose.children.iter().any(|node| {
            node.role == A11yRole::TextInput && node.name.as_deref() == Some("To")
        }));
        assert!(compose.children.iter().any(|node| {
            node.role == A11yRole::MultilineTextInput
                && node.name.as_deref() == Some("Message body")
        }));
        assert!(app.perform_semantic_action(
            "mail.compose:discard",
            &Action::Activate,
            &mut doc,
            &automerge::ROOT
        ));
        assert!(
            !app.compose.open,
            "semantic discard uses compose close path"
        );

        app.open_setup_edit(None);
        let setup = app.accessibility().expect("setup dialog semantics");
        assert_eq!(setup.role, A11yRole::Dialog);
        assert!(setup.children.iter().any(|node| {
            node.role == A11yRole::TextInput
                && node.name.as_deref() == Some("Email address")
                && node.action_target.as_deref() == Some("mail.setup:field:1")
        }));
        assert!(app.perform_semantic_action(
            "mail.setup:cancel",
            &Action::Activate,
            &mut doc,
            &automerge::ROOT
        ));
        assert!(!app.setup_open, "semantic cancel closes account setup");
    }

    #[test]
    fn narrow_then_wide_reflows_to_three_panes() {
        // Same instance, resized wide→narrow→wide must re-derive the layout.
        let (mut app, _doc) = app();
        app.layout_for_test(1280.0, 800.0);
        let wide_detail_x0 = app.nav.detail_rect().x0;
        app.layout_for_test(560.0, 860.0);
        assert!(app.shared.borrow().narrow, "narrow flag set at 560");
        // Overview is full-width in narrow.
        assert!(
            (app.nav.overview_rect().width() - 560.0).abs() < 2.0,
            "list full-width narrow"
        );
        app.layout_for_test(1280.0, 800.0);
        assert!(!app.shared.borrow().narrow, "wide flag re-derived at 1280");
        assert!(
            (app.nav.detail_rect().x0 - wide_detail_x0).abs() < 2.0,
            "reflows back to three panes"
        );
    }

    #[test]
    fn wide_sidebar_folder_click_switches_folder() {
        let (mut app, mut doc) = app();
        app.layout_for_test(1280.0, 800.0);
        // The Sent row of the active account. Resolved from the sidebar's own
        // laid-out rect rather than a screen literal: the shell reserves a band
        // at the top of the sidebar for the collapse chip, so the rows sit at an
        // offset the test should not have to restate.
        let sidebar = app.nav.sidebar_content_rect();
        let p = Point::new(sidebar.x0 + 130.0, sidebar.y0 + 250.0);
        assert!(click_at(&mut app, &mut doc, p), "folder click consumed");
        assert_eq!(
            app.shared.borrow().folder,
            Folder::Sent,
            "clicking Sent switches the folder"
        );
    }

    #[test]
    fn narrow_hamburger_opens_and_esc_closes_drawer() {
        let (mut app, mut doc) = app();
        app.layout_for_test(560.0, 860.0);
        let ham = app.nav.collapse_button_rect();
        assert!(ham.width() > 0.0, "hamburger present on the narrow list");
        assert!(
            click_at(&mut app, &mut doc, ham.center()),
            "hamburger click consumed"
        );
        assert!(app.nav.is_sidebar_open(), "hamburger opens the drawer");
        // Esc dismisses the open overlay drawer.
        assert!(dispatch(&mut app, &esc_event(), &mut doc), "Esc consumed");
        assert!(!app.nav.is_sidebar_open(), "Esc closes the drawer");
    }

    #[test]
    fn selecting_message_marks_read_and_persists() {
        let (app, mut doc) = app();
        let id = {
            let st = app.shared.borrow();
            st.mailbox
                .messages_in(Folder::Inbox)
                .into_iter()
                .find(|m| !m.read)
                .map(|m| m.id)
        }
        .expect("an unread message");
        app.shared.borrow_mut().select_message(&mut doc, id);
        assert!(app.shared.borrow().mailbox.get(id).unwrap().read);
        let mut fresh = app.shared.borrow().mailbox.clone();
        for m in fresh.messages.values_mut() {
            m.read = false;
        }
        MailDoc::apply_flags(&doc, &mut fresh);
        assert!(
            fresh.get(id).unwrap().read,
            "read flag persisted to the CRDT"
        );
    }

    #[test]
    fn resource_open_marks_message_read_through_the_document_action() {
        let (mut app, mut doc) = app();
        let id = app
            .shared
            .borrow()
            .mailbox
            .messages_in(Folder::Inbox)
            .into_iter()
            .find(|message| !message.read)
            .map(|message| message.id)
            .expect("sample contains an unread message");
        let payload = serde_json::to_vec(&crate::actions::MailOperation::RevealMessage {
            id: id.to_string(),
        })
        .unwrap();
        assert!(matches!(
            app.start_resource_operation_with_document(
                qos_actions::InvocationId::default(),
                qos_actions::OperationKind::View,
                crate::actions::MAIL_OPERATION_TYPE,
                &payload,
                &mut doc,
                &automerge::ROOT,
            )
            .unwrap(),
            Some(ui::widget::ResourceOperationStart::Completed(_))
        ));
        assert!(
            app.shared.borrow().mailbox.get(id).unwrap().read,
            "Open immediately dispatches the canonical mark-read action"
        );
        let dispatched = app
            .shared
            .borrow()
            .actions
            .last_dispatched()
            .cloned()
            .expect("Open emitted an action");
        let expected =
            crate::actions::encode(&crate::actions::set_read_action(vec![id.to_string()], true));
        assert_eq!(dispatched.type_id, expected.type_id);
        assert_eq!(
            dispatched.payload, expected.payload,
            "resource Open and every on-screen mark-read control use the same action payload"
        );
        assert!(
            doc.get(&automerge::ROOT, "ui")
                .expect("document remains readable")
                .is_none(),
            "Open records no selection, folder, search, mode, or compose presentation state"
        );
        assert!(
            app.take_committed_action().is_some(),
            "mark-read remains a replayable collaborative action"
        );
    }

    #[test]
    fn resource_opens_before_one_sync_each_keep_normal_read_semantics() {
        let (mut app, mut doc) = app();
        let ids: Vec<_> = app
            .shared
            .borrow()
            .mailbox
            .messages_in(Folder::Inbox)
            .into_iter()
            .filter(|message| !message.read)
            .map(|message| message.id)
            .take(2)
            .collect();
        assert_eq!(ids.len(), 2, "sample contains two unread inbox messages");

        for id in &ids {
            let payload = serde_json::to_vec(&crate::actions::MailOperation::RevealMessage {
                id: id.to_string(),
            })
            .unwrap();
            assert!(matches!(
                app.start_resource_operation_with_document(
                    qos_actions::InvocationId::default(),
                    qos_actions::OperationKind::View,
                    crate::actions::MAIL_OPERATION_TYPE,
                    &payload,
                    &mut doc,
                    &automerge::ROOT,
                )
                .unwrap(),
                Some(ui::widget::ResourceOperationStart::Completed(_))
            ));
        }

        assert!(ids.iter().all(|id| {
            app.shared
                .borrow()
                .mailbox
                .get(*id)
                .is_some_and(|message| message.read)
        }));
    }

    #[test]
    fn legacy_read_only_open_route_refuses_without_changing_presentation_or_document() {
        let (mut app, mut doc) = app();
        let target = app
            .shared
            .borrow()
            .mailbox
            .messages_in(Folder::Inbox)
            .first()
            .map(|message| message.id)
            .expect("sample contains an inbox message");
        let (folder_before, selected_before, inspection_before, search_before, status_before) = {
            let state = app.shared.borrow();
            (
                state.folder,
                state.selected,
                state.inspection,
                state.search.clone(),
                state.status.clone(),
            )
        };
        let target_read_before = app
            .shared
            .borrow()
            .mailbox
            .get(target)
            .is_some_and(|message| message.read);
        let heads_before = doc.get_heads();
        let payload = serde_json::to_vec(&crate::actions::MailOperation::RevealMessage {
            id: target.to_string(),
        })
        .unwrap();

        let error = app
            .invoke_resource_operation(
                qos_actions::OperationKind::View,
                crate::actions::MAIL_OPERATION_TYPE,
                &payload,
                &doc,
                &automerge::ROOT,
            )
            .expect_err("the read-only route cannot defer an Open mutation");

        assert!(error.contains("admitted mutable operation"));
        assert_eq!(doc.get_heads(), heads_before);
        let state = app.shared.borrow();
        assert_eq!(state.folder, folder_before);
        assert_eq!(state.selected, selected_before);
        assert_eq!(state.inspection, inspection_before);
        assert_eq!(state.search, search_before);
        assert_eq!(state.status, status_before);
        assert_eq!(
            state
                .mailbox
                .get(target)
                .is_some_and(|message| message.read),
            target_read_before
        );
    }

    #[test]
    fn explicit_resource_preview_keeps_an_unread_message_unread_and_announces_that_fact() {
        let (mut app, mut doc) = app();
        let id = app
            .shared
            .borrow()
            .mailbox
            .messages_in(Folder::Inbox)
            .into_iter()
            .find(|message| !message.read)
            .map(|message| message.id)
            .expect("sample contains an unread message");
        let payload = serde_json::to_vec(&crate::actions::MailOperation::InspectMessage {
            id: id.to_string(),
        })
        .unwrap();
        let heads_before_preview = doc.get_heads();
        assert!(
            app.invoke_resource_operation(
                qos_actions::OperationKind::View,
                crate::actions::MAIL_OPERATION_TYPE,
                &payload,
                &doc,
                &automerge::ROOT,
            )
            .unwrap()
        );
        assert_eq!(app.selected_message(), Some(id));
        assert!(
            !app.shared.borrow().mailbox.get(id).unwrap().read,
            "preview is read-state neutral before sync"
        );
        assert_eq!(doc.get_heads(), heads_before_preview);
        app.sync(&mut doc, &automerge::ROOT);
        assert!(
            !app.shared.borrow().mailbox.get(id).unwrap().read,
            "unlike Open message, explicit preview never queues mark-read"
        );
        assert!(
            app.take_committed_action().is_none(),
            "a read-state-neutral preview creates no collaborative action"
        );
        let semantics = app.accessibility().expect("reader accessibility");
        let reader = semantics
            .children
            .iter()
            .find(|node| node.role == ui::a11y::Role::Document)
            .expect("reader document");
        assert!(
            reader
                .description
                .as_deref()
                .is_some_and(|text| text.contains("without changing its read state")),
            "assistive technology receives the same explicit preview distinction"
        );
    }

    #[test]
    fn offline_preview_send_keeps_the_message_in_the_composer() {
        let (mut app, mut doc) = app();
        let before = app.shared.borrow().mailbox.count(Folder::Sent);
        app.compose.open_blank();
        app.compose.layout(Rect::new(0.0, 0.0, 1280.0, 800.0));
        let draft = crate::model::Draft {
            to: "dest@there.example".into(),
            subject: "Hi".into(),
            body: "Hello".into(),
            html_body: Some("<p>Hello</p>".into()),
            ..Default::default()
        };
        app.compose.reattach(&draft);
        app.send_compose(&mut doc);
        assert!(app.compose.open, "offline preview must preserve the draft");
        assert_eq!(
            app.shared.borrow().mailbox.count(Folder::Sent),
            before,
            "validating a MIME message locally is not delivery"
        );
        assert!(
            app.shared
                .borrow()
                .status
                .as_deref()
                .is_some_and(|status| status.contains("offline preview"))
        );
    }

    #[test]
    #[allow(
        clippy::too_many_lines,
        reason = "the regression deliberately drives the full three-request interleaving in one readable sequence"
    )]
    fn interleaved_engine_events_only_settle_their_own_request() {
        let (mut app, mut doc) = app();
        let (outgoing, _outgoing_rx) = std::sync::mpsc::channel();
        let (incoming_tx, incoming) = std::sync::mpsc::channel();
        app.engine = Some(EngineHandle {
            tx: outgoing,
            rx: incoming,
        });

        let refresh_id = uuid::Uuid::new_v4();
        let send_id = uuid::Uuid::new_v4();
        let unrelated_id = uuid::Uuid::new_v4();
        let invocation = qos_actions::InvocationId::new();
        app.resource_refresh_invocation = Some((refresh_id, invocation));
        let message = app.shared.borrow().mailbox.messages_in(Folder::Inbox)[0].clone();
        app.pending_send = Some(PendingSend {
            request_id: send_id,
            message,
            edited_draft: None,
        });
        app.pending_engine_requests
            .insert(refresh_id, EngineRequestKind::Fetch);
        app.pending_engine_requests
            .insert(send_id, EngineRequestKind::Send);
        app.pending_engine_requests
            .insert(unrelated_id, EngineRequestKind::StoreFlag);
        app.awaiting_engine = true;

        incoming_tx
            .send(EngineEvent::Error {
                request_id: unrelated_id,
                kind: EngineRequestKind::StoreFlag,
                context: "flag".into(),
                message: "rejected".into(),
            })
            .unwrap();
        incoming_tx
            .send(EngineEvent::Sent {
                request_id: unrelated_id,
                wire_bytes: 9,
            })
            .unwrap();
        incoming_tx
            .send(EngineEvent::Completed {
                request_id: unrelated_id,
                kind: crate::engine::EngineRequestKind::StoreFlag,
            })
            .unwrap();
        app.drain_engine(&mut doc);
        assert!(app.resource_refresh_invocation.is_some());
        assert!(app.resource_refresh_result.is_none());
        assert!(app.pending_send.is_some());
        assert!(app.pending_engine_requests.contains_key(&refresh_id));
        assert!(app.pending_engine_requests.contains_key(&send_id));
        assert!(!app.pending_engine_requests.contains_key(&unrelated_id));
        assert!(
            app.shared
                .borrow()
                .status
                .as_deref()
                .is_none_or(|status| !status.contains("Delivered")),
            "an unmatched Sent event must not claim delivery"
        );

        incoming_tx
            .send(EngineEvent::Fetched {
                request_id: send_id,
                account_id: "me@qos.example".into(),
                folder: Folder::Inbox,
                messages: Vec::new(),
            })
            .unwrap();
        app.drain_engine(&mut doc);
        assert!(app.pending_send.is_some(), "wrong-kind results are inert");
        assert!(app.pending_engine_requests.contains_key(&send_id));

        incoming_tx
            .send(EngineEvent::Fetched {
                request_id: refresh_id,
                account_id: "me@qos.example".into(),
                folder: Folder::Inbox,
                messages: Vec::new(),
            })
            .unwrap();
        incoming_tx
            .send(EngineEvent::Completed {
                request_id: refresh_id,
                kind: crate::engine::EngineRequestKind::Fetch,
            })
            .unwrap();
        app.drain_engine(&mut doc);
        assert!(app.resource_refresh_invocation.is_some());
        assert!(matches!(
            app.resource_refresh_result.as_ref(),
            Some(qos_actions::InvocationUpdate::Succeeded { invocation: got, .. }) if *got == invocation
        ));
        assert!(matches!(
            app.poll_resource_operation(invocation, false, &doc, &automerge::ROOT),
            Some(qos_actions::InvocationUpdate::Succeeded { invocation: got, .. }) if got == invocation
        ));
        assert!(app.resource_refresh_invocation.is_none());
        assert!(app.pending_send.is_some());

        incoming_tx
            .send(EngineEvent::Sent {
                request_id: send_id,
                wire_bytes: 42,
            })
            .unwrap();
        incoming_tx
            .send(EngineEvent::Completed {
                request_id: send_id,
                kind: crate::engine::EngineRequestKind::Send,
            })
            .unwrap();
        app.drain_engine(&mut doc);
        assert!(app.pending_send.is_none());
        assert!(!app.awaiting_engine);
    }

    #[test]
    fn completed_refresh_cannot_be_replaced_before_its_owner_polls() {
        let (mut app, doc) = app();
        let (outgoing, _outgoing_rx) = std::sync::mpsc::channel();
        let (_incoming_tx, incoming) = std::sync::mpsc::channel();
        app.engine = Some(EngineHandle {
            tx: outgoing,
            rx: incoming,
        });
        let request_id = uuid::Uuid::new_v4();
        let owner = qos_actions::InvocationId::new();
        app.resource_refresh_invocation = Some((request_id, owner));
        app.resource_refresh_result = Some(qos_actions::InvocationUpdate::Succeeded {
            invocation: owner,
            output: qos_actions::ActionOutput::default(),
        });

        let payload =
            serde_json::to_vec(&crate::actions::MailOperation::RefreshCurrentFolder).unwrap();
        assert!(
            app.start_resource_operation(
                qos_actions::InvocationId::new(),
                qos_actions::OperationKind::Effect,
                crate::actions::MAIL_OPERATION_TYPE,
                &payload,
                &doc,
                &automerge::ROOT,
            )
            .is_err()
        );
        assert!(
            app.poll_resource_operation(
                qos_actions::InvocationId::new(),
                false,
                &doc,
                &automerge::ROOT
            )
            .is_none()
        );
        assert!(matches!(
            app.poll_resource_operation(owner, false, &doc, &automerge::ROOT),
            Some(qos_actions::InvocationUpdate::Succeeded { invocation, .. }) if invocation == owner
        ));
        assert!(app.resource_refresh_invocation.is_none());
    }

    #[test]
    fn context_and_swipe_actions_are_mirrored() {
        let (app, _doc) = app();
        let id = app.shared.borrow().mailbox.messages_in(Folder::Inbox)[0].id;
        let menu = app.shared.borrow().context_items_for(id);
        assert!(
            menu.contains(&CtxAction::Archive),
            "swipe-left action present in menu"
        );
        assert!(
            menu.contains(&CtxAction::Delete),
            "swipe-right action present in menu"
        );
    }

    #[test]
    fn setup_save_adds_account() {
        let (mut app, mut doc) = app();
        app.open_setup_edit(None);
        app.setup_inputs[1].set_text("new@host.example");
        app.setup_inputs[2].set_text("new@host.example");
        app.setup_inputs[4].set_text("imap.host.example");
        app.setup_inputs[6].set_text("smtp.host.example");
        let before = app.shared.borrow().accounts.len();
        // Drive the offline probe explicitly so this offline-save flow is
        // deterministic under both builds (the live probe's connect gating is
        // covered by the `validate` state-machine tests and the socket tests).
        app.save_setup_with(&mut doc, &crate::validate::OfflineProbe);
        assert!(!app.setup_open);
        assert_eq!(app.shared.borrow().accounts.len(), before + 1);
        assert_eq!(
            app.shared.borrow().accounts.active_config().email,
            "new@host.example"
        );
    }

    #[test]
    fn sample_mode_persists_to_a_sandbox_not_the_real_store() {
        // Regression guard for the leak where the bundled demo accounts
        // (you@qos.example, you@hooli.example, new@host.example) ended up in the
        // user's real ~/.config/qos/accounts/store.json: the sample / shots /
        // test app must resolve a throwaway sandbox as its persist target, never
        // the real per-user config root.
        let root = MailApp::new_sample()
            .accounts_persist_root()
            .expect("sample mode has a persist root");
        let real = accounts::config_root().expect("a resolvable real config root");
        assert_ne!(
            root, real,
            "sample mode must NOT target the real config root"
        );
        assert!(
            root.starts_with(std::env::temp_dir()),
            "sample mode must persist under a throwaway temp dir, got {}",
            root.display()
        );
    }

    #[test]
    fn sample_mode_save_never_writes_the_real_account_store() {
        // Snapshot the real store path's bytes (it may or may not exist on this
        // machine), drive the full add-account save in sample mode — which does
        // persist — then prove the account landed in the sandbox and the real
        // store is byte-for-byte unchanged.
        let real_path = accounts::store_path();
        let before = real_path.as_ref().and_then(|p| std::fs::read(p).ok());

        let (mut app, mut doc) = app(); // new_sample: sandboxed
        app.open_setup_edit(None);
        app.setup_inputs[1].set_text("guard@example.test");
        app.setup_inputs[2].set_text("guard@example.test");
        app.setup_inputs[4].set_text("imap.example.test");
        app.setup_inputs[6].set_text("smtp.example.test");
        app.save_setup_with(&mut doc, &crate::validate::OfflineProbe);
        assert_eq!(
            app.shared.borrow().accounts.active_config().email,
            "guard@example.test",
            "the account was added in memory"
        );

        // The save landed in the sandbox …
        let root = app.accounts_persist_root().expect("sandbox root");
        let sandboxed = crate::account::AccountStore::load_in(&root);
        assert!(
            sandboxed
                .accounts
                .iter()
                .any(|a| a.config.email == "guard@example.test"),
            "the save must have persisted into the sandbox store"
        );

        // … and the real store is untouched (absent stays absent; present stays
        // identical).
        let after = real_path.as_ref().and_then(|p| std::fs::read(p).ok());
        assert_eq!(
            before, after,
            "sample / shots mode must not create or modify the real account store"
        );
    }

    #[test]
    fn live_mode_persists_to_the_real_config_root() {
        // The live app is the ONLY constructor allowed to write the real store.
        let app = MailApp::new_live();
        assert_eq!(
            app.accounts_persist_root(),
            accounts::config_root(),
            "the live app must persist to the real per-user config root"
        );
    }

    #[test]
    fn account_settings_sheet_is_scoped_to_the_selected_account() {
        let (mut app, _doc) = app(); // sample store: 2 accounts, active = 0
        assert_eq!(app.shared.borrow().accounts.active, 0);
        // Opening settings for account #1 (you@hooli.example) — reached from that
        // account's gear — must populate the form from THAT account, not the
        // active one, so the sheet honestly reads as its settings.
        app.open_setup_edit(Some(1));
        assert_eq!(app.setup_editing, Some(1));
        assert_eq!(
            app.read_setup_config().email,
            "you@hooli.example",
            "the account-settings form is scoped to the clicked account"
        );
    }

    #[test]
    fn live_starts_without_fabricated_messages() {
        // The live constructor must not seed a sample corpus.
        let app = MailApp::new_live();
        assert!(
            app.shared.borrow().mailbox.messages.is_empty(),
            "no fabricated startup mail"
        );
    }

    #[test]
    fn reply_all_seeds_sender_in_to_and_others_in_cc() {
        let (mut app, mut doc) = app();
        // A message with more than one recipient.
        let id = {
            let st = app.shared.borrow();
            st.mailbox
                .messages
                .values()
                .find(|m| m.folder == Folder::Inbox && m.to.len() > 1)
                .expect("a multi-recipient message")
                .id
        };
        app.shared
            .borrow_mut()
            .apply_message_action(&mut doc, id, CtxAction::ReplyAll);
        app.process_intents();
        assert!(app.compose.open, "reply-all opens the composer");
        let d = app.compose.to_draft();
        let sender = app
            .shared
            .borrow()
            .mailbox
            .get(id)
            .unwrap()
            .from
            .email
            .clone();
        assert!(d.to.contains(&sender), "sender goes in To: {}", d.to);
        assert!(!d.cc.is_empty(), "other recipients populate Cc: {}", d.cc);
        assert!(
            !d.cc.contains("you@qos.example"),
            "our own address is excluded from Cc: {}",
            d.cc
        );
        assert!(
            !d.cc.contains(&sender),
            "the sender is not duplicated into Cc: {}",
            d.cc
        );
    }

    #[test]
    fn save_draft_lands_in_drafts_and_reopens() {
        let (mut app, mut doc) = app();
        let before = app.shared.borrow().mailbox.count(Folder::Drafts);
        app.compose.open_blank();
        app.compose.layout(Rect::new(0.0, 0.0, 1280.0, 800.0));
        let draft = crate::model::Draft {
            to: "dest@there.example".into(),
            subject: "WIP proposal".into(),
            body: "half written".into(),
            html_body: Some("<p>half written</p>".into()),
            ..Default::default()
        };
        app.compose.reattach(&draft);
        app.save_compose_draft(&mut doc);
        assert!(!app.compose.open, "save closes the composer");
        assert_eq!(
            app.shared.borrow().mailbox.count(Folder::Drafts),
            before + 1,
            "the draft appears in Drafts"
        );

        // Reopening the Drafts message re-seeds the composer for editing.
        let id = {
            let st = app.shared.borrow();
            st.mailbox
                .messages_in(Folder::Drafts)
                .iter()
                .find(|m| m.subject == "WIP proposal")
                .unwrap()
                .id
        };
        app.open_draft(id);
        assert!(app.compose.open, "the draft reopens in the composer");
        assert_eq!(app.compose.to_draft().subject, "WIP proposal");
        assert_eq!(app.editing_draft, Some(id));
    }

    #[test]
    fn saving_edited_draft_updates_in_place_not_duplicates() {
        let (mut app, mut doc) = app();
        app.compose.open_blank();
        app.compose.layout(Rect::new(0.0, 0.0, 1280.0, 800.0));
        app.compose.reattach(&crate::model::Draft {
            subject: "First".into(),
            body: "one".into(),
            ..Default::default()
        });
        app.save_compose_draft(&mut doc);
        let after_first = app.shared.borrow().mailbox.count(Folder::Drafts);
        // Re-open + re-save the same draft.
        let id = app.editing_draft.expect("editing the saved draft");
        app.open_draft(id);
        app.save_compose_draft(&mut doc);
        assert_eq!(
            app.shared.borrow().mailbox.count(Folder::Drafts),
            after_first,
            "re-saving updates in place"
        );
    }

    #[test]
    fn presentation_state_is_local_and_never_restored_from_a_peer_document() {
        let mut doc = AutoCommit::new();
        {
            let mut app = MailApp::new_sample();
            app.sync(&mut doc, &automerge::ROOT);
            app.shared
                .borrow_mut()
                .select_folder(&mut doc, Folder::Sent);
            app.shared.borrow_mut().set_active_account(1);
            app.shared.borrow_mut().search = "private query".into();
            app.compose.set_format(ComposeFormat::Text);
        }
        // A second app sharing the document receives only domain state.
        let mut app2 = MailApp::new_sample();
        app2.sync(&mut doc, &automerge::ROOT);
        assert_eq!(
            app2.shared.borrow().folder,
            Folder::Inbox,
            "folder is local"
        );
        assert!(app2.shared.borrow().search.is_empty(), "search is local");
        assert_eq!(
            app2.shared.borrow().accounts.active,
            0,
            "the device-local active account is never restored from shared state"
        );
        assert_eq!(
            app2.compose.format(),
            ComposeFormat::Html,
            "compose format is local"
        );
        assert!(
            doc.get(&automerge::ROOT, "ui")
                .expect("document remains readable")
                .is_none(),
            "window presentation never enters collaborative state"
        );
    }

    #[test]
    fn compose_format_restores_per_device_without_entering_the_shared_document() {
        let persistence = AccountsPersist::sandbox();
        let preference_path = persistence
            .local_preferences_path()
            .expect("sandbox has a local preference path");
        let first_state = MailState::shared(MailState::new_sample(avatar_store_offline()));
        let mut first = MailApp::assemble(first_state, None, persistence.clone());
        first.compose.set_format(ComposeFormat::Text);
        first.persist_compose_format_if_changed();
        assert!(preference_path.is_file(), "format is persisted locally");

        let second_state = MailState::shared(MailState::new_sample(avatar_store_offline()));
        let second = MailApp::assemble(second_state, None, persistence);
        assert_eq!(
            second.compose.format(),
            ComposeFormat::Text,
            "a later window on this device restores its local preference"
        );

        let mut doc = AutoCommit::new();
        first.sync(&mut doc, &automerge::ROOT);
        let mut peer = MailApp::new_sample();
        peer.sync(&mut doc, &automerge::ROOT);
        assert_eq!(
            peer.compose.format(),
            ComposeFormat::Html,
            "a peer with a different local store never receives this preference"
        );
        assert!(doc.get(&automerge::ROOT, "ui").unwrap().is_none());
    }

    #[test]
    fn sample_compose_format_preference_never_uses_the_real_config_root() {
        let mut app = MailApp::new_sample();
        let sandbox = app.accounts_persist_root().expect("sample sandbox");
        app.compose.set_format(ComposeFormat::Text);
        app.persist_compose_format_if_changed();
        assert!(sandbox.join("mail-local.json").is_file());
        assert_ne!(Some(sandbox), accounts::config_root());
    }

    #[test]
    fn active_account_selection_persists_locally_without_touching_automerge() {
        let (mut app, mut doc) = app();
        let selected_id = app.shared.borrow().accounts.accounts[1].id.clone();
        app.shared.borrow_mut().set_active_account(1);
        app.sync(&mut doc, &automerge::ROOT);

        let root = app
            .accounts_persist_root()
            .expect("sample app has a sandbox");
        let reloaded = AccountStore::load_in(&root);
        assert_eq!(
            reloaded.active_account().map(|account| account.id.as_str()),
            Some(selected_id.as_str()),
            "the shared device-local account store remembers the selected account"
        );
        assert!(
            doc.get(&automerge::ROOT, "account")
                .expect("document remains readable")
                .is_none(),
            "account configuration never crosses the collaborative boundary"
        );
    }

    #[test]
    fn setup_email_autofills_connection_hosts() {
        let (mut app, _doc) = app();
        app.open_setup_edit(None);
        app.setup_inputs[1].set_text("person@gmail.com");
        app.maybe_autofill();
        assert_eq!(
            app.setup_inputs[4].value(),
            "imap.gmail.com",
            "IMAP host autofilled"
        );
        assert_eq!(
            app.setup_inputs[6].value(),
            "smtp.gmail.com",
            "SMTP host autofilled"
        );
    }

    #[test]
    fn context_menu_click_applies_the_action() {
        let (mut app, mut doc) = app();
        app.layout_for_test(1280.0, 800.0);
        let id = app.shared.borrow().mailbox.messages_in(Folder::Inbox)[0].id;
        app.shared
            .borrow_mut()
            .push_intent(Intent::ContextMenu(id, Point::new(400.0, 300.0)));
        app.process_intents();
        assert!(app.context_menu.is_some(), "menu opened");
        app.rebuild_overlay_hits();
        let items = app.context_menu.as_ref().unwrap().items.clone();
        let idx = items.iter().position(|a| *a == CtxAction::Archive).unwrap();
        let rect = app
            .overlay_hits
            .iter()
            .find_map(|(r, h)| match h {
                OverlayHit::CtxItem(i) if *i == idx => Some(*r),
                _ => None,
            })
            .expect("archive item rect");
        let before = app.shared.borrow().mailbox.count(Folder::Archive);
        assert!(
            click_at(&mut app, &mut doc, rect.center()),
            "menu item click consumed"
        );
        assert_eq!(
            app.shared.borrow().mailbox.count(Folder::Archive),
            before + 1,
            "clicking Archive archived the message"
        );
        assert!(
            app.context_menu.is_none(),
            "menu dismissed after the action"
        );
    }

    #[test]
    fn setup_tls_toggle_flips_the_port() {
        let (mut app, mut doc) = app();
        app.layout_for_test(1100.0, 780.0);
        app.open_setup_edit(None);
        app.rebuild_overlay_hits();
        assert_eq!(
            app.setup_inputs[5].value(),
            "993",
            "IMAP port starts at the TLS default"
        );
        let toggle = app
            .overlay_hits
            .iter()
            .find(|(_, h)| matches!(h, OverlayHit::ToggleImapTls))
            .map(|(r, _)| *r)
            .expect("imap tls toggle");
        assert!(
            click_at(&mut app, &mut doc, toggle.center()),
            "tls toggle consumed"
        );
        assert!(!app.setup_imap_tls, "TLS turned off");
        assert_eq!(
            app.setup_inputs[5].value(),
            "143",
            "port switched to the plaintext IMAP port"
        );
    }

    #[test]
    fn shortcut_c_opens_compose() {
        let (mut app, mut doc) = app();
        app.layout_for_test(1280.0, 800.0);
        assert!(!app.compose.open);
        assert!(
            dispatch(&mut app, &char_key("c"), &mut doc),
            "c shortcut consumed"
        );
        assert!(app.compose.open, "'c' opened the composer");
    }

    #[test]
    fn shortcut_e_archives_selected() {
        let (mut app, mut doc) = app();
        app.layout_for_test(1280.0, 800.0);
        let before = app.shared.borrow().mailbox.count(Folder::Archive);
        assert!(app.shared.borrow().selected.is_some());
        dispatch(&mut app, &char_key("e"), &mut doc);
        assert_eq!(
            app.shared.borrow().mailbox.count(Folder::Archive),
            before + 1,
            "'e' archived the selection"
        );
        assert!(app.take_committed_action().is_some());
    }

    #[test]
    fn reader_shortcuts_reply_star_and_mark_unread_through_visible_paths() {
        let (mut app, mut doc) = app();
        app.layout_for_test(1280.0, 800.0);
        let id = app.shared.borrow().selected.expect("selected message");

        assert!(dispatch(&mut app, &char_key("r"), &mut doc));
        assert!(app.compose.open, "R opens the visible reply composer");
        app.compose.close();

        let was_starred = app.shared.borrow().mailbox.get(id).unwrap().starred;
        assert!(dispatch(&mut app, &char_key("s"), &mut doc));
        assert_eq!(
            app.shared.borrow().mailbox.get(id).unwrap().starred,
            !was_starred
        );
        assert!(app.take_committed_action().is_some());

        assert!(dispatch(&mut app, &char_key("u"), &mut doc));
        assert!(!app.shared.borrow().mailbox.get(id).unwrap().read);
        assert!(app.take_committed_action().is_some());
    }

    #[test]
    fn shortcut_arrow_down_moves_selection() {
        let (mut app, mut doc) = app();
        app.layout_for_test(1280.0, 800.0);
        let first = app.shared.borrow().selected;
        dispatch(&mut app, &named_key(NamedKey::ArrowDown), &mut doc);
        assert_ne!(
            app.shared.borrow().selected,
            first,
            "ArrowDown moved the selection"
        );
    }

    #[test]
    fn shortcut_delete_trashes_selected() {
        let (mut app, mut doc) = app();
        app.layout_for_test(1280.0, 800.0);
        let before = app.shared.borrow().mailbox.count(Folder::Trash);
        dispatch(&mut app, &named_key(NamedKey::Delete), &mut doc);
        assert_eq!(
            app.shared.borrow().mailbox.count(Folder::Trash),
            before + 1,
            "Delete moved the selection to Trash"
        );
        assert!(app.take_committed_action().is_some());
    }

    // ---- first-run onboarding --------------------------------------------

    #[test]
    fn first_run_shows_onboarding_and_add_opens_setup() {
        let mut app = MailApp::new_first_run();
        let mut doc = AutoCommit::new();
        app.sync(&mut doc, &automerge::ROOT);
        app.layout_for_test(1100.0, 780.0);
        assert!(
            app.is_first_run(),
            "no configured account → first-run onboarding"
        );
        let semantics = app.first_run.accessibility().expect("first-run semantics");
        assert_eq!(semantics.name.as_deref(), Some("Welcome to Mail"));
        assert!(semantics.children.iter().any(|node| {
            node.role == ui::a11y::Role::Button && node.name.as_deref() == Some("Add account")
        }));
        assert!(
            app.first_run
                .perform_action(&ui::a11y::Action::Activate, &mut doc, &automerge::ROOT,),
            "assistive activation reaches Add account"
        );
        app.sync(&mut doc, &automerge::ROOT);
        assert!(app.setup_open, "Add account opens the account setup sheet");
        assert!(
            !app.is_first_run(),
            "an open setup sheet supersedes the first-run screen"
        );
    }

    // ---- add-account: single-border layout, Tab, autoconfig, OAuth --------

    #[test]
    fn setup_fields_use_single_border_no_wrapper() {
        let (mut app, _doc) = app();
        app.layout_for_test(1100.0, 780.0);
        app.open_setup_edit(None);
        app.rebuild_overlay_hits();
        let mut n = 0;
        for (rect, hit) in &app.overlay_hits {
            if let OverlayHit::SetupField(i) = hit {
                // The input is laid out at exactly the field hit rect, so only
                // its own single border draws — no wider app-drawn border rect
                // stacks a second outline on top.
                assert_eq!(
                    app.setup_inputs[*i].get_rect(),
                    *rect,
                    "field {i}: input rect must equal its hit rect (single border)"
                );
                n += 1;
            }
        }
        assert_eq!(n, 8, "all eight fields are shown in password mode");
    }

    #[test]
    fn setup_tab_key_advances_between_fields() {
        let (mut app, mut doc) = app();
        app.layout_for_test(1100.0, 780.0);
        app.open_setup_edit(None);
        app.focus_setup(Some(0));
        assert!(
            dispatch(&mut app, &named_key(NamedKey::Tab), &mut doc),
            "Tab consumed"
        );
        assert_eq!(app.setup_focus, Some(1), "Tab advances to the next field");
        assert!(dispatch(&mut app, &named_key(NamedKey::Tab), &mut doc));
        assert_eq!(app.setup_focus, Some(2), "Tab keeps advancing");
        // Reverse step wraps back.
        app.focus_setup_step(-1);
        assert_eq!(app.setup_focus, Some(1), "Shift+Tab moves back a field");
    }

    #[test]
    fn oauth_mode_drops_password_from_tab_order() {
        let (mut app, _doc) = app();
        app.open_setup_edit(None);
        app.setup_auth = crate::model::AuthMethod::Password;
        assert!(
            app.setup_tab_order().contains(&3),
            "password field is tabbable under password auth"
        );
        app.setup_auth = crate::model::AuthMethod::OAuth;
        assert!(
            !app.setup_tab_order().contains(&3),
            "no password field to tab to under OAuth"
        );
    }

    // The Enter-key save runs through the key handler, which uses the build's
    // default probe. On the offline (default) build that is the offline probe,
    // so the account persists; the live build performs a real IMAP/SMTP probe
    // that this test provides no server for (that path is covered by the
    // `validate` state-machine tests and the live socket tests).
    #[cfg(not(feature = "live"))]
    #[test]
    fn setup_enter_on_last_field_submits() {
        let (mut app, mut doc) = app();
        app.layout_for_test(1100.0, 780.0);
        app.open_setup_edit(None);
        app.setup_inputs[1].set_text("z@host.example");
        app.setup_inputs[2].set_text("z@host.example");
        app.setup_inputs[4].set_text("imap.host.example");
        app.setup_inputs[6].set_text("smtp.host.example");
        let before = app.shared.borrow().accounts.len();
        let last = *app.setup_tab_order().last().unwrap();
        app.focus_setup(Some(last));
        assert!(
            dispatch(&mut app, &named_key(NamedKey::Enter), &mut doc),
            "Enter consumed"
        );
        assert_eq!(
            app.shared.borrow().accounts.len(),
            before + 1,
            "Enter on the last field saves the account"
        );
    }

    #[test]
    fn gmail_email_presets_oauth_and_still_autofills_hosts() {
        let (mut app, _doc) = app();
        app.open_setup_edit(None);
        app.setup_inputs[1].set_text("someone@gmail.com");
        app.maybe_autofill();
        assert_eq!(
            app.setup_auth,
            crate::model::AuthMethod::OAuth,
            "Gmail presets to OAuth"
        );
        assert!(
            app.setup_provider.is_some(),
            "provider detected from the domain"
        );
        assert_eq!(
            app.setup_inputs[4].value(),
            "imap.gmail.com",
            "IMAP host still autofilled"
        );
    }

    #[test]
    fn setup_tab_traverses_every_field_in_order() {
        // Tab must reach every field, in the email → … → IMAP → port → SMTP
        // order the user expects, wrapping at the end; Shift+Tab steps back.
        let (mut app, mut doc) = app();
        app.open_setup_edit(None);
        app.setup_auth = crate::model::AuthMethod::Password; // password field tabbable
        app.focus_setup(Some(0));
        for exp in [1usize, 2, 3, 4, 5, 6, 7, 0] {
            assert!(
                dispatch(&mut app, &named_key(NamedKey::Tab), &mut doc),
                "Tab consumed"
            );
            assert_eq!(app.setup_focus, Some(exp), "Tab lands on field {exp}");
        }
        // The order genuinely walks email(1) → IMAP host(4) → IMAP port(5) →
        // SMTP host(6) → SMTP port(7).
        let order = app.setup_tab_order();
        let pos = |i: usize| order.iter().position(|&x| x == i).unwrap();
        assert!(pos(1) < pos(4) && pos(4) < pos(5) && pos(5) < pos(6) && pos(6) < pos(7));
        // Shift+Tab (the reverse the handler drives) steps back a field.
        app.focus_setup(Some(4));
        app.focus_setup_step(-1);
        assert_eq!(
            app.setup_focus,
            Some(3),
            "Shift+Tab moves back to the previous field"
        );
    }

    #[test]
    fn autofill_uses_the_builtin_table_across_providers() {
        // The built-in table fills the RIGHT servers offline, including cases
        // the old generic `imap.<domain>` guess got wrong (Outlook → office365).
        let (mut app, _doc) = app();
        app.open_setup_edit(None);
        app.setup_inputs[1].set_text("person@outlook.de");
        app.maybe_autofill();
        assert_eq!(
            app.setup_inputs[4].value(),
            "outlook.office365.com",
            "Outlook → office365, any TLD"
        );
        assert_eq!(app.setup_inputs[6].value(), "smtp.office365.com");

        app.open_setup_edit(None);
        app.setup_inputs[1].set_text("hi@gmx.net");
        app.maybe_autofill();
        assert_eq!(
            app.setup_inputs[4].value(),
            "imap.gmx.net",
            "GMX resolved offline from the table"
        );

        app.open_setup_edit(None);
        app.setup_inputs[1].set_text("me@fastmail.com");
        app.maybe_autofill();
        assert_eq!(app.setup_inputs[4].value(), "imap.fastmail.com");
        assert_eq!(
            app.setup_inputs[5].value(),
            "993",
            "port filled from the table too"
        );
    }

    #[test]
    fn typing_the_email_fills_servers_without_leaving_the_field() {
        // Autofill runs as the address is typed, not only on focus-leave: a key
        // event in the email field pre-fills the servers.
        let (mut app, mut doc) = app();
        app.open_setup_edit(None);
        app.focus_setup(Some(1));
        assert!(
            app.setup_inputs[4].value().is_empty(),
            "IMAP host starts blank"
        );
        app.setup_inputs[1].set_text("me@gmail.com");
        // A key event routed to the focused email field triggers the live fill.
        dispatch(&mut app, &named_key(NamedKey::ArrowRight), &mut doc);
        assert_eq!(
            app.setup_inputs[4].value(),
            "imap.gmail.com",
            "servers fill as the address is typed"
        );
        assert_eq!(app.setup_inputs[6].value(), "smtp.gmail.com");
    }

    #[test]
    fn status_toast_auto_dismisses_after_its_lifetime() {
        // A "Synced N messages" toast must fade on its own, not linger forever.
        let (mut app, _doc) = app();
        let t0 = std::time::Instant::now();
        app.shared.borrow_mut().status = Some("Synced 3 messages".into());
        app.expire_toast_at(t0); // first observation arms the deadline
        assert!(
            app.shared.borrow().status.is_some(),
            "toast shows immediately"
        );
        assert!(app.toast_pending(), "a dismiss deadline is armed");
        app.expire_toast_at(t0 + std::time::Duration::from_secs(1));
        assert!(
            app.shared.borrow().status.is_some(),
            "still visible within its lifetime"
        );
        app.expire_toast_at(t0 + std::time::Duration::from_secs(5));
        assert!(
            app.shared.borrow().status.is_none(),
            "toast auto-dismissed past its deadline"
        );
        assert!(!app.toast_pending(), "the deadline cleared once dismissed");
    }

    // ---- test-before-save state machine (persist on success only) --------

    struct FixedProbe {
        imap_ok: bool,
    }
    impl crate::validate::ProbeTransport for FixedProbe {
        fn imap_login(&self, _cfg: &AccountConfig) -> Result<(), String> {
            if self.imap_ok {
                Ok(())
            } else {
                Err("535 auth rejected".into())
            }
        }
        fn smtp_handshake(&self, _cfg: &AccountConfig) -> Result<(), String> {
            Ok(())
        }
    }

    #[test]
    fn save_persists_only_when_verification_succeeds() {
        let (mut app, mut doc) = app();
        app.open_setup_edit(None);
        app.setup_inputs[1].set_text("new@host.example");
        app.setup_inputs[2].set_text("new@host.example");
        app.setup_inputs[4].set_text("imap.host.example");
        app.setup_inputs[6].set_text("smtp.host.example");
        let before = app.shared.borrow().accounts.len();

        // Failing verification: no persist, sheet stays open, error surfaced.
        app.save_setup_with(&mut doc, &FixedProbe { imap_ok: false });
        assert_eq!(
            app.shared.borrow().accounts.len(),
            before,
            "a failed IMAP check must not persist the account"
        );
        assert!(
            app.setup_open,
            "the sheet stays open on a failed verification"
        );
        assert!(
            app.setup_error.as_deref().unwrap_or("").contains("IMAP"),
            "a specific IMAP error is shown"
        );

        // Succeeding verification: account saved, sheet closes.
        app.save_setup_with(&mut doc, &FixedProbe { imap_ok: true });
        assert_eq!(
            app.shared.borrow().accounts.len(),
            before + 1,
            "a verified account persists"
        );
        assert!(!app.setup_open, "the sheet closes on success");
        assert!(app.setup_error.is_none());
    }
}
