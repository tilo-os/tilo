//! Mail's exported **actions** and the **resource tree** it publishes to Ctrl+K.
//!
//! Every document-mutating operation Mail performs on its shared mailbox state is
//! a [`MailAction`]: a small serializable value that deterministically mutates the
//! CRDT (see [`crate::doc`], where per-message flags, the local-folder registry,
//! and the draft live). Because that state already rides in the shared document,
//! an action replicates and replays for free, and feeds straight back into the
//! panes on the next `sync`. The exact same [`EncodedAction`] is what the on-screen
//! affordances (the row star, the reader's action bar, the context menu, Save
//! draft) and the Ctrl+K command palette both build and dispatch — one source of
//! truth, one replay path.
//!
//! ## The split
//!
//! **Document-mutating → an action:** mark read/unread, star, move to a folder
//! (archive / delete-to-trash / junk / move-to-inbox are all a move), add/remove a
//! label, create/rename/delete a local folder, permanently purge a trashed
//! message, and save/discard the draft.
//!
//! **External, non-deterministic → never an action:** IMAP fetch/sync, SMTP send,
//! and account auth all write mailbox state as *external ingestion* driven by the
//! network (see [`crate::engine`]); they can't replay byte-identically, so they
//! stay outside the action model. Sending a mail is an external effect; **saving**
//! a draft is an action.
//!
//! **Presentation / view state → never an action:** the compose WYSIWYG buffer
//! until it is saved or sent, the selection, the search query, which folder/pane is
//! open, and the read-pane scroll. Nothing to replicate.
//!
//! ## Determinism contract
//!
//! Messages are addressed by their id string and folders by their key; a payload
//! carries the exact ids and the exact target value, so [`Action::apply`] is a pure
//! function of `(payload, base document)` — no RNG, no wall-clock, no app state.
//! Freshly-minted ids (a new local folder) are minted at *authoring* time and baked
//! into the payload. Bulk operations over several messages are batched into one
//! action (one undo boundary, one actor-pinned change, one byte-identical replay),
//! and their ids are applied in the payload's given order. A malformed payload (an
//! unknown folder key) is a **no-op**, never an error, so a bad replay can't wedge
//! a peer.

use automerge::AutoCommit;
use serde::{Deserialize, Serialize};

use qos_actions::{
    Action, ActionContract, ActionError, ActionRegistry, ActionSpec, Doc, EncodedAction,
    ExecutionLocus, ExecutionMode, OperationKind, Resource, ResourceProvider, RetryPolicy,
};

use crate::doc::MailDoc;
use crate::model::{Draft, Folder};

/// Registry `type_id` for every Mail action.
pub const MAIL_ACTION_TYPE: &str = "mail.action";
pub const MAIL_OPERATION_TYPE: &str = "mail.operation";

/// Bounds applied at the replicated-action boundary.  The UI normally keeps
/// values much smaller; these limits make a malformed, remote, or replayed
/// envelope unable to turn one mail action into an unbounded CRDT delta.
const MAX_MESSAGE_IDS_PER_ACTION: usize = 256;
const MAX_MESSAGE_ID_CHARS: usize = 128;
const MAX_LABEL_CHARS: usize = 128;
const MAX_FOLDER_NAME_CHARS: usize = 96;
const MAX_DRAFT_ADDRESS_CHARS: usize = 8 * 1024;
const MAX_DRAFT_SUBJECT_CHARS: usize = 998;
const MAX_DRAFT_BODY_CHARS: usize = 256 * 1024;

/// Take at most `max` Unicode scalar values without slicing a UTF-8 byte
/// offset.  Control characters are removed from one-line fields; bodies keep
/// normal newlines but still reject NUL and other control injection.
fn bounded_text(value: &str, max: usize, multiline: bool) -> String {
    value
        .trim()
        .chars()
        .filter(|ch| !ch.is_control() || (multiline && matches!(ch, '\n' | '\r' | '\t')))
        .take(max)
        .collect()
}

/// Normalise a batch before applying it.  This both bounds work and makes a
/// duplicated id in a hostile payload behave exactly like one requested id.
fn bounded_ids(ids: &[String]) -> Vec<&str> {
    let mut result = Vec::with_capacity(ids.len().min(MAX_MESSAGE_IDS_PER_ACTION));
    for id in ids {
        if result.len() == MAX_MESSAGE_IDS_PER_ACTION {
            break;
        }
        let id = id.trim();
        if id.is_empty() || id.chars().count() > MAX_MESSAGE_ID_CHARS || result.contains(&id) {
            continue;
        }
        result.push(id);
    }
    result
}

#[derive(Debug, Clone, PartialEq, Eq, Serialize, Deserialize)]
pub enum MailOperation {
    RefreshCurrentFolder,
    /// Reveal a system folder without changing the collaborative document.
    RevealFolder {
        folder: String,
    },
    RevealAccount {
        /// Account ids come from the device-local account store, so an action
        /// address keeps pointing at the same account when another account is
        /// added, removed, or reordered.
        id: String,
    },
    /// Reveal an already-loaded message. The admitted Open operation
    /// synchronously dispatches the canonical document `SetRead` action before
    /// it completes, so history, sync, notifications, and unread counters all
    /// observe the same state transition. This is the operation behind the
    /// plainly named **Open message** action.
    RevealMessage {
        id: String,
    },
    /// Inspect an already-loaded message without changing its read flag.
    ///
    /// This deliberately has a different operation and a deliberately explicit
    /// label in the resource tree: an agent (or a person checking a message)
    /// must never get a surprising read receipt merely by asking to inspect it.
    /// Normal list activation and **Open message** still use [`Self::RevealMessage`]
    /// and therefore mark an unread message as read.
    InspectMessage {
        id: String,
    },
    RevealDraft,
    SaveAttachment {
        message_id: String,
        index: usize,
    },
}

/// Decode a Mail effect operation when `type_id` addresses this application.
///
/// # Errors
///
/// Returns the JSON decoding error when a Mail operation payload is malformed.
pub fn decode_operation(type_id: &str, payload: &[u8]) -> Result<Option<MailOperation>, String> {
    if type_id != MAIL_OPERATION_TYPE {
        return Ok(None);
    }
    serde_json::from_slice(payload)
        .map(Some)
        .map_err(|e| e.to_string())
}

/// The persisted scalar fields of the in-progress draft, in exactly the shape
/// [`MailDoc::store_draft`] writes. Carrying the document shape keeps
/// [`Action::apply`] a pure write with no re-derivation.
#[derive(Debug, Clone, PartialEq, Eq, Serialize, Deserialize, Default)]
pub struct DraftData {
    pub to: String,
    pub cc: String,
    pub bcc: String,
    pub subject: String,
    pub body: String,
    pub html_body: Option<String>,
}

impl DraftData {
    pub fn from_draft(d: &Draft) -> Self {
        Self {
            to: bounded_text(&d.to, MAX_DRAFT_ADDRESS_CHARS, false),
            cc: bounded_text(&d.cc, MAX_DRAFT_ADDRESS_CHARS, false),
            bcc: bounded_text(&d.bcc, MAX_DRAFT_ADDRESS_CHARS, false),
            subject: bounded_text(&d.subject, MAX_DRAFT_SUBJECT_CHARS, false),
            body: bounded_text(&d.body, MAX_DRAFT_BODY_CHARS, true),
            html_body: d
                .html_body
                .as_deref()
                .map(|body| bounded_text(body, MAX_DRAFT_BODY_CHARS, true)),
        }
    }

    fn to_draft(&self) -> Draft {
        Draft {
            to: bounded_text(&self.to, MAX_DRAFT_ADDRESS_CHARS, false),
            cc: bounded_text(&self.cc, MAX_DRAFT_ADDRESS_CHARS, false),
            bcc: bounded_text(&self.bcc, MAX_DRAFT_ADDRESS_CHARS, false),
            subject: bounded_text(&self.subject, MAX_DRAFT_SUBJECT_CHARS, false),
            body: bounded_text(&self.body, MAX_DRAFT_BODY_CHARS, true),
            html_body: self
                .html_body
                .as_deref()
                .map(|body| bounded_text(body, MAX_DRAFT_BODY_CHARS, true)),
            attachments: Vec::new(),
            in_reply_to: None,
        }
    }
}

/// Every collaborative operation Mail exports on its shared mailbox state.
///
/// Determinism contract: ids and target values are carried in the payload;
/// [`Action::apply`] never touches the RNG or the wall-clock and applies its ids
/// in the payload's given order. A malformed payload is a **no-op**.
#[derive(Debug, Clone, PartialEq, Eq, Serialize, Deserialize)]
pub enum MailAction {
    /// Set the read/unread flag on a batch of messages.
    SetRead { ids: Vec<String>, read: bool },
    /// Set the starred flag on a batch of messages.
    SetStarred { ids: Vec<String>, starred: bool },
    /// Move a batch of messages to `folder` (a folder key from
    /// [`Folder::as_key`]). Archive, delete-to-trash, junk, and move-to-inbox are
    /// all this with a specific target. An unknown key is a no-op.
    Move { ids: Vec<String>, folder: String },
    /// Permanently remove a batch which is already in Trash. This writes a
    /// tombstone rather than directly altering a peer's hydrated corpus, so a
    /// delayed action cannot resurrect its flags.
    Purge { ids: Vec<String> },
    /// Add a label/tag to a batch of messages. Idempotent per message.
    AddLabel { ids: Vec<String>, label: String },
    /// Remove a label/tag from a batch of messages.
    RemoveLabel { ids: Vec<String>, label: String },
    /// Create a user-defined local folder with a stable id + display name (the id
    /// is minted at authoring time).
    CreateFolder { id: String, name: String },
    /// Rename a user-defined local folder. A no-op for an unknown id.
    RenameFolder { id: String, name: String },
    /// Delete a user-defined local folder from the registry.
    DeleteFolder { id: String },
    /// Save (create or overwrite) the in-progress draft.
    SaveDraft(DraftData),
    /// Discard the in-progress draft, clearing it from the document.
    DiscardDraft,
}

impl Action for MailAction {
    fn apply(&self, doc: &mut Doc) -> Result<(), ActionError> {
        match self {
            MailAction::SetRead { ids, read } => {
                for id in bounded_ids(ids) {
                    if MailDoc::is_present_message(doc, id) {
                        MailDoc::set_read(doc, id, *read);
                    }
                }
            }
            MailAction::SetStarred { ids, starred } => {
                for id in bounded_ids(ids) {
                    if MailDoc::is_present_message(doc, id) {
                        MailDoc::set_starred(doc, id, *starred);
                    }
                }
            }
            MailAction::Move { ids, folder } => {
                // An unknown folder key (e.g. a stale local-folder id) is a no-op
                // rather than a wrong move — the system `Folder` enum is total.
                if let Some(f) = Folder::from_key(folder) {
                    for id in bounded_ids(ids) {
                        if MailDoc::is_present_message(doc, id) {
                            MailDoc::set_folder_for(doc, id, f);
                        }
                    }
                }
            }
            MailAction::Purge { ids } => {
                for id in bounded_ids(ids) {
                    if MailDoc::is_present_message(doc, id) {
                        MailDoc::mark_message_purged(doc, id);
                    }
                }
            }
            MailAction::AddLabel { ids, label } => {
                let label = bounded_text(label, MAX_LABEL_CHARS, false);
                if label.is_empty() {
                    return Ok(());
                }
                for id in bounded_ids(ids) {
                    if MailDoc::is_present_message(doc, id) {
                        MailDoc::add_label(doc, id, &label);
                    }
                }
            }
            MailAction::RemoveLabel { ids, label } => {
                let label = bounded_text(label, MAX_LABEL_CHARS, false);
                if label.is_empty() {
                    return Ok(());
                }
                for id in bounded_ids(ids) {
                    if MailDoc::is_present_message(doc, id) {
                        MailDoc::remove_label(doc, id, &label);
                    }
                }
            }
            MailAction::CreateFolder { id, name } => {
                let name = bounded_text(name, MAX_FOLDER_NAME_CHARS, false);
                if id.chars().count() <= MAX_MESSAGE_ID_CHARS && !name.is_empty() {
                    MailDoc::create_folder(doc, id, &name);
                }
            }
            MailAction::RenameFolder { id, name } => {
                let name = bounded_text(name, MAX_FOLDER_NAME_CHARS, false);
                if id.chars().count() <= MAX_MESSAGE_ID_CHARS && !name.is_empty() {
                    MailDoc::rename_folder(doc, id, &name);
                }
            }
            MailAction::DeleteFolder { id } => {
                if id.chars().count() <= MAX_MESSAGE_ID_CHARS {
                    MailDoc::delete_folder(doc, id);
                }
            }
            MailAction::SaveDraft(data) => {
                MailDoc::store_draft(doc, &data.to_draft());
            }
            MailAction::DiscardDraft => {
                MailDoc::clear_draft(doc);
            }
        }
        Ok(())
    }

    fn locus(&self) -> ExecutionLocus {
        ExecutionLocus::ClientLocal
    }
}

/// Register Mail's action decoder for palette execution + remote replay.
pub fn register(registry: &mut ActionRegistry) {
    registry.register::<MailAction>(MAIL_ACTION_TYPE);
}

/// Encode any [`MailAction`] into the wire form the palette and the on-screen
/// affordances both dispatch. The single point that turns a Mail action into a
/// replayable envelope.
///
/// # Panics
/// Never in practice: [`MailAction`] is a plain derived-`Serialize` enum with
/// no non-serializable fields, so encoding it cannot fail.
#[allow(
    clippy::expect_used,
    reason = "MailAction is a plain derived-Serialize enum, so encoding cannot fail; an un-encodable action has no replayable form to fall back to"
)]
pub fn encode(action: &MailAction) -> EncodedAction {
    EncodedAction::encode(MAIL_ACTION_TYPE, action).expect("MailAction is always serializable")
}

// ===========================================================================
// Action builders — the single source of truth shared by the on-screen
// affordances (see `crate::state` / `crate::app`) and the Ctrl+K resource tree.
// ===========================================================================

/// Set the read flag on a batch of messages.
pub fn set_read_action(ids: Vec<String>, read: bool) -> MailAction {
    MailAction::SetRead { ids, read }
}

/// Set the starred flag on a batch of messages.
pub fn set_starred_action(ids: Vec<String>, starred: bool) -> MailAction {
    MailAction::SetStarred { ids, starred }
}

/// Move a batch of messages to a system folder.
pub fn move_action(ids: Vec<String>, folder: Folder) -> MailAction {
    MailAction::Move {
        ids,
        folder: folder.as_key().to_string(),
    }
}

/// Permanently purge a batch of already-trashed messages.
pub fn purge_action(ids: Vec<String>) -> MailAction {
    MailAction::Purge { ids }
}

/// Add a label to a batch of messages.
pub fn add_label_action(ids: Vec<String>, label: &str) -> MailAction {
    MailAction::AddLabel {
        ids,
        label: label.to_string(),
    }
}

/// Remove a label from a batch of messages.
pub fn remove_label_action(ids: Vec<String>, label: &str) -> MailAction {
    MailAction::RemoveLabel {
        ids,
        label: label.to_string(),
    }
}

/// Create a local folder with a caller-minted id.
pub fn create_folder_action(id: &str, name: &str) -> MailAction {
    MailAction::CreateFolder {
        id: id.to_string(),
        name: name.to_string(),
    }
}

/// Rename a local folder.
pub fn rename_folder_action(id: &str, name: &str) -> MailAction {
    MailAction::RenameFolder {
        id: id.to_string(),
        name: name.to_string(),
    }
}

/// Delete a local folder.
pub fn delete_folder_action(id: &str) -> MailAction {
    MailAction::DeleteFolder { id: id.to_string() }
}

/// Save (create or overwrite) the in-progress draft.
pub fn save_draft_action(draft: &Draft) -> MailAction {
    MailAction::SaveDraft(DraftData::from_draft(draft))
}

/// Discard the in-progress draft.
pub fn discard_draft_action() -> MailAction {
    MailAction::DiscardDraft
}

// ===========================================================================
// Resource tree
// ===========================================================================

/// Largest number of message rows materialised into the currently-open
/// resource tree. Individual messages and threads remain lazily resolvable by
/// stable id, so this is a snapshot-memory ceiling rather than a discovery cap.
pub(crate) const OPEN_MESSAGE_LIMIT: usize = 100;

/// One message surfaced as a resource, with the scalar state its actions need
/// resolved at authoring time (so "Mark read" builds the byte-identical action
/// the on-screen control does).
#[derive(Debug, Clone)]
pub struct MessageRow {
    pub id: String,
    /// Stable conversation anchor from [`crate::model::Thread::id`]. This is
    /// separate from the subject: display text is neither unique nor durable.
    pub thread_id: String,
    pub subject: String,
    pub thread_subject: String,
    pub folder: Folder,
    pub read: bool,
    pub starred: bool,
    pub labels: Vec<String>,
    pub attachments: Vec<AttachmentRow>,
}

#[derive(Debug, Clone)]
pub struct AttachmentRow {
    pub filename: String,
    pub size: u64,
    pub downloadable: bool,
}

/// Project exactly one loaded message into the scalar data required to author
/// its canonical resource. Keeping this conversion public within Mail lets the
/// small open-resource snapshot and lazy resolver use the same row without
/// cloning the entire mailbox.
pub(crate) fn message_row(message: &crate::model::Message) -> MessageRow {
    MessageRow {
        id: message.id.to_string(),
        // A caller that materialises a folder tree replaces this with the
        // thread projection's anchor. Keeping the message id here makes
        // on-demand message/search rows safe and self-contained.
        thread_id: message.id.to_string(),
        subject: message.subject.clone(),
        thread_subject: message.thread_subject(),
        folder: message.folder,
        read: message.read,
        starred: message.starred,
        labels: message.labels.clone(),
        attachments: message
            .attachments
            .iter()
            .map(|attachment| AttachmentRow {
                filename: attachment.filename.clone(),
                size: attachment.size,
                downloadable: attachment.is_downloadable(),
            })
            .collect(),
    }
}

/// The presentation context Mail hands [`provide_resources`]: the device-local
/// account list plus collaborative mailbox state (current folder/messages,
/// local-folder registry, and draft). Connection accounts stay out of the
/// Automerge document; their ids are nevertheless stable resource addresses.
#[derive(Debug, Clone)]
pub struct MailResourceCtx {
    pub mailbox_label: String,
    pub current_folder: Folder,
    pub accounts: Vec<(String, String, bool)>,
    /// Loaded messages in the currently-open folder. Resource materialization
    /// applies its own bound so a large mailbox cannot inflate Ctrl+K snapshots.
    pub messages: Vec<MessageRow>,
    /// User-defined local folders `(id, name)`, sorted by id.
    pub custom_folders: Vec<(String, String)>,
    /// Whether a persisted draft exists (so "Discard draft" is offered).
    pub has_draft: bool,
    pub can_sync: bool,
}

/// # Panics
/// Never in practice: [`MailAction`] is a plain derived-`Serialize` enum with
/// no non-serializable fields, so encoding it cannot fail.
#[allow(
    clippy::expect_used,
    reason = "MailAction is a plain derived-Serialize enum, so encoding cannot fail; a spec that cannot encode its action would be an unusable palette entry"
)]
fn immediate_spec(id: &str, label: &str, action: &MailAction) -> ActionSpec {
    ActionSpec::immediate(id, label, MAIL_ACTION_TYPE, action)
        .expect("encode mail action")
        .reversible()
}

#[allow(
    clippy::expect_used,
    reason = "MailOperation is a derived-Serialize enum; an unencodable operation is a programmer invariant violation"
)]
fn view_spec(id: &str, label: &str, operation: &MailOperation) -> ActionSpec {
    ActionSpec::operation(
        id,
        label,
        OperationKind::View,
        MAIL_OPERATION_TYPE,
        operation,
    )
    .expect("encode mail view operation")
    .retry_policy(RetryPolicy::Idempotent)
}

#[allow(
    clippy::expect_used,
    reason = "MailOperation is a derived-Serialize enum; an unencodable operation is a programmer invariant violation"
)]
fn effect_spec(id: &str, label: &str, operation: &MailOperation) -> ActionSpec {
    ActionSpec::operation(
        id,
        label,
        OperationKind::Effect,
        MAIL_OPERATION_TYPE,
        operation,
    )
    .expect("encode mail effect operation")
}

fn message_label(m: &MessageRow) -> String {
    let s = m.subject.trim();
    let base = if s.is_empty() { "(no subject)" } else { s };
    if m.starred {
        format!("★ {base}")
    } else {
        base.to_string()
    }
}

pub(crate) fn message_resource(message: &MessageRow) -> Resource {
    let mut resource = Resource::new(
        format!("mail.message:{}", message.id),
        "mail.message",
        message_label(message),
    );
    resource = resource.with_action(view_spec(
        "open",
        "Open message",
        &MailOperation::RevealMessage {
            id: message.id.clone(),
        },
    ));
    resource = resource.with_action(view_spec(
        "inspect",
        "Preview without marking read",
        &MailOperation::InspectMessage {
            id: message.id.clone(),
        },
    ));
    resource = resource.with_action(immediate_spec(
        "read",
        if message.read {
            "Mark unread"
        } else {
            "Mark read"
        },
        &set_read_action(vec![message.id.clone()], !message.read),
    ));
    resource = resource.with_action(immediate_spec(
        "star",
        if message.starred { "Unstar" } else { "Star" },
        &set_starred_action(vec![message.id.clone()], !message.starred),
    ));
    resource = resource.with_action(immediate_spec(
        "archive",
        "Archive",
        &move_action(vec![message.id.clone()], Folder::Archive),
    ));
    let delete = if message.folder == Folder::Trash {
        immediate_spec(
            "delete",
            "Delete permanently",
            &purge_action(vec![message.id.clone()]),
        )
    } else {
        immediate_spec(
            "delete",
            "Delete",
            &move_action(vec![message.id.clone()], Folder::Trash),
        )
    };
    resource = resource.with_action(delete.destructive());

    let message_id = message.id.clone();
    resource = resource.with_action(ActionSpec::prompted(
        "add-label",
        "Add label…",
        "Label",
        "label…",
        ExecutionLocus::ClientLocal,
        move |label: &str| encode(&add_label_action(vec![message_id.clone()], label.trim())),
    ));
    for (index, label) in message.labels.iter().enumerate() {
        resource = resource.with_action(immediate_spec(
            &format!("remove-label-{index}"),
            &format!("Remove label “{label}”"),
            &remove_label_action(vec![message.id.clone()], label),
        ));
    }
    for (index, attachment) in message.attachments.iter().enumerate() {
        let save = effect_spec(
            "save",
            "Save attachment",
            &MailOperation::SaveAttachment {
                message_id: message.id.clone(),
                index,
            },
        );
        resource = resource.with_child(
            Resource::new(
                format!("mail.attachment:{}:{index}", message.id),
                "mail.attachment",
                format!(
                    "{} · {}",
                    attachment.filename,
                    ui::format::bytes(attachment.size)
                ),
            )
            .with_action(if attachment.downloadable {
                save
            } else {
                save.unavailable("not_downloaded", "Attachment content is not downloaded yet")
            }),
        );
    }
    resource
}

/// Build Mail's resource tree: the mailbox root (exporting "New folder"),
/// every system folder with its loaded messages nested (each exporting
/// read / flag / move / delete + label actions), and one `mail.folder:<id>` per
/// user-defined local folder (rename / delete). The Drafts folder additionally
/// exports "Discard draft" when a draft is in progress. Every operation is the
/// same action the on-screen affordance dispatches.
#[allow(
    clippy::too_many_lines,
    reason = "the mailbox hierarchy is intentionally authored together so every visible entity and operation shares one contract"
)]
/// Stable mailbox root. Accounts, folders and messages are dynamic children
/// served through Mail's retained provider rather than root browse pages.
pub fn mailbox_root(ctx: &MailResourceCtx) -> Resource {
    let mut root = Resource::new("mail.mailbox", "mail.mailbox", ctx.mailbox_label.clone());

    if let Ok(refresh) = ActionSpec::operation(
        "refresh",
        "Refresh current folder",
        OperationKind::Effect,
        MAIL_OPERATION_TYPE,
        &MailOperation::RefreshCurrentFolder,
    ) {
        let refresh = refresh.with_contract(ActionContract {
            retry: RetryPolicy::Idempotent,
            execution: ExecutionMode::Background { cancellable: false },
            tags: vec!["network".into(), "mail".into(), "refresh".into()],
            ..ActionContract::default()
        });
        root = root.with_action(if ctx.can_sync {
            refresh
        } else {
            refresh.unavailable("account_offline", "No connected mail account is available")
        });
    }

    // Mailbox-level: create a new local folder. The id is minted once when the
    // name is committed, then baked into the envelope, so replay stays
    // deterministic.
    root = root.with_action(
        ActionSpec::prompted(
            "new-folder",
            "New folder",
            "Name",
            "folder name…",
            ExecutionLocus::ClientLocal,
            move |name: &str| {
                let id = uuid::Uuid::new_v4().to_string();
                encode(&create_folder_action(&id, name.trim()))
            },
        )
        .reversible(),
    );

    root
}

pub fn provide_resources(ctx: &MailResourceCtx, _doc: &AutoCommit) -> Vec<Resource> {
    let mut root = mailbox_root(ctx);
    root = root.with_child(
        Resource::new("mail.accounts", "mail.account.collection", "Accounts").with_children(
            ctx.accounts.iter().map(|(id, label, active)| {
                Resource::new(
                    format!("mail.account:{id}"),
                    "mail.account",
                    if *active {
                        format!("{label} · Active")
                    } else {
                        label.clone()
                    },
                )
                .with_action(view_spec(
                    "open",
                    "Open account",
                    &MailOperation::RevealAccount { id: id.clone() },
                ))
            }),
        ),
    );

    // Every searchable system folder and loaded message gets a stable address.
    // The supplied rows are already the current folder's projection (including
    // virtual Starred), so they must not be filtered again by physical folder.
    for folder in Folder::ALL {
        let mut folder_node = system_folder_resource(folder, ctx.has_draft);
        if folder == ctx.current_folder {
            let mut threads: Vec<(String, String, Vec<&MessageRow>)> = Vec::new();
            for message in ctx.messages.iter().rev().take(OPEN_MESSAGE_LIMIT) {
                if let Some((_, _, messages)) = threads
                    .iter_mut()
                    .find(|(id, _, _)| id == &message.thread_id)
                {
                    messages.push(message);
                } else {
                    threads.push((
                        message.thread_id.clone(),
                        message.thread_subject.clone(),
                        vec![message],
                    ));
                }
            }
            for (thread_id, thread_subject, messages) in threads {
                let stable = thread_resource_key(folder, &thread_id);
                folder_node = folder_node.with_child(
                    Resource::new(
                        format!("mail.thread:{stable}"),
                        "mail.thread",
                        if thread_subject.is_empty() {
                            "(no subject)".into()
                        } else {
                            thread_subject
                        },
                    )
                    .with_children(messages.into_iter().map(message_resource)),
                );
            }
        }
        root = root.with_child(folder_node);
    }

    // User-defined local folders — rename / delete.
    for (id, name) in &ctx.custom_folders {
        let rid = id.clone();
        let mut f = Resource::new(format!("mail.folder:{id}"), "mail.folder", name.clone());
        f = f.with_action(
            ActionSpec::prompted(
                "rename",
                "Rename folder",
                "Name",
                "folder name…",
                ExecutionLocus::ClientLocal,
                move |n: &str| encode(&rename_folder_action(&rid, n.trim())),
            )
            .reversible(),
        );
        f = f.with_action(
            immediate_spec("delete-folder", "Delete folder", &delete_folder_action(id))
                .destructive(),
        );
        root = root.with_child(f);
    }

    vec![root]
}

/// Build the canonical resource for a built-in folder. Kept separate from the
/// tree assembly above so the search provider can materialize the *same*
/// folder resource lazily instead of returning an address which only happens
/// to work when another provider has already built the whole mailbox tree.
pub(crate) fn system_folder_resource(folder: Folder, has_draft: bool) -> Resource {
    let mut folder_node = Resource::new(
        format!("mail.folder:{}", folder.as_key()),
        "mail.folder",
        folder.title().to_string(),
    )
    .with_action(view_spec(
        "open",
        "Open folder",
        &MailOperation::RevealFolder {
            folder: folder.as_key().to_string(),
        },
    ));
    if folder == Folder::Drafts && has_draft {
        folder_node = folder_node.with_action(
            immediate_spec("discard-draft", "Discard draft", &discard_draft_action()).destructive(),
        );
        folder_node = folder_node.with_child(
            Resource::new("mail.draft:current", "mail.draft", "Current draft")
                .with_action(view_spec(
                    "open",
                    "Continue editing",
                    &MailOperation::RevealDraft,
                ))
                .with_action(
                    immediate_spec("discard", "Discard draft", &discard_draft_action())
                        .destructive(),
                ),
        );
    }
    folder_node
}

pub(crate) fn thread_resource_key(folder: Folder, thread_id: &str) -> String {
    // The RFC References root (or the model's documented legacy fallback) is
    // a stable domain identity. Scoping it to the folder prevents virtual
    // Starred and a physical folder from claiming the same resource address,
    // while avoiding lossy subject-derived hashes.
    format!("{}:{thread_id}", folder.as_key())
}

impl ResourceProvider for crate::app::MailApp {
    fn resources(&self, doc: &AutoCommit) -> Vec<Resource> {
        provide_resources(&self.mail_resource_ctx(doc), doc)
    }

    fn resource(&self, doc: &AutoCommit, id: &str) -> Option<Resource> {
        fn find(resources: Vec<Resource>, id: &str) -> Option<Resource> {
            for resource in resources {
                if resource.id.as_str() == id {
                    return Some(resource);
                }
                if let Some(found) = find(resource.children, id) {
                    return Some(found);
                }
            }
            None
        }

        if let Some(message_id) = id.strip_prefix("mail.message:") {
            // The open tree carries only a small current-folder prefix. Do
            // not make the remainder of a loaded mailbox unreachable to an
            // agent or a canonical search address merely because it was not
            // among those materialised rows.
            let row = self.resource_message_row(message_id)?;
            return Some(message_resource(&row));
        }
        if let Some(rest) = id.strip_prefix("mail.attachment:")
            && let Some((message_id, index)) = rest.rsplit_once(':')
            && let Ok(index) = index.parse::<usize>()
        {
            let row = self.resource_message_row(message_id)?;
            return message_resource(&row).children.into_iter().nth(index);
        }
        if let Some(stable) = id.strip_prefix("mail.thread:") {
            let (subject, messages) = self.resource_thread_rows(stable)?;
            return Some(
                Resource::new(
                    id,
                    "mail.thread",
                    if subject.is_empty() {
                        "(no subject)".into()
                    } else {
                        subject
                    },
                )
                .with_children(messages.iter().map(message_resource)),
            );
        }
        let ctx = self.mail_resource_ctx(doc);
        find(provide_resources(&ctx, doc), id)
    }
}

#[cfg(test)]
mod tests {
    use super::*;
    use crate::app::{MailApp, avatar_store_offline};
    use crate::model::Folder;
    use crate::state::{CtxAction, MailState};

    use qos_actions::{ActionInput, LocalTransport};
    use ui::widget::Widget;

    fn registry() -> ActionRegistry {
        let mut r = ActionRegistry::new();
        register(&mut r);
        r
    }

    fn immediate_encode(spec: &ActionSpec) -> EncodedAction {
        match &spec.input {
            ActionInput::Immediate(enc) => enc.clone(),
            ActionInput::Prompted { .. } => {
                panic!("expected an immediate action: {}", spec.id)
            }
        }
    }

    fn prompted_encode(spec: &ActionSpec, arg: &str) -> EncodedAction {
        match &spec.input {
            ActionInput::Prompted { build, .. } => build(arg),
            ActionInput::Immediate(_) => {
                panic!("expected a prompted action: {}", spec.id)
            }
        }
    }

    /// Dispatch an action through the executor, as the on-screen affordance path
    /// does.
    fn dispatch(doc: &mut AutoCommit, action: &MailAction) {
        let encoded = encode(action);
        let decoded = registry().decode(&encoded).unwrap();
        let mut tx = LocalTransport::new();
        qos_actions::dispatch(doc, decoded.as_ref(), encoded, &mut tx).unwrap();
    }

    /// A sample app synced into a fresh document, plus that document.
    fn seeded_app() -> (MailApp, ui::State) {
        let mut app = MailApp::new_sample();
        let mut state = ui::State::new();
        app.sync(&mut state.doc, &state.root);
        (app, state)
    }

    #[test]
    fn message_resource_distinguishes_open_from_read_state_neutral_preview() {
        let (app, state) = seeded_app();
        let message = app
            .mail_resource_ctx(&state.doc)
            .messages
            .into_iter()
            .find(|message| !message.read)
            .expect("sample has an unread message");
        let resource = message_resource(&message);
        let open = resource
            .actions
            .iter()
            .find(|action| action.id == "open")
            .expect("normal open action");
        let preview = resource
            .actions
            .iter()
            .find(|action| action.id == "inspect")
            .expect("explicit preview action");
        assert_eq!(open.label, "Open message");
        assert_eq!(preview.label, "Preview without marking read");
        let ActionInput::Immediate(open_payload) = &open.input else {
            panic!("open is an immediate view operation");
        };
        let ActionInput::Immediate(preview_payload) = &preview.input else {
            panic!("preview is an immediate view operation");
        };
        assert!(matches!(
            decode_operation(&open_payload.type_id, &open_payload.payload).unwrap(),
            Some(MailOperation::RevealMessage { .. })
        ));
        assert!(matches!(
            decode_operation(&preview_payload.type_id, &preview_payload.payload).unwrap(),
            Some(MailOperation::InspectMessage { .. })
        ));
    }

    /// A sample message id (as a string) taken from the Inbox.
    fn an_inbox_id(st: &MailState) -> String {
        st.mailbox.messages_in(Folder::Inbox)[0].id.to_string()
    }

    /// Ctrl+K on Mail yields the mailbox root exporting "New folder", the open
    /// folder with `mail.message:<id>` children exporting read / star / archive /
    /// delete, and surfaces them in the one palette. Drives the real resource hook.
    #[test]
    fn ctrl_k_publishes_the_mailbox_tree() {
        let (app, state) = seeded_app();
        let resources = Widget::resources(&app, &state.doc);
        assert_eq!(resources.len(), 1, "one mailbox root");
        let mailbox = &resources[0];
        assert_eq!(mailbox.kind, "mail.mailbox");
        let mb_actions: Vec<&str> = mailbox.actions.iter().map(|a| a.id.as_str()).collect();
        assert!(mb_actions.contains(&"new-folder"), "{mb_actions:?}");
        assert!(mb_actions.contains(&"refresh"), "{mb_actions:?}");
        let refresh = mailbox.actions.iter().find(|a| a.id == "refresh").unwrap();
        assert_eq!(
            refresh.contract.execution,
            qos_actions::ExecutionMode::Background { cancellable: false }
        );
        assert_eq!(refresh.contract.result, qos_actions::ResultSpec::None);

        let folder = mailbox
            .children
            .iter()
            .find(|r| r.kind == "mail.folder")
            .expect("an open folder node");
        assert!(
            !folder.children.is_empty() && folder.children.len() <= 100,
            "the open folder publishes a bounded thread hierarchy"
        );
        assert!(
            folder.children.iter().all(|thread| {
                thread.kind == "mail.thread"
                    && !thread.children.is_empty()
                    && thread
                        .children
                        .iter()
                        .all(|item| item.kind == "mail.message")
            }),
            "messages are grouped under searchable thread resources"
        );
        let id = app.mail_resource_ctx(&state.doc).messages[0].id.clone();
        let message = <MailApp as ResourceProvider>::resource(
            &app,
            &state.doc,
            &format!("mail.message:{id}"),
        )
        .expect("a message remains addressable outside the snapshot");
        let msg_actions: Vec<&str> = message.actions.iter().map(|a| a.id.as_str()).collect();
        for want in ["read", "star", "archive", "delete", "add-label"] {
            assert!(
                msg_actions.contains(&want),
                "message exports {want}: {msg_actions:?}"
            );
        }
        assert_eq!(
            message
                .actions
                .iter()
                .find(|a| a.id == "delete")
                .unwrap()
                .contract
                .risk,
            qos_actions::RiskLevel::Destructive
        );

        let mut palette = ui::ActionPalette::new();
        palette.load_open_resources(&resources);
        palette.open();
        let labels = palette.result_labels();
        assert!(
            labels.iter().any(|l| l.contains("New folder")),
            "{labels:?}"
        );
    }

    #[test]
    fn ten_thousand_messages_do_not_expand_the_open_snapshot() {
        let mut ctx = MailResourceCtx {
            mailbox_label: "Scale".into(),
            current_folder: Folder::Inbox,
            accounts: vec![("scale@example.test".into(), "Scale".into(), true)],
            messages: Vec::new(),
            custom_folders: Vec::new(),
            has_draft: false,
            can_sync: false,
        };
        ctx.messages.extend((0..10_000).map(|id| MessageRow {
            id: id.to_string(),
            thread_id: id.to_string(),
            subject: format!("Message {id}"),
            thread_subject: format!("Message {id}"),
            folder: Folder::Inbox,
            read: false,
            starred: false,
            labels: Vec::new(),
            attachments: Vec::new(),
        }));
        let resources = provide_resources(&ctx, &AutoCommit::new());
        let inbox = resources[0]
            .children
            .iter()
            .find(|resource| resource.id.as_str() == "mail.folder:inbox")
            .expect("inbox resource");
        assert_eq!(inbox.children.len(), 100, "open hierarchy is bounded");
        assert!(
            inbox
                .children
                .iter()
                .all(|thread| { thread.kind == "mail.thread" && thread.children.len() == 1 })
        );
        assert!(message_resource(&ctx.messages[9_999]).actions.len() >= 5);
    }

    #[test]
    fn same_subject_threads_keep_distinct_stable_resource_addresses() {
        let ctx = MailResourceCtx {
            mailbox_label: "Mailbox".into(),
            current_folder: Folder::Inbox,
            accounts: Vec::new(),
            messages: vec![
                MessageRow {
                    id: "newer".into(),
                    thread_id: "thread-b".into(),
                    subject: "Status update".into(),
                    thread_subject: "Status update".into(),
                    folder: Folder::Inbox,
                    read: false,
                    starred: false,
                    labels: Vec::new(),
                    attachments: Vec::new(),
                },
                MessageRow {
                    id: "older".into(),
                    thread_id: "thread-a".into(),
                    subject: "Status update".into(),
                    thread_subject: "Status update".into(),
                    folder: Folder::Inbox,
                    read: false,
                    starred: false,
                    labels: Vec::new(),
                    attachments: Vec::new(),
                },
            ],
            custom_folders: Vec::new(),
            has_draft: false,
            can_sync: false,
        };
        let resources = provide_resources(&ctx, &AutoCommit::new());
        let inbox = resources[0]
            .children
            .iter()
            .find(|resource| resource.id.as_str() == "mail.folder:inbox")
            .expect("inbox resource");
        assert_eq!(
            inbox.children.len(),
            2,
            "same display text must not merge threads"
        );
        let ids: Vec<_> = inbox
            .children
            .iter()
            .map(|thread| thread.id.as_str())
            .collect();
        assert!(ids.contains(&"mail.thread:inbox:thread-a"));
        assert!(ids.contains(&"mail.thread:inbox:thread-b"));
    }

    #[test]
    fn account_resource_uses_a_durable_id_not_its_display_index() {
        let ctx = MailResourceCtx {
            mailbox_label: "Mailbox".into(),
            current_folder: Folder::Inbox,
            accounts: vec![
                ("personal-42".into(), "Personal".into(), true),
                ("work-99".into(), "Work".into(), false),
            ],
            messages: Vec::new(),
            custom_folders: Vec::new(),
            has_draft: false,
            can_sync: false,
        };
        let resources = provide_resources(&ctx, &AutoCommit::new());
        let address = qos_actions::ActionAddress::new("mail.account:work-99", "open");
        let encoded = qos_actions::door::encode(&resources, &address, None)
            .expect("the stable account address resolves through the mailbox tree");
        assert_eq!(
            decode_operation(&encoded.type_id, &encoded.payload).unwrap(),
            Some(MailOperation::RevealAccount {
                id: "work-99".into()
            })
        );
    }

    /// The full undo covenant on one action: dispatched through the executor a
    /// move-to-Trash mutates the document and records exactly one undo boundary,
    /// and Ctrl+Z (the host's `undo`) reverts precisely that action.
    #[test]
    fn move_action_records_one_undo_boundary_and_reverts() {
        let mut state = ui::State::new();
        // A message currently in the Inbox.
        let id = "msg-1";
        MailDoc::set_folder_for(&mut state.doc, id, Folder::Inbox);
        let before_heads = state.doc.get_heads();
        assert_eq!(MailDoc::get_folder_for(&state.doc, id), Some(Folder::Inbox));

        let encoded = encode(&move_action(vec![id.to_string()], Folder::Trash));
        let decoded = registry().decode(&encoded).unwrap();
        let mut tx = LocalTransport::new();
        qos_actions::dispatch(&mut state.doc, decoded.as_ref(), encoded, &mut tx).unwrap();
        state.record_committed_action(before_heads, None, None);

        assert_eq!(
            MailDoc::get_folder_for(&state.doc, id),
            Some(Folder::Trash),
            "the action moved the message to Trash"
        );
        assert!(
            state.peek_last_undo().is_some(),
            "exactly one undo boundary recorded"
        );

        state.undo(None, None).expect("an undo entry to pop");
        assert_eq!(
            MailDoc::get_folder_for(&state.doc, id),
            Some(Folder::Inbox),
            "undo reverted the move and nothing else"
        );
    }

    /// The collaboration guarantee: replaying the same encoded action on a second
    /// independent replica (from the same base state) lands on the byte-identical
    /// document — same head hashes, not merely the same values.
    #[test]
    fn set_starred_replays_byte_identical_on_a_peer() {
        let mut a = AutoCommit::new();
        MailDoc::set_folder_for(&mut a, "m", Folder::Inbox);
        a.commit();
        let bytes = a.save();
        let mut b = AutoCommit::load(&bytes).unwrap();
        assert_eq!(
            a.get_heads(),
            b.get_heads(),
            "precondition: same base state"
        );

        let action = set_starred_action(vec!["m".to_string()], true);
        let encoded = encode(&action);
        let env = qos_actions::apply_local(&mut a, &action, encoded).unwrap();
        qos_actions::replay(&mut b, &env, &registry()).unwrap();

        assert_eq!(
            a.get_heads(),
            b.get_heads(),
            "replay reproduced the identical change"
        );
        assert_eq!(MailDoc::get_starred(&b, "m"), Some(true));
    }

    #[test]
    fn concurrent_same_message_flag_edits_merge_without_losing_either_field() {
        let mut base = AutoCommit::new();
        MailDoc::register_message(&mut base, "m");
        base.commit();
        let bytes = base.save();
        let mut read_replica = AutoCommit::load(&bytes).unwrap();
        let mut star_replica = AutoCommit::load(&bytes).unwrap();
        read_replica.set_actor(automerge::ActorId::from(vec![1]));
        star_replica.set_actor(automerge::ActorId::from(vec![2]));

        set_read_action(vec!["m".into()], true)
            .apply(&mut read_replica)
            .unwrap();
        read_replica.commit();
        set_starred_action(vec!["m".into()], true)
            .apply(&mut star_replica)
            .unwrap();
        star_replica.commit();

        read_replica.merge(&mut star_replica).unwrap();
        assert_eq!(MailDoc::get_read(&read_replica, "m"), Some(true));
        assert_eq!(MailDoc::get_starred(&read_replica, "m"), Some(true));
    }

    /// A batched multi-message move is one change and replays byte-identically on
    /// a peer — the whole batch, one actor, equal heads.
    #[test]
    fn batched_move_replays_byte_identical() {
        let mut a = AutoCommit::new();
        for id in ["m1", "m2", "m3"] {
            MailDoc::set_folder_for(&mut a, id, Folder::Inbox);
        }
        a.commit();
        let bytes = a.save();
        let mut b = AutoCommit::load(&bytes).unwrap();
        assert_eq!(
            a.get_heads(),
            b.get_heads(),
            "precondition: same base state"
        );

        let action = move_action(vec!["m1".into(), "m2".into(), "m3".into()], Folder::Archive);
        let encoded = encode(&action);
        let env = qos_actions::apply_local(&mut a, &action, encoded).unwrap();
        qos_actions::replay(&mut b, &env, &registry()).unwrap();

        assert_eq!(
            a.get_heads(),
            b.get_heads(),
            "the whole batch replayed identically"
        );
        for id in ["m1", "m2", "m3"] {
            assert_eq!(MailDoc::get_folder_for(&b, id), Some(Folder::Archive));
        }
    }

    /// Adding a label also replays byte-identically — the list-mutating path, not
    /// just a scalar flag.
    #[test]
    fn add_label_replays_byte_identical() {
        let mut a = AutoCommit::new();
        MailDoc::set_folder_for(&mut a, "m", Folder::Inbox);
        a.commit();
        let bytes = a.save();
        let mut b = AutoCommit::load(&bytes).unwrap();

        let action = add_label_action(vec!["m".to_string()], "work");
        let encoded = encode(&action);
        let env = qos_actions::apply_local(&mut a, &action, encoded).unwrap();
        qos_actions::replay(&mut b, &env, &registry()).unwrap();

        assert_eq!(
            a.get_heads(),
            b.get_heads(),
            "label add replayed identically"
        );
        assert_eq!(MailDoc::get_labels(&b, "m"), vec!["work"]);
    }

    /// Saving a draft persists it; discarding clears it — both through the action.
    #[test]
    fn save_then_discard_draft_action() {
        let mut doc = AutoCommit::new();
        let draft = Draft {
            to: "x@y.example".into(),
            subject: "Hi".into(),
            ..Default::default()
        };
        dispatch(&mut doc, &save_draft_action(&draft));
        assert_eq!(MailDoc::load_draft(&doc).to, "x@y.example");
        dispatch(&mut doc, &discard_draft_action());
        assert!(
            MailDoc::load_draft(&doc).to.is_empty(),
            "discard cleared the draft"
        );
    }

    /// The "New folder" prompted action mints an id and creates a folder in the
    /// registry.
    #[test]
    fn new_folder_action_creates_a_local_folder() {
        let (app, state) = seeded_app();
        let resources = Widget::resources(&app, &state.doc);
        let spec = resources[0]
            .actions
            .iter()
            .find(|a| a.id == "new-folder")
            .unwrap();
        let encoded = prompted_encode(spec, "Receipts");
        let mut doc = state.doc;
        let decoded = registry().decode(&encoded).unwrap();
        let mut tx = LocalTransport::new();
        qos_actions::dispatch(&mut doc, decoded.as_ref(), encoded, &mut tx).unwrap();
        let folders = MailDoc::list_folders(&doc);
        assert_eq!(folders.len(), 1, "one local folder created");
        assert_eq!(folders[0].1, "Receipts");
    }

    /// Single source of truth #1: the palette's per-message archive / read specs
    /// encode byte-identically to the builders the on-screen controls call.
    #[test]
    fn palette_and_builder_encode_identically() {
        let (app, state) = seeded_app();
        let id = app.mail_resource_ctx(&state.doc).messages[0].id.clone();
        let message = <MailApp as ResourceProvider>::resource(
            &app,
            &state.doc,
            &format!("mail.message:{id}"),
        )
        .unwrap();

        // Archive spec == move-to-Archive builder.
        let archive_spec = message.actions.iter().find(|a| a.id == "archive").unwrap();
        let from_spec = immediate_encode(archive_spec);
        let from_builder = encode(&move_action(vec![id.clone()], Folder::Archive));
        assert_eq!(from_spec.type_id, from_builder.type_id);
        assert_eq!(
            from_spec.payload, from_builder.payload,
            "archive is one source of truth"
        );

        // Read toggle spec == set-read builder for the negated current state.
        let read_spec = message.actions.iter().find(|a| a.id == "read").unwrap();
        let row_read = app
            .mail_resource_ctx(&state.doc)
            .messages
            .iter()
            .find(|m| m.id == id)
            .map(|m| m.read)
            .unwrap();
        let from_spec = immediate_encode(read_spec);
        let from_builder = encode(&set_read_action(vec![id.clone()], !row_read));
        assert_eq!(
            from_spec.payload, from_builder.payload,
            "read toggle is one source of truth"
        );

        // Add-label prompted spec == add-label builder for the same text.
        let label_spec = message
            .actions
            .iter()
            .find(|a| a.id == "add-label")
            .unwrap();
        let from_spec = prompted_encode(label_spec, "work");
        let from_builder = encode(&add_label_action(vec![id], "work"));
        assert_eq!(
            from_spec.payload, from_builder.payload,
            "add-label is one source of truth"
        );
    }

    /// Single source of truth #2: the on-screen message affordance
    /// ([`MailState::apply_message_action`]) dispatches the byte-identical action
    /// the palette's archive spec builds — proven on the real dispatch path via
    /// the framework [`ui::ActionHost`].
    #[test]
    fn affordance_dispatches_the_palette_action() {
        let mut st = MailState::new_sample(avatar_store_offline());
        let mut doc = AutoCommit::new();
        let id = an_inbox_id(&st);

        st.apply_message_action(&mut doc, id.parse().unwrap(), CtxAction::Archive);
        let dispatched = st
            .actions
            .last_dispatched()
            .expect("archive dispatched an action");
        let expected = encode(&move_action(vec![id.clone()], Folder::Archive));
        assert_eq!(dispatched.type_id, expected.type_id);
        assert_eq!(
            dispatched.payload, expected.payload,
            "the archive affordance and the palette build the identical action"
        );
        // And it really moved the message in the document.
        assert_eq!(MailDoc::get_folder_for(&doc, &id), Some(Folder::Archive));
    }

    #[test]
    fn stale_or_unknown_message_actions_fail_closed_without_orphan_flags() {
        let mut doc = AutoCommit::new();
        let action = set_read_action(vec!["not-a-loaded-message".into()], true);
        action.apply(&mut doc).unwrap();
        assert_eq!(
            MailDoc::get_read(&doc, "not-a-loaded-message"),
            None,
            "an action from a stale palette row cannot mint flags"
        );

        MailDoc::register_message(&mut doc, "gone");
        MailDoc::mark_message_purged(&mut doc, "gone");
        set_starred_action(vec!["gone".into()], true)
            .apply(&mut doc)
            .unwrap();
        assert_eq!(
            MailDoc::get_starred(&doc, "gone"),
            None,
            "an explicit tombstone refuses delayed replay"
        );
    }

    #[test]
    fn replicated_text_and_batch_deltas_are_unicode_safe_and_bounded() {
        let mut doc = AutoCommit::new();
        MailDoc::register_message(&mut doc, "m");
        let ids = std::iter::repeat_n("m".to_string(), MAX_MESSAGE_IDS_PER_ACTION + 20).collect();
        let label = format!("  {}\0ignored", "🦀".repeat(MAX_LABEL_CHARS + 4));
        MailAction::AddLabel { ids, label }.apply(&mut doc).unwrap();
        let labels = MailDoc::get_labels(&doc, "m");
        assert_eq!(labels.len(), 1, "duplicate ids are one logical target");
        assert_eq!(labels[0].chars().count(), MAX_LABEL_CHARS);
        assert!(labels[0].chars().all(|ch| !ch.is_control()));

        let draft = Draft {
            subject: "é".repeat(MAX_DRAFT_SUBJECT_CHARS + 10),
            body: format!("{}\0", "🦀".repeat(MAX_DRAFT_BODY_CHARS + 10)),
            ..Draft::default()
        };
        save_draft_action(&draft).apply(&mut doc).unwrap();
        let stored = MailDoc::load_draft(&doc);
        assert_eq!(stored.subject.chars().count(), MAX_DRAFT_SUBJECT_CHARS);
        assert_eq!(stored.body.chars().count(), MAX_DRAFT_BODY_CHARS);
        assert!(stored.body.is_char_boundary(stored.body.len()));
        assert!(!stored.body.contains('\0'));
    }

    #[test]
    fn purge_replays_to_peers_and_refuses_late_flag_resurrection() {
        let mut a = AutoCommit::new();
        MailDoc::register_message(&mut a, "m");
        MailDoc::set_folder_for(&mut a, "m", Folder::Trash);
        a.commit();
        let mut b = AutoCommit::load(&a.save()).unwrap();

        let action = purge_action(vec!["m".into()]);
        let envelope = qos_actions::apply_local(&mut a, &action, encode(&action)).unwrap();
        qos_actions::replay(&mut b, &envelope, &registry()).unwrap();
        assert_eq!(a.get_heads(), b.get_heads(), "purge is replay-identical");
        assert!(!MailDoc::is_present_message(&b, "m"));

        let late = set_read_action(vec!["m".into()], true);
        late.apply(&mut b).unwrap();
        assert_eq!(MailDoc::get_read(&b, "m"), None);
    }

    #[test]
    fn trash_resource_uses_the_same_purge_action_as_the_delete_affordance() {
        let row = MessageRow {
            id: "m".into(),
            thread_id: "m".into(),
            subject: "Already trashed".into(),
            thread_subject: "Already trashed".into(),
            folder: Folder::Trash,
            read: true,
            starred: false,
            labels: Vec::new(),
            attachments: Vec::new(),
        };
        let resource = message_resource(&row);
        let delete = resource
            .actions
            .iter()
            .find(|action| action.id == "delete")
            .expect("delete action");
        assert_eq!(delete.label, "Delete permanently");
        let encoded = immediate_encode(delete);
        let expected = encode(&purge_action(vec!["m".into()]));
        assert_eq!(encoded.type_id, expected.type_id);
        assert_eq!(encoded.payload, expected.payload);
    }
}
