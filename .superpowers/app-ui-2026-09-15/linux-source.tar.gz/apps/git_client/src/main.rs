//! Git — standard qOS application entry point.

#![allow(
    clippy::arithmetic_side_effects,
    clippy::cast_possible_truncation,
    clippy::cast_precision_loss,
    clippy::cast_sign_loss,
    clippy::cast_possible_wrap,
    reason = "app-local arithmetic"
)]
#![cfg_attr(
    test,
    allow(
        clippy::unwrap_used,
        clippy::expect_used,
        clippy::indexing_slicing,
        clippy::string_slice,
        clippy::panic,
        clippy::unreachable,
        reason = "in a test these are the assertion, not a hazard"
    )
)]

use ui::launch::{LaunchArgs, LaunchError, LaunchSpec};
use ui::widget::Widget;

const WIDE_VIEWPORT: (u32, u32) = (1280, 800);
const NARROW_VIEWPORT: (u32, u32) = (680, 860);

#[cfg(feature = "thin")]
extern crate runtime_dylib;

fn prepare_shot(narrow: bool) -> Box<dyn Widget> {
    // An explicit repository is the only way screenshots may inspect the
    // surrounding checkout; otherwise use the deterministic sample fixture.
    if std::env::var_os("GIT_CLIENT_REPO").is_none() {
        unsafe { std::env::set_var("GIT_CLIENT_SAMPLE", "1") };
    }
    if narrow {
        unsafe { std::env::set_var("GIT_CLIENT_FLAP_OPEN", "1") };
    }
    git_client::app_root()
}

#[allow(
    clippy::unnecessary_wraps,
    reason = "signature is fixed by ui::launch::ShotFactory"
)]
fn shot_root(_: &LaunchArgs) -> Result<Box<dyn Widget>, LaunchError> {
    Ok(prepare_shot(false))
}

fn command(args: &LaunchArgs) -> Result<bool, LaunchError> {
    if let Some(message) = args.value("--stage-commit") {
        stage_and_commit(message)?;
        return Ok(true);
    }
    let Some(out) = args.value("--shots-narrow") else {
        return Ok(false);
    };
    render(
        prepare_shot(true),
        NARROW_VIEWPORT,
        std::path::Path::new(out),
    );
    // Preserve the old behavior where both screenshot flags render both files.
    Ok(args.shots.is_none())
}

fn render(root: Box<dyn Widget>, viewport: (u32, u32), out: &std::path::Path) {
    let theme = match std::env::var("QOS_SHOTS_THEME").ok().as_deref() {
        Some("light") => ui::Theme::light(),
        Some("high-contrast") => ui::Theme::high_contrast(),
        _ => ui::Theme::dark(),
    };
    ui::headless::FrameHarness::new_with_theme(ui::State::new(), root, viewport, theme)
        .render_png(out);
    println!("git_client: wrote shot to {}", out.display());
}

fn stage_and_commit(message: &str) -> Result<(), LaunchError> {
    let path = std::env::var("GIT_CLIENT_REPO").map_or_else(
        |_| std::env::current_dir().unwrap_or_else(|_| ".".into()),
        std::path::PathBuf::from,
    );
    git_client::repo::stage_all(&path)
        .map_err(|error| LaunchError::Operation(format!("could not stage changes: {error}")))?;
    let id = git_client::repo::commit(&path, message)
        .map_err(|error| LaunchError::Operation(format!("could not create commit: {error}")))?;
    println!("git_client: committed {id} to {}", path.display());
    Ok(())
}

pub fn main() {
    ui::launch::run_or_exit(
        &LaunchSpec::new("dev.qos.git-client", git_client::app_root)
            .shot_root(shot_root)
            .shot_viewport(|_| WIDE_VIEWPORT)
            .allowed_live_options(&["--stage-commit", "--shots-narrow"])
            .command_handler(command)
            .configure_app(|app| git_client::actions::register(app.action_registry_mut())),
    );
}
