//! Camera — standard qOS application entry point.

#![allow(
    clippy::arithmetic_side_effects,
    clippy::cast_possible_truncation,
    clippy::cast_precision_loss,
    clippy::cast_sign_loss,
    clippy::cast_possible_wrap,
    reason = "app-local arithmetic"
)]
#![cfg_attr(
    test,
    allow(
        clippy::unwrap_used,
        clippy::expect_used,
        clippy::indexing_slicing,
        clippy::string_slice,
        clippy::panic,
        clippy::unreachable,
        reason = "in a test these are the assertion, not a hazard"
    )
)]

use ui::launch::{LaunchArgs, LaunchError, LaunchSpec};
use ui::widget::Widget;

const DEFAULT_SHOTS_VIEWPORT: (u32, u32) = (1280, 800);

#[cfg(feature = "thin")]
extern crate runtime_dylib;

fn command(args: &LaunchArgs) -> Result<bool, LaunchError> {
    let Some(dir) = args.value("--emit-photos") else {
        return Ok(false);
    };
    emit_photos(std::path::Path::new(dir)).map_err(|error| {
        LaunchError::Operation(format!("could not emit sample photos: {error}"))
    })?;
    println!("camera: wrote sample photos to {dir}");
    Ok(true)
}

#[allow(
    clippy::unnecessary_wraps,
    reason = "signature is fixed by ui::launch::ShotFactory"
)]
fn shot_root(args: &LaunchArgs) -> Result<Box<dyn Widget>, LaunchError> {
    // These variables are consumed while the widget is constructed. Startup
    // is still single-threaded here, before any camera worker exists.
    unsafe {
        for (option, variable) in [
            ("--screen", "CAMERA_SCREEN"),
            ("--dir", "CAMERA_DIR"),
            ("--scroll", "CAMERA_SCROLL"),
            ("--hover", "CAMERA_SHOT_HOVER"),
            ("--library-loading", "CAMERA_SHOT_LIBRARY_LOADING"),
        ] {
            if let Some(value) = args.value(option) {
                std::env::set_var(variable, value);
            }
        }
        if args.has("--select") {
            std::env::set_var("CAMERA_SELECT", "1");
        }
        if args.has("--scan-first") {
            std::env::set_var("CAMERA_SCAN_FIRST", "1");
        }
        if args.has("--confirm-delete") {
            std::env::set_var("CAMERA_CONFIRM_DELETE", "1");
        }
        if args.has("--library-loading") {
            std::env::set_var("CAMERA_SHOT_LIBRARY_LOADING", "1");
        }
        if let Some(state) = args.value("--camera-state") {
            std::env::set_var("CAMERA_SHOT_CAMERA_STATE", state);
        }
        // Sample timestamps and relative labels must be byte-for-byte stable
        // across offscreen renders. A caller can still override this fixed
        // fixture clock explicitly when it needs a particular reference time.
        if args.shots.is_some() && std::env::var_os("CAMERA_SHOT_NOW").is_none() {
            std::env::set_var("CAMERA_SHOT_NOW", "1800000000");
        }
    }

    let disk = args.has("--disk") || std::env::var_os("CAMERA_SHOTS_DISK").is_some();
    Ok(if disk {
        camera::app_root()
    } else {
        camera::shots_root()
    })
}

fn render_shot(args: &LaunchArgs) -> Result<(), LaunchError> {
    let out = args.shots.as_deref().ok_or(LaunchError::ShotsUnsupported)?;
    let (default_width, default_height) = args.viewport.unwrap_or(DEFAULT_SHOTS_VIEWPORT);
    let width = args
        .value("--width")
        .and_then(|value| value.parse().ok())
        .unwrap_or(default_width);
    let height = args
        .value("--height")
        .and_then(|value| value.parse().ok())
        .unwrap_or(default_height);
    let theme = match std::env::var("QOS_SHOTS_THEME").ok().as_deref() {
        Some("light") => ui::Theme::light(),
        Some("high-contrast") => ui::Theme::high_contrast(),
        _ => ui::Theme::dark(),
    }
    .with_reduce_motion(matches!(
        std::env::var("QOS_SHOTS_REDUCE_MOTION").ok().as_deref(),
        Some("1" | "true" | "yes")
    ));
    ui::headless::FrameHarness::new_with_theme(
        ui::State::new(),
        shot_root(args)?,
        (width, height),
        theme,
    )
    .render_png(out);
    println!("dev.qos.camera: wrote shot to {}", out.display());
    Ok(())
}

pub fn main() {
    ui::launch::run_or_exit(
        &LaunchSpec::new("dev.qos.camera", camera::app_root)
            .shot_handler(render_shot)
            .allowed_flags(&[
                "--select",
                "--scan-first",
                "--confirm-delete",
                "--disk",
                "--library-loading",
            ])
            .allowed_options(&[
                "--screen",
                "--dir",
                "--scroll",
                "--hover",
                "--width",
                "--height",
                "--camera-state",
            ])
            .allowed_live_options(&["--emit-photos"])
            .command_handler(command)
            .configure_app(|app| camera::actions::register(app.action_registry_mut())),
    );
}

/// Write procedural photos and a lossless QR poster for headless testing.
fn emit_photos(dir: &std::path::Path) -> Result<(), Box<dyn std::error::Error>> {
    use camera::model::PhotoFormat;
    std::fs::create_dir_all(dir)?;
    for seed in 0..5u8 {
        let frame = camera::frame::thumbnail(seed, 960, 640);
        camera::library::write_photo(dir, &frame, PhotoFormat::Jpeg)?;
        std::thread::sleep(std::time::Duration::from_millis(4));
    }
    let (qr, _) = camera::frame::scanner_frame(
        4,
        900,
        640,
        "WIFI:T:WPA2;S:qOS Lounge;P:welcome-aboard;H:false;;",
    );
    camera::library::write_photo(dir, &qr, PhotoFormat::Png)?;
    Ok(())
}
