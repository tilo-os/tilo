# Measured UI Components Implementation Plan

> **For agentic workers:** REQUIRED SUB-SKILL: Use superpowers:subagent-driven-development (recommended) or superpowers:executing-plans to implement this plan task-by-task. Steps use checkbox (`- [ ]`) syntax for tracking.

**Goal:** Repair shared sizing and interaction contracts so app authors get readable, balanced layouts with fewer manual measurements.

**Architecture:** Add one resolved-text normalization boundary while preserving existing relative APIs. Repair EmptyState, rich editor, opt-in scrolling editor fill and measured actionable Toolbar overflow. App composition migrations consume existing Card/Actions/FormPage rather than inventing another layout system.

**Tech Stack:** Rust, Taffy, cosmic-text, Vello and qOS Widget lifecycle.

**Spec:** `docs/superpowers/specs/2026-09-15-app-ui-balance.md`

## Global Constraints

- Reuse the repository Cargo target cache; do not rebuild all dependencies into a new target directory without a concrete build-isolation need. Isolate runtime captures with task-specific HOME and XDG_CONFIG_HOME/XDG_DATA_HOME/XDG_CACHE_HOME/XDG_STATE_HOME, separately from build caches.

- Prioritize ordinary100% and narrow layout as well as200% text.
- Preserve primary actions, keyboard access, state and explicit manual dimensions.
- Keep legacy renderer-relative font APIs compatible; theme-resolved fonts must scale once.
- Do not globally change primitive padding or reinterpret explicit fixed sizes.
- Preserve unrelated working changes and untracked Scratchpad ownership.
- No pushes, merges, publishing or dependency upgrades.
- Existing linked worktree /Users/xaver/dev/qos-macos-shell; sequential implementers and scoped reviews.
- Focused RED/GREEN behavior regressions before implementation; run relevant existing UI tests once before scoped commit. CARGO_BUILD_JOBS=4, CARGO_PROFILE_DEV_DEBUG=0, CARGO_PROFILE_TEST_DEBUG=0.
- Every task report includes exact commands/results, self-review, screenshot paths if requested, and remaining gaps. No subagents from implementers.

### Task 2: Rich editor measurement and scale

**Files:** `ui/src/widget/rich_text_line.rs`, `ui/src/widget/text_input.rs`, `ui/src/widget/block_editor.rs`; Scrollable fill is separately owned by Task3; do not edit it in Task2.

Confirmed double scaling: RichTextLine::build_layout at442 calls `inner.set_font_size(self.font_size * theme.text_scale)`, but TextInput::ensure_shaped_layout at1581 again computes `size * theme.text_scale`. Its comment claiming the first multiplier is needed is misleading. BlockEditor constructs RichTextLine from base `BlockKind::font_size`; list-prefix painting uses base fonts, so do not globally divide BlockEditor fonts.

- [ ] Set RichTextLine inner override to base `self.font_size`. Keep row height resolved once. Test actual shaped run font size, cursor position and selection bounds after layout+draw, not row-height-only assertions. Heading, paragraph, inline code and numbered prefix must align at1 and2. Cover scale changes on the same editor instance, undo/redo and pointer caret placement.
- [ ] Include CodeEditor/TextInput gutter number sizing in the same scale contract: corrected Typst200% capture shows oversized numbers overlapping wrapped lines. Measure number width/line height once; keep logical line numbers aligned to visual text rows, including wrapped lines, pointer caret and selection. Add regression through the existing CodeEditor wrapper.
- [ ] Audit TextInput multiline measurement: `measure` (3546) uses build_lines/content_height while draw uses shaped layout. Establish a single height basis for measured rows and the shaped draw path; add long wrapping line tests where content heights and caret line indexes agree at2.

