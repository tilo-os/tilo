# Task review package

Plan: docs/superpowers/plans/2026-09-15-measured-ui-components.md
Base: 5673a5e67
Head: cec5c10c7

## Commits

```
cec5c10c7 fix(ui): preserve intrinsic card height
```

## Files

```
 .../task-5-report.md                               |  91 +++++++
 ui/src/widget/card.rs                              |   8 +-
 ui/src/widget/card_composition.rs                  | 298 ++++++++++++++++++++-
 3 files changed, 393 insertions(+), 4 deletions(-)
```

## Diff

```diff
diff --git a/.superpowers/sdd/2026-09-15-measured-ui-components/task-5-report.md b/.superpowers/sdd/2026-09-15-measured-ui-components/task-5-report.md
new file mode 100644
index 000000000..8bc1d5e17
--- /dev/null
+++ b/.superpowers/sdd/2026-09-15-measured-ui-components/task-5-report.md
@@ -0,0 +1,91 @@
+# Task 5 report — Intrinsic card and section minimum propagation
+
+Status: **DONE_WITH_CONCERNS**. Card, ContentCard, and CardGrid now contribute their automatic block-axis minimum to intrinsic Grid rows. The Store catalogue and Settings Region dependency regressions pass, and fresh captures show the previously overlapping sections in order.
+
+## Scope and implementation
+
+- Changed `Card`, `ContentCard`, and `CardGrid` from a zero minimum height to an automatic minimum height. Each source site explains that `flex_shrink` does not protect a Grid item during Grid sizing.
+- Kept the zero minimum width that allows text and cards to wrap in narrow layouts.
+- Preserved explicit CardGrid row heights, button dimensions, flexible internal tracks, surface caps, padding, gaps, and application composition.
+- Added measured framework regressions for eight automatic cards plus a trailing action, a legacy Card with six form rows, direct narrow and nested wide section grids, 1×/2× text scale, and wide→narrow→wide relayout equivalence.
+- Did not change application source or capture routing.
+
+The task started from `5ca1d1d83`. Unrelated Chromium work advanced the shared branch through `19f65aab7`, `736da9dc7`, and `5673a5e67` while this task was in progress; those commits are outside this task's diff.
+
+## RED evidence
+
+Before changing production code:
+
+- `cargo test -p store full_narrow_catalogue_keeps_discover_section_below_ready_cards -- --nocapture` — failed: Ready-card descendants ended at y=863 while Discover began at y=576.
+- `cargo test -p settings --test it region_preview_follows_every_format_control -- --nocapture` — failed: the final field ended at y=450 while Preview began at y=436.
+- `cargo test -p ui widget::card_composition::tests::automatic_content_cards_expand_a_short_scroll_stack --lib` — failed: the first automatic card extended to y=188 while the next began at y=37.
+- `cargo test -p ui widget::card_composition::tests::automatic_legacy_card_expands_in_a_short_intrinsic_grid --lib` — failed: Preview began at y=340 before the legacy Card ended at y=355.
+- `cargo test -p ui widget::card_composition::tests::nested_card_grids_propagate_content_minimum_to_following_sections --lib` — failed after matching the Store's direct narrow topology: Discover began before the Ready cards ended.
+
+The first small nested fixture did not reproduce the contract and was replaced before implementation, as required by the brief.
+
+## GREEN and compatibility evidence
+
+Focused verification after the three automatic minimum-height changes:
+
+- `cargo test -p ui widget::card_composition::tests --lib` — 10 passed.
+- `cargo test -p ui widget::card::tests --lib` — 13 passed.
+- `cargo test -p ui widget::column::tests --lib` — 15 passed.
+- `cargo test -p ui widget::scrollable::tests --lib` — 34 passed.
+- `cargo test -p store full_narrow_catalogue_keeps_discover_section_below_ready_cards -- --nocapture` — 1 passed.
+- `cargo test -p settings --test it region_preview_follows_every_format_control -- --nocapture` — 1 passed.
+
+Existing compatibility coverage remains green:
+
+- `content_cards_keep_explicit_fixed_rows` keeps `CardGrid::with_card_height(180)` at exactly 180px with oversized prose.
+- `actions_keep_manual_sizes_and_secondary_then_primary_order` keeps authored button dimensions and action order.
+- CardGrid's legacy fixed-row tests keep explicit grid rows unchanged.
+- The new relayout test verifies 1× and 2× text, including wide→narrow→wide geometry matching a fresh wide layout.
+- The short-stack test verifies that content owns the scroll extent while the viewport stays fixed, the bottom action becomes reachable, pointer activation fires once, keyboard focus traversal reaches it, and semantic activation fires once.
+
+## Broad UI suite
+
+`CARGO_BUILD_JOBS=4 CARGO_PROFILE_DEV_DEBUG=0 CARGO_PROFILE_TEST_DEBUG=0 cargo test -p ui` was run once after focused tests:
+
+- UI library: 3,070 passed.
+- UI integration tests: 294 passed, 3 failed.
+
+The three failures and their exact observed mismatches were:
+
+1. `bound_component_dispatch::legacy_bound_mutable_admission_edits_only_its_record_and_refuses_missing_or_busy` — actual `[("bound-B", true), ("", true)]`, expected `[("bound-B", true)]`.
+2. `design_token_audit::app_and_shell_theme_escape_hatches_do_not_grow` — `shell/src/shell/frame.rs` reported `literal_color=1` and `white_or_black=2`, both with baseline 0.
+3. `typography_visual_regression::multilingual_gallery_matches_scale_matrix` — all six snapshots were taller than their baselines; examples include 1160×1073 versus 1160×824, 1450×1341 versus 1450×1030, and 1740×1788 versus 1740×1415.
+
+To establish provenance, an isolated worktree at the then-current shared HEAD was populated with the current unrelated working changes while omitting only this task's `card.rs` and `card_composition.rs` edits. Each failing test was rerun individually there and produced the same mismatch. These three failures are therefore baseline-confirmed and are not caused by this task's Card changes.
+
+## Fresh visual evidence
+
+Store and Settings were freshly built from the corrected shared source with:
+
+`CARGO_TARGET_DIR=.superpowers/app-ui-2026-09-15/task5-after-20260916/target CARGO_BUILD_JOBS=4 CARGO_PROFILE_DEV_DEBUG=0 cargo build --locked -p store -p settings`
+
+The build passed. Binary SHA-256 values were:
+
+- Store: `6c27510f98d50a00d9310097eb64342647ff3bb6a17d38051a723ab6f52bb901`
+- Settings: `080b133a34100f0d099cbc71dbaa4e13a12d90b384d4f55aebf259dc04daca86`
+
+Each app used its own isolated `XDG_CONFIG_HOME`, `XDG_DATA_HOME`, `XDG_CACHE_HOME`, and `XDG_STATE_HOME` beneath `.superpowers/app-ui-2026-09-15/task5-after-20260916/profiles/`. All capture commands exited 0. Evidence is under `.superpowers/app-ui-2026-09-15/task5-after-20260916/captures/`:
+
+- Store `wide.png` — 1200×800; the three Ready cards end before the three Discover cards.
+- Store `narrow.png` — 480×900; Terminal, Files, and VLC cards are disjoint and Discover follows below the fold.
+- Store `short.png` — 800×480; card content remains contained and the viewport owns scrolling.
+- Store `large-text.png` — 800×900 at 2× text; cards expand and remain disjoint, with lower content available by scrolling.
+- Settings `panel-region_formats.png` — 1200×760 on the truthful Region route; all six controls remain inside Formats and Preview begins below it.
+- Settings `panel-region_formats-narrow.png` — 440×820 on the truthful narrow Region route; Preview clears the final control and Shared follows below.
+- Settings `panel-region-formats-large-text.png` — 1200×760 at 2× text on the Region route; Formats expands and Preview remains below it.
+- Settings `short.png` — 800×480 on the ordinary responsive route; External Accounts is disjoint and scrollable. This is not presented as Region evidence.
+
+All eight PNGs were inspected after capture and their dimensions were verified with `file`.
+
+## Self-review and remaining concerns
+
+- The production change is limited to the diagnosed Taffy minimum-height contribution at three component boundaries. No pixel minimums or application workarounds were introduced.
+- The tests preserve the min-width-zero and fixed-size contracts while exercising both direct and nested Grid composition.
+- `FrameHarness` does not reproduce the application's host-level Enter-key fallback. The regression proves pointer activation, keyboard focus reachability, and one semantic activation; it does not directly synthesize Enter for the final action. Existing Button host behavior is unchanged.
+- The three broad-suite failures remain open in their existing owners, with isolated baseline reproduction recorded above.
+- No push or merge was performed.
diff --git a/ui/src/widget/card.rs b/ui/src/widget/card.rs
index 5783c60d2..0c0e679a6 100644
--- a/ui/src/widget/card.rs
+++ b/ui/src/widget/card.rs
@@ -168,21 +168,23 @@ impl Widget for Card {
                 // taller. Overflow is the caller's fixed-size choice, not a larger
                 // card surface or a changed row height.
                 grid_template_rows: vec![minmax(taffy::style_helpers::min_content(), fr(1.0_f32))],
                 grid_template_columns: vec![flex(1.0_f32)],
                 size: Size {
                     width: percent(1.0_f32),
                     height: taffy::Dimension::auto(),
                 },
                 min_size: Size {
                     width: length(0.0_f32),
-                    height: length(0.0_f32),
+                    // Intrinsic Grid rows need this item's automatic block minimum;
+                    // `flex_shrink` does not protect an item in Grid sizing.
+                    height: taffy::Dimension::auto(),
                 },
                 ..Default::default()
             },
             &[child],
         );
         node_map.insert(node, std::ptr::from_mut::<dyn Widget>(self));
         node
     }
 
     fn measure(
@@ -407,21 +409,23 @@ impl CardGrid {
     )]
     fn grid_style(&self) -> Style {
         Style {
             display: taffy::Display::Grid,
             size: Size {
                 width: percent(1.0_f32),
                 height: taffy::Dimension::auto(),
             },
             min_size: Size {
                 width: length(0.0_f32),
-                height: length(0.0_f32),
+                // Intrinsic Grid rows need this item's automatic block minimum;
+                // `flex_shrink` does not protect an item in Grid sizing.
+                height: taffy::Dimension::auto(),
             },
             flex_shrink: 0.0,
             align_self: Some(taffy::AlignSelf::Start),
             align_content: Some(taffy::AlignContent::Start),
             grid_template_columns: Self::column_tracks(self.min_card_w),
             grid_auto_rows: vec![
                 self.card_h
                     .map_or_else(taffy::style_helpers::min_content, |height| {
                         length(height as f32)
                     }),
diff --git a/ui/src/widget/card_composition.rs b/ui/src/widget/card_composition.rs
index 2790829cc..99520740c 100644
--- a/ui/src/widget/card_composition.rs
+++ b/ui/src/widget/card_composition.rs
@@ -111,21 +111,23 @@ impl Widget for ContentCard {
             Style {
                 display: taffy::Display::Grid,
                 grid_template_rows: tracks,
                 grid_template_columns: vec![minmax(length(0.0_f32), fr(1.0_f32))],
                 size: Size {
                     width: percent(1.0_f32),
                     height: auto(),
                 },
                 min_size: Size {
                     width: length(0.0_f32),
-                    height: length(0.0_f32),
+                    // Intrinsic Grid rows need this item's automatic block minimum;
+                    // `flex_shrink` does not protect an item in Grid sizing.
+                    height: auto(),
                 },
                 flex_shrink: 0.0,
                 padding: taffy::Rect {
                     left: length(theme.padding_standard),
                     right: length(theme.padding_standard),
                     top: length(theme.padding_standard),
                     bottom: length(theme.padding_standard),
                 },
                 gap: Size {
                     width: length(theme.gap_standard),
@@ -215,21 +217,23 @@ impl Widget for Actions {
         presence: &PresenceCtx,
     ) {
         self.parts.draw(scene, transform, text, theme, presence);
     }
 }
 
 #[cfg(test)]
 mod tests {
     use super::*;
     use crate::headless::{FrameHarness, InspectionNode};
-    use crate::widget::{Card, CardGrid};
+    use crate::widget::{Card, CardGrid, Column, Container, Scrollable};
+    use std::cell::Cell;
+    use std::rc::Rc;
 
     fn fixture() -> Element {
         Box::new(CardGrid::content_sized(vec![
             Box::new(
                 Card::composed(Box::new(Text::new("Short description")))
                     .with_title("Terminal")
                     .with_footer(Box::new(Actions::new(
                         Button::new("open", "Open", Some("opened")).primary(),
                     ))),
             ),
@@ -258,20 +262,135 @@ mod tests {
                 && child.y0 >= bounds.y0 - 1.0
                 && child.y1 <= bounds.y1 + 1.0,
             "{} {child:?} escapes {bounds:?}",
             node.widget
         );
         for descendant in &node.children {
             assert_contained(descendant, bounds);
         }
     }
 
+    fn find<'a>(node: &'a InspectionNode, id: &str) -> &'a InspectionNode {
+        if node.test_id.as_deref() == Some(id) {
+            return node;
+        }
+        node.children
+            .iter()
+            .find_map(|child| find_optional(child, id))
+            .unwrap_or_else(|| panic!("missing inspection node {id:?}"))
+    }
+
+    fn find_optional<'a>(node: &'a InspectionNode, id: &str) -> Option<&'a InspectionNode> {
+        (node.test_id.as_deref() == Some(id))
+            .then_some(node)
+            .or_else(|| {
+                node.children
+                    .iter()
+                    .find_map(|child| find_optional(child, id))
+            })
+    }
+
+    fn automatic_card(index: usize) -> Element {
+        Box::new(
+            Card::composed(Box::new(Text::new(
+                &"A useful multi-line description that must remain inside its own card. ".repeat(3),
+            )))
+            .with_header(Box::new(
+                Container::new()
+                    .with_no_padding()
+                    .with_height(40.0)
+                    .with_child(Box::new(Text::new(&format!("Application {index}")))),
+            ))
+            .with_footer(Box::new(Actions::new(Button::new(
+                &format!("details-{index}"),
+                "View details",
+                None,
+            )))),
+        )
+    }
+
+    fn standalone_stack_fixture(invocations: Rc<Cell<usize>>) -> Element {
+        let mut content = Column::new()
+            .with_no_padding()
+            .with_intrinsic_height()
+            .with_gap(8.0);
+        for index in 0..8 {
+            content = content.push(automatic_card(index));
+        }
+        content = content
+            .push(Box::new(
+                Text::new("All applications").with_id("trailing-heading"),
+            ))
+            .push(Box::new(
+                Button::new("final-action", "Open all applications", None).on_click(move || {
+                    invocations.set(invocations.get() + 1);
+                }),
+            ));
+        Box::new(Scrollable::new_vertical().with_child(Box::new(content)))
+    }
+
+    fn section_grid(prefix: &str, count: usize) -> Element {
+        Box::new(CardGrid::content_sized(
+            (0..count)
+                .map(|index| {
+                    Box::new(Card::composed(Box::new(
+                        Container::new()
+                            .with_no_padding()
+                            .with_height(72.0)
+                            .with_child(Box::new(Text::new(&format!("{prefix} card {index}")))),
+                    ))) as Element
+                })
+                .collect(),
+        ))
+    }
+
+    fn section_fixture(wide: bool) -> Element {
+        let content = if wide {
+            let ready = Column::new()
+                .with_no_padding()
+                .with_intrinsic_height()
+                .with_gap(8.0)
+                .push(Box::new(Text::new("Ready").with_id("ready-heading")))
+                .push(Box::new(Text::new("Installed applications")))
+                .push(section_grid("ready", 6));
+            let discover = Column::new()
+                .with_no_padding()
+                .with_intrinsic_height()
+                .with_gap(8.0)
+                .push(Box::new(Text::new("Discover").with_id("discover-heading")))
+                .push(Box::new(Text::new("Available applications")))
+                .push(section_grid("discover", 4));
+            Column::new()
+                .with_no_padding()
+                .with_intrinsic_height()
+                .with_gap(0.0)
+                .push(Box::new(ready))
+                .push(Box::new(
+                    Container::new().with_no_padding().with_height(16.0),
+                ))
+                .push(Box::new(discover))
+        } else {
+            Column::new()
+                .with_no_padding()
+                .with_intrinsic_height()
+                .with_gap(8.0)
+                .push(Box::new(Text::new("Ready").with_id("ready-heading")))
+                .push(section_grid("ready", 6))
+                .push(Box::new(
+                    Container::new().with_no_padding().with_height(16.0),
+                ))
+                .push(Box::new(Text::new("Discover").with_id("discover-heading")))
+                .push(section_grid("discover", 4))
+        };
+        Box::new(Scrollable::new_vertical().with_child(Box::new(content)))
+    }
+
     fn long_fixture() -> Element {
         Box::new(CardGrid::content_sized(
             (0..3)
                 .map(|index| {
                     Box::new(
                         Card::composed(Box::new(Text::new(
                             &"Manage your documents and shared workspace. ".repeat(index + 1),
                         )))
                         .with_title("Workspace connections and documents")
                         .with_footer(Box::new(
@@ -379,20 +498,195 @@ mod tests {
         let last = after.root.children[0].children.last().unwrap();
         let action = last.children[2].children.last().unwrap();
         assert!(
             rect(action).y0 >= 0.0 && rect(action).y1 <= 400.0,
             "last action {:?}",
             rect(action)
         );
         assert!((rect(last).y1 - 400.0).abs() < 1.0);
     }
 
+    #[test]
+    fn automatic_content_cards_expand_a_short_scroll_stack() {
+        let invocations = Rc::new(Cell::new(0));
+        let mut harness = FrameHarness::new_with_theme(
+            crate::State::new(),
+            standalone_stack_fixture(invocations.clone()),
+            (480, 360),
+            Theme::dark(),
+        );
+        let before = harness.inspection();
+        let content = &before.root.children[0];
+        let cards = &content.children[..8];
+        for (index, card) in cards.iter().enumerate() {
+            assert_contained(card, rect(card));
+            if let Some(next) = cards.get(index + 1) {
+                assert!(
+                    rect(next).y0 >= rect(card).y1 + 7.0,
+                    "card {index} {:?} overlaps next card {:?}",
+                    rect(card),
+                    rect(next)
+                );
+            }
+        }
+        let trailing = rect(find(&before.root, "trailing-heading"));
+        assert!(trailing.y0 >= rect(cards.last().unwrap()).y1 + 7.0);
+        assert!(
+            rect(content).height() > 360.0,
+            "content must own scroll extent"
+        );
+        assert_eq!(rect(&before.root).height(), 360.0, "viewport stays fixed");
+
+        harness.click_at(8.0, 8.0);
+        harness.scroll(0.0, -10_000.0);
+        let final_rect = rect(find(&harness.inspection().root, "final-action"));
+        assert!(
+            final_rect.y0 >= 0.0 && final_rect.y1 <= 360.0,
+            "final action must be reachable after scrolling: {final_rect:?}"
+        );
+        harness.click_named("final-action").unwrap();
+        assert_eq!(invocations.get(), 1, "pointer activation fires once");
+        assert_eq!(
+            harness
+                .tab_through()
+                .last()
+                .and_then(|(_, name)| name.as_deref()),
+            Some("Open all applications")
+        );
+        harness
+            .perform_named("final-action", &crate::a11y::Action::Activate)
+            .unwrap();
+        assert_eq!(invocations.get(), 2, "focused activation fires once");
+    }
+
+    #[test]
+    fn automatic_legacy_card_expands_in_a_short_intrinsic_grid() {
+        let mut rows = Column::new()
+            .with_no_padding()
+            .with_intrinsic_height()
+            .with_gap(12.0);
+        for index in 0..6 {
+            rows = rows.push(Box::new(
+                Container::new()
+                    .with_no_padding()
+                    .with_height(40.0)
+                    .with_child(Box::new(
+                        Text::new(&format!("Format control {index}"))
+                            .with_id(format!("format-{index}")),
+                    )),
+            ));
+        }
+        let content = Column::new()
+            .with_no_padding()
+            .with_intrinsic_height()
+            .with_gap(20.0)
+            .push(Box::new(Card::titled("Region formats", Box::new(rows))))
+            .push(Box::new(Text::new("Preview").with_id("preview-heading")));
+        let harness = FrameHarness::new(
+            crate::State::new(),
+            Box::new(Scrollable::new_vertical().with_child(Box::new(content))),
+            (480, 360),
+        );
+        let snapshot = harness.inspection();
+        let content = &snapshot.root.children[0];
+        let card = &content.children[0];
+        let last_row = rect(find(card, "format-5"));
+        let preview = rect(find(&snapshot.root, "preview-heading"));
+        assert!(
+            last_row.y1 <= rect(card).y1 + 1.0,
+            "{last_row:?} escapes {:?}",
+            rect(card)
+        );
+        assert!(
+            preview.y0 >= rect(card).y1 + 19.0,
+            "preview {preview:?} overlaps legacy card {:?}",
+            rect(card)
+        );
+        assert!(rect(content).height() > 360.0);
+        assert_eq!(rect(&snapshot.root).height(), 360.0);
+    }
+
+    #[test]
+    fn nested_card_grids_propagate_content_minimum_to_following_sections() {
+        for (wide, viewport) in [(false, (480, 360)), (true, (1000, 360))] {
+            let harness = FrameHarness::new_with_theme(
+                crate::State::new(),
+                section_fixture(wide),
+                viewport,
+                Theme::dark(),
+            );
+            let snapshot = harness.inspection();
+            let content = &snapshot.root.children[0];
+            let (ready_grid, discover_grid) = if wide {
+                (
+                    content.children[0].children.last().unwrap(),
+                    content.children[2].children.last().unwrap(),
+                )
+            } else {
+                (&content.children[1], &content.children[4])
+            };
+            let ready_last_bottom = ready_grid
+                .children
+                .iter()
+                .map(|card| rect(card).y1)
+                .fold(f64::NEG_INFINITY, f64::max);
+            let discover_last_bottom = discover_grid
+                .children
+                .iter()
+                .map(|card| rect(card).y1)
+                .fold(f64::NEG_INFINITY, f64::max);
+            assert!(ready_last_bottom <= rect(ready_grid).y1 + 1.0);
+            assert!(discover_last_bottom <= rect(discover_grid).y1 + 1.0);
+            assert!(
+                rect(find(content, "discover-heading")).y0 >= ready_last_bottom + 15.0,
+                "{viewport:?}: discover section begins before ready cards end"
+            );
+            assert!(
+                rect(&snapshot.root.children[0]).height() > f64::from(viewport.1),
+                "{viewport:?}: section content must exceed the fixed viewport"
+            );
+        }
+    }
+
+    #[test]
+    fn short_card_stack_resize_and_text_scale_match_fresh_geometry() {
+        fn geometry(node: &InspectionNode) -> Vec<[f64; 4]> {
+            let mut all = vec![node.rect];
+            for child in &node.children {
+                all.extend(geometry(child));
+            }
+            all
+        }
+
+        for scale in [1.0, 2.0] {
+            let theme = Theme::dark().with_text_scale(scale);
+            let mut resized = FrameHarness::new_with_theme(
+                crate::State::new(),
+                section_fixture(true),
+                (1000, 360),
+                theme.clone(),
+            );
+            resized.resize((480, 360)).unwrap();
+            resized.resize((1000, 360)).unwrap();
+            let fresh = FrameHarness::new_with_theme(
+                crate::State::new(),
+                section_fixture(true),
+                (1000, 360),
+                theme,
+            );
+            assert_eq!(
+                geometry(&resized.inspection().root),
+                geometry(&fresh.inspection().root)
+            );
+        }
+    }
+
     #[test]
     fn actions_keep_manual_sizes_and_secondary_then_primary_order() {
         let actions = Actions::new(Button::new("primary", "Primary", None).with_size(97.0, 35.0))
             .secondary(Button::new("secondary", "Secondary", None).fit_content(33.0));
         let harness = FrameHarness::new_with_theme(
             crate::State::new(),
             Box::new(actions),
             (600, 80),
             Theme::dark().with_text_scale(2.0),
         );
```
