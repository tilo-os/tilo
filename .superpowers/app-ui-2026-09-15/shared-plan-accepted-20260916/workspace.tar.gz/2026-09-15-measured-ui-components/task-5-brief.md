# Measured UI Components Implementation Plan

> **For agentic workers:** REQUIRED SUB-SKILL: Use superpowers:subagent-driven-development (recommended) or superpowers:executing-plans to implement this plan task-by-task. Steps use checkbox (`- [ ]`) syntax for tracking.

**Goal:** Repair shared sizing and interaction contracts so app authors get readable, balanced layouts with fewer manual measurements.

**Architecture:** Add one resolved-text normalization boundary while preserving existing relative APIs. Repair EmptyState, rich editor, opt-in scrolling editor fill and measured actionable Toolbar overflow. App composition migrations consume existing Card/Actions/FormPage rather than inventing another layout system.

**Tech Stack:** Rust, Taffy, cosmic-text, Vello and qOS Widget lifecycle.

**Spec:** `docs/superpowers/specs/2026-09-15-app-ui-balance.md`

## Global Constraints

- Reuse the repository Cargo target cache; do not rebuild all dependencies into a new target directory without a concrete build-isolation need. Isolate runtime captures with task-specific HOME and XDG_CONFIG_HOME/XDG_DATA_HOME/XDG_CACHE_HOME/XDG_STATE_HOME, separately from build caches.

- Prioritize ordinary100% and narrow layout as well as200% text.
- Preserve primary actions, keyboard access, state and explicit manual dimensions.
- Keep legacy renderer-relative font APIs compatible; theme-resolved fonts must scale once.
- Do not globally change primitive padding or reinterpret explicit fixed sizes.
- Preserve unrelated working changes and untracked Scratchpad ownership.
- No pushes, merges, publishing or dependency upgrades.
- Existing linked worktree /Users/xaver/dev/qos-macos-shell; sequential implementers and scoped reviews.
- Focused RED/GREEN behavior regressions before implementation; run relevant existing UI tests once before scoped commit. CARGO_BUILD_JOBS=4, CARGO_PROFILE_DEV_DEBUG=0, CARGO_PROFILE_TEST_DEBUG=0.
- Every task report includes exact commands/results, self-review, screenshot paths if requested, and remaining gaps. No subagents from implementers.

### Task 5: Intrinsic card and section minimum propagation

**Execution order ruling:** Run before Tasks1–4, immediately after App Composition Task3 has saved its independent app edits. Fresh visual review exposed this missing dependency; App Task3 acceptance waits for this shared fix.

**Files:** `ui/src/widget/card.rs`, `ui/src/widget/card_composition.rs`, focused framework/harness tests. Inspect but preserve unrelated `column.rs` formatting. Do not change application files in this task.

**Diagnosis:** Read `.superpowers/app-ui-2026-09-15/intrinsic-card-diagnosis.md`. This is a source-backed hypothesis, not verified implementation. Card, ContentCard and CardGrid explicitly set min-height zero; enclosing intrinsic Column uses automatic Grid rows, which can allocate less than content in a definite short viewport. Current Store narrow capture has Discover more overlapping Files despite individual card containment. Do not compensate with app pixel heights.

- [ ] First reproduce RED with actual measured layout in a short definite Scrollable: intrinsic Column containing at least eight standalone ContentCards and trailing action; repeat legacy Card containing six form rows. Assert each surface contains descendants, following siblings clear previous content plus requested gap, and content exceeds fixed viewport. Test geometry before paint.
- [ ] Add nested section regression: Ready heading, content-sized CardGrid of six cards, spacer, Discover heading, second grid. Cover one-column narrow and nested multi-column wide paths, each grid allocated bottom beyond last card bottom, following section below preceding content. Small fixture under MaxContent does not establish this contract.
- [ ] First candidate restore automatic minimum height on Card, ContentCard and CardGrid while retaining min-width zero for wrapping. Keep internal min-content/flexible tracks, fixed row lengths, default Column fill/flex contracts, surface caps, padding and gap behavior unless a failing test proves another change necessary. If candidate fails, inspect first broken node's min-size, allocation and content contribution rather than layering speculative styles.
- [ ] Verify authored `CardGrid::with_card_height(180)` stays exact with oversized prose, existing fixed buttons remain exact, legacy fixed grid rows remain unchanged. Do not replace automatic minima with unconditional measured pixel minimums. Long automatic content must scroll; viewport/header do not grow.
- [ ] Verify 1×/2× and wide→narrow→wide produce same geometry as fresh layout, bottom action remains reachable by scrolling, pointer and keyboard invokes it exactly once. Run relevant Card, CardGrid, ContentCard, intrinsic Column and scroll regressions; broad UI suite once after focused passes.
- [ ] Build Store/Settings with corrected shared source and capture narrow/short/wide and scaled routes using isolated profiles. In full catalogue, Discover starts below all installed cards; in Region, Preview starts below final control. No application workarounds or capture-path changes in this shared commit. Coordinate exact route fixtures from App Task3 report.

**Report:** `.superpowers/sdd/2026-09-15-measured-ui-components/task-5-report.md`; include RED/GREEN evidence, candidate result, fixed/manual compatibility, capture provenance and remaining limitations. Scoped commit, no subagents or pushes.

