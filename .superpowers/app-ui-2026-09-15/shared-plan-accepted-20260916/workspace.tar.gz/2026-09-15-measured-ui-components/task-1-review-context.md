# Controller rulings for Task 1 review

- Public helper fully resolved size+letter spacing. Legacy Text letter spacing stays renderer-relative.
- Tiny-pane contract approved: measured retained auto height/min-height100%, explicit into_scrollable route; icon then message may shed, but title/action remain essential. Immediate paint exposes minimum essential height; wholly offscreen action must not be reported as visible target. No global Scrollable behavior change.
- Scope extends to ui/src/app/card_composition_tests.rs for real host keyboard regression using existing private activation fallback. Semantic Activate alone was insufficient; host regression now present.
- Root independently inspected all three VPN PNGs: empty state centered and bounded; top Tor capsule at2x remains a separate app Task22 issue.
- Baseline __eh_frame linker warning and concurrent dirty Chromium test failure are outside scope; do not require unrelated cleanup. No broad-suite rerun requested.
- Original dispatch BASE7231a8170, effective review base12c7cc90c verified external-only browser/guided-setup/shared-runtime changes; package contains exactly Task1 commit. Root FORM_COMPOSITION.md dirty doc is outside Task1.

Review spec and quality against brief/report/diff. Do not broaden into other apps, existing scroll behavior, or unrelated concurrent files. Read-only except your review report. No subagents. No repeated broad tests; a concrete code doubt permits one focused check.
