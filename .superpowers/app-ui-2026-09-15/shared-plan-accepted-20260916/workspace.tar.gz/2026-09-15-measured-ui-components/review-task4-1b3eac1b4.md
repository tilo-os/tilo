# Review package: d02c1ade3..1b3eac1b4

## Commits
1b3eac1b4 Fix measured toolbar layout and reachable command overflow

## Files changed
 .../task-4-report.md                               |   94 ++
 ui/src/widget/context_menu.rs                      |  350 +++-
 ui/src/widget/toolbar.rs                           | 1728 ++++++++++++++------
 3 files changed, 1690 insertions(+), 482 deletions(-)

## Diff
diff --git a/.superpowers/sdd/2026-09-15-measured-ui-components/task-4-report.md b/.superpowers/sdd/2026-09-15-measured-ui-components/task-4-report.md
new file mode 100644
index 000000000..47edd9aca
--- /dev/null
+++ b/.superpowers/sdd/2026-09-15-measured-ui-components/task-4-report.md
@@ -0,0 +1,94 @@
+# Shared Task 4 — measured Toolbar and reachable overflow
+
+## Scope and source
+
+- Verified starting HEAD `fba9ea50f`; worked in the existing `codex/macos-shell` checkout. Concurrent docs/other work continued; no unrelated source was edited or staged.
+- Owned production files: `ui/src/widget/toolbar.rs`, `ui/src/widget/context_menu.rs`. No Widget trait changes, dependency changes, pushes, merges, or app migrations.
+- Used the supplied brief/preflight and executing-plans, test-driven-development, verification-before-completion workflow. No worker subagents.
+
+## Implementation
+
+Toolbar now caches resolved theme typography, padding, target size and actual renderer-measured item/chip extents. Intrinsic measurement, final fitting and placement share that cache. Renderer input normalization applies theme text scale once. The final lifecycle ignores the public compatibility estimate from `recompute_visible`; narrow allocations remain authoritative and clip glyph paint. Hidden item rectangles are zero, spacers share residual space, and decoration-only suffixes never create overflow.
+
+The owned ContextMenu maps action rows back to original ToolbarItem indices and drains selection exactly once into the original FnMut. Separators are trimmed/collapsed, spacers omitted. The opt-in anchored menu route measures labels/row heights, clamps to viewport, clips paint, scrolls on wheel, adjusts hit testing for scroll, and scrolls keyboard/accessibility focus into view. Existing `open_at` point placement/fixed geometry is retained and covered.
+
+Toolbar remains the retained host focus owner. It handles orientation arrows, Enter/Space, internal menu focus, Escape return, pointer/modal capture and focus trapping. Pointer presses survive unchanged layout passes. Synthetic accessibility supplies named buttons/menu commands, stable original-index action routes, expanded/focus state, and clipped painted row bounds. Resize reconciles hidden indices and preserves a still-hidden focused command; eliminating overflow closes the menu and chooses a reachable focus target.
+
+## RED / GREEN evidence
+
+All Cargo commands used the repository target cache and:
+
+```sh
+CARGO_BUILD_JOBS=4 CARGO_PROFILE_DEV_DEBUG=0 CARGO_PROFILE_TEST_DEBUG=0
+```
+
+1. `cargo test -p ui --lib widget::toolbar::tests -- --nocapture`
+   - Initial test helper compile error (`Size::MAX_CONTENT` trait not imported) corrected before behavioral RED.
+   - RED: 4 passed, 2 failed as expected: equal heuristic widths for `WWW`/`iii`, and Toolbar not focusable.
+   - First GREEN: 6 passed.
+2. `cargo test -p ui --lib widget::toolbar::lifecycle_tests -- --nocapture`
+   - Corrected the new host test helper to rebuild `BoundNodeMap` admission; an empty map intentionally suppresses callbacks.
+   - Behavioral RED after helper correction: 5 passed, 2 failed (initial focus incorrectly last; press lost across layout).
+   - Fixed focus initialization and preserved reachable hover/press targets across layout.
+3. Final `cargo test -p ui --lib widget::toolbar -- --nocapture`: **15 passed, 1 manual GPU fixture ignored**.
+4. `cargo test -p ui --lib widget::context_menu -- --nocapture`: **13 passed**.
+5. `cargo test -p ui --lib context_menu -- --nocapture`: **15 passed**, including existing TextInput copy/cut menu routing.
+6. `cargo test -p ui --lib widget::layout -- --nocapture`: **7 passed**, shared host solver/admission/focus tests.
+7. `cargo test -p ui --test it context_menu -- --nocapture`: **1 passed**, existing legacy integration test.
+8. `cargo check -p ui --lib`: **passed**.
+9. `rustfmt --edition 2024 --check ui/src/widget/toolbar.rs ui/src/widget/context_menu.rs`: **passed**.
+10. `git diff --check -- ui/src/widget/toolbar.rs ui/src/widget/context_menu.rs`: **passed**.
+
+The focused cases include Unicode/Arabic/CJK/combining/emoji labels, long translations, `WWW` versus `iii`, both orientations, exact/under/tiny allocations, 1×/2× resolved themes, resize while open, all original callbacks once through pointer/keyboard/accessibility, clipped accessibility geometry, focus return, outside-dismiss click suppression, meaningful separators, wheel limits and offset-aware hit testing.
+
+The macOS lib-test link emitted the existing `__eh_frame section too large (max 16MB)` warning; all reported test/check exits were successful. The first RED invocation briefly waited for an unrelated shared build lock; no separate target cache was created.
+
+## Rendered evidence and provenance
+
+Manual fixture `widget::toolbar::lifecycle_tests::rendered_toolbar_overflow_fixtures` was executed separately using the compiled library test binary, `--ignored --nocapture`, and existing `crate::offscreen::OffscreenRenderer`. It uses the real build → admitted shared solver → apply → draw → keyboard menu navigation → draw_overlay path. Last hidden command activation is asserted once after each capture. Result: **1 passed**.
+
+Runtime isolation:
+
+```text
+HOME=/tmp/qos-task4-runtime/home
+XDG_CONFIG_HOME=/tmp/qos-task4-runtime/config
+XDG_DATA_HOME=/tmp/qos-task4-runtime/data
+XDG_CACHE_HOME=/tmp/qos-task4-runtime/cache
+XDG_STATE_HOME=/tmp/qos-task4-runtime/state
+QUICK_UI_SCREENSHOT_DIR=/Users/xaver/dev/qos-macos-shell/.superpowers/sdd/2026-09-15-measured-ui-components/task-4-captures
+```
+
+Command (environment above):
+
+```sh
+/Users/xaver/dev/qos-macos-shell/target/debug/deps/ui-98aece3f3d10fdcd widget::toolbar::lifecycle_tests::rendered_toolbar_overflow_fixtures --ignored --nocapture
+```
+
+- `task-4-captures/toolbar-ordinary-100.png`: 720×340 viewport, 530px Toolbar, `Theme::dark().with_text_scale(1.0)`, matching renderer scale. Popup below the chip; labels and selected final command fit.
+- `task-4-captures/toolbar-narrow-200.png`: 320×260 viewport, 290px Toolbar, `Theme::dark().with_text_scale(2.0)`, matching renderer scale. Menu fills available height, is scrolled to the final command, and stays within viewport. Selected final command is fully readable.
+- Worker opened and inspected both images. Controller separately inspected both and confirmed the visual fixture gate passes pending independent code review.
+- Captures remain retained in the task evidence directory; they are not app screenshots or live macOS window/focus proof.
+
+SHA-256 at validation/capture:
+
+```text
+ff901324b3fb50e313dfe58495b34277d13147f40e71930814ed32dc97f5fd72  ui/src/widget/toolbar.rs
+b9b87e5052b19b95137fc0cdfadbd982730c44164685e50a3f730696cbaa5e36  ui/src/widget/context_menu.rs
+6fbcc5817a1453721d2075b15492d1e7598f79920c3cdde6b596539f8b547dcd  target/debug/deps/ui-98aece3f3d10fdcd
+29808354e98a80611d1b941d6411bfae0071c85acfd9998096a4483e28cd43ac  task-4-captures/toolbar-ordinary-100.png
+3c5bb675d1396823df5a286288b9ea3a9caa29772a8e60450fa5be8f22229b68  task-4-captures/toolbar-narrow-200.png
+```
+
+## Self-review and limits
+
+- Confirmed only the existing ContextMenu paints/handles the popup; Toolbar owns neither a new overlay stack nor copied callbacks.
+- Confirmed `Widget` remains unchanged and existing ContextMenu/TextInput route tests pass.
+- Confirmed actual shared host admission/settlement is exercised, not just manually seeded geometry.
+- Confirmed explicit narrow allocations and menu viewport containment with ordinary and 200% rendered evidence.
+- App-specific consumer migrations and live OS focus/assistive-technology acceptance are outside this shared-widget task. No full workspace suite, app startup, or end-user app screenshot claims are made.
+- `open_anchored` is an owned-menu route; callers should run `layout_within` before paint (Toolbar does this in normal draw, then uses the same geometry in overlay/input). Existing retained legacy ContextMenu sizing remains unchanged.
+- No known blocking issue remains from scoped tests/self-review. Independent controller code review remains the next gate.
+
+## Commit discipline
+
+Commit only `ui/src/widget/toolbar.rs`, `ui/src/widget/context_menu.rs`, and this report with `git commit --only`. Verify the resulting commit file list; preserve all unrelated working-tree and index content. The returned task status records the resulting commit ID.
diff --git a/ui/src/widget/context_menu.rs b/ui/src/widget/context_menu.rs
index 0675df1c2..641a7e550 100644
--- a/ui/src/widget/context_menu.rs
+++ b/ui/src/widget/context_menu.rs
@@ -1,28 +1,28 @@
 //! `ContextMenu` primitive — a right-click / long-press invoked list of
-//! actions with optional separators, backed visually by `overlay::Popover`
-//! so it participates in the overlay stack, scrim dismissal, and focus
-//! contract.
+//! actions with optional separators. Standalone owners draw it in their
+//! overlay pass. `open_anchored` opts into measured, viewport-bounded geometry;
+//! legacy `open_at` callers retain their point placement and fixed rows.
 //!
 //! Callers push `MenuItem::action(label, fn)` and optional
 //! `MenuItem::separator()` entries, then call `open_at` on right-click.
 
 use automerge::{AutoCommit, ObjId};
 use std::sync::Arc;
 use taffy::{Dimension, NodeId, Size, Style, TaffyTree};
 use vello::Scene;
 use vello::kurbo::{Affine, Point, Rect, RoundedRect, Stroke, Vec2};
-use winit::event::{ElementState, KeyEvent, MouseButton, WindowEvent};
+use winit::event::{ElementState, KeyEvent, MouseButton, MouseScrollDelta, WindowEvent};
 use winit::keyboard::{Key, NamedKey};
 
 use crate::presence::PresenceCtx;
-use crate::text_render::TextRenderer;
+use crate::text_render::{TextRenderer, TextStyle};
 use crate::theme::Theme;
 use crate::widget::TaffyTreeExt;
 use crate::widget::Widget;
 
 pub type MenuAction = Arc<dyn Fn() + Send + Sync>;
 
 /// Separators are purely visual and ignored by [`ContextMenu::click_item`].
 #[derive(Clone)]
 pub enum MenuItem {
     Action { label: String, action: MenuAction },
@@ -75,66 +75,215 @@ pub struct ContextMenu {
     /// `MouseInput` carries no position, so this is tracked from
     /// `CursorMoved` to map a press to a row.
     last_cursor: Point,
     /// Set by `handle_event`, drained by [`ContextMenu::take_selection`].
     /// The `&mut self` + CRDT-friendly action channel: instead of forcing
     /// every menu action through an `Arc<dyn Fn()>` (which can't splice
     /// into an Automerge doc the host owns), the host polls
     /// `take_selection()` after dispatching the event and mutates itself.
     /// The legacy `Arc` callback still fires too.
     selection: Option<usize>,
+    bounds: Option<(Rect, Rect)>,
+    row_height: f64,
+    measured_width: f64,
+    scroll_offset: f64,
 }
 
 impl Default for ContextMenu {
     fn default() -> Self {
         Self::new()
     }
 }
 
 impl ContextMenu {
     pub fn new() -> Self {
         Self {
             items: Vec::new(),
             open: false,
             position: None,
             rect: Rect::ZERO,
             hovered: None,
             last_cursor: Point::ZERO,
             selection: None,
+            bounds: None,
+            row_height: ROW_HEIGHT,
+            measured_width: MENU_WIDTH,
+            scroll_offset: 0.0,
         }
     }
 
     pub fn push(&mut self, item: MenuItem) {
         self.items.push(item);
     }
 
     pub fn items(&self) -> &[MenuItem] {
         &self.items
     }
 
     /// Also computes `rect` immediately (via
     /// [`layout_at_position`](Self::layout_at_position)) so
     /// [`item_at`](Self::item_at) / [`contains`](Self::contains) are usable
     /// without first running a `draw`/`apply_layout` pass — needed by
     /// consumers (like `TextInput`) that route a click to a row in the same
     /// input batch the menu opened in.
     pub fn open_at(&mut self, position: [f32; 2]) {
+        self.bounds = None;
+        self.scroll_offset = 0.0;
         self.open = true;
         self.position = Some(position);
         self.layout_at_position();
     }
 
+    /// Open a shared menu inside a host viewport. Geometry is immediately usable;
+    /// call `layout_within` with the renderer before painting to settle text metrics.
+    pub fn open_anchored(&mut self, anchor: Rect, viewport: Rect) {
+        self.open = true;
+        self.hovered = None;
+        self.scroll_offset = 0.0;
+        self.reanchor(anchor, viewport);
+    }
+
+    pub fn reanchor(&mut self, anchor: Rect, viewport: Rect) {
+        self.bounds = Some((anchor, viewport));
+        self.layout_at_position();
+    }
+
+    pub fn layout_within(&mut self, text: &mut TextRenderer, theme: &Theme) {
+        let style = text.renderer_input_style(&TextStyle::new(theme.tokens.typography.scale.sm));
+        let mut width: f64 = 0.0;
+        let mut height: f64 = 0.0;
+        for item in &self.items {
+            if let Some(label) = item.label() {
+                let (w, h) = text.measure_style(label, None, &style);
+                width = width.max(f64::from(w));
+                height = height.max(f64::from(h));
+            }
+        }
+        self.measured_width = width + 20.0;
+        self.row_height = (height + 12.0).max(ROW_HEIGHT);
+        self.layout_at_position();
+        self.ensure_hover_visible();
+    }
+
+    fn row_height(&self, item: &MenuItem) -> f64 {
+        if self.bounds.is_some() && matches!(item, MenuItem::Action { .. }) {
+            self.row_height
+        } else {
+            item_height(item)
+        }
+    }
+
+    fn content_height(&self) -> f64 {
+        self.items.iter().map(|item| self.row_height(item)).sum()
+    }
+
+    fn body_rect(&self) -> Rect {
+        let inset = if self.bounds.is_some() {
+            PADDING.min(self.rect.height() / 4.0)
+        } else {
+            PADDING
+        };
+        Rect::new(
+            self.rect.x0,
+            self.rect.y0 + inset,
+            self.rect.x1,
+            self.rect.y1 - inset,
+        )
+    }
+
+    fn max_scroll(&self) -> f64 {
+        (self.content_height() - self.body_rect().height()).max(0.0)
+    }
+
+    /// Painted (clipped) geometry of an action row, in host coordinates.
+    pub fn item_rect(&self, index: usize) -> Option<Rect> {
+        if !self.open || !matches!(self.items.get(index), Some(MenuItem::Action { .. })) {
+            return None;
+        }
+        let body = self.body_rect();
+        let top = body.y0 - self.scroll_offset
+            + self
+                .items
+                .iter()
+                .take(index)
+                .map(|item| self.row_height(item))
+                .sum::<f64>();
+        let rect = Rect::new(
+            body.x0,
+            top,
+            body.x1,
+            top + self.row_height(self.items.get(index)?),
+        )
+        .intersect(body);
+        (!rect.is_zero_area()).then_some(rect)
+    }
+
+    pub fn focus_item(&mut self, index: usize) -> bool {
+        if !matches!(self.items.get(index), Some(MenuItem::Action { .. })) {
+            return false;
+        }
+        self.hovered = Some(index);
+        self.ensure_hover_visible();
+        true
+    }
+
+    pub fn focus_first_action(&mut self) {
+        self.hovered = None;
+        self.move_hover(1);
+    }
+
+    fn ensure_hover_visible(&mut self) {
+        if self.bounds.is_none() {
+            return;
+        }
+        if let Some(index) = self.hovered {
+            let top = self
+                .items
+                .iter()
+                .take(index)
+                .map(|item| self.row_height(item))
+                .sum::<f64>();
+            let height = self
+                .items
+                .get(index)
+                .map_or(0.0, |item| self.row_height(item));
+            let body_height = self.body_rect().height();
+            if top < self.scroll_offset {
+                self.scroll_offset = top;
+            } else if top + height > self.scroll_offset + body_height {
+                self.scroll_offset = top + height.min(body_height) - body_height;
+            }
+        }
+        self.scroll_offset = self.scroll_offset.clamp(0.0, self.max_scroll());
+    }
+
     /// Mirrors the `build_layout` + `apply_layout` geometry without a taffy
     /// round-trip. A no-op when the menu has never been positioned. Lets a
     /// standalone consumer (one that owns a `ContextMenu` as a field rather
     /// than a tree node) hit-test and draw the menu directly.
     pub fn layout_at_position(&mut self) {
+        if let Some((anchor, viewport)) = self.bounds {
+            let width = self.measured_width.min(viewport.width().max(0.0));
+            let height = (self.content_height() + PADDING * 2.0).min(viewport.height().max(0.0));
+            let x = anchor
+                .x0
+                .clamp(viewport.x0, (viewport.x1 - width).max(viewport.x0));
+            let preferred_y = if anchor.y1 + height <= viewport.y1 {
+                anchor.y1
+            } else {
+                anchor.y0 - height
+            };
+            let y = preferred_y.clamp(viewport.y0, (viewport.y1 - height).max(viewport.y0));
+            self.rect = Rect::new(x, y, x + width, y + height);
+            self.scroll_offset = self.scroll_offset.clamp(0.0, self.max_scroll());
+            return;
+        }
         let Some([px, py]) = self.position else {
             return;
         };
         let height = PADDING * 2.0
             + self
                 .items
                 .iter()
                 .map(item_height)
                 .sum::<f64>()
                 .max(ROW_HEIGHT);
@@ -157,31 +306,25 @@ impl ContextMenu {
     pub fn position(&self) -> Option<[f32; 2]> {
         self.position
     }
 
     /// Lets a consumer route a left-click to
     /// [`click_item`](Self::click_item) without re-deriving the row layout.
     pub fn item_at(&self, point: [f64; 2]) -> Option<usize> {
         if !self.open {
             return None;
         }
-        let [px, py] = point;
-        if px < self.rect.x0 || px > self.rect.x1 || py < self.rect.y0 || py > self.rect.y1 {
-            return None;
-        }
-        let mut y = self.rect.y0 + PADDING;
-        for (idx, item) in self.items.iter().enumerate() {
-            let h = item_height(item);
-            if matches!(item, MenuItem::Action { .. }) && py >= y && py < y + h {
+        let point = Point::new(point[0], point[1]);
+        for idx in 0..self.items.len() {
+            if self.item_rect(idx).is_some_and(|rect| rect.contains(point)) {
                 return Some(idx);
             }
-            y += h;
         }
         None
     }
 
     /// For dismiss-on-click-outside routing.
     pub fn contains(&self, point: [f64; 2]) -> bool {
         self.open
             && self
                 .rect
                 .contains(vello::kurbo::Point::new(point[0], point[1]))
@@ -227,20 +370,21 @@ impl ContextMenu {
         // and entering from below at the last; otherwise step off the row we
         // are on. Either way the walk then visits at most `n` candidates.
         let mut idx = match self.hovered {
             Some(i) => wrapping_step(i, n, down),
             None if down => 0,
             None => n.saturating_sub(1),
         };
         for _ in 0..n {
             if matches!(self.items.get(idx), Some(MenuItem::Action { .. })) {
                 self.hovered = Some(idx);
+                self.ensure_hover_visible();
                 return;
             }
             idx = wrapping_step(idx, n, down);
         }
     }
 }
 
 /// One step through `n` items, wrapping past either end. Kept in `usize`
 /// so a menu index can never go negative or wrap through a cast.
 fn wrapping_step(i: usize, n: usize, down: bool) -> usize {
@@ -296,20 +440,24 @@ impl Widget for ContextMenu {
                 width: Dimension::length(MENU_WIDTH as f32),
                 height: Dimension::length(height as f32),
             },
             ..Default::default()
         });
         node_map.insert(node, std::ptr::from_mut::<dyn Widget>(self));
         node
     }
 
     fn apply_layout(&mut self, taffy: &TaffyTree<()>, node: NodeId, origin: Point) {
+        if self.bounds.is_some() {
+            self.layout_at_position();
+            return;
+        }
         // The caller-provided anchor wins when open; otherwise the
         // taffy-assigned position keeps offscreen/closed menus sensible.
         let l = taffy.layout(node).copied().unwrap_or_default();
         let (x0, y0) = if let (true, Some([px, py])) = (self.open, self.position) {
             (f64::from(px), f64::from(py))
         } else {
             (
                 origin.x + f64::from(l.location.x),
                 origin.y + f64::from(l.location.y),
             )
@@ -327,90 +475,115 @@ impl Widget for ContextMenu {
         scene: &mut Scene,
         transform: Affine,
         text_renderer: &mut TextRenderer,
         theme: &Theme,
         _presence: &PresenceCtx,
     ) {
         if !self.open {
             return;
         }
 
+        if self.bounds.is_some() {
+            self.layout_within(text_renderer, theme);
+        }
         let shape = RoundedRect::from_rect(self.rect, f64::from(theme.tokens.radii.md));
         // The near-black overlay tier, so the menu reads as an opaque
         // raised sheet, never bleeding the content beneath.
         scene.fill(
             vello::peniko::Fill::NonZero,
             transform,
             theme.tokens.colors.surfaces.overlay,
             None,
             &shape,
         );
         scene.stroke(
             &Stroke::new(1.0),
             transform,
             theme.tokens.colors.border_standard,
             None,
             &shape,
         );
 
         let text_size = theme.tokens.typography.scale.sm;
-        let mut y = self.rect.y0 + PADDING;
+        let style = text_renderer.renderer_input_style(&TextStyle::new(text_size));
+        scene.push_layer(
+            vello::peniko::Fill::NonZero,
+            vello::peniko::BlendMode::default(),
+            1.0,
+            transform,
+            &self.body_rect(),
+        );
+        let mut y = self.body_rect().y0 - self.scroll_offset;
         for (idx, item) in self.items.iter().enumerate() {
+            let row_height = self.row_height(item);
             match item {
                 MenuItem::Action { label, .. } => {
                     if self.hovered == Some(idx) {
                         let hl = Rect::new(
                             self.rect.x0 + 4.0,
                             y + 1.0,
                             self.rect.x1 - 4.0,
-                            y + ROW_HEIGHT - 1.0,
+                            y + row_height - 1.0,
                         );
                         let hl_shape = RoundedRect::from_rect(hl, f64::from(theme.tokens.radii.sm));
                         // Matches the dropdown / autocomplete row hover.
                         scene.fill(
                             vello::peniko::Fill::NonZero,
                             transform,
                             theme.tokens.colors.surface_white_10,
                             None,
                             &hl_shape,
                         );
                     }
-                    let label_y = y + (ROW_HEIGHT - f64::from(text_size)) / 2.0;
-                    text_renderer.draw_text(
-                        scene,
-                        label,
-                        text_size,
-                        theme.tokens.colors.text_primary,
-                        transform.pre_translate(Vec2::new(self.rect.x0 + 10.0, label_y)),
-                        None,
-                    );
-                    y += ROW_HEIGHT;
+                    let (_, label_height) = text_renderer.measure_style(label, None, &style);
+                    let label_y = y + (row_height - f64::from(label_height)) / 2.0;
+                    if self.bounds.is_some() {
+                        text_renderer.draw_style(
+                            scene,
+                            label,
+                            theme.tokens.colors.text_primary,
+                            transform.pre_translate(Vec2::new(self.rect.x0 + 10.0, label_y)),
+                            None,
+                            &style,
+                        );
+                    } else {
+                        text_renderer.draw_text(
+                            scene,
+                            label,
+                            text_size,
+                            theme.tokens.colors.text_primary,
+                            transform.pre_translate(Vec2::new(self.rect.x0 + 10.0, label_y)),
+                            None,
+                        );
+                    }
+                    y += row_height;
                 }
                 MenuItem::Separator => {
                     let sep_y = y + SEPARATOR_HEIGHT / 2.0;
                     let line = Rect::new(
                         self.rect.x0 + 8.0,
                         sep_y - 0.5,
                         self.rect.x1 - 8.0,
                         sep_y + 0.5,
                     );
                     scene.fill(
                         vello::peniko::Fill::NonZero,
                         transform,
                         theme.tokens.colors.border_standard,
                         None,
                         &line,
                     );
                     y += SEPARATOR_HEIGHT;
                 }
             }
         }
+        scene.pop_layer();
     }
 
     fn handle_event(
         &mut self,
         event: &WindowEvent,
         scale_factor: f64,
         _modifiers: &winit::event::Modifiers,
         _state: &mut AutoCommit,
         _path: &ObjId,
         handled: &mut bool,
@@ -450,20 +623,29 @@ impl Widget for ContextMenu {
                     *handled = true;
                 }
                 Key::Named(NamedKey::Enter) => {
                     if let Some(idx) = self.hovered {
                         self.click_item(idx);
                     }
                     *handled = true;
                 }
                 _ => {}
             },
+            WindowEvent::MouseWheel { delta, .. } if self.bounds.is_some() => {
+                let delta = match delta {
+                    MouseScrollDelta::LineDelta(_, y) => f64::from(*y) * self.row_height,
+                    MouseScrollDelta::PixelDelta(p) => p.y / scale_factor,
+                };
+                self.scroll_offset = (self.scroll_offset - delta).clamp(0.0, self.max_scroll());
+                self.hovered = self.item_at([self.last_cursor.x, self.last_cursor.y]);
+                *handled = true;
+            }
             WindowEvent::MouseInput {
                 state: ElementState::Pressed,
                 button: MouseButton::Left,
                 ..
             } => {
                 if let Some(idx) = self.item_at([self.last_cursor.x, self.last_cursor.y]) {
                     self.click_item(idx);
                     *handled = true;
                 } else {
                     // An open menu is modal-ish: swallow the dismiss click
@@ -750,21 +932,137 @@ mod tests {
         let r = m.get_rect();
         let row0_y = r.y0 + PADDING + ROW_HEIGHT / 2.0;
         dispatch(&mut m, &cursor_at(Point::new(r.x0 + 10.0, row0_y)));
         assert_eq!(m.hovered(), Some(0), "cursor over row 0 highlights it");
         // Move onto the separator → no hover.
         let sep_y = r.y0 + PADDING + ROW_HEIGHT + SEPARATOR_HEIGHT / 2.0;
         dispatch(&mut m, &cursor_at(Point::new(r.x0 + 10.0, sep_y)));
         assert_eq!(m.hovered(), None, "cursor over a separator clears hover");
     }
 
+    #[test]
+    fn bounded_wheel_hit_testing_and_keyboard_activation_share_scroll_offset() {
+        let mut menu = ContextMenu::new();
+        for index in 0..20 {
+            menu.push(MenuItem::action(format!("Command {index}"), || {}));
+        }
+        menu.open_anchored(
+            Rect::new(10.0, 10.0, 30.0, 30.0),
+            Rect::new(0.0, 0.0, 180.0, 100.0),
+        );
+        menu.layout_within(&mut TextRenderer::new(), &Theme::dark());
+        let point = menu.get_rect().center();
+        dispatch(&mut menu, &cursor_at(point));
+        let wheel = |y| WindowEvent::MouseWheel {
+            device_id: synth_device(),
+            delta: MouseScrollDelta::LineDelta(0.0, y),
+            phase: winit::event::TouchPhase::Moved,
+        };
+        assert!(dispatch(&mut menu, &wheel(-100.0)));
+        assert_eq!(menu.scroll_offset, menu.max_scroll());
+        let last = menu.item_rect(19).unwrap().center();
+        assert_eq!(menu.item_at([last.x, last.y]), Some(19));
+        dispatch(&mut menu, &cursor_at(last));
+        dispatch(&mut menu, &left_press());
+        assert_eq!(menu.take_selection(), Some(19));
+        assert_eq!(menu.take_selection(), None);
+        menu.open_anchored(Rect::ZERO, Rect::new(0.0, 0.0, 180.0, 100.0));
+        menu.focus_first_action();
+        for _ in 0..19 {
+            dispatch(&mut menu, &key(NamedKey::ArrowDown));
+        }
+        assert_eq!(menu.hovered(), Some(19));
+        assert!(menu.item_rect(19).is_some());
+        dispatch(&mut menu, &key(NamedKey::Enter));
+        assert_eq!(menu.take_selection(), Some(19));
+        menu.open_anchored(Rect::ZERO, Rect::new(0.0, 0.0, 180.0, 100.0));
+        dispatch(&mut menu, &wheel(100.0));
+        assert_eq!(menu.scroll_offset, 0.0);
+    }
+
     #[test]
     fn modal_capture_when_open() {
         let (m, _f) = open_menu();
         assert!(
             Widget::modal_capture(&m).is_some(),
             "open menu reports capture"
         );
         let closed = ContextMenu::new();
         assert!(Widget::modal_capture(&closed).is_none());
     }
 }
+
+#[cfg(test)]
+mod bounded_tests {
+    use super::*;
+
+    #[test]
+    fn bounded_menu_measures_scales_and_clamps_at_all_edges() {
+        let viewport = Rect::new(10.0, 20.0, 110.0, 95.0);
+        for anchor in [
+            Rect::new(10.0, 20.0, 30.0, 40.0),
+            Rect::new(90.0, 20.0, 110.0, 40.0),
+            Rect::new(10.0, 75.0, 30.0, 95.0),
+            Rect::new(90.0, 75.0, 110.0, 95.0),
+        ] {
+            let mut menu = ContextMenu::new();
+            for _ in 0..8 {
+                menu.push(MenuItem::action(
+                    "Sehr lange übersetzte Aktion 共有 العربية",
+                    || {},
+                ));
+            }
+            menu.open_anchored(anchor, viewport);
+            let mut text = TextRenderer::new();
+            text.set_text_scale(2.0);
+            menu.layout_within(&mut text, &Theme::dark().with_text_scale(2.0));
+            assert_eq!(menu.get_rect().intersect(viewport), menu.get_rect());
+            assert!(menu.row_height > ROW_HEIGHT);
+            menu.focus_item(7);
+            assert!(menu.scroll_offset > 0.0);
+            let last = menu.item_rect(7).unwrap();
+            assert_eq!(menu.item_at([last.center().x, last.center().y]), Some(7));
+            assert!(menu.item_rect(0).is_none());
+            menu.move_hover(1);
+            assert_eq!(menu.hovered(), Some(0));
+            assert_eq!(menu.scroll_offset, 0.0);
+        }
+    }
+    #[test]
+    fn width_uses_shaping_and_legacy_open_resets_bounded_geometry() {
+        let mut narrow = ContextMenu::new();
+        narrow.push(MenuItem::action("iii", || {}));
+        let mut wide = ContextMenu::new();
+        wide.push(MenuItem::action("WWW", || {}));
+        let mut text = TextRenderer::new();
+        for menu in [&mut narrow, &mut wide] {
+            menu.open_anchored(Rect::ZERO, Rect::new(0.0, 0.0, 1000.0, 1000.0));
+            menu.layout_within(&mut text, &Theme::dark());
+        }
+        assert!(wide.get_rect().width() > narrow.get_rect().width());
+        wide.open_at([900.0, 950.0]);
+        assert_eq!(
+            wide.get_rect(),
+            Rect::new(
+                900.0,
+                950.0,
+                900.0 + MENU_WIDTH,
+                950.0 + ROW_HEIGHT + 2.0 * PADDING
+            )
+        );
+        assert_eq!(wide.scroll_offset, 0.0);
+    }
+    #[test]
+    fn tiny_viewport_keeps_focused_rows_reachable() {
+        let mut menu = ContextMenu::new();
+        menu.push(MenuItem::action("First", || {}));
+        menu.push(MenuItem::separator());
+        menu.push(MenuItem::action("Last", || {}));
+        let viewport = Rect::new(0.0, 0.0, 4.0, 4.0);
+        menu.open_anchored(viewport, viewport);
+        menu.layout_within(&mut TextRenderer::new(), &Theme::dark());
+        menu.focus_item(2);
+        assert_eq!(menu.get_rect(), viewport);
+        let last = menu.item_rect(2).unwrap();
+        assert_eq!(menu.item_at([last.center().x, last.center().y]), Some(2));
+    }
+}
diff --git a/ui/src/widget/toolbar.rs b/ui/src/widget/toolbar.rs
index aab2ad83f..51f2e8064 100644
--- a/ui/src/widget/toolbar.rs
+++ b/ui/src/widget/toolbar.rs
@@ -1,660 +1,1002 @@
-//! Toolbar widget — a horizontal or vertical strip of buttons, separators
-//! and greedy spacers, with overflow collapse into a `…` chip when the
-//! computed item extent exceeds the toolbar's rect along its orientation
-//! axis.
-//!
-//! Owns its layout end-to-end rather than delegating child sizing to Taffy:
-//! `build_layout` measures each item (GPU-free `TextRenderer`-style
-//! approximations) and writes the visible-count + overflow flag
-//! `apply_layout` places rects from. Spacers soak the residual axis space;
-//! the overflow chip always wins a trailing slot once visibility drops
-//! below the item count. See `tabs.rs` for the strip-of-rects precedent.
-
+//! A measured command strip with a shared ContextMenu for overflow.
+//! The extent cache is the sole source for intrinsic sizing, fitting and placement.
 use automerge::{AutoCommit, ObjId};
 use std::collections::HashMap;
 use taffy::{Dimension, NodeId, Size, Style, TaffyTree};
 use vello::Scene;
-use vello::kurbo::{Affine, Point, Rect, RoundedRect};
+use vello::kurbo::{Affine, Point, Rect, RoundedRect, Stroke};
 use winit::event::{ElementState, MouseButton, WindowEvent};
+use winit::keyboard::{Key, NamedKey};
 
+use super::context_menu::{ContextMenu, MenuItem};
+use crate::a11y::{AccessNode, AccessState, Action, Role};
 use crate::presence::PresenceCtx;
-use crate::text_render::TextRenderer;
+use crate::text_render::{TextRenderer, TextStyle};
 use crate::theme::Theme;
-use crate::widget::TaffyTreeExt;
-use crate::widget::Widget;
-
-/// Approximate per-character width used by `build_layout` to size button
-/// labels without invoking `TextRenderer`. Matches `tabs.rs::apply_layout`'s
-/// heuristic so a Toolbar reads at the same density as a `TabBar` beside it.
-const APPROX_CHAR_W: f64 = 7.0;
-
-/// Width (Horizontal) or height (Vertical) of a Separator line. Always
-/// 1 logical pixel — a thinner divider reads as a hairline, a thicker
-/// one starts to look like a rule.
-const SEPARATOR_LINE_PX: f64 = 1.0;
-
-/// Width of the overflow `…` chip on the trailing edge of an overflowing
-/// toolbar. Sized to comfortably fit the three-dot glyph plus padding;
-/// chosen to roughly match a one-character button so the chip doesn't
-/// dominate the visible items it's replacing.
-const OVERFLOW_CHIP_AXIS_PX: f64 = 24.0;
+use crate::widget::{TaffyTreeExt, Widget};
 
 #[derive(Clone, Copy, PartialEq, Eq, Debug)]
 pub enum Orientation {
     Horizontal,
     Vertical,
 }
 
 pub enum ToolbarItem {
     Button {
         label: String,
         on_click: Box<dyn FnMut()>,
     },
     Separator,
     Spacer,
 }
 
+#[derive(Clone, Copy, PartialEq, Eq, Debug)]
+enum Target {
+    Item(usize),
+    Overflow,
+}
+
 pub struct Toolbar {
     items: Vec<ToolbarItem>,
     orientation: Orientation,
-    overflow_open: bool,
     rect: Rect,
     item_rects: Vec<Rect>,
     visible_count: usize,
-    /// Per-item hover flag, populated by `handle_event`. Aligned 1:1 with
-    /// `items`. Kept independent of `visible_count` so a hover that
-    /// happened pre-overflow doesn't latch on after the items collapse.
-    item_hover: Vec<bool>,
-    /// True while the pointer is over the overflow chip. Drives the
-    /// chip's hover background like a regular button. Painted only when
-    /// `has_overflow()` is true.
-    overflow_hover: bool,
-    /// Cached overflow-chip hit rect (only meaningful when
-    /// `has_overflow()` is true). Populated alongside `item_rects` in
-    /// `apply_layout` so `handle_event` can hit-test without re-deriving
-    /// the chip's position.
+    extents: Vec<Size<f32>>,
+    chip_extent: Size<f32>,
+    intrinsic: Size<f32>,
+    font: TextStyle,
+    padding: f32,
+    minimum: f32,
+    separator: f32,
     overflow_rect: Rect,
+    hovered: Option<Target>,
+    pressed: Option<Target>,
+    focused: bool,
+    focus: Option<Target>,
+    menu: ContextMenu,
+    menu_indices: Vec<Option<usize>>,
+    viewport: Option<Rect>,
+    swallow_release: bool,
 }
 
 impl Toolbar {
     pub fn new(orientation: Orientation) -> Self {
         Self {
             items: Vec::new(),
             orientation,
-            overflow_open: false,
             rect: Rect::ZERO,
             item_rects: Vec::new(),
             visible_count: 0,
-            item_hover: Vec::new(),
-            overflow_hover: false,
+            extents: Vec::new(),
+            chip_extent: Size::ZERO,
+            intrinsic: Size::ZERO,
+            font: TextStyle::new(14.0),
+            padding: 8.0,
+            minimum: 32.0,
+            separator: 9.0,
             overflow_rect: Rect::ZERO,
+            hovered: None,
+            pressed: None,
+            focused: false,
+            focus: None,
+            menu: ContextMenu::new(),
+            menu_indices: Vec::new(),
+            viewport: None,
+            swallow_release: false,
         }
     }
 
     #[must_use]
     pub fn push_button(mut self, label: &str, on_click: impl FnMut() + 'static) -> Self {
         self.items.push(ToolbarItem::Button {
             label: label.to_string(),
             on_click: Box::new(on_click),
         });
-        self.item_hover.push(false);
         self
     }
-
     #[must_use]
     pub fn push_separator(mut self) -> Self {
         self.items.push(ToolbarItem::Separator);
-        self.item_hover.push(false);
         self
     }
-
     #[must_use]
     pub fn push_spacer(mut self) -> Self {
         self.items.push(ToolbarItem::Spacer);
-        self.item_hover.push(false);
         self
     }
 
-    /// True if the toolbar's computed item extent exceeded its rect's
-    /// extent along the orientation axis on the last layout pass. While
-    /// true, items past `visible_count` are collapsed into a single
-    /// overflow chip on the trailing edge.
     pub fn has_overflow(&self) -> bool {
-        self.visible_count < self.items.len()
+        self.items
+            .iter()
+            .skip(self.visible_count)
+            .any(|item| matches!(item, ToolbarItem::Button { .. }))
     }
-
-    /// Number of items currently rendered as their own rect (i.e. *not*
-    /// folded into the overflow chip). Always `<= items.len()`. When
-    /// `has_overflow()` is true this is strictly less.
     pub fn visible_count(&self) -> usize {
         self.visible_count
     }
-
-    /// Number of `ToolbarItem::Separator` entries in the toolbar. Cheap
-    /// accessor for the divider-paint test — keeps the test stable
-    /// against future scene-encoding refactors that might shuffle which
-    /// primitive emits the divider stroke.
     pub fn separator_count(&self) -> usize {
         self.items
             .iter()
-            .filter(|i| matches!(i, ToolbarItem::Separator))
+            .filter(|item| matches!(item, ToolbarItem::Separator))
             .count()
     }
-
-    /// Axis extent one item occupies: a button's label plus padding, a
-    /// separator's hairline plus its surrounding air, and zero for a
-    /// spacer (which is sized from the residual, not measured).
-    fn measure_item_axis(&self, item: &ToolbarItem, theme: &Theme) -> f64 {
-        match item {
-            ToolbarItem::Spacer => 0.0,
-            ToolbarItem::Separator => SEPARATOR_LINE_PX + 2.0 * f64::from(theme.tokens.spacing.s2),
-            ToolbarItem::Button { label, .. } => {
-                let pad = 2.0 * f64::from(theme.tokens.spacing.s3);
-                let text_axis = match self.orientation {
-                    Orientation::Horizontal => count_to_f64(label.chars().count()) * APPROX_CHAR_W,
-                    Orientation::Vertical => f64::from(theme.tokens.typography.scale.sm),
-                };
-                (text_axis + pad).max(f64::from(theme.tokens.spacing.s8))
-            }
-        }
+    pub fn is_overflow_open(&self) -> bool {
+        self.menu.is_open()
     }
 
-    /// Decide how many leading items fit inside `axis_extent`, writing
-    /// [`Self::visible_count`] (and therefore [`Self::has_overflow`]).
-    ///
-    /// Greedy from the leading edge: take items while they fit. The moment
-    /// one doesn't, the trailing edge has to give up
-    /// [`OVERFLOW_CHIP_AXIS_PX`] to the `…` chip, so the fit is re-checked
-    /// against the smaller budget — otherwise the last item admitted would
-    /// sit underneath the chip. Spacers measure zero and are always
-    /// admitted; they soak the residual in `apply_layout`.
+    /// Compatibility estimate for callers without a renderer. Real lifecycle layout
+    /// always replaces this decision with the measured extent cache.
     pub fn recompute_visible(&mut self, axis_extent: f64, theme: &Theme) {
-        if self.items.is_empty() {
-            self.visible_count = 0;
-            return;
-        }
-        let extents: Vec<f64> = self
+        let mut used = 0.0;
+        let axes: Vec<f64> = self
             .items
             .iter()
-            .map(|it| self.measure_item_axis(it, theme))
+            .map(|item| match item {
+                ToolbarItem::Spacer => 0.0,
+                ToolbarItem::Separator => f64::from(1.0 + 2.0 * theme.tokens.spacing.s2),
+                ToolbarItem::Button { label, .. } => {
+                    let text = match self.orientation {
+                        Orientation::Horizontal => count_to_f64(label.chars().count()) * 7.0,
+                        Orientation::Vertical => f64::from(theme.tokens.typography.scale.sm),
+                    };
+                    (text + 2.0 * f64::from(theme.tokens.spacing.s3))
+                        .max(f64::from(theme.tokens.spacing.s8))
+                }
+            })
             .collect();
-        let total: f64 = extents.iter().sum();
-        if total <= axis_extent {
-            self.visible_count = self.items.len();
-            return;
-        }
-        let budget = (axis_extent - OVERFLOW_CHIP_AXIS_PX).max(0.0);
-        let mut used = 0.0;
-        let mut n = 0usize;
-        for e in &extents {
-            if used + e > budget {
-                break;
-            }
-            used += e;
-            n = n.saturating_add(1);
-        }
-        // Collapsing everything leaves a toolbar that is only a `…` chip —
-        // honest for a genuinely tiny strip, but never collapse when the
-        // items would have fit without the chip's own reservation.
-        self.visible_count = n.min(self.items.len().saturating_sub(1));
+        let budget = if axes.iter().sum::<f64>() <= axis_extent {
+            axis_extent
+        } else {
+            (axis_extent - 24.0).max(0.0)
+        };
+        self.visible_count = axes
+            .iter()
+            .take_while(|axis| {
+                used += **axis;
+                used <= budget
+            })
+            .count();
     }
 
-    /// True while the overflow popover is open. (The popover itself is
-    /// not painted by this widget — `WindowGroup`-style hosts paint it
-    /// in a later pass.)
-    pub fn is_overflow_open(&self) -> bool {
-        self.overflow_open
+    fn axis(&self, size: Size<f32>) -> f64 {
+        f64::from(match self.orientation {
+            Orientation::Horizontal => size.width,
+            Orientation::Vertical => size.height,
+        })
     }
 
-    /// `build_layout` only has the theme (not the final width);
-    /// `apply_layout` has the post-taffy width, so the overflow fit is
-    /// decided here, using the same approximate, theme-free extents as
-    /// [`Self::place_visible_items`] below so the two agree. Split out of
-    /// `apply_layout` to keep it under clippy's line budget.
-    fn decide_visible_count(&self, axis_total: f64) -> usize {
-        let item_axis = |it: &ToolbarItem| -> f64 {
-            match it {
-                ToolbarItem::Spacer => 0.0,
-                ToolbarItem::Separator => SEPARATOR_LINE_PX + 8.0,
-                ToolbarItem::Button { label, .. } => {
-                    let text_axis = match self.orientation {
-                        Orientation::Horizontal => {
-                            count_to_f64(label.chars().count()) * APPROX_CHAR_W
-                        }
-                        Orientation::Vertical => 16.0,
-                    };
-                    (text_axis + 16.0).max(32.0)
-                }
+    fn update_measurements(&mut self, text: &mut TextRenderer) -> bool {
+        let style = text.renderer_input_style(&self.font);
+        let button = |label: &str, text: &mut TextRenderer| {
+            let (width, height) = text.measure_style(label, None, &style);
+            Size {
+                width: (width + self.padding * 2.0).max(self.minimum),
+                height: (height + self.padding * 2.0).max(self.minimum),
             }
         };
-        let total_extent: f64 = self.items.iter().map(&item_axis).sum();
-        if total_extent <= axis_total {
-            return self.items.len();
-        }
-        let budget = (axis_total - OVERFLOW_CHIP_AXIS_PX).max(0.0);
-        let mut acc = 0.0;
-        let mut fit = 0usize;
-        for it in &self.items {
-            let e = item_axis(it);
-            if acc + e > budget {
-                break;
-            }
-            acc += e;
-            fit = fit.saturating_add(1);
-        }
-        fit
-    }
-
-    /// Per-item axis extent for the first `n_visible` items, plus how many
-    /// of them are spacers — the two inputs [`Self::place_visible_items`]
-    /// needs to turn a visible-count decision into rects. Split out of
-    /// `place_visible_items` to keep it under clippy's line budget.
-    fn measure_visible_axes(&self, n_visible: usize) -> (Vec<f64>, usize) {
-        let mut measured_axes = vec![0.0_f64; n_visible];
-        let mut spacer_count = 0usize;
-        for (i, it) in self.items.iter().take(n_visible).enumerate() {
-            match it {
-                ToolbarItem::Spacer => {
-                    spacer_count = spacer_count.saturating_add(1);
-                }
-                ToolbarItem::Separator => {
-                    if let Some(slot) = measured_axes.get_mut(i) {
-                        *slot = SEPARATOR_LINE_PX + 8.0;
-                    }
-                }
-                ToolbarItem::Button { label, .. } => {
-                    let pad = 16.0;
-                    let text_axis = match self.orientation {
-                        Orientation::Horizontal => {
-                            count_to_f64(label.chars().count()) * APPROX_CHAR_W
-                        }
-                        Orientation::Vertical => 16.0,
-                    };
-                    if let Some(slot) = measured_axes.get_mut(i) {
-                        *slot = (text_axis + pad).max(32.0);
-                    }
-                }
-            }
+        let chip = button("…", text);
+        let extents: Vec<_> = self
+            .items
+            .iter()
+            .map(|item| match item {
+                ToolbarItem::Button { label, .. } => button(label, text),
+                ToolbarItem::Spacer => Size::ZERO,
+                ToolbarItem::Separator => match self.orientation {
+                    Orientation::Horizontal => Size {
+                        width: self.separator,
+                        height: self.minimum,
+                    },
+                    Orientation::Vertical => Size {
+                        width: self.minimum,
+                        height: self.separator,
+                    },
+                },
+            })
+            .collect();
+        let changed = extents != self.extents || chip != self.chip_extent;
+        self.extents = extents;
+        self.chip_extent = chip;
+        self.intrinsic =
+            self.extents
+                .iter()
+                .fold(Size::ZERO, |size, item| match self.orientation {
+                    Orientation::Horizontal => Size {
+                        width: size.width + item.width,
+                        height: size.height.max(item.height),
+                    },
+                    Orientation::Vertical => Size {
+                        width: size.width.max(item.width),
+                        height: size.height + item.height,
+                    },
+                });
+        changed
+    }
+
+    fn fit(&self, budget: f64) -> usize {
+        let mut used = 0.0;
+        self.extents
+            .iter()
+            .take_while(|size| {
+                used += self.axis(**size);
+                used <= budget
+            })
+            .count()
+    }
+
+    fn place(&mut self) {
+        let axis_total = match self.orientation {
+            Orientation::Horizontal => self.rect.width(),
+            Orientation::Vertical => self.rect.height(),
+        }
+        .max(0.0);
+        self.visible_count = self.fit(axis_total);
+        if self.has_overflow() {
+            self.visible_count = self.fit((axis_total - self.axis(self.chip_extent)).max(0.0));
         }
-        (measured_axes, spacer_count)
-    }
-
-    /// Places `item_rects` (and the overflow chip rect) for the
-    /// `self.visible_count` decided by [`Self::decide_visible_count`].
-    /// `apply_layout` has no `Theme`, so extents are recomputed here with
-    /// the same hardcoded constants as `decide_visible_count` rather than
-    /// calling `measure_item_axis` — approximate, but deterministic and
-    /// consistent with the overflow decision just made. Split out of
-    /// `apply_layout` to keep it under clippy's line budget.
-    fn place_visible_items(&mut self, axis_total: f64) {
-        let n_visible = self.visible_count.min(self.items.len());
-        let overflow = self.has_overflow();
-
-        let (measured_axes, spacer_count) = self.measure_visible_axes(n_visible);
-        let used: f64 = measured_axes.iter().sum();
-        let chip_reserve = if overflow { OVERFLOW_CHIP_AXIS_PX } else { 0.0 };
-        let residual = (axis_total - used - chip_reserve).max(0.0);
-        let per_spacer = if spacer_count > 0 {
-            residual / count_to_f64(spacer_count)
+        let chip = if self.has_overflow() {
+            self.axis(self.chip_extent).min(axis_total)
         } else {
             0.0
         };
-
-        let cross_start = match self.orientation {
-            Orientation::Horizontal => self.rect.y0,
-            Orientation::Vertical => self.rect.x0,
-        };
-        let cross_end = match self.orientation {
-            Orientation::Horizontal => self.rect.y1,
-            Orientation::Vertical => self.rect.x1,
+        let used: f64 = self
+            .extents
+            .iter()
+            .take(self.visible_count)
+            .map(|size| self.axis(*size))
+            .sum();
+        let spacers = self
+            .items
+            .iter()
+            .take(self.visible_count)
+            .filter(|item| matches!(item, ToolbarItem::Spacer))
+            .count();
+        let spacer = if spacers == 0 {
+            0.0
+        } else {
+            (axis_total - used - chip).max(0.0) / count_to_f64(spacers)
         };
-
-        let mut axis_cursor = match self.orientation {
+        self.item_rects = vec![Rect::ZERO; self.items.len()];
+        let mut cursor = match self.orientation {
             Orientation::Horizontal => self.rect.x0,
             Orientation::Vertical => self.rect.y0,
         };
-
-        for (i, item) in self.items.iter().take(n_visible).enumerate() {
+        for (index, item) in self.items.iter().take(self.visible_count).enumerate() {
             let extent = if matches!(item, ToolbarItem::Spacer) {
-                per_spacer
+                spacer
             } else {
-                measured_axes.get(i).copied().unwrap_or(0.0)
+                self.extents.get(index).map_or(0.0, |size| self.axis(*size))
             };
-            let r = match self.orientation {
+            let rect = match self.orientation {
                 Orientation::Horizontal => {
-                    Rect::new(axis_cursor, cross_start, axis_cursor + extent, cross_end)
+                    Rect::new(cursor, self.rect.y0, cursor + extent, self.rect.y1)
                 }
                 Orientation::Vertical => {
-                    Rect::new(cross_start, axis_cursor, cross_end, axis_cursor + extent)
+                    Rect::new(self.rect.x0, cursor, self.rect.x1, cursor + extent)
                 }
             };
-            if let Some(slot) = self.item_rects.get_mut(i) {
-                *slot = r;
+            if let Some(slot) = self.item_rects.get_mut(index) {
+                *slot = rect;
             }
-            axis_cursor += extent;
+            cursor += extent;
         }
-        // Items beyond `visible_count` keep `Rect::ZERO`: not rendered as
-        // their own rect, and any hover targeting them is silently
-        // dropped on the next `handle_event` (CursorMoved reads
-        // `item_rects`).
-        for r in self.item_rects.iter_mut().skip(n_visible) {
-            *r = Rect::ZERO;
-        }
-
-        if overflow {
-            self.overflow_rect = match self.orientation {
+        self.overflow_rect = if self.has_overflow() {
+            match self.orientation {
                 Orientation::Horizontal => Rect::new(
-                    self.rect.x1 - OVERFLOW_CHIP_AXIS_PX,
-                    cross_start,
+                    self.rect.x1 - chip,
+                    self.rect.y0,
                     self.rect.x1,
-                    cross_end,
+                    self.rect.y1,
                 ),
                 Orientation::Vertical => Rect::new(
-                    cross_start,
-                    self.rect.y1 - OVERFLOW_CHIP_AXIS_PX,
-                    cross_end,
+                    self.rect.x0,
+                    self.rect.y1 - chip,
+                    self.rect.x1,
                     self.rect.y1,
                 ),
-            };
+            }
         } else {
-            self.overflow_rect = Rect::ZERO;
+            Rect::ZERO
+        };
+        self.reconcile_menu();
+        let targets = self.targets();
+        if self.focus.is_some_and(|target| !targets.contains(&target)) {
+            self.focus = targets.last().copied();
         }
+        self.hovered = self.hovered.filter(|target| targets.contains(target));
+        self.pressed = self.pressed.filter(|target| targets.contains(target));
     }
-}
 
-/// Composes a paint transform with a translation. `Affine`'s `Mul` impl is
-/// pure `f64` matrix multiply-add with no overflow trap, so it cannot
-/// panic regardless of operand magnitude.
-#[allow(
-    clippy::arithmetic_side_effects,
-    reason = "Affine composition is float matrix math and cannot panic"
-)]
-fn translated(transform: Affine, x: f64, y: f64) -> Affine {
-    transform * Affine::translate((x, y))
+    fn reconcile_menu(&mut self) {
+        let mut indices = Vec::new();
+        let mut separator = false;
+        for (index, item) in self.items.iter().enumerate().skip(self.visible_count) {
+            match item {
+                ToolbarItem::Button { .. } => {
+                    if separator && !indices.is_empty() {
+                        indices.push(None);
+                    }
+                    indices.push(Some(index));
+                    separator = false;
+                }
+                ToolbarItem::Separator => separator = true,
+                ToolbarItem::Spacer => {}
+            }
+        }
+        if indices != self.menu_indices {
+            let open = self.menu.is_open();
+            let focused_index = self
+                .menu
+                .hovered()
+                .and_then(|row| self.menu_indices.get(row).copied().flatten());
+            self.menu = ContextMenu::new();
+            for index in &indices {
+                self.menu
+                    .push(match index.and_then(|index| self.items.get(index)) {
+                        Some(ToolbarItem::Button { label, .. }) => {
+                            MenuItem::action(label.clone(), || {})
+                        }
+                        _ => MenuItem::separator(),
+                    });
+            }
+            self.menu_indices = indices;
+            if open && self.has_overflow() {
+                self.open_menu(true);
+                if let Some(row) = self
+                    .menu_indices
+                    .iter()
+                    .position(|index| *index == focused_index)
+                {
+                    self.menu.focus_item(row);
+                }
+            }
+        }
+        if !self.has_overflow() {
+            self.menu.close();
+        }
+        if let Some(viewport) = self.viewport {
+            self.menu.reanchor(self.overflow_rect, viewport);
+        }
+    }
+
+    fn open_menu(&mut self, keyboard: bool) {
+        if !self.has_overflow() {
+            return;
+        }
+        self.menu
+            .open_anchored(self.overflow_rect, self.viewport.unwrap_or(self.rect));
+        self.focus = Some(Target::Overflow);
+        if keyboard {
+            self.menu.focus_first_action();
+        }
+    }
+    fn invoke(&mut self, index: usize) {
+        if let Some(ToolbarItem::Button { on_click, .. }) = self.items.get_mut(index) {
+            on_click();
+        }
+    }
+    fn drain_menu(&mut self) {
+        if let Some(index) = self
+            .menu
+            .take_selection()
+            .and_then(|row| self.menu_indices.get(row).copied().flatten())
+        {
+            self.invoke(index);
+        }
+        if !self.menu.is_open() {
+            self.focus = Some(Target::Overflow);
+        }
+    }
+    fn targets(&self) -> Vec<Target> {
+        let mut targets: Vec<_> = self
+            .items
+            .iter()
+            .enumerate()
+            .take(self.visible_count)
+            .filter_map(|(index, item)| {
+                matches!(item, ToolbarItem::Button { .. }).then_some(Target::Item(index))
+            })
+            .collect();
+        if self.has_overflow() {
+            targets.push(Target::Overflow);
+        }
+        targets
+    }
+    fn target_rect(&self, target: Target) -> Option<Rect> {
+        match target {
+            Target::Item(index) => self.item_rects.get(index).copied(),
+            Target::Overflow => Some(self.overflow_rect),
+        }
+    }
+    fn activate(&mut self, target: Target) {
+        match target {
+            Target::Item(index) => self.invoke(index),
+            Target::Overflow => self.open_menu(true),
+        }
+    }
+    fn move_focus(&mut self, forward: bool) {
+        let targets = self.targets();
+        if targets.is_empty() {
+            return;
+        }
+        let index = self
+            .focus
+            .and_then(|focus| targets.iter().position(|target| *target == focus));
+        let next = match index {
+            None => 0,
+            Some(index) if forward => index.saturating_add(1) % targets.len(),
+            Some(index) => index
+                .checked_sub(1)
+                .unwrap_or_else(|| targets.len().saturating_sub(1)),
+        };
+        self.focus = targets.get(next).copied();
+    }
+    fn semantic_target(&self, path: &[usize]) -> Option<Target> {
+        let targets = self.targets();
+        match path {
+            [child] => targets.get(*child).copied(),
+            [menu, child] if self.menu.is_open() && *menu == targets.len() => self
+                .menu_indices
+                .iter()
+                .flatten()
+                .nth(*child)
+                .map(|index| Target::Item(*index)),
+            _ => None,
+        }
+    }
+    fn focus_target(&mut self, target: Target) {
+        self.focused = true;
+        match target {
+            Target::Item(index) if index >= self.visible_count => {
+                self.open_menu(true);
+                if let Some(row) = self
+                    .menu_indices
+                    .iter()
+                    .position(|value| *value == Some(index))
+                {
+                    self.menu.focus_item(row);
+                }
+            }
+            _ => self.focus = Some(target),
+        }
+    }
 }
 
-/// Widens a character/spacer count to `f64` for layout math. Goes through
-/// `u32` (exactly representable in `f64`) with a saturating fallback
-/// rather than an `as` cast, so it's lossless for any realistic label
-/// length or item count.
 fn count_to_f64(n: usize) -> f64 {
     f64::from(u32::try_from(n).unwrap_or(u32::MAX))
 }
-
-/// Narrows a layout dimension to `f32` for taffy. Every call site is a
-/// toolbar axis extent, always many orders of magnitude below `f32::MAX`,
-/// so the truncation the lint warns about can't actually occur.
-#[cfg(test)]
 #[allow(
     clippy::cast_possible_truncation,
-    reason = "toolbar axis extents never approach f32::MAX"
+    reason = "bounded logical layout dimensions"
 )]
 #[cfg(test)]
-fn to_f32(v: f64) -> f32 {
-    v as f32
+fn to_f32(value: f64) -> f32 {
+    value as f32
+}
+#[allow(
+    clippy::arithmetic_side_effects,
+    reason = "affine composition is non-panicking float math"
+)]
+fn translated(transform: Affine, x: f64, y: f64) -> Affine {
+    transform * Affine::translate((x, y))
 }
 
 impl Widget for Toolbar {
     fn sync(&mut self, _state: &mut AutoCommit, _path: &ObjId) {}
-
     fn build_layout(
         &mut self,
-        taffy: &mut TaffyTree<()>,
+        tree: &mut TaffyTree<()>,
         theme: &Theme,
-        node_map: &mut HashMap<NodeId, *mut dyn Widget>,
+        nodes: &mut HashMap<NodeId, *mut dyn Widget>,
     ) -> NodeId {
-        // Fixed cross-axis size, derived from the button padding + sm
-        // typography slug so the strip reads as compact chrome.
-        let cross_axis_size = theme.tokens.typography.scale.sm + 2.0 * theme.tokens.spacing.s2;
-        let (w, h) = match self.orientation {
-            Orientation::Horizontal => (Dimension::auto(), Dimension::length(cross_axis_size)),
-            Orientation::Vertical => (Dimension::length(cross_axis_size), Dimension::auto()),
+        self.font = TextStyle::new(theme.tokens.typography.scale.sm);
+        self.padding = theme.tokens.spacing.s3;
+        self.minimum = theme.tokens.spacing.s8;
+        self.separator = 1.0 + 2.0 * theme.tokens.spacing.s2;
+        // Bootstrap only for legacy callers that skip renderer settlement.
+        self.extents = self
+            .items
+            .iter()
+            .map(|item| match item {
+                ToolbarItem::Button { .. } => Size {
+                    width: self.minimum,
+                    height: self.minimum,
+                },
+                ToolbarItem::Separator => match self.orientation {
+                    Orientation::Horizontal => Size {
+                        width: self.separator,
+                        height: self.minimum,
+                    },
+                    Orientation::Vertical => Size {
+                        width: self.minimum,
+                        height: self.separator,
+                    },
+                },
+                ToolbarItem::Spacer => Size::ZERO,
+            })
+            .collect();
+        self.chip_extent = Size {
+            width: self.minimum,
+            height: self.minimum,
         };
-        let node = taffy.leaf_node(Style {
-            size: Size {
-                width: w,
-                height: h,
+        let node = tree.leaf_node(Style {
+            flex_shrink: 1.0,
+            min_size: Size {
+                width: Dimension::length(0.0),
+                height: Dimension::length(0.0),
             },
-            flex_shrink: 0.0,
             ..Default::default()
         });
-        node_map.insert(node, std::ptr::from_mut::<dyn Widget>(self));
-        // Measure against whatever axis extent the last layout gave us.
-        // On the very first pass `self.rect` is empty, so fall back to
-        // "everything fits" rather than collapsing the whole strip into
-        // an overflow chip before the toolbar has ever been sized.
-        let axis_extent = match self.orientation {
-            Orientation::Horizontal => self.rect.width(),
-            Orientation::Vertical => self.rect.height(),
-        };
-        if axis_extent > 0.0 {
-            self.recompute_visible(axis_extent, theme);
-        } else if self.visible_count == 0 {
-            self.visible_count = self.items.len();
-        }
+        nodes.insert(node, std::ptr::from_mut::<dyn Widget>(self));
         node
     }
-
-    fn apply_layout(&mut self, taffy: &TaffyTree<()>, node: NodeId, origin: Point) {
-        let layout = taffy.layout(node).copied().unwrap_or_default();
+    fn measure(
+        &mut self,
+        known: Size<Option<f32>>,
+        _available: Size<taffy::AvailableSpace>,
+        text: &mut TextRenderer,
+    ) -> Size<f32> {
+        self.update_measurements(text);
+        Size {
+            width: known.width.unwrap_or(self.intrinsic.width),
+            height: known.height.unwrap_or(self.intrinsic.height),
+        }
+    }
+    fn adjust_layout_with_measure(
+        &mut self,
+        tree: &mut TaffyTree<()>,
+        node: NodeId,
+        text: &mut TextRenderer,
+    ) -> bool {
+        let changed = self.update_measurements(text);
+        if changed {
+            let _ = tree.mark_dirty(node);
+        }
+        changed
+    }
+    fn apply_layout(&mut self, tree: &TaffyTree<()>, node: NodeId, origin: Point) {
+        let layout = tree.layout(node).copied().unwrap_or_default();
+        let x = origin.x + f64::from(layout.location.x);
+        let y = origin.y + f64::from(layout.location.y);
         self.rect = Rect::new(
-            origin.x + f64::from(layout.location.x),
-            origin.y + f64::from(layout.location.y),
-            origin.x + f64::from(layout.location.x) + f64::from(layout.size.width),
-            origin.y + f64::from(layout.location.y) + f64::from(layout.size.height),
+            x,
+            y,
+            x + f64::from(layout.size.width),
+            y + f64::from(layout.size.height),
         );
-
-        self.item_rects.clear();
-        self.item_rects.resize(self.items.len(), Rect::ZERO);
-        if self.items.is_empty() {
-            self.visible_count = 0;
-            self.overflow_rect = Rect::ZERO;
-            return;
-        }
-
-        let axis_total = match self.orientation {
-            Orientation::Horizontal => self.rect.width(),
-            Orientation::Vertical => self.rect.height(),
-        };
-
-        self.visible_count = self.decide_visible_count(axis_total);
-        self.place_visible_items(axis_total);
+        self.place();
     }
-
     fn draw(
         &mut self,
         scene: &mut Scene,
         transform: Affine,
-        text_renderer: &mut TextRenderer,
+        text: &mut TextRenderer,
         theme: &Theme,
-        _presence: &PresenceCtx,
+        presence: &PresenceCtx,
     ) {
-        let tokens = &theme.tokens;
-        let radius = f64::from(tokens.radii.sm);
-        let font_size = tokens.typography.scale.sm;
-        let n_visible = self.visible_count.min(self.items.len());
-
-        for (i, (item, &r)) in self
-            .items
-            .iter()
-            .zip(self.item_rects.iter())
-            .enumerate()
-            .take(n_visible)
-        {
-            if r.is_zero_area() {
+        self.viewport = presence.viewport.get().or(self.viewport);
+        if let Some(viewport) = self.viewport {
+            self.menu.reanchor(self.overflow_rect, viewport);
+        }
+        self.menu.layout_within(text, theme);
+        let style = text.renderer_input_style(&self.font);
+        // Explicit tiny allocations remain authoritative, including for glyph paint.
+        scene.push_layer(
+            vello::peniko::Fill::NonZero,
+            vello::peniko::BlendMode::default(),
+            1.0,
+            transform,
+            &self.rect,
+        );
+        for (index, item) in self.items.iter().enumerate().take(self.visible_count) {
+            let Some(rect) = self
+                .item_rects
+                .get(index)
+                .copied()
+                .filter(|rect| !rect.is_zero_area())
+            else {
                 continue;
-            }
+            };
             match item {
-                ToolbarItem::Button { label, .. } => {
-                    let hovered = self.item_hover.get(i).copied().unwrap_or(false);
-                    let bg = if hovered {
-                        theme.bg_hover
-                    } else {
-                        tokens.colors.surfaces.raised
-                    };
-                    let shape = RoundedRect::from_rect(r, radius);
-                    scene.fill(vello::peniko::Fill::NonZero, transform, bg, None, &shape);
-                    let (tw, th) = text_renderer.measure(label, font_size, None);
-                    let tx = r.center().x - f64::from(tw) / 2.0;
-                    let ty = r.center().y - f64::from(th) / 2.0;
-                    text_renderer.draw_text(
-                        scene,
-                        label,
-                        font_size,
-                        tokens.colors.text_primary,
-                        translated(transform, tx, ty),
-                        None,
-                    );
-                }
+                ToolbarItem::Button { label, .. } => self.draw_button(
+                    scene,
+                    transform,
+                    text,
+                    theme,
+                    &style,
+                    Target::Item(index),
+                    rect,
+                    label,
+                ),
                 ToolbarItem::Separator => {
-                    // Hairline divider perpendicular to the orientation
-                    // axis. Margin `s2` from each end along the cross
-                    // axis (so the line doesn't kiss the toolbar edge).
-                    let margin = f64::from(tokens.spacing.s2);
-                    let line_rect = match self.orientation {
-                        Orientation::Horizontal => {
-                            let cx = r.center().x;
-                            Rect::new(
-                                cx - SEPARATOR_LINE_PX / 2.0,
-                                r.y0 + margin,
-                                cx + SEPARATOR_LINE_PX / 2.0,
-                                r.y1 - margin,
-                            )
-                        }
-                        Orientation::Vertical => {
-                            let cy = r.center().y;
-                            Rect::new(
-                                r.x0 + margin,
-                                cy - SEPARATOR_LINE_PX / 2.0,
-                                r.x1 - margin,
-                                cy + SEPARATOR_LINE_PX / 2.0,
-                            )
-                        }
+                    let margin = f64::from(theme.tokens.spacing.s2);
+                    let line = match self.orientation {
+                        Orientation::Horizontal => Rect::new(
+                            rect.center().x - 0.5,
+                            rect.y0 + margin,
+                            rect.center().x + 0.5,
+                            (rect.y1 - margin).max(rect.y0 + margin),
+                        ),
+                        Orientation::Vertical => Rect::new(
+                            rect.x0 + margin,
+                            rect.center().y - 0.5,
+                            (rect.x1 - margin).max(rect.x0 + margin),
+                            rect.center().y + 0.5,
+                        ),
                     };
                     scene.fill(
                         vello::peniko::Fill::NonZero,
                         transform,
-                        tokens.colors.border_standard,
+                        theme.tokens.colors.border_standard,
                         None,
-                        &line_rect,
+                        &line,
                     );
                 }
-                ToolbarItem::Spacer => {
-                    // Greedy spacer — soaks remaining space, paints
-                    // nothing. Stays in `item_rects` so apply_layout
-                    // bookkeeping is uniform.
-                }
+                ToolbarItem::Spacer => {}
             }
         }
-
-        if self.has_overflow() && !self.overflow_rect.is_zero_area() {
-            let bg = if self.overflow_hover {
-                theme.bg_hover
-            } else {
-                tokens.colors.surfaces.raised
-            };
-            let shape = RoundedRect::from_rect(self.overflow_rect, radius);
-            scene.fill(vello::peniko::Fill::NonZero, transform, bg, None, &shape);
-            let label = "…";
-            let (tw, th) = text_renderer.measure(label, font_size, None);
-            let tx = self.overflow_rect.center().x - f64::from(tw) / 2.0;
-            let ty = self.overflow_rect.center().y - f64::from(th) / 2.0;
-            text_renderer.draw_text(
+        if self.has_overflow() {
+            self.draw_button(
                 scene,
-                label,
-                font_size,
-                tokens.colors.text_primary,
-                translated(transform, tx, ty),
-                None,
+                transform,
+                text,
+                theme,
+                &style,
+                Target::Overflow,
+                self.overflow_rect,
+                "…",
             );
         }
+        scene.pop_layer();
+    }
+    fn draw_overlay(
+        &mut self,
+        scene: &mut Scene,
+        transform: Affine,
+        text: &mut TextRenderer,
+        theme: &Theme,
+        presence: &PresenceCtx,
+    ) {
+        self.menu.draw(scene, transform, text, theme, presence);
     }
-
     fn handle_event(
         &mut self,
         event: &WindowEvent,
-        scale_factor: f64,
-        _modifiers: &winit::event::Modifiers,
-        _state: &mut AutoCommit,
-        _path: &ObjId,
+        scale: f64,
+        modifiers: &winit::event::Modifiers,
+        state: &mut AutoCommit,
+        path: &ObjId,
         handled: &mut bool,
-        _focus_target: &mut Option<NodeId>,
-        _node_id: NodeId,
-        _taffy: &TaffyTree<()>,
+        focus_target: &mut Option<NodeId>,
+        node: NodeId,
+        tree: &TaffyTree<()>,
     ) {
+        if self.menu.is_open() {
+            self.menu.handle_event(
+                event,
+                scale,
+                modifiers,
+                state,
+                path,
+                handled,
+                focus_target,
+                node,
+                tree,
+            );
+            if matches!(
+                event,
+                WindowEvent::MouseInput {
+                    state: ElementState::Pressed,
+                    ..
+                }
+            ) {
+                self.swallow_release = true;
+            }
+            self.drain_menu();
+            return;
+        }
         match event {
             WindowEvent::CursorMoved { position, .. } => {
-                let pos = Point::new(position.x / scale_factor, position.y / scale_factor);
-                let n_visible = self.visible_count.min(self.items.len());
-                if self.item_hover.len() != self.items.len() {
-                    self.item_hover.resize(self.items.len(), false);
-                }
-                for (i, h) in self.item_hover.iter_mut().enumerate() {
-                    let new_h = i < n_visible
-                        && self
-                            .items
-                            .get(i)
-                            .is_some_and(|it| matches!(it, ToolbarItem::Button { .. }))
-                        && self.item_rects.get(i).is_some_and(|r| r.contains(pos));
-                    if new_h != *h {
-                        *h = new_h;
-                        *handled = true;
-                    }
+                let point = Point::new(position.x / scale, position.y / scale);
+                let hovered = self.targets().into_iter().find(|target| {
+                    self.target_rect(*target)
+                        .is_some_and(|rect| rect.contains(point))
+                });
+                if hovered != self.hovered {
+                    self.hovered = hovered;
+                    *handled = true;
                 }
-                let new_oh = self.has_overflow() && self.overflow_rect.contains(pos);
-                if new_oh != self.overflow_hover {
-                    self.overflow_hover = new_oh;
+            }
+            WindowEvent::MouseInput {
+                state: ElementState::Pressed,
+                button: MouseButton::Left,
+                ..
+            } => {
+                self.pressed = self.hovered;
+                if let Some(target) = self.pressed {
+                    self.focus_target(target);
+                    *focus_target = Some(node);
                     *handled = true;
                 }
             }
             WindowEvent::MouseInput {
                 state: ElementState::Released,
                 button: MouseButton::Left,
                 ..
             } => {
-                let n_visible = self.visible_count.min(self.items.len());
-                for i in 0..n_visible {
-                    if self.item_hover.get(i).copied().unwrap_or(false)
-                        && let Some(ToolbarItem::Button { on_click, .. }) = self.items.get_mut(i)
+                if self.swallow_release {
+                    self.swallow_release = false;
+                    self.pressed = None;
+                    *handled = true;
+                    return;
+                }
+                if let Some(target) = self
+                    .pressed
+                    .take()
+                    .filter(|target| Some(*target) == self.hovered)
+                {
+                    self.activate(target);
+                    *handled = true;
+                }
+            }
+            WindowEvent::KeyboardInput { event, .. }
+                if self.focused && event.state == ElementState::Pressed =>
+            {
+                match &event.logical_key {
+                    Key::Named(NamedKey::Enter | NamedKey::Space) => {
+                        if let Some(target) = self.focus {
+                            self.activate(target);
+                        }
+                        *handled = true;
+                    }
+                    Key::Named(NamedKey::ArrowRight)
+                        if self.orientation == Orientation::Horizontal =>
                     {
-                        on_click();
+                        self.move_focus(true);
                         *handled = true;
                     }
-                }
-                if self.overflow_hover && self.has_overflow() {
-                    self.overflow_open = !self.overflow_open;
-                    *handled = true;
+                    Key::Named(NamedKey::ArrowLeft)
+                        if self.orientation == Orientation::Horizontal =>
+                    {
+                        self.move_focus(false);
+                        *handled = true;
+                    }
+                    Key::Named(NamedKey::ArrowDown)
+                        if self.orientation == Orientation::Vertical =>
+                    {
+                        self.move_focus(true);
+                        *handled = true;
+                    }
+                    Key::Named(NamedKey::ArrowUp) if self.orientation == Orientation::Vertical => {
+                        self.move_focus(false);
+                        *handled = true;
+                    }
+                    _ => {}
                 }
             }
             _ => {}
         }
     }
-
+    fn is_focusable(&self) -> bool {
+        self.items
+            .iter()
+            .any(|item| matches!(item, ToolbarItem::Button { .. }))
+    }
+    fn set_focus(&mut self, focused: bool) {
+        self.focused = focused;
+        if focused && self.focus.is_none() {
+            self.focus = self.targets().first().copied();
+        }
+        if !focused {
+            self.menu.close();
+            self.pressed = None;
+        }
+    }
+    fn is_focused(&self) -> bool {
+        self.focused
+    }
+    fn traps_focus(&self) -> bool {
+        self.menu.is_open()
+    }
+    fn wants_pointer_capture(&self) -> bool {
+        self.menu.is_open() || self.pressed.is_some() || self.swallow_release
+    }
+    fn modal_capture(&self) -> Option<Rect> {
+        self.menu.modal_capture()
+    }
     fn name(&self) -> &'static str {
         "Toolbar"
     }
-
-    /// The toolbar reports [`Role::Toolbar`] — a strip of controls. Its
-    /// items are drawn directly (not child widgets), so they don't flow
-    /// through `children()`; the container itself stands in for the strip.
-    /// It carries no name of its own (a labelling host would supply one).
-    fn accessibility(&self) -> Option<crate::a11y::AccessNode> {
-        use crate::a11y::{AccessNode, Role};
-        Some(AccessNode::new(Role::Toolbar))
-    }
-
     fn get_rect(&self) -> Rect {
         self.rect
     }
+    fn accessibility(&self) -> Option<AccessNode> {
+        let mut children: Vec<_> = self
+            .targets()
+            .iter()
+            .map(|target| {
+                let (name, route, expanded) = match target {
+                    Target::Item(index) => (
+                        match self.items.get(*index) {
+                            Some(ToolbarItem::Button { label, .. }) => label.clone(),
+                            _ => String::new(),
+                        },
+                        format!("toolbar.item.{index}"),
+                        None,
+                    ),
+                    Target::Overflow => (
+                        "More commands".to_owned(),
+                        "toolbar.overflow".to_owned(),
+                        Some(self.menu.is_open()),
+                    ),
+                };
+                AccessNode::new(Role::Button)
+                    .with_name(name)
+                    .with_action_target(route)
+                    .with_state(AccessState {
+                        focusable: true,
+                        focused: self.focused
+                            && !self.menu.is_open()
+                            && self.focus == Some(*target),
+                        expanded,
+                        ..Default::default()
+                    })
+            })
+            .collect();
+        if self.menu.is_open() {
+            let rows = self
+                .menu_indices
+                .iter()
+                .enumerate()
+                .filter_map(|(row, index)| {
+                    let index = (*index)?;
+                    let ToolbarItem::Button { label, .. } = self.items.get(index)? else {
+                        return None;
+                    };
+                    Some(
+                        AccessNode::new(Role::MenuItem)
+                            .with_name(label.clone())
+                            .with_action_target(format!("toolbar.item.{index}"))
+                            .with_state(AccessState {
+                                focusable: true,
+                                focused: self.focused && self.menu.hovered() == Some(row),
+                                ..Default::default()
+                            }),
+                    )
+                })
+                .collect();
+            children.push(AccessNode::new(Role::Menu).with_children(rows));
+        }
+        Some(
+            AccessNode::new(Role::Toolbar)
+                .with_state(AccessState {
+                    focusable: self.is_focusable(),
+                    focused: self.focused,
+                    ..Default::default()
+                })
+                .with_children(children),
+        )
+    }
+    fn synthetic_accessibility_rect(&self, path: &[usize]) -> Option<Rect> {
+        match self.semantic_target(path)? {
+            Target::Item(index) if index >= self.visible_count => self
+                .menu_indices
+                .iter()
+                .position(|value| *value == Some(index))
+                .and_then(|row| self.menu.item_rect(row)),
+            target => self.target_rect(target),
+        }
+    }
+    fn focus_synthetic_accessibility(&mut self, path: &[usize]) -> bool {
+        let Some(target) = self.semantic_target(path) else {
+            return false;
+        };
+        self.focus_target(target);
+        true
+    }
+    fn perform_semantic_action(
+        &mut self,
+        target: &str,
+        action: &Action,
+        _state: &mut AutoCommit,
+        _path: &ObjId,
+    ) -> bool {
+        let target = if target == "toolbar.overflow" && self.has_overflow() {
+            Target::Overflow
+        } else if let Some(index) = target
+            .strip_prefix("toolbar.item.")
+            .and_then(|index| index.parse::<usize>().ok())
+        {
+            if !matches!(self.items.get(index), Some(ToolbarItem::Button { .. }))
+                || (index >= self.visible_count && !self.menu.is_open())
+            {
+                return false;
+            }
+            Target::Item(index)
+        } else {
+            return false;
+        };
+        match action {
+            Action::Focus => self.focus_target(target),
+            Action::Activate => {
+                if let Target::Item(index) = target
+                    && index >= self.visible_count
+                {
+                    if let Some(row) = self
+                        .menu_indices
+                        .iter()
+                        .position(|value| *value == Some(index))
+                    {
+                        self.menu.click_item(row);
+                        self.drain_menu();
+                    }
+                } else {
+                    self.activate(target);
+                }
+            }
+            _ => return false,
+        }
+        true
+    }
 }
 
+impl Toolbar {
+    #[allow(
+        clippy::too_many_arguments,
+        reason = "paint inputs and an immediate-mode button's geometry"
+    )]
+    fn draw_button(
+        &self,
+        scene: &mut Scene,
+        transform: Affine,
+        text: &mut TextRenderer,
+        theme: &Theme,
+        style: &TextStyle,
+        target: Target,
+        rect: Rect,
+        label: &str,
+    ) {
+        if rect.is_zero_area() {
+            return;
+        }
+        let shape = RoundedRect::from_rect(rect, f64::from(theme.tokens.radii.sm));
+        let color = if self.hovered == Some(target) {
+            theme.bg_hover
+        } else {
+            theme.tokens.colors.surfaces.raised
+        };
+        scene.fill(vello::peniko::Fill::NonZero, transform, color, None, &shape);
+        if self.focused && self.focus == Some(target) && !self.menu.is_open() {
+            scene.stroke(
+                &Stroke::new(2.0),
+                transform,
+                theme.tokens.colors.border_focus,
+                None,
+                &shape,
+            );
+        }
+        let (width, height) = text.measure_style(label, None, style);
+        text.draw_style(
+            scene,
+            label,
+            theme.tokens.colors.text_primary,
+            translated(
+                transform,
+                rect.center().x - f64::from(width) / 2.0,
+                rect.center().y - f64::from(height) / 2.0,
+            ),
+            None,
+            style,
+        );
+    }
+}
 // =====================================================================
 // Tests
 // =====================================================================
 
 #[cfg(test)]
 mod tests {
     use super::*;
     use crate::presence::PresenceCtx;
     use vello_encoding::DrawTag;
 
@@ -716,20 +1058,87 @@ mod tests {
 
     fn count_color_fills(scene: &Scene) -> usize {
         scene
             .encoding()
             .draw_tags
             .iter()
             .filter(|t| **t == DrawTag::COLOR)
             .count()
     }
 
+    #[test]
+    fn measured_labels_and_tiny_overflow_follow_lifecycle() {
+        let mut tb = Toolbar::new(Orientation::Horizontal)
+            .push_button("WWW", || {})
+            .push_button("iii", || {});
+        let theme = Theme::dark();
+        let mut text = TextRenderer::new();
+        let mut tree = TaffyTree::new();
+        let node = tb.build_layout(&mut tree, &theme, &mut HashMap::new());
+        tb.adjust_layout_with_measure(&mut tree, node, &mut text);
+        tree.set_style(
+            node,
+            Style {
+                size: Size {
+                    width: Dimension::length(500.0),
+                    height: Dimension::length(40.0),
+                },
+                ..Default::default()
+            },
+        )
+        .unwrap();
+        tree.compute_layout(
+            node,
+            Size {
+                width: taffy::AvailableSpace::MaxContent,
+                height: taffy::AvailableSpace::MaxContent,
+            },
+        )
+        .unwrap();
+        tb.apply_layout(&tree, node, Point::ZERO);
+        assert!(
+            tb.item_rects[0].width() > tb.item_rects[1].width(),
+            "renderer widths must replace character counting"
+        );
+        tree.set_style(
+            node,
+            Style {
+                size: Size {
+                    width: Dimension::length(5.0),
+                    height: Dimension::length(40.0),
+                },
+                ..Default::default()
+            },
+        )
+        .unwrap();
+        tree.compute_layout(
+            node,
+            Size {
+                width: taffy::AvailableSpace::MaxContent,
+                height: taffy::AvailableSpace::MaxContent,
+            },
+        )
+        .unwrap();
+        tb.apply_layout(&tree, node, Point::ZERO);
+        assert!(tb.overflow_rect.x0 >= tb.rect.x0);
+        assert!(tb.item_rects.iter().all(|r| *r == Rect::ZERO));
+    }
+
+    #[test]
+    fn toolbar_exposes_focusable_named_commands() {
+        let tb = lay_out(n_button_toolbar(3), 100.0);
+        assert!(tb.is_focusable());
+        let node = tb.accessibility().unwrap();
+        assert!(!node.children.is_empty());
+        assert!(node.children.iter().all(|c| c.name.is_some()));
+    }
+
     #[test]
     fn accessibility_reports_toolbar_role() {
         use crate::a11y::Role;
         let tb = n_button_toolbar(3);
         let node = Widget::accessibility(&tb).expect("toolbar is a semantic strip");
         assert_eq!(node.role, Role::Toolbar);
         assert_eq!(node.name, None, "toolbar carries no name of its own");
     }
 
     /// Three buttons + ample width must lay out three non-empty rects
@@ -833,10 +1242,417 @@ mod tests {
             400.0,
         );
         let bare_scene = render(&mut bare);
         let bare_fills = count_color_fills(&bare_scene);
         assert!(
             fills > bare_fills,
             "separator must add at least one COLOR fill (with={fills}, without={bare_fills})"
         );
     }
 }
+
+#[cfg(test)]
+mod lifecycle_tests {
+    use super::*;
+    use std::cell::RefCell;
+    use std::rc::Rc;
+    use winit::event::{DeviceId, KeyEvent};
+
+    fn settle(tb: &mut Toolbar, width: f32, height: f32, scale: f32) {
+        let theme = Theme::dark().with_text_scale(scale);
+        let mut text = TextRenderer::new();
+        text.set_text_scale(scale);
+        let mut tree = TaffyTree::new();
+        let mut nodes = HashMap::new();
+        let node = tb.build_layout(&mut tree, &theme, &mut nodes);
+        let mut style = tree.style(node).unwrap().clone();
+        style.size = Size {
+            width: Dimension::length(width),
+            height: Dimension::length(height),
+        };
+        tree.set_style(node, style).unwrap();
+        let mut bindings = crate::bound_dispatch::BoundNodeMap::default();
+        unsafe {
+            bindings.rebuild(tb, &tree, node, &nodes);
+            crate::widget::layout::compute_widget_layout(
+                &mut tree,
+                node,
+                Size {
+                    width: taffy::AvailableSpace::Definite(width),
+                    height: taffy::AvailableSpace::Definite(height),
+                },
+                &nodes,
+                &bindings,
+                &mut text,
+            )
+            .unwrap();
+        }
+        tb.apply_layout(&tree, node, Point::new(10.0, 10.0));
+        let presence = PresenceCtx::default();
+        presence
+            .viewport
+            .set(Some(Rect::new(0.0, 0.0, 360.0, 220.0)));
+        let mut scene = Scene::new();
+        tb.draw(&mut scene, Affine::IDENTITY, &mut text, &theme, &presence);
+        tb.draw_overlay(&mut scene, Affine::IDENTITY, &mut text, &theme, &presence);
+    }
+    fn dispatch(tb: &mut Toolbar, event: WindowEvent) -> bool {
+        let mut tree = TaffyTree::new();
+        let node = tree.leaf_node(Style::default());
+        let mut handled = false;
+        tb.handle_event(
+            &event,
+            1.0,
+            &Default::default(),
+            &mut AutoCommit::new(),
+            &automerge::ROOT,
+            &mut handled,
+            &mut None,
+            node,
+            &tree,
+        );
+        handled
+    }
+    fn cursor(tb: &mut Toolbar, p: Point) {
+        dispatch(
+            tb,
+            WindowEvent::CursorMoved {
+                device_id: unsafe { std::mem::zeroed::<DeviceId>() },
+                position: winit::dpi::PhysicalPosition::new(p.x, p.y),
+            },
+        );
+    }
+    fn mouse(tb: &mut Toolbar, state: ElementState) -> bool {
+        dispatch(
+            tb,
+            WindowEvent::MouseInput {
+                device_id: unsafe { std::mem::zeroed::<DeviceId>() },
+                state,
+                button: MouseButton::Left,
+            },
+        )
+    }
+    fn key(tb: &mut Toolbar, key: NamedKey) -> bool {
+        let mut event: KeyEvent = unsafe { std::mem::zeroed() };
+        event.logical_key = Key::Named(key);
+        event.physical_key = winit::keyboard::PhysicalKey::Unidentified(
+            winit::keyboard::NativeKeyCode::Unidentified,
+        );
+        event.location = winit::keyboard::KeyLocation::Standard;
+        event.state = ElementState::Pressed;
+        event.text = None;
+        dispatch(
+            tb,
+            WindowEvent::KeyboardInput {
+                device_id: unsafe { std::mem::zeroed() },
+                event,
+                is_synthetic: true,
+            },
+        )
+    }
+    fn counted(n: usize) -> (Toolbar, Rc<RefCell<Vec<usize>>>) {
+        let counts = Rc::new(RefCell::new(vec![0; n]));
+        let mut tb = Toolbar::new(Orientation::Horizontal);
+        for index in 0..n {
+            let counts = counts.clone();
+            tb = tb.push_button(&format!("Command {index}"), move || {
+                counts.borrow_mut()[index] += 1
+            });
+        }
+        (tb, counts)
+    }
+    #[test]
+    fn pointer_survives_layout_between_press_and_release() {
+        let (mut tb, counts) = counted(2);
+        settle(&mut tb, 350.0, 45.0, 1.0);
+        let p = tb.item_rects[0].center();
+        cursor(&mut tb, p);
+        mouse(&mut tb, ElementState::Pressed);
+        settle(&mut tb, 350.0, 45.0, 1.0);
+        mouse(&mut tb, ElementState::Released);
+        assert_eq!(*counts.borrow(), vec![1, 0]);
+    }
+    #[test]
+    fn tab_focus_starts_at_first_command_and_arrows_skip_decoration() {
+        let mut tb = Toolbar::new(Orientation::Horizontal)
+            .push_button("First", || {})
+            .push_separator()
+            .push_spacer()
+            .push_button("Last", || {});
+        settle(&mut tb, 350.0, 45.0, 1.0);
+        tb.set_focus(true);
+        assert_eq!(tb.focus, Some(Target::Item(0)));
+        key(&mut tb, NamedKey::ArrowRight);
+        assert_eq!(tb.focus, Some(Target::Item(3)));
+    }
+    #[test]
+    fn every_callback_is_reachable_once_by_each_input_route() {
+        for route in 0..3 {
+            let (mut tb, counts) = counted(8);
+            settle(&mut tb, 180.0, 45.0, 1.0);
+            tb.set_focus(true);
+            for index in 0..8 {
+                if index < tb.visible_count {
+                    match route {
+                        0 => {
+                            let p = tb.item_rects[index].center();
+                            cursor(&mut tb, p);
+                            mouse(&mut tb, ElementState::Pressed);
+                            mouse(&mut tb, ElementState::Released);
+                        }
+                        1 => {
+                            tb.focus = Some(Target::Item(index));
+                            key(&mut tb, NamedKey::Enter);
+                        }
+                        _ => {
+                            assert!(tb.perform_semantic_action(
+                                &format!("toolbar.item.{index}"),
+                                &Action::Activate,
+                                &mut AutoCommit::new(),
+                                &automerge::ROOT
+                            ));
+                        }
+                    }
+                } else {
+                    tb.focus = Some(Target::Overflow);
+                    key(&mut tb, NamedKey::Space);
+                    settle(&mut tb, 180.0, 45.0, 1.0);
+                    let row = tb
+                        .menu_indices
+                        .iter()
+                        .position(|entry| *entry == Some(index))
+                        .unwrap();
+                    while tb.menu.hovered() != Some(row) {
+                        key(&mut tb, NamedKey::ArrowDown);
+                    }
+                    match route {
+                        0 => {
+                            let p = tb.menu.item_rect(row).unwrap().center();
+                            cursor(&mut tb, p);
+                            mouse(&mut tb, ElementState::Pressed);
+                            mouse(&mut tb, ElementState::Released);
+                        }
+                        1 => {
+                            key(&mut tb, NamedKey::Enter);
+                        }
+                        _ => {
+                            assert!(tb.perform_semantic_action(
+                                &format!("toolbar.item.{index}"),
+                                &Action::Activate,
+                                &mut AutoCommit::new(),
+                                &automerge::ROOT
+                            ));
+                        }
+                    }
+                    assert!(!tb.menu.is_open());
+                    assert_eq!(tb.focus, Some(Target::Overflow));
+                }
+            }
+            assert_eq!(*counts.borrow(), vec![1; 8], "route {route}");
+        }
+    }
+    #[test]
+    fn measured_unicode_scale_orientation_and_resize() {
+        for orientation in [Orientation::Horizontal, Orientation::Vertical] {
+            let mut tb = Toolbar::new(orientation)
+                .push_button("WWW", || {})
+                .push_button("iii", || {})
+                .push_button("共有 العربية e\u{301} 😀", || {})
+                .push_button("Eine sehr lange übersetzte Aktion", || {});
+            settle(&mut tb, 140.0, 90.0, 1.0);
+            assert!(tb.extents[0].width > tb.extents[1].width);
+            let small = tb.extents.clone();
+            tb.open_menu(true);
+            settle(&mut tb, 140.0, 90.0, 2.0);
+            assert!(tb.extents[2].width > small[2].width);
+            assert!(tb.extents[2].height > small[2].height);
+            assert!(
+                tb.item_rects
+                    .iter()
+                    .skip(tb.visible_count)
+                    .all(|rect| *rect == Rect::ZERO)
+            );
+            assert!(tb.menu.is_open());
+            assert!(tb.menu.get_rect().x0 >= 0.0 && tb.menu.get_rect().x1 <= 360.0);
+            settle(&mut tb, 2000.0, 1000.0, 2.0);
+            assert!(!tb.has_overflow());
+            assert!(!tb.menu.is_open());
+            assert!(tb.targets().contains(&tb.focus.unwrap()));
+        }
+    }
+    #[test]
+    fn decorations_never_create_an_overflow_menu() {
+        let mut tb = Toolbar::new(Orientation::Horizontal)
+            .push_button("A", || {})
+            .push_separator()
+            .push_spacer();
+        settle(&mut tb, 100.0, 45.0, 1.0);
+        let exact = tb.extents[0].width;
+        settle(&mut tb, exact, 45.0, 1.0);
+        assert_eq!(tb.visible_count, 1);
+        assert!(!tb.has_overflow());
+        assert_eq!(tb.overflow_rect, Rect::ZERO);
+        settle(&mut tb, exact - 1.0, 45.0, 1.0);
+        assert!(tb.has_overflow());
+        assert!(tb.menu_indices.iter().all(Option::is_some));
+    }
+    #[test]
+    fn escape_and_outside_press_restore_focus_without_click_through() {
+        let (mut tb, counts) = counted(5);
+        settle(&mut tb, 180.0, 45.0, 1.0);
+        tb.set_focus(true);
+        tb.focus = Some(Target::Overflow);
+        key(&mut tb, NamedKey::Enter);
+        assert!(tb.traps_focus() && tb.wants_pointer_capture());
+        key(&mut tb, NamedKey::Escape);
+        assert!(!tb.traps_focus());
+        assert!(tb.is_focused());
+        assert_eq!(tb.focus, Some(Target::Overflow));
+        key(&mut tb, NamedKey::Enter);
+        let p = tb.item_rects[0].center();
+        cursor(&mut tb, p);
+        mouse(&mut tb, ElementState::Pressed);
+        mouse(&mut tb, ElementState::Released);
+        assert_eq!(*counts.borrow(), vec![0; 5]);
+    }
+    #[test]
+    fn resize_reconciles_original_indices_and_meaningful_separators() {
+        let mut tb = Toolbar::new(Orientation::Horizontal)
+            .push_separator()
+            .push_button("One", || {})
+            .push_separator()
+            .push_separator()
+            .push_spacer()
+            .push_button("Two", || {})
+            .push_separator()
+            .push_button("Three", || {})
+            .push_separator();
+        settle(&mut tb, 5.0, 45.0, 1.0);
+        assert_eq!(tb.menu_indices, vec![Some(1), None, Some(5), None, Some(7)]);
+        assert!(tb.overflow_rect.x0 >= tb.rect.x0);
+        tb.open_menu(true);
+        tb.menu.focus_item(4);
+        let width = tb
+            .extents
+            .iter()
+            .take(5)
+            .map(|size| size.width)
+            .sum::<f32>()
+            + tb.chip_extent.width;
+        settle(&mut tb, width, 45.0, 1.0);
+        assert!(tb.menu.is_open());
+        assert_eq!(tb.menu_indices, vec![Some(5), None, Some(7)]);
+        assert_eq!(tb.menu.hovered(), Some(2));
+        assert!(tb.menu.get_rect().x0 >= 0.0 && tb.menu.get_rect().x1 <= 360.0);
+    }
+
+    #[test]
+    fn vertical_navigation_and_tiny_chip_stay_inside_allocation() {
+        let mut tb = Toolbar::new(Orientation::Vertical)
+            .push_button("One", || {})
+            .push_separator()
+            .push_button("Two", || {});
+        settle(&mut tb, 120.0, 180.0, 1.0);
+        tb.set_focus(true);
+        key(&mut tb, NamedKey::ArrowDown);
+        assert_eq!(tb.focus, Some(Target::Item(2)));
+        key(&mut tb, NamedKey::ArrowUp);
+        assert_eq!(tb.focus, Some(Target::Item(0)));
+        settle(&mut tb, 120.0, 5.0, 2.0);
+        assert!(tb.has_overflow());
+        assert!(tb.overflow_rect.y0 >= tb.rect.y0 && tb.overflow_rect.y1 <= tb.rect.y1);
+        assert!(tb.item_rects.iter().all(|rect| *rect == Rect::ZERO));
+    }
+
+    #[test]
+    fn accessibility_menu_rows_have_routes_bounds_and_focus() {
+        let (mut tb, _) = counted(12);
+        settle(&mut tb, 120.0, 45.0, 1.0);
+        tb.set_focus(true);
+        tb.open_menu(true);
+        let menu_child = tb.targets().len();
+        let node = tb.accessibility().unwrap();
+        assert_eq!(node.children[menu_child].role, Role::Menu);
+        assert!(
+            node.children[menu_child]
+                .children
+                .iter()
+                .all(|child| child.action_target.is_some())
+        );
+        let last = node.children[menu_child].children.len() - 1;
+        assert!(tb.focus_synthetic_accessibility(&[menu_child, last]));
+        let rect = tb
+            .synthetic_accessibility_rect(&[menu_child, last])
+            .unwrap();
+        assert!(rect.y0 >= tb.menu.get_rect().y0 && rect.y1 <= tb.menu.get_rect().y1);
+        assert!(
+            tb.accessibility().unwrap().children[menu_child].children[last]
+                .state
+                .focused
+        );
+    }
+    #[test]
+    #[ignore = "manual offscreen evidence; set QUICK_UI_SCREENSHOT_DIR"]
+    fn rendered_toolbar_overflow_fixtures() {
+        let dir = std::env::var("QUICK_UI_SCREENSHOT_DIR").unwrap();
+        std::fs::create_dir_all(&dir).unwrap();
+        for (name, width, height, scale, toolbar_width) in [
+            ("toolbar-ordinary-100", 720u32, 340u32, 1.0, 530.0),
+            ("toolbar-narrow-200", 320u32, 260u32, 2.0, 290.0),
+        ] {
+            let labels = [
+                "New",
+                "Open",
+                "Save",
+                "WWW",
+                "iii",
+                "共有",
+                "العربية",
+                "Übersetzte Aktion",
+                "Export",
+                "Last hidden command",
+            ];
+            let fired = Rc::new(RefCell::new(0));
+            let mut tb = Toolbar::new(Orientation::Horizontal);
+            for (index, label) in labels.iter().enumerate() {
+                let fired = fired.clone();
+                tb = tb.push_button(label, move || {
+                    if index == 9 {
+                        *fired.borrow_mut() += 1;
+                    }
+                });
+            }
+            settle(&mut tb, toolbar_width, 44.0 * scale, scale);
+            let theme = Theme::dark().with_text_scale(scale);
+            let mut text = TextRenderer::new();
+            text.set_text_scale(scale);
+            let presence = PresenceCtx::default();
+            presence.viewport.set(Some(Rect::new(
+                0.0,
+                0.0,
+                f64::from(width),
+                f64::from(height),
+            )));
+            let mut scene = Scene::new();
+            tb.draw(&mut scene, Affine::IDENTITY, &mut text, &theme, &presence);
+            tb.set_focus(true);
+            tb.focus = Some(Target::Overflow);
+            key(&mut tb, NamedKey::Enter);
+            let last = tb.menu_indices.len() - 1;
+            while tb.menu.hovered() != Some(last) {
+                key(&mut tb, NamedKey::ArrowDown);
+            }
+            scene.reset();
+            tb.draw(&mut scene, Affine::IDENTITY, &mut text, &theme, &presence);
+            tb.draw_overlay(&mut scene, Affine::IDENTITY, &mut text, &theme, &presence);
+            assert!(tb.menu.item_rect(last).is_some());
+            let mut renderer = crate::offscreen::OffscreenRenderer::new(width, height);
+            let path = format!("{dir}/{name}.png");
+            renderer.render_png(&scene, theme.bg_app, &path);
+            key(&mut tb, NamedKey::Enter);
+            assert_eq!(*fired.borrow(), 1);
+            eprintln!(
+                "capture {path}; viewport={width}x{height}; toolbar_width={toolbar_width}; Theme::dark().with_text_scale({scale}); last command fired once"
+            );
+        }
+    }
+}
