# Task 4 preflight: measured Toolbar with reachable overflow

## Feasibility and smallest scope

Task 4 is implementable without changing the `Widget` trait. `Toolbar` can use the existing renderer-aware settlement hook, overlay pass, focus hooks, synthetic accessibility routes, modal capture and pointer capture. One production scope addition is necessary in `ui/src/widget/context_menu.rs`: the menu currently has a fixed width/full content height and positions directly from one point, with no viewport, height cap or scroll offset (`context_menu.rs:120-143`, `context_menu.rs:255-264`). Therefore viewport containment and a taller-than-viewport menu cannot be implemented correctly in `toolbar.rs` while still reusing `ContextMenu`'s row hit-testing and selection drain.

No change is needed in `ui/src/widget/mod.rs`. Its current contracts already cover renderer-aware settlement (`mod.rs:595-609`), focus ownership (`mod.rs:818-847`), synthetic semantic children/actions (`mod.rs:859-998`), pointer capture (`mod.rs:1539-1546`), modal capture (`mod.rs:1575-1587`) and top-layer drawing (`mod.rs:1702-1717`). The shared solver reruns layout until `adjust_layout_with_measure` settles (`layout.rs:96-137`).

## Existing primitives to reuse

- `ToolbarItem::Button` owns the original `Box<dyn FnMut()>` (`toolbar.rs:48-55`, `toolbar.rs:94-101`). Do not move or clone callbacks into menu rows.
- `ContextMenu::selection` plus `take_selection()` is explicitly the mutable-host action channel (`context_menu.rs:78-84`, `context_menu.rs:190-213`). Build menu actions with no-op `MenuItem::action(label, || {})`, keep a parallel `Vec<Option<usize>>` from menu row to original toolbar item index, drain once after menu event dispatch, then invoke the original `FnMut` once. `TextInput` already uses this parallel-row pattern (`text_input.rs:259-262`, `text_input.rs:3286-3353`, `text_input.rs:3363-3420`).
- `ContextMenu` already supplies separator-skipping Up/Down navigation (`context_menu.rs:219-241`), Escape/Enter handling (`context_menu.rs:431-457`), outside-click dismissal without click-through (`context_menu.rs:460-473`), and menu/menu-item roles (`context_menu.rs:493-534`).
- Override `Toolbar::draw_overlay` and call `Widget::draw(&mut menu, ...)`, following the established owned-menu pattern (`text_input.rs:4248-4267`).
- While the menu is open, `Toolbar::wants_pointer_capture()` should return true so ancestor `Row`/`Column` routing selects it before siblings (`mod.rs:1539-1546`, `row.rs:284-302`, `row.rs:322-326`). `Toolbar::modal_capture()` should forward the menu rect and `Toolbar::traps_focus()` should return true while open. `ContextMenu` already exposes modal capture but not focus trapping (`context_menu.rs:483-490`).
- Cache the window viewport during the normal `draw` call from `PresenceCtx::viewport` (`presence/mod.rs:486-489`); the app sets that value around normal drawing but restores it before `draw_overlay` (`app.rs:6664-6689`). Interactive opening necessarily follows an earlier frame, so that cached viewport is available for placement.
- Theme token sizes are already resolved by `Theme::with_text_scale` (`theme.rs:723-746`). Convert a cached resolved `TextStyle` with `TextRenderer::renderer_input_style` before both `measure_style` and `draw_style`, or renderer scale applies twice (`text_render.rs:1370-1393`, `text_render.rs:1485-1503`, `text_render.rs:1851-1869`).

## Concrete Toolbar shape

Add cached resolved font style/padding/minimum target, `Vec<Size<f32>>` item extents, a measured overflow-control extent, intrinsic size, focus state/target, owned `ContextMenu`, menu-row-to-toolbar-index mapping, and last known viewport. The extent vector stays 1:1 with `items`; spacers have zero intrinsic axis extent, separators use the cached spacing, and buttons use actual label width and height plus cached padding.

`build_layout` should cache theme-derived values and leave the shrinkable axis `auto` with `flex_shrink: 1` and a zero axis minimum, like other content-sized controls (`button.rs:830-864`). `measure()` should return the intrinsic size derived from the cached vector: sum item axes and take the maximum cross extent. `adjust_layout_with_measure` should measure every button label and the overflow glyph with the same renderer-input style used for paint, update the vector/intrinsic size, and return true only when cached values changed. This lets the solver recompute intrinsic layout while preserving a narrower parent allocation. Theme changes refresh the resolved cache in `build_layout`; renderer-scale changes alter measured extents in the adjustment pass. Labels currently have no mutation API after builder construction, so rebuilding a toolbar is the only current label-change path; any future setter must mark this cache stale.

`apply_layout` should be the only authoritative visibility/placement decision. Delete the hard-coded final-layout paths at `toolbar.rs:214-280`; decide and place from the cached vector. Measure and reserve the overflow control before accepting leading items. Clamp the chip's axis extent to the actual allocated axis so widths/heights below the chip measure never produce a rect outside the toolbar. Keep `recompute_visible(axis, theme)` as the existing approximate public compatibility method (`toolbar.rs:162-200`), but its result must be replaced by the measured decision on the next real lifecycle pass, as required by the brief.

Overflow is actionable only when at least one `Button` is hidden. Omit spacers from the menu, remove leading/trailing separators and collapse adjacent separators so every emitted separator has hidden buttons on both sides. If the suffix contains only separators/spacers, hide those decoration rects without showing a separator-only overflow menu. Zero every non-visible `item_rect` on every layout (`toolbar.rs:336-342`). Rebuild the menu mapping when the measured hidden-button set changes; if resize removes overflow, close the menu and move the internal focus to the last reachable visible command.

## Popup, input and focus flow

Opening the overflow control should build/reconcile the mapped menu, anchor it to `overflow_rect`, focus its first action for keyboard opening, and keep host focus on the Toolbar node. When open, dispatch every event to `ContextMenu` before toolbar buttons, drain selection immediately, invoke the mapped original callback once, and return when the menu consumed or dismissed the event. This preserves callback ownership and prevents an outside dismiss press from activating a toolbar item beneath it.

Make Toolbar focusable and retain an internal target of `Item(original_index)` or `Overflow`. Orientation arrows move over visible buttons plus overflow and skip separators/spacers; Enter/Space activates a button or opens overflow. Once open, ContextMenu owns Up/Down/Enter/Escape. Escape closes and restores the internal target to `Overflow`; host focus never needs to move to a second node. This is the smallest correct interpretation of “focus return,” because an owned standalone `ContextMenu` is not a retained child and does not implement `is_focusable`/`set_focus`.

Publish `Role::Toolbar` with synthetic named `Role::Button` children for visible commands and a named overflow button with `expanded: Some(menu.is_open())`. While open, also publish a `Role::Menu` containing mapped hidden commands as `Role::MenuItem` nodes. Give actionable nodes stable `with_action_target` values based on original item index, return their painted rects through `synthetic_accessibility_rect`, and route Focus/Activate through `focus_synthetic_accessibility`/`perform_semantic_action`. Merely nesting `ContextMenu::accessibility()` is insufficient: its current menu-item nodes have labels and focusable state but no action targets or bounds (`context_menu.rs:493-534`), and the owned menu is not present in Toolbar's retained `children()` tree.

## Necessary ContextMenu addition

Add a narrow reusable placement/scroll contract rather than a Toolbar-only second menu implementation:

- viewport/anchor setters (or one `open_anchored(anchor, viewport)` method), plus renderer-aware `layout_within(text, theme)`;
- width measured from action labels and capped to viewport width; placement below/above the anchor and clamped on both axes;
- body height capped to viewport height, a row scroll offset, clipped drawing, and offset-aware `item_at`;
- wheel scrolling and `ensure_hover_visible` after Up/Down or programmatic focus;
- a public “focus first action” operation for keyboard opening, and a row-rect accessor if Toolbar supplies menu-item accessibility bounds.

The related `widget::Popover` demonstrates viewport injection and horizontal clamp (`popover.rs:132-141`, `popover.rs:248-280`), but it also computes full row height and has no scrolling, and it cannot represent separators. Replacing ContextMenu with Popover would contradict the brief and lose the required menu-index mapping. Extending ContextMenu is the smaller scope.

## Brief/API conflicts and resolutions

1. “Popup must remain within host bounds and scroll” conflicts with ContextMenu's fixed `MENU_WIDTH`, full summed height, point-only placement and no wheel branch (`context_menu.rs:120-143`, `context_menu.rs:255-264`, `context_menu.rs:409-476`). Resolve with the scoped ContextMenu API above.
2. “Focusable command/overflow semantics” cannot be achieved by the current Toolbar node, which exposes only `Role::Toolbar` (`toolbar.rs:633-644`). Resolve inside Toolbar using existing synthetic accessibility/action hooks; no trait expansion.
3. “Focus return” cannot literally transfer focus to/from ContextMenu because it is an owned field rather than a registered child. Keep the Toolbar node focused, move its internal focus into menu rows while open, and restore the overflow target on close.
4. The current ContextMenu module comment says it is backed by overlay Popover (`context_menu.rs:1-4`), but the implementation directly owns its geometry/paint and never uses `crate::overlay::Popover`. Treat the implementation as authoritative; do not introduce the separate overlay stack for this task.

## Focused regression cases

- Exact measurement: equal-length `WWW`/`iii`; Arabic/CJK/combining/emoji labels; long translations; normal and 200% resolved theme plus renderer scale (applied once); horizontal and vertical intrinsic/placed extents.
- Fit edges: exact-fit, one-pixel-under, allocation smaller than measured chip, empty toolbar, trailing/leading/adjacent separators, spacers around the cut, and hidden suffix containing no buttons. Assert invisible rects are zero and the chip stays inside the toolbar.
- Resize/scale while open: hidden mapping updates, still-hidden callbacks retain original indices, newly fitting commands leave the menu, no-overflow resize closes it, anchor remains attached, and focus falls back to a reachable target.
- Callback reachability: direct pointer, direct keyboard, overflow pointer, overflow keyboard, and accessibility activation each invoke every original callback exactly once; a ContextMenu no-op callback plus drained selection must not double-fire.
- Popup containment: each window edge/corner, viewport narrower than menu, viewport shorter than all rows, wheel to first/last, arrow navigation auto-scroll, Enter after scrolling, correct offset hit-testing, and outside press dismisses without activating content underneath.
- Focus/a11y: Tab reaches Toolbar, orientation arrows skip decoration, Enter/Space opens, Escape closes/restores overflow focus, menu trap blocks traversal behind it, accessible roles/names/expanded/focused/hidden states match paint, and action targets activate both visible and overflowed commands.

No tests or production files were changed during this preflight.
