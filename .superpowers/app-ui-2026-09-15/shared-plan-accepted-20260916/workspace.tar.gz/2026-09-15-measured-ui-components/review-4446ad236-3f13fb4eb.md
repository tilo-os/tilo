# Review package: 4446ad236..3f13fb4eb

## Commits
3f13fb4eb fix(ui): unify rich editor text geometry

## Files changed
 .../task-2-report.md                               |  86 +++++
 ui/src/widget/block_editor.rs                      | 116 ++++++-
 ui/src/widget/code_editor.rs                       |  63 ++++
 ui/src/widget/rich_text_line.rs                    |  74 ++++-
 ui/src/widget/text_input.rs                        | 346 +++++++++++++++++++--
 5 files changed, 651 insertions(+), 34 deletions(-)

## Diff
diff --git a/.superpowers/sdd/2026-09-15-measured-ui-components/task-2-report.md b/.superpowers/sdd/2026-09-15-measured-ui-components/task-2-report.md
new file mode 100644
index 000000000..8205ee82f
--- /dev/null
+++ b/.superpowers/sdd/2026-09-15-measured-ui-components/task-2-report.md
@@ -0,0 +1,86 @@
+# Task 2 report: rich editor measurement and scale
+
+## Scope
+
+Implemented the shared rich editor measurement work in:
+
+- `ui/src/widget/rich_text_line.rs`
+- `ui/src/widget/text_input.rs`
+- `ui/src/widget/block_editor.rs`
+- `ui/src/widget/code_editor.rs`
+
+No `Scrollable` production code or `apps/code_editor` files were changed. No screenshots were requested for this task.
+
+## RED evidence
+
+All regression tests were written and observed failing before the corresponding production change.
+
+1. `CARGO_BUILD_JOBS=4 CARGO_PROFILE_DEV_DEBUG=0 CARGO_PROFILE_TEST_DEBUG=0 cargo test -p ui base_font_override_scales_once_across_relayout_caret_selection_and_pointer -- --nocapture`
+   - Failed because a base 16px `RichTextLine` shaped at 64px under a 2x theme instead of 32px.
+   - This confirmed the `RichTextLine::build_layout` multiplier and the inner `TextInput` multiplier were both active.
+
+2. `CARGO_BUILD_JOBS=4 CARGO_PROFILE_DEV_DEBUG=0 CARGO_PROFILE_TEST_DEBUG=0 cargo test -p ui multiline_measure_uses_the_same_scaled_shaped_rows_as_draw -- --nocapture`
+   - Failed with measured height `208.5` while the shaped draw path required `401`.
+   - This confirmed `measure` used the approximate `build_lines` model while draw used `RichTextLayout`.
+
+3. `CARGO_BUILD_JOBS=4 CARGO_PROFILE_DEV_DEBUG=0 CARGO_PROFILE_TEST_DEBUG=0 cargo test -p ui scaled_gutter_and_wrapped_rows_share_the_shaped_editor_geometry -- --nocapture`
+   - Failed because gutter width remained `39.84` at both 1x and 2x.
+   - This confirmed gutter width used an unscaled digit-ratio estimate while line-number glyphs scaled.
+
+4. `CARGO_BUILD_JOBS=4 CARGO_PROFILE_DEV_DEBUG=0 CARGO_PROFILE_TEST_DEBUG=0 cargo test -p ui --lib measured_multiline_pointer_geometry_tracks_applied_origin_before_draw -- --nocapture`
+   - Failed with byte `74` instead of the expected second-line start at byte `68`.
+   - This confirmed the measured shaped paragraph retained a zero origin after external layout and before first draw.
+
+5. `CARGO_BUILD_JOBS=4 CARGO_PROFILE_DEV_DEBUG=0 CARGO_PROFILE_TEST_DEBUG=0 cargo test -p ui --lib multiline_measure_uses_build_layout_theme_scale_when_renderer_is_stale -- --nocapture`
+   - Failed because `build_layout(theme 2x) -> measure(renderer 1x) -> draw(theme 2x)` measured and drew different heights.
+   - This confirmed measurement could not rely on the renderer's retained scale when the layout theme was authoritative.
+
+## Implementation
+
+- `RichTextLine` now passes its base font override to `TextInput`; its wrapper row height remains resolved once from the theme scale.
+- Single-line caret and selection bands now read the retained shaped layout's actual line metric after draw. This keeps heading, paragraph and inline-code geometry aligned with the shaped glyph run.
+- Multiline `TextInput::measure` now shapes a `RichTextLayout` using the same size, family, wrap width and line height used by draw. `content_height`, caret rows, selection rows and pointer hit-testing therefore share one paragraph model.
+- `TextInput::build_layout` retains the theme text scale for measurement. Direct measurement without a prior themed layout pass falls back to the renderer scale. A scale change on the same widget marks multiline layout dirty.
+- Applying layout refreshes the shaped paragraph origin, including the gutter offset, so pointer placement is correct before first draw.
+- Code-editor gutter width now comes from a measured line-number label plus scaled padding. The resolved line-number style is converted through `TextRenderer::renderer_input_style`, avoiding a second renderer scale during paint.
+- Numbered block prefixes use an extracted origin calculation tied to the same resolved line-height band as their editable text.
+
+## GREEN verification
+
+Focused regressions passed:
+
+- `cargo test -p ui --lib base_font_override_scales_once_across_relayout_caret_selection_and_pointer -- --nocapture`
+- `cargo test -p ui --lib multiline_measure_uses_the_same_scaled_shaped_rows_as_draw -- --nocapture`
+- `cargo test -p ui --lib measured_multiline_pointer_geometry_tracks_applied_origin_before_draw -- --nocapture`
+- `cargo test -p ui --lib multiline_measure_uses_build_layout_theme_scale_when_renderer_is_stale -- --nocapture`
+- `cargo test -p ui --lib scaled_multiline_geometry_refreshes_across_model_undo_redo_replay -- --nocapture`
+- `cargo test -p ui --lib scaled_gutter_and_wrapped_rows_share_the_shaped_editor_geometry -- --nocapture`
+- `cargo test -p ui --lib heading_paragraph_inline_code_and_numbered_prefix_scale_once -- --nocapture`
+
+The final current-source library test executable was produced by the last focused Cargo run, after all Task 2 source changes. Running its relevant module filters directly avoided rebuilding unrelated concurrent test edits:
+
+- `target/debug/deps/ui-98aece3f3d10fdcd widget::text_input::tests --nocapture` — 99 passed.
+- `target/debug/deps/ui-98aece3f3d10fdcd widget::rich_text_line::tests --nocapture` — 25 passed.
+- `target/debug/deps/ui-98aece3f3d10fdcd widget::code_editor::tests --nocapture` — 22 passed.
+- `target/debug/deps/ui-98aece3f3d10fdcd widget::block_editor::tests --nocapture` — 69 passed.
+
+Build and formatting checks:
+
+- `CARGO_BUILD_JOBS=4 CARGO_PROFILE_DEV_DEBUG=0 cargo check -p ui` — passed.
+- `rustfmt --edition 2024 --check ui/src/widget/rich_text_line.rs ui/src/widget/text_input.rs ui/src/widget/block_editor.rs ui/src/widget/code_editor.rs` — passed.
+- `git diff --check -- ui/src/widget/rich_text_line.rs ui/src/widget/text_input.rs ui/src/widget/block_editor.rs ui/src/widget/code_editor.rs` — passed.
+
+The test link emits the existing macOS `__eh_frame section too large` warning. It does not fail the build or tests.
+
+## Self-review
+
+- Verified base-versus-resolved ownership: `RichTextLine` and `TextInput` overrides remain base values; only the shaped layout and wrapper geometry resolve the active theme scale.
+- Verified renderer-relative conversion is limited to gutter painting and measurement; direct `RichTextLayout` shaping receives resolved sizes.
+- Verified the same widget instance transitions 1x -> 2x and 2x -> 1x, and model replay equivalent to undo/redo invalidates and restores wrapped geometry.
+- Verified actual caret, selection, wrapped logical rows, pointer events, inline-code marks, heading/paragraph sizes and numbered-prefix alignment rather than row-height constants alone.
+- Preserved all unrelated dirty and untracked files. Only the four task widget files and this report are intended for the scoped commit.
+
+## Remaining gaps
+
+- No application capture was produced in this implementer task; the controller owns Notes, Calendar and corrected Typst integration captures.
+- The full UI suite was intentionally not repeated because the task brief directs focused editor filters and records unrelated Chromium churn. All relevant editor module tests and `cargo check -p ui` are green.
diff --git a/ui/src/widget/block_editor.rs b/ui/src/widget/block_editor.rs
index 173574066..b41855bc5 100644
--- a/ui/src/widget/block_editor.rs
+++ b/ui/src/widget/block_editor.rs
@@ -3369,35 +3369,53 @@ fn draw_bullet_prefix(line_rect: Rect, prefix_x0: f64, gutter: f64, ctx: &mut Bl
 fn draw_numbered_prefix(
     idx: usize,
     line_rect: Rect,
     prefix_x0: f64,
     font_size: f32,
     ctx: &mut BlockDrawCtx<'_>,
 ) {
     let num = ctx.ordinals.get(idx).copied().unwrap_or(1).max(1);
     let label = format!("{num}.");
     let (label_w, _) = ctx.text_renderer.measure(&label, font_size, None);
-    // Matches RichTextLine's line height so the ordinal
-    // sits on the item text's baseline.
-    let line_height = f64::from(font_size * ctx.theme.text_scale) * 1.25;
-    let text_y = line_rect.y0 + (line_rect.height() - line_height) / 2.0;
-    let x = (line_rect.x0 - 6.0 - f64::from(label_w)).max(prefix_x0);
+    let origin = numbered_prefix_origin(
+        line_rect,
+        prefix_x0,
+        f64::from(label_w),
+        font_size,
+        ctx.theme.text_scale,
+    );
     ctx.text_renderer.draw_text(
         ctx.scene,
         &label,
         font_size,
         ctx.theme.tokens.colors.text_primary,
-        translated(ctx.transform, x, text_y),
+        translated(ctx.transform, origin.x, origin.y),
         None,
     );
 }
 
+fn numbered_prefix_origin(
+    line_rect: Rect,
+    prefix_x0: f64,
+    label_width: f64,
+    font_size: f32,
+    text_scale: f32,
+) -> Point {
+    // Matches RichTextLine's resolved shaped line height so the ordinal sits
+    // on the item text's baseline at every accessibility scale.
+    let line_height = f64::from(font_size * text_scale) * 1.25;
+    Point::new(
+        (line_rect.x0 - 6.0 - label_width).max(prefix_x0),
+        line_rect.y0 + (line_rect.height() - line_height) / 2.0,
+    )
+}
+
 fn draw_checklist_prefix(
     done: bool,
     line_rect: Rect,
     prefix_x0: f64,
     gutter: f64,
     ctx: &mut BlockDrawCtx<'_>,
 ) {
     let scale = f64::from(ctx.theme.text_scale);
     let cy = f64::midpoint(line_rect.y0, line_rect.y1);
     let cx = prefix_x0 + gutter / 2.0;
@@ -5572,20 +5590,106 @@ mod tests {
         e.blocks[0].line.set_text("plain");
         e.focused = Some(0);
         assert!(e.try_convert_to(0, BlockKind::CodeBlock { lang: None }));
         assert!(
             e.blocks()[0].line.inner().is_mono(),
             "converting to a code block switches the cell to monospace"
         );
         assert!(!Block::paragraph("hi").line.inner().is_mono());
     }
 
+    fn layout_and_draw_editor(editor: &mut BlockEditor, theme: &Theme) {
+        let mut taffy = TaffyTree::<()>::new();
+        let mut node_map: HashMap<NodeId, *mut dyn Widget> = HashMap::new();
+        let node = editor.build_layout(&mut taffy, theme, &mut node_map);
+        taffy
+            .compute_layout(
+                node,
+                Size {
+                    width: taffy::AvailableSpace::Definite(640.0),
+                    height: taffy::AvailableSpace::MaxContent,
+                },
+            )
+            .expect("block editor layout");
+        editor.apply_layout(&taffy, node, Point::ZERO);
+        let mut renderer = TextRenderer::new();
+        renderer.set_text_scale(theme.text_scale);
+        editor.draw(
+            &mut Scene::new(),
+            Affine::IDENTITY,
+            &mut renderer,
+            theme,
+            &PresenceCtx::empty(),
+        );
+    }
+
+    #[test]
+    fn heading_paragraph_inline_code_and_numbered_prefix_scale_once() {
+        let heading = Block::heading(1, "Heading");
+        let mut paragraph = Block::paragraph("inline code");
+        paragraph
+            .line
+            .set_marks(vec![MarkSpan::new(0..6, Mark::Code)]);
+        paragraph.line.inner_mut().set_selection(0, 6);
+        let numbered = Block::numbered(0, "numbered");
+        let mut editor = BlockEditor::new();
+        editor.set_blocks(vec![heading, paragraph, numbered]);
+
+        layout_and_draw_editor(&mut editor, &Theme::dark());
+        assert_eq!(
+            editor.blocks[0].line.inner().shaped_font_size_for_test(),
+            Some(28.0)
+        );
+        assert_eq!(
+            editor.blocks[1].line.inner().shaped_font_size_for_test(),
+            Some(16.0)
+        );
+
+        let large = Theme::dark().with_text_scale(2.0);
+        layout_and_draw_editor(&mut editor, &large);
+        assert_eq!(
+            editor.blocks[0].line.inner().shaped_font_size_for_test(),
+            Some(56.0)
+        );
+        for index in [1, 2] {
+            assert_eq!(
+                editor.blocks[index]
+                    .line
+                    .inner()
+                    .shaped_font_size_for_test(),
+                Some(32.0)
+            );
+        }
+        let selection = editor.blocks[1].line.selection_rect(&large, 0, 6);
+        assert!((selection.height() - 40.0).abs() < 0.1);
+
+        let numbered_line = &editor.blocks[2].line;
+        let line_rect = numbered_line.get_rect();
+        let gutter = prefix_gutter_for(&editor.blocks[2].kind) * 2.0;
+        let mut renderer = TextRenderer::new();
+        renderer.set_text_scale(2.0);
+        let (label_width, _) = renderer.measure("1.", 16.0, None);
+        let origin = numbered_prefix_origin(
+            line_rect,
+            line_rect.x0 - gutter,
+            f64::from(label_width),
+            16.0,
+            2.0,
+        );
+        let caret = numbered_line.caret_rect(&large, 0);
+        assert!(
+            (origin.y - caret.y0).abs() < 0.1,
+            "numbered prefix and shaped item share a baseline band"
+        );
+        assert!(origin.x < line_rect.x0);
+    }
+
     #[test]
     fn high_text_checklist_and_code_rows_leave_full_scaled_line_bands() {
         let mut editor = BlockEditor::new();
         editor.set_blocks(vec![
             Block::checklist(0, false, "Ship the high-text layout"),
             Block::code_block(Some("rust".into()), "let scale = 2;"),
         ]);
         let theme = Theme::dark().with_text_scale(2.0);
         let mut taffy = TaffyTree::<()>::new();
         let mut node_map: HashMap<NodeId, *mut dyn Widget> = HashMap::new();
diff --git a/ui/src/widget/code_editor.rs b/ui/src/widget/code_editor.rs
index 5c3fd693b..125cee27c 100644
--- a/ui/src/widget/code_editor.rs
+++ b/ui/src/widget/code_editor.rs
@@ -1927,11 +1927,74 @@ mod tests {
             .with_initial_value("x");
         without_g.set_rect(Rect::new(0.0, 0.0, 400.0, 200.0));
         draw_once(&mut without_g, &theme);
         let caret_without = without_g.inner().caret_rect(&theme, 0).x0;
 
         assert!(
             caret_with > caret_without + 10.0,
             "the gutter shifts the caret right ({caret_with} vs {caret_without})",
         );
     }
+
+    #[test]
+    fn scaled_gutter_and_wrapped_rows_share_the_shaped_editor_geometry() {
+        let text = "first logical line wraps across several visual rows because the editor is narrow\nsecond";
+        let mut normal = CodeEditor::local().with_initial_value(text);
+        normal.set_rect(Rect::new(0.0, 0.0, 190.0, 420.0));
+        draw_once(&mut normal, &Theme::dark());
+        let normal_gutter = normal.gutter_width();
+        let normal_line_height = normal.line_height();
+
+        let theme = Theme::dark().with_text_scale(2.0);
+        let mut large = CodeEditor::local().with_initial_value(text);
+        large.set_rect(Rect::new(0.0, 0.0, 190.0, 900.0));
+        draw_once(&mut large, &theme);
+        assert!(
+            large.gutter_width() >= normal_gutter * 1.8,
+            "measured gutter grows with its line-number glyphs ({} vs {})",
+            large.gutter_width(),
+            normal_gutter,
+        );
+        assert!(
+            large.line_height() >= normal_line_height * 1.9,
+            "wrapper reports the shaped 2× row height"
+        );
+
+        let first_end = text.find('\n').expect("hard line break");
+        let wrapped = large.selection_rects(&theme, 0, first_end);
+        assert!(wrapped.len() >= 2, "first logical line wraps visually");
+        assert!(wrapped.iter().all(|rect| {
+            (rect.height() - large.line_height()).abs() < 0.1
+                && rect.x0 >= large.rect().x0 + large.gutter_width()
+        }));
+        let second_start = first_end + 1;
+        let caret = large.caret_rect(&theme, second_start);
+        assert!(caret.x0 >= large.rect().x0 + large.gutter_width());
+        let point = Point::new(caret.x0 + 1.0, caret.y0 + caret.height() / 2.0);
+        assert_eq!(large.byte_at_point(point), second_start);
+        let mut doc = AutoCommit::new();
+        drive(
+            &mut large,
+            &mut doc,
+            &WindowEvent::CursorMoved {
+                device_id: unsafe { std::mem::zeroed() },
+                position: winit::dpi::PhysicalPosition::new(point.x, point.y),
+            },
+            mods(false, false),
+        );
+        assert!(drive(
+            &mut large,
+            &mut doc,
+            &WindowEvent::MouseInput {
+                device_id: unsafe { std::mem::zeroed() },
+                state: ElementState::Pressed,
+                button: winit::event::MouseButton::Left,
+            },
+            mods(false, false),
+        ));
+        assert_eq!(
+            large.cursor_pos(),
+            second_start,
+            "pointer event places the caret on the logical second line through wrapped rows"
+        );
+    }
 }
diff --git a/ui/src/widget/rich_text_line.rs b/ui/src/widget/rich_text_line.rs
index c5f0e4827..027402787 100644
--- a/ui/src/widget/rich_text_line.rs
+++ b/ui/src/widget/rich_text_line.rs
@@ -427,26 +427,25 @@ impl Widget for RichTextLine {
         self.inner.sync(state, path);
         self.align_bound_projection(state);
     }
 
     fn build_layout(
         &mut self,
         taffy: &mut TaffyTree<()>,
         theme: &Theme,
         node_map: &mut HashMap<NodeId, *mut dyn Widget>,
     ) -> NodeId {
-        // The inner input owns the shaped document text (which bypasses
-        // `TextRenderer`'s global scale), so hand it the effective size here.
-        // Keeping its row height on the same scale prevents large-text lines
-        // from painting into their neighbours.
+        // Font overrides remain base values. TextInput's shaped layout applies
+        // the theme scale exactly once; the row height is resolved here because
+        // this wrapper owns the surrounding document geometry.
         let scale = theme.text_scale;
-        self.inner.set_font_size(self.font_size * scale);
+        self.inner.set_font_size(self.font_size);
         // font_size * 1.5 so headings end up taller than paragraph rows without a measure pass.
         let height = (self.font_size * scale * 1.5).max(20.0 * scale);
         let node = taffy.leaf_node(Style {
             size: Size {
                 width: Dimension::percent(1.0),
                 height: Dimension::length(height),
             },
             ..Default::default()
         });
         node_map.insert(node, std::ptr::from_mut::<dyn Widget>(self));
@@ -917,20 +916,21 @@ pub fn link_at_byte(marks_list: &[MarkSpan], byte: usize) -> Option<PageId> {
         {
             return Some(*id);
         }
     }
     None
 }
 
 #[cfg(test)]
 mod tests {
     use super::*;
+    use crate::widget::marks::Mark;
     use winit::event::KeyEvent;
     use winit::keyboard::{
         Key, KeyLocation, ModifiersKeyState, ModifiersState, NamedKey, PhysicalKey, SmolStr,
     };
 
     /// `KeyEventExtra` is `pub(crate)` in winit 0.30, so this zero-constructs
     /// rather than using a struct literal.
     fn key_press(named: NamedKey) -> WindowEvent {
         let mut ev: KeyEvent = unsafe { std::mem::zeroed() };
         ev.logical_key = Key::Named(named);
@@ -978,20 +978,84 @@ mod tests {
             &modifiers,
             &mut state,
             &root,
             &mut handled,
             &mut focus_target,
             fake_node,
             &taffy,
         );
     }
 
+    fn layout_and_draw(line: &mut RichTextLine, theme: &Theme, width: f32) {
+        let mut taffy = TaffyTree::<()>::new();
+        let mut node_map = HashMap::new();
+        let node = line.build_layout(&mut taffy, theme, &mut node_map);
+        taffy
+            .compute_layout(
+                node,
+                Size {
+                    width: taffy::AvailableSpace::Definite(width),
+                    height: taffy::AvailableSpace::MaxContent,
+                },
+            )
+            .expect("rich line layout");
+        line.apply_layout(&taffy, node, Point::ZERO);
+
+        let mut renderer = TextRenderer::new();
+        renderer.set_text_scale(theme.text_scale);
+        let mut scene = Scene::new();
+        line.draw(
+            &mut scene,
+            Affine::IDENTITY,
+            &mut renderer,
+            theme,
+            &PresenceCtx::empty(),
+        );
+    }
+
+    #[test]
+    fn base_font_override_scales_once_across_relayout_caret_selection_and_pointer() {
+        let mut line = RichTextLine::new().with_text("alpha beta").with_size(16.0);
+        line.set_marks(vec![MarkSpan::new(0..5, Mark::Code)]);
+        line.inner_mut().set_selection(0, 5);
+
+        let normal = Theme::dark();
+        layout_and_draw(&mut line, &normal, 320.0);
+        assert_eq!(line.inner().shaped_font_size_for_test(), Some(16.0));
+        assert!((line.caret_rect(&normal, 5).height() - 20.0).abs() < 0.1);
+        assert!((line.selection_rect(&normal, 0, 5).height() - 20.0).abs() < 0.1);
+
+        let large = Theme::dark().with_text_scale(2.0);
+        layout_and_draw(&mut line, &large, 320.0);
+        assert_eq!(line.inner().shaped_font_size_for_test(), Some(32.0));
+        let caret = line.caret_rect(&large, 5);
+        assert!(
+            (caret.height() - 40.0).abs() < 0.1,
+            "scaled caret height was {}",
+            caret.height()
+        );
+        let selection = line.selection_rect(&large, 0, 5);
+        assert!(
+            (selection.height() - 40.0).abs() < 0.1,
+            "scaled selection height was {}",
+            selection.height()
+        );
+
+        let target = 6;
+        let x = line.pixel_x_for_byte(&large, target);
+        assert_eq!(
+            line.byte_for_pixel_x(&large, x),
+            target,
+            "pointer inverse lands on the scaled shaped caret stop"
+        );
+    }
+
     #[test]
     fn bound_line_reads_text_from_doc() {
         use automerge::{ObjType, ROOT, transaction::Transactable};
         let mut doc = automerge::AutoCommit::new();
         let tid = doc.put_object(&ROOT, "t", ObjType::Text).unwrap();
         doc.splice_text(&tid, 0, 0, "hello").unwrap();
 
         let mut line = RichTextLine::new();
         line.bind_text(tid.clone());
         // The root arg is unused once a Text is bound.
diff --git a/ui/src/widget/text_input.rs b/ui/src/widget/text_input.rs
index 8020dd81d..f92ea5b5c 100644
--- a/ui/src/widget/text_input.rs
+++ b/ui/src/widget/text_input.rs
@@ -124,22 +124,20 @@ const MULTI_CLICK_INTERVAL: Duration = Duration::from_millis(400);
 const MULTI_CLICK_RADIUS: f64 = 4.0;
 /// Spellcheck runs immediately, but the word containing the caret stays
 /// visually quiet for this long after an edit so its underline does not
 /// flicker while the user is still forming it.
 const SPELL_EDIT_SETTLE: Duration = Duration::from_millis(250);
 /// External Hunspell sessions are persistent but still use IPC. Coalesce the
 /// prefixes of a rapidly typed non-English word while preserving prior spans.
 const EXTERNAL_SPELLCHECK_DELAY: Duration = Duration::from_millis(100);
 const ML_PAD_X: f64 = 10.0;
 const ML_PAD_Y: f64 = 8.0;
-/// Approximate glyph advance; used identically for gutter geometry and
-/// drawing so both stay aligned despite being approximate.
 const GUTTER_DIGIT_RATIO: f64 = 0.62;
 const GUTTER_PAD_L: f64 = 8.0;
 const GUTTER_PAD_R: f64 = 12.0;
 
 /// Unit the in-flight drag snaps to, set from the click ladder on press.
 #[derive(Copy, Clone, Debug, PartialEq, Eq)]
 enum DragUnit {
     Char,
     Word,
     All,
@@ -213,20 +211,23 @@ pub struct TextInput {
     single_layout: Option<RichTextLayout>,
     single_origin: Point,
     shaped_layout_signature: u64,
     /// In-progress IME composition. It is inserted only in the display
     /// layout and never exposed through value, clipboard, CRDT, or a11y.
     preedit: String,
     preedit_cursor: Option<(usize, usize)>,
     scroll_x: f64,
     last_edit_time: Option<Instant>,
     font_size_override: Option<f32>,
+    /// Theme scale captured during `build_layout`; direct measurement falls
+    /// back to the renderer when no themed layout pass has occurred.
+    layout_text_scale: Option<f32>,
     /// Renders without the rounded-rect chrome, for block-editor cells that
     /// should read as document copy, not a form field.
     plain: bool,
     /// Direct Automerge `Text` binding, wins over `on_change_path` — how
     /// `BlockEditor` binds text nested inside a `List`, which a flat string
     /// key can't address.
     bound_text: Option<ObjId>,
     /// Stamped on every inserted run so peers can highlight "what they wrote".
     local_author: Option<String>,
     /// `self.text` stays the real value; only the render substitutes bullets.
@@ -277,20 +278,22 @@ pub struct TextInput {
     enter_submits: bool,
     submit_requested: bool,
     /// The plaintext still never reaches the a11y tree or `text_review`.
     reveal: bool,
     /// Rebuilt by each `draw`; empty in single-line mode.
     lines: Vec<VisualLine>,
     /// Preserved across consecutive `Up`/`Down`; reset on any other move.
     goal_x: Option<f64>,
     scroll_y: f64,
     gutter: bool,
+    /// Width measured from the same scaled line-number style used to paint.
+    measured_gutter_width: f64,
     highlight_current_line: bool,
     /// `None` renders the whole body in one colour; `Some` colours per [`Span`] via `token_color`.
     highlighter: Option<Box<dyn Highlighter>>,
     /// `Some(0)` inserts a literal `\t`; `None` leaves Tab for focus traversal.
     tab_spaces: Option<usize>,
     /// Rebuilt only when the text changes (keyed by `hl_sig`).
     hl_spans: Vec<Vec<Span>>,
     hl_line_starts: Vec<usize>,
     hl_sig: u64,
     /// Only re-centres when the caret moves, so a wheel scroll away from it sticks.
@@ -378,20 +381,21 @@ impl TextInput {
             on_change: None,
             action: None,
             last_notified_text: String::new(),
             local_state: None,
             model_layout_dirty: false,
             crdt_bound: false,
             direct_crdt_writes: true,
             path_was_present: false,
             external_buffer: None,
             font_size_override: None,
+            layout_text_scale: None,
             plain: false,
             bound_text: None,
             local_author: None,
             secret: false,
             disabled: false,
             kind: TextInputKind::Prose,
             spellcheck: None,
             autocorrect: None,
             spell_active: false,
             spell_language,
@@ -412,20 +416,21 @@ impl TextInput {
             family: None,
             multiline: false,
             multiline_shaped: false,
             enter_submits: false,
             submit_requested: false,
             reveal: false,
             lines: Vec::new(),
             goal_x: None,
             scroll_y: 0.0,
             gutter: false,
+            measured_gutter_width: 0.0,
             highlight_current_line: false,
             highlighter: None,
             tab_spaces: None,
             hl_spans: Vec::new(),
             hl_line_starts: Vec::new(),
             hl_sig: u64::MAX,
             last_scroll_caret: None,
             last_caret_width: 2.0,
             interaction: crate::interaction::InteractionEnvironment::default(),
         }
@@ -1012,20 +1017,27 @@ impl TextInput {
     }
 
     pub fn body_line_height(&self) -> f64 {
         self.line_height()
     }
 
     pub fn gutter_width(&self) -> f64 {
         self.code_gutter_w()
     }
 
+    #[cfg(test)]
+    pub(crate) fn shaped_font_size_for_test(&self) -> Option<f32> {
+        self.single_layout
+            .as_ref()
+            .map(|layout| layout.buffer.metrics().font_size)
+    }
+
     /// Requires a prior `draw` to have built the metrics.
     pub fn byte_at_point(&self, point: Point) -> usize {
         self.position_at_point(point).byte
     }
 
     /// Exact caret position under a point, including mixed-BiDi affinity.
     pub fn position_at_point(&self, point: Point) -> TextPosition {
         self.resolve_position(point)
     }
 
@@ -1046,20 +1058,29 @@ impl TextInput {
     pub fn text_padding_x(&self, theme: &Theme) -> f64 {
         if self.plain {
             0.0
         } else {
             f64::from(theme.padding_standard)
         }
     }
 
     /// Single source of truth for both the local and any peer caret, so they line up.
     pub fn text_band(&self) -> (f64, f64) {
+        if !self.multiline
+            && !self.masked()
+            && let Some(layout) = &self.single_layout
+        {
+            return (
+                self.single_origin.y,
+                f64::from(layout.buffer.metrics().line_height),
+            );
+        }
         let text_size = self.font_size_override.unwrap_or(FONT_SIZE);
         let line_height = f64::from(text_size * LINE_HEIGHT_RATIO);
         let text_y = self.rect.y0 + (self.rect.height() - line_height) / 2.0;
         (text_y, line_height)
     }
 
     /// Requires a prior `draw` to have populated `char_x_positions`.
     fn caret_x_at(&self, theme: &Theme, position: TextPosition) -> f64 {
         if (!self.multiline || self.multiline_shaped)
             && !self.masked()
@@ -1202,20 +1223,25 @@ impl TextInput {
             ));
         }
         out
     }
 
     fn effective_font_size(&self) -> f32 {
         self.font_size_override.unwrap_or(FONT_SIZE)
     }
 
     fn line_height(&self) -> f64 {
+        if self.multiline_shaped
+            && let Some(layout) = &self.single_layout
+        {
+            return f64::from(layout.buffer.metrics().line_height);
+        }
         f64::from(self.effective_font_size() * LINE_HEIGHT_RATIO)
     }
 
     /// Falls back to one row when nothing has been laid out yet.
     pub fn content_height(&self) -> f64 {
         if self.multiline_shaped
             && let Some(layout) = &self.single_layout
         {
             return f64::from(layout.height()) + ML_PAD_Y * 2.0;
         }
@@ -1558,69 +1584,87 @@ impl TextInput {
     /// Every unmasked multiline input—including attributed source code—uses
     /// the same shaped paragraph for paint, wrapping, carets, selection,
     /// hit-testing, vertical movement, and IME composition.
     /// Rebuilds `self.single_layout` (and its signature) if the shaped
     /// spans, family or size changed since the last draw. Returns the
     /// `TextStyle` used, so gutter line numbers reuse the exact metrics.
     fn ensure_shaped_layout(
         &mut self,
         tr: &mut TextRenderer,
         theme: &Theme,
-        size: f32,
+        style: &TextStyle,
         available_width: f32,
-    ) -> TextStyle {
-        let family = self.family.clone().unwrap_or(if self.mono {
-            FontChoice::Monospace
-        } else {
-            FontChoice::SansSerif
-        });
-        // RichTextLayout owns its own cosmic-text shaping metrics rather than
-        // going through TextRenderer::draw_text, so it must receive the
-        // accessibility scale explicitly. Without this, multiline editors
-        // stayed visually tiny while the surrounding chrome and static text
-        // correctly followed Theme::text_scale.
-        let layout_size = size * theme.text_scale;
-        let style = TextStyle::new(layout_size)
-            .with_line_height(LINE_HEIGHT_RATIO)
-            .with_family(family.clone());
+    ) {
         self.refresh_highlight();
         let display = self.layout_display_text();
         let spans = self.highlighted_display_spans(theme);
         debug_assert_eq!(
             spans
                 .iter()
                 .map(|span| span.text.as_str())
                 .collect::<String>(),
             display
         );
         let signature = Self::attributed_signature(
-            self.shaped_signature(&display, &family, layout_size, Some(available_width)),
+            self.shaped_signature(&display, &style.family, style.size, Some(available_width)),
             &spans,
         );
         if self.single_layout.is_none() || self.shaped_layout_signature != signature {
             let mut layout = RichTextLayout::shape_styled(
                 &mut tr.font_system,
                 &spans,
                 &style,
                 Some(available_width),
                 TextAlign::Left,
                 Vec::new(),
                 Vec::new(),
             );
             if !self.preedit.is_empty() {
                 let start = self.cursor_pos.min(self.text.len());
                 layout.add_underline(start..start.saturating_add(self.preedit.len()));
             }
             self.single_layout = Some(layout);
             self.shaped_layout_signature = signature;
         }
-        style
+    }
+
+    fn multiline_style(&self, scale: f32) -> TextStyle {
+        let family = self.family.clone().unwrap_or(if self.mono {
+            FontChoice::Monospace
+        } else {
+            FontChoice::SansSerif
+        });
+        TextStyle::new(self.effective_font_size() * scale)
+            .with_line_height(LINE_HEIGHT_RATIO)
+            .with_family(family)
+    }
+
+    fn update_gutter_metrics(
+        &mut self,
+        tr: &mut TextRenderer,
+        renderer_style: &TextStyle,
+        scale: f32,
+    ) {
+        if !self.gutter || !self.multiline {
+            self.measured_gutter_width = 0.0;
+            return;
+        }
+        let lines = self
+            .text
+            .bytes()
+            .filter(|&byte| byte == b'\n')
+            .count()
+            .saturating_add(1);
+        let label = lines.max(10).to_string();
+        let (number_width, _) = tr.measure_style(&label, None, renderer_style);
+        self.measured_gutter_width =
+            f64::from(number_width) + (GUTTER_PAD_L + GUTTER_PAD_R) * f64::from(scale);
     }
 
     /// Keeps the caret in view by adjusting `self.scroll_y`. Only re-centres
     /// when the caret moved since the last draw, so a wheel scroll away from
     /// it sticks.
     fn update_ml_scroll(&mut self, caret_top: f32, caret_height: f32, layout_height: f32) {
         let view_height = (self.rect.height() - ML_PAD_Y * 2.0).max(1.0);
         if self.is_focused && self.last_scroll_caret != Some(self.cursor_pos) {
             if f64::from(caret_top) - self.scroll_y < 0.0 {
                 self.scroll_y = f64::from(caret_top);
@@ -1774,27 +1818,30 @@ impl TextInput {
     /// hit-testing, vertical movement and IME composition.
     fn draw_multiline_shaped(
         &mut self,
         scene: &mut Scene,
         transform: Affine,
         tr: &mut TextRenderer,
         theme: &Theme,
         shape: &RoundedRect,
     ) {
         let size = self.effective_font_size();
+        let style = self.multiline_style(theme.text_scale);
+        let renderer_style = tr.renderer_input_style(&style);
+        self.update_gutter_metrics(tr, &renderer_style, theme.text_scale);
         let left = self.ml_left();
         #[allow(
             clippy::cast_possible_truncation,
             reason = "widget width is a bounded on-screen size for vello/layout math, never near f32's range"
         )]
         let available_width = (self.rect.width() - left - ML_PAD_X).max(1.0) as f32;
-        let style = self.ensure_shaped_layout(tr, theme, size, available_width);
+        self.ensure_shaped_layout(tr, theme, &style, available_width);
 
         let caret_position = if self.preedit.is_empty() {
             self.text_to_layout_position(self.caret_position())
         } else {
             TextPosition::new(self.preedit_layout_caret())
         };
         let caret_byte = caret_position.byte;
         let Some((caret_top, caret_height, layout_height)) =
             self.single_layout.as_ref().map(|layout| {
                 let (_, top, height) = layout.caret_geometry_at(caret_position);
@@ -1854,21 +1901,21 @@ impl TextInput {
                 theme.text_primary
             };
             tr.draw_rich(scene, layout, text_transform, color);
         }
 
         self.draw_gutter_line_numbers(
             scene,
             transform,
             tr,
             theme,
-            &style,
+            &renderer_style,
             caret_byte,
             gutter_width,
         );
         self.draw_ml_caret(scene, transform, theme, caret_position);
         scene.pop_layer();
     }
 
     /// Adjusts `self.scroll_y` so the caret row stays in view, re-centring
     /// only on caret movement (matches [`Self::update_ml_scroll`]'s policy
     /// for the shaped path).
@@ -2228,20 +2275,30 @@ impl TextInput {
             Some(self.text.clone())
         } else {
             None
         }
     }
 
     /// Bypasses `draw_with_presence` — only safe on local-mode `TextInputs`
     /// with no presence path or permission scope.
     pub fn apply_layout_external(&mut self, rect: Rect) {
         self.rect = rect;
+        self.refresh_multiline_origin();
+    }
+
+    fn refresh_multiline_origin(&mut self) {
+        if self.multiline && self.multiline_shaped {
+            self.single_origin = Point::new(
+                self.rect.x0 + self.ml_left(),
+                self.rect.y0 + ML_PAD_Y - self.scroll_y,
+            );
+        }
     }
 
     #[must_use]
     pub fn with_id(mut self, id: &str) -> Self {
         self.id = id.to_string();
         self
     }
 
     /// Bind this input to one root-level document string.
     ///
@@ -2368,20 +2425,23 @@ impl TextInput {
 
     pub fn set_tab_width(&mut self, n: usize) {
         self.tab_spaces = Some(n);
     }
 
     /// Pure function of line count + font size, so geometry and painting stay identical.
     fn code_gutter_w(&self) -> f64 {
         if !self.gutter || !self.multiline {
             return 0.0;
         }
+        if self.measured_gutter_width > 0.0 {
+            return self.measured_gutter_width;
+        }
         let lines = self
             .text
             .bytes()
             .filter(|&b| b == b'\n')
             .count()
             .saturating_add(1);
         // Counted with integer division rather than `log10().floor()` so a
         // float-precision wobble near a power of ten can't under-count a digit.
         let mut digits = 0u32;
         let mut n = lines;
@@ -3504,23 +3564,27 @@ impl Widget for TextInput {
                 // existed. An error is likewise not evidence of deletion.
             }
         }
         self.clamp_to_text();
         self.last_notified_text.clone_from(&self.text);
     }
 
     fn build_layout(
         &mut self,
         taffy: &mut TaffyTree<()>,
-        _theme: &Theme,
+        theme: &Theme,
         node_map: &mut std::collections::HashMap<NodeId, *mut dyn Widget>,
     ) -> NodeId {
+        if self.layout_text_scale != Some(theme.text_scale) {
+            self.layout_text_scale = Some(theme.text_scale);
+            self.model_layout_dirty |= self.multiline;
+        }
         // Multiline is measured (grows with content, see `measure`); single-line is a fixed 40px row.
         let height = if self.multiline {
             Dimension::auto()
         } else {
             Dimension::length(40.0_f32.max(self.interaction.minimum_target()))
         };
         let node = taffy.leaf_node(Style {
             size: Size {
                 width: Dimension::percent(1.0),
                 height,
@@ -3532,38 +3596,84 @@ impl Widget for TextInput {
     }
 
     fn apply_layout(&mut self, taffy: &TaffyTree<()>, node: NodeId, origin: Point) {
         let layout = taffy.layout(node).copied().unwrap_or_default();
         self.rect = Rect::new(
             origin.x + f64::from(layout.location.x),
             origin.y + f64::from(layout.location.y),
             origin.x + f64::from(layout.location.x) + f64::from(layout.size.width),
             origin.y + f64::from(layout.location.y) + f64::from(layout.size.height),
         );
+        self.refresh_multiline_origin();
     }
 
     /// Single-line keeps its fixed row height from `build_layout` (ZERO
     /// here). Embedded callers use `apply_layout_external` and never reach this.
     fn measure(
         &mut self,
         known: taffy::Size<Option<f32>>,
         available: taffy::Size<taffy::AvailableSpace>,
         text_renderer: &mut TextRenderer,
     ) -> taffy::Size<f32> {
         if !self.multiline {
             self.model_layout_dirty = false;
             return taffy::Size::ZERO;
         }
         let width = known.width.unwrap_or(match available.width {
             taffy::AvailableSpace::Definite(w) => w,
             _ => 400.0,
         });
+        if !self.masked() {
+            let scale = self
+                .layout_text_scale
+                .unwrap_or_else(|| text_renderer.text_scale());
+            let style = self.multiline_style(scale);
+            let renderer_style = text_renderer.renderer_input_style(&style);
+            self.update_gutter_metrics(text_renderer, &renderer_style, scale);
+            let available_width = (f64::from(width) - self.ml_left() - ML_PAD_X).max(1.0) as f32;
+            let display = self.layout_display_text();
+            let signature =
+                self.shaped_signature(&display, &style.family, style.size, Some(available_width));
+            if self.single_layout.is_none() || self.shaped_layout_signature != signature {
+                let mut layout = RichTextLayout::shape_plain(
+                    &mut text_renderer.font_system,
+                    &display,
+                    &style,
+                    Some(available_width),
+                );
+                if !self.preedit.is_empty() {
+                    let start = self.cursor_pos.min(self.text.len());
+                    layout.add_underline(start..start.saturating_add(self.preedit.len()));
+                }
+                self.single_layout = Some(layout);
+                self.shaped_layout_signature = signature;
+            }
+            self.multiline_shaped = true;
+            self.lines.clear();
+            self.refresh_multiline_origin();
+            let height = self
+                .single_layout
+                .as_ref()
+                .map_or(f64::from(style.line_height_px()), |layout| {
+                    f64::from(layout.height())
+                })
+                + ML_PAD_Y * 2.0;
+            self.model_layout_dirty = false;
+            #[allow(
+                clippy::cast_possible_truncation,
+                reason = "content height is a bounded on-screen size for taffy layout, never near f32's range"
+            )]
+            return taffy::Size {
+                width,
+                height: height as f32,
+            };
+        }
         let avail_w = (f64::from(width) - self.ml_left() - ML_PAD_X).max(1.0);
         self.build_lines(text_renderer, avail_w);
         #[allow(
             clippy::cast_possible_truncation,
             reason = "content height is a bounded on-screen size for taffy layout, never near f32's range"
         )]
         let height = self.content_height() as f32;
         self.model_layout_dirty = false;
         taffy::Size { width, height }
     }
@@ -6742,20 +6852,210 @@ mod tests {
         assert!(
             large_line_h >= normal_line_h * 1.9,
             "editor line metric scales with the theme ({large_line_h} vs {normal_line_h})"
         );
         assert!(
             large_height >= normal_height * 1.9,
             "editor paragraph geometry scales with the theme ({large_height} vs {normal_height})"
         );
     }
 
+    #[test]
+    fn multiline_measure_uses_the_same_scaled_shaped_rows_as_draw() {
+        let text = "A long wrapping line whose measured height must match the caret rows produced by the shaped draw path at large text.";
+        let mut input = TextInput::local()
+            .multiline(true)
+            .with_font_size(14.0)
+            .with_initial_value(text);
+        let mut renderer = TextRenderer::new();
+        renderer.set_text_scale(2.0);
+        let measured = Widget::measure(
+            &mut input,
+            taffy::Size {
+                width: Some(180.0),
+                height: None,
+            },
+            taffy::Size {
+                width: taffy::AvailableSpace::Definite(180.0),
+                height: taffy::AvailableSpace::MaxContent,
+            },
+            &mut renderer,
+        );
+
+        input.apply_layout_external(Rect::new(0.0, 0.0, 180.0, f64::from(measured.height)));
+        let theme = Theme::dark().with_text_scale(2.0);
+        draw_with_theme(&mut input, &theme);
+        let layout = input
+            .single_layout
+            .as_ref()
+            .expect("shaped multiline layout");
+        let expected_height = layout.height() + (ML_PAD_Y * 2.0) as f32;
+        assert!(
+            (measured.height - expected_height).abs() < 0.1,
+            "measure {measured:?} must use drawn shaped height {expected_height}"
+        );
+        let last_row = layout.visual_line_index(input.text_to_layout_byte(text.len()));
+        let caret = input.caret_rect(&theme, text.len());
+        assert_eq!(
+            (caret.y0 / caret.height()).floor() as usize,
+            last_row,
+            "caret row and shaped visual row index agree"
+        );
+    }
+
+    #[test]
+    fn multiline_measure_uses_build_layout_theme_scale_when_renderer_is_stale() {
+        let text = "The layout theme owns accessibility scale even when a retained renderer still carries its previous frame value.";
+        let mut input = TextInput::local().multiline(true).with_initial_value(text);
+        let large = Theme::dark().with_text_scale(2.0);
+        let mut taffy = TaffyTree::<()>::new();
+        let mut node_map = std::collections::HashMap::new();
+        let _ = Widget::build_layout(&mut input, &mut taffy, &large, &mut node_map);
+
+        let mut renderer = TextRenderer::new();
+        assert_eq!(renderer.text_scale(), 1.0, "stale renderer precondition");
+        let measured_large = Widget::measure(
+            &mut input,
+            taffy::Size {
+                width: Some(180.0),
+                height: None,
+            },
+            taffy::Size {
+                width: taffy::AvailableSpace::Definite(180.0),
+                height: taffy::AvailableSpace::MaxContent,
+            },
+            &mut renderer,
+        );
+        input.apply_layout_external(Rect::new(0.0, 0.0, 180.0, f64::from(measured_large.height)));
+        draw_with_theme(&mut input, &large);
+        let drawn_large = input.content_height() as f32;
+        assert!((measured_large.height - drawn_large).abs() < 0.1);
+
+        let normal = Theme::dark();
+        let mut taffy = TaffyTree::<()>::new();
+        let mut node_map = std::collections::HashMap::new();
+        let _ = Widget::build_layout(&mut input, &mut taffy, &normal, &mut node_map);
+        let measured_normal = Widget::measure(
+            &mut input,
+            taffy::Size {
+                width: Some(180.0),
+                height: None,
+            },
+            taffy::Size {
+                width: taffy::AvailableSpace::Definite(180.0),
+                height: taffy::AvailableSpace::MaxContent,
+            },
+            &mut renderer,
+        );
+        input.apply_layout_external(Rect::new(
+            0.0,
+            0.0,
+            180.0,
+            f64::from(measured_normal.height),
+        ));
+        draw_with_theme(&mut input, &normal);
+        assert!((measured_normal.height - input.content_height() as f32).abs() < 0.1);
+        assert!(
+            measured_large.height > measured_normal.height * 1.8,
+            "same instance remeasures from large text back to normal"
+        );
+    }
+
+    #[test]
+    fn measured_multiline_pointer_geometry_tracks_applied_origin_before_draw() {
+        let text = "first wrapped row continues for a while before the second hard line\nsecond";
+        let mut input = TextInput::local().multiline(true).with_initial_value(text);
+        let mut renderer = TextRenderer::new();
+        renderer.set_text_scale(2.0);
+        let measured = Widget::measure(
+            &mut input,
+            taffy::Size {
+                width: Some(180.0),
+                height: None,
+            },
+            taffy::Size {
+                width: taffy::AvailableSpace::Definite(180.0),
+                height: taffy::AvailableSpace::MaxContent,
+            },
+            &mut renderer,
+        );
+        input.apply_layout_external(Rect::new(
+            100.0,
+            50.0,
+            280.0,
+            50.0 + f64::from(measured.height),
+        ));
+        let second = text.find('\n').expect("hard break") + 1;
+        let (x, top, height) = input
+            .single_layout
+            .as_ref()
+            .expect("measurement retained shaped rows")
+            .caret_geometry(input.text_to_layout_byte(second));
+        let point = Point::new(
+            input.rect.x0 + input.ml_left() + f64::from(x) + 1.0,
+            input.rect.y0 + ML_PAD_Y + f64::from(top + height / 2.0),
+        );
+        assert_eq!(
+            input.byte_at_point(point),
+            second,
+            "pointer uses the applied widget origin before the first draw"
+        );
+    }
+
+    #[test]
+    fn scaled_multiline_geometry_refreshes_across_model_undo_redo_replay() {
+        let long = "undo and redo replay model text through the same widget, including a long line that wraps at large text";
+        let theme = Theme::dark().with_text_scale(2.0);
+        let mut input = TextInput::local().multiline(true).with_initial_value(long);
+        input.apply_layout_external(Rect::new(0.0, 0.0, 180.0, 400.0));
+        draw_with_theme(&mut input, &theme);
+        let long_height = input.content_height();
+        let long_rows = input
+            .single_layout
+            .as_ref()
+            .expect("redo source layout")
+            .buffer
+            .layout_runs()
+            .count();
+        assert!(long_rows > 1, "precondition: large text wraps");
+
+        input.set_text("undo");
+        input.set_cursor_pos(input.value().len());
+        draw_with_theme(&mut input, &theme);
+        assert_eq!(
+            input
+                .single_layout
+                .as_ref()
+                .expect("undo layout")
+                .buffer
+                .layout_runs()
+                .count(),
+            1
+        );
+        assert!(input.content_height() < long_height);
+
+        input.set_text(long);
+        input.set_cursor_pos(long.len());
+        draw_with_theme(&mut input, &theme);
+        assert_eq!(
+            input
+                .single_layout
+                .as_ref()
+                .expect("redo layout")
+                .buffer
+                .layout_runs()
+                .count(),
+            long_rows
+        );
+        assert!((input.content_height() - long_height).abs() < 0.1);
+    }
+
     /// Mirrors the handler's own `padding_x = 10.0`; assumes `scroll_x == 0`.
     fn x_for_byte(ti: &TextInput, b: usize) -> f64 {
         ti.rect.x0 + 10.0 + ti.char_x_positions()[b]
     }
 
     #[test]
     fn shift_arrow_extends_selection_by_char() {
         let mut ti = TextInput::local().with_initial_value("abcdef");
         ti.set_focus(true);
         ti.set_cursor_pos(3);
