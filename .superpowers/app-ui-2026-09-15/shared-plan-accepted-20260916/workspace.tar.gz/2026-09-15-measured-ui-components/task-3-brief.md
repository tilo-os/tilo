# Measured UI Components Implementation Plan

> **For agentic workers:** REQUIRED SUB-SKILL: Use superpowers:subagent-driven-development (recommended) or superpowers:executing-plans to implement this plan task-by-task. Steps use checkbox (`- [ ]`) syntax for tracking.

**Goal:** Repair shared sizing and interaction contracts so app authors get readable, balanced layouts with fewer manual measurements.

**Architecture:** Add one resolved-text normalization boundary while preserving existing relative APIs. Repair EmptyState, rich editor, opt-in scrolling editor fill and measured actionable Toolbar overflow. App composition migrations consume existing Card/Actions/FormPage rather than inventing another layout system.

**Tech Stack:** Rust, Taffy, cosmic-text, Vello and qOS Widget lifecycle.

**Spec:** `docs/superpowers/specs/2026-09-15-app-ui-balance.md`

## Global Constraints

- Reuse the repository Cargo target cache; do not rebuild all dependencies into a new target directory without a concrete build-isolation need. Isolate runtime captures with task-specific HOME and XDG_CONFIG_HOME/XDG_DATA_HOME/XDG_CACHE_HOME/XDG_STATE_HOME, separately from build caches.

- Prioritize ordinary100% and narrow layout as well as200% text.
- Preserve primary actions, keyboard access, state and explicit manual dimensions.
- Keep legacy renderer-relative font APIs compatible; theme-resolved fonts must scale once.
- Do not globally change primitive padding or reinterpret explicit fixed sizes.
- Preserve unrelated working changes and untracked Scratchpad ownership.
- No pushes, merges, publishing or dependency upgrades.
- Existing linked worktree /Users/xaver/dev/qos-macos-shell; sequential implementers and scoped reviews.
- Focused RED/GREEN behavior regressions before implementation; run relevant existing UI tests once before scoped commit. CARGO_BUILD_JOBS=4, CARGO_PROFILE_DEV_DEBUG=0, CARGO_PROFILE_TEST_DEBUG=0.
- Every task report includes exact commands/results, self-review, screenshot paths if requested, and remaining gaps. No subagents from implementers.

### Task 3: Opt-in full writing surface

**Files:** `ui/src/widget/scrollable.rs`, scoped tests; minimal `apps/scratchpad/src/lib.rs` opt-in only after framework test passes.

**Interfaces:** Produces `Scrollable::with_content_min_viewport_height()` builder, default false, preserving intrinsic overflow and existing explicit child dimensions. Consume existing measured layout hooks. For explicit fixed-height children, preserve fixed contract rather than force viewport min; document this distinction.

- [ ] Scratchpad's38px editor is **not** inherently a wrong multiline minimum: TextInput::build_layout uses auto height and measures content; Scrollable::fill_parent_height grows viewport only (scrollable.rs972/995). Empty short fields should stay compact in forms. Add opt-in `Scrollable::with_content_min_viewport_height()` (or equivalent existing API if discovered) setting the direct child's minimum height to available viewport during measured layout, while retaining intrinsic height for overflowing content. Default false. The Widget prepaint hook explicitly permits changing only its own node style: do not mutate the child node through that hook. Implement the minimum via an owned wrapper with its own hook/inherited viewport decision, or a bounded layout-protocol extension reviewed separately. This is preferable to globally expanding multiline inputs.
- [ ] Prove empty editor fills viewport, long editor exceeds viewport and scrolls, short form multiline remains content-sized, footer stays visible, clicking lower empty area focuses/positions caret. Then one-line Scratchpad opt-in on its existing Scrollable chain (`apps/scratchpad/src/lib.rs:116–124`) preserves original source and all action bindings. Coordinate that app edit with controller.

- [ ] Preserve original Scratchpad file backed up at `.superpowers/app-ui-2026-09-15/scratchpad-original/lib.rs`; minimal diff only, do not stage pre-existing untracked app/manifests. Save the app-only patch in this task's report workspace; framework changes may be committed independently. The user explicitly authorized improving every app; owner task is finished, so no permission pause.
- [ ] Recapture Scratchpad wide/narrow/200%, inspect empty writing area, edit and save via existing action binding, then reopen isolated profile and verify persisted body. Confirm field remains scrollable for long content and footer stays reachable.


- [ ] Integration-discovered first-wheel symptom: the Scratchpad capture harness fails to move the outer scroll area. A visible final-line fixture now reproduces1079.375px content inside1079px bounds, consuming the first wheel in0.375px internal overflow. Earlier trailing-empty-line fixtures did not reproduce the same content extent. Keep exact behavioral evidence and normal theme construction. Scope includes a narrowly verified intrinsic multiline measurement correction in `ui/src/widget/text_input.rs` (round-up containment is a candidate, not a substitute for diagnosis). Add a real first-wheel regression and preserve explicit/manual heights, single-line behavior and current shaped caret/selection/measurement guarantees. Do not globally alter scroll event consumption. Report the source addition and exact RED/GREEN evidence.

- [ ] Verified second-click focus defect: Scrollable currently preassigns its own focus before child dispatch; an already-focused TextInput consumes the press without assigning focus again, so typing is lost. Defer background focus fallback until a child leaves the press unhandled; retain scrollbar focus, explicit child focus changes and outside-pane behavior. Test repeated click/typing with opt-in and default Scrollable plus existing pane/bar focus cases.
