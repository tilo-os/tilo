# Shared measured UI final owned review

Only the listed owned commits are included. Other concurrent changes on this branch are excluded. Final source reference73dde03c6; subsequentdd4538234 docs only. Each patch is an owned commit, in integration order. Task reports/reviews in durable audit implementation directory supply validation and earlier finding history.

## cec5c10c7
```diff
commit cec5c10c7a21781b4afdeac88452f8134ae5b8d5
Author:     Xaver Emmerling <xaver@Mac.lan>
AuthorDate: Wed Sep 16 07:20:58 2026 -0700
Commit:     Xaver Emmerling <xaver@Mac.lan>
CommitDate: Wed Sep 16 07:20:58 2026 -0700

    fix(ui): preserve intrinsic card height
---
 ui/src/widget/card.rs             |   8 +-
 ui/src/widget/card_composition.rs | 298 +++++++++++++++++++++++++++++++++++++-
 2 files changed, 302 insertions(+), 4 deletions(-)

diff --git a/ui/src/widget/card.rs b/ui/src/widget/card.rs
index 5783c60d2..0c0e679a6 100644
--- a/ui/src/widget/card.rs
+++ b/ui/src/widget/card.rs
@@ -175,7 +175,9 @@ impl Widget for Card {
                 },
                 min_size: Size {
                     width: length(0.0_f32),
-                    height: length(0.0_f32),
+                    // Intrinsic Grid rows need this item's automatic block minimum;
+                    // `flex_shrink` does not protect an item in Grid sizing.
+                    height: taffy::Dimension::auto(),
                 },
                 ..Default::default()
             },
@@ -414,7 +416,9 @@ impl CardGrid {
             },
             min_size: Size {
                 width: length(0.0_f32),
-                height: length(0.0_f32),
+                // Intrinsic Grid rows need this item's automatic block minimum;
+                // `flex_shrink` does not protect an item in Grid sizing.
+                height: taffy::Dimension::auto(),
             },
             flex_shrink: 0.0,
             align_self: Some(taffy::AlignSelf::Start),
diff --git a/ui/src/widget/card_composition.rs b/ui/src/widget/card_composition.rs
index 2790829cc..99520740c 100644
--- a/ui/src/widget/card_composition.rs
+++ b/ui/src/widget/card_composition.rs
@@ -118,7 +118,9 @@ impl Widget for ContentCard {
                 },
                 min_size: Size {
                     width: length(0.0_f32),
-                    height: length(0.0_f32),
+                    // Intrinsic Grid rows need this item's automatic block minimum;
+                    // `flex_shrink` does not protect an item in Grid sizing.
+                    height: auto(),
                 },
                 flex_shrink: 0.0,
                 padding: taffy::Rect {
@@ -222,7 +224,9 @@ impl Widget for Actions {
 mod tests {
     use super::*;
     use crate::headless::{FrameHarness, InspectionNode};
-    use crate::widget::{Card, CardGrid};
+    use crate::widget::{Card, CardGrid, Column, Container, Scrollable};
+    use std::cell::Cell;
+    use std::rc::Rc;
 
     fn fixture() -> Element {
         Box::new(CardGrid::content_sized(vec![
@@ -265,6 +269,121 @@ mod tests {
         }
     }
 
+    fn find<'a>(node: &'a InspectionNode, id: &str) -> &'a InspectionNode {
+        if node.test_id.as_deref() == Some(id) {
+            return node;
+        }
+        node.children
+            .iter()
+            .find_map(|child| find_optional(child, id))
+            .unwrap_or_else(|| panic!("missing inspection node {id:?}"))
+    }
+
+    fn find_optional<'a>(node: &'a InspectionNode, id: &str) -> Option<&'a InspectionNode> {
+        (node.test_id.as_deref() == Some(id))
+            .then_some(node)
+            .or_else(|| {
+                node.children
+                    .iter()
+                    .find_map(|child| find_optional(child, id))
+            })
+    }
+
+    fn automatic_card(index: usize) -> Element {
+        Box::new(
+            Card::composed(Box::new(Text::new(
+                &"A useful multi-line description that must remain inside its own card. ".repeat(3),
+            )))
+            .with_header(Box::new(
+                Container::new()
+                    .with_no_padding()
+                    .with_height(40.0)
+                    .with_child(Box::new(Text::new(&format!("Application {index}")))),
+            ))
+            .with_footer(Box::new(Actions::new(Button::new(
+                &format!("details-{index}"),
+                "View details",
+                None,
+            )))),
+        )
+    }
+
+    fn standalone_stack_fixture(invocations: Rc<Cell<usize>>) -> Element {
+        let mut content = Column::new()
+            .with_no_padding()
+            .with_intrinsic_height()
+            .with_gap(8.0);
+        for index in 0..8 {
+            content = content.push(automatic_card(index));
+        }
+        content = content
+            .push(Box::new(
+                Text::new("All applications").with_id("trailing-heading"),
+            ))
+            .push(Box::new(
+                Button::new("final-action", "Open all applications", None).on_click(move || {
+                    invocations.set(invocations.get() + 1);
+                }),
+            ));
+        Box::new(Scrollable::new_vertical().with_child(Box::new(content)))
+    }
+
+    fn section_grid(prefix: &str, count: usize) -> Element {
+        Box::new(CardGrid::content_sized(
+            (0..count)
+                .map(|index| {
+                    Box::new(Card::composed(Box::new(
+                        Container::new()
+                            .with_no_padding()
+                            .with_height(72.0)
+                            .with_child(Box::new(Text::new(&format!("{prefix} card {index}")))),
+                    ))) as Element
+                })
+                .collect(),
+        ))
+    }
+
+    fn section_fixture(wide: bool) -> Element {
+        let content = if wide {
+            let ready = Column::new()
+                .with_no_padding()
+                .with_intrinsic_height()
+                .with_gap(8.0)
+                .push(Box::new(Text::new("Ready").with_id("ready-heading")))
+                .push(Box::new(Text::new("Installed applications")))
+                .push(section_grid("ready", 6));
+            let discover = Column::new()
+                .with_no_padding()
+                .with_intrinsic_height()
+                .with_gap(8.0)
+                .push(Box::new(Text::new("Discover").with_id("discover-heading")))
+                .push(Box::new(Text::new("Available applications")))
+                .push(section_grid("discover", 4));
+            Column::new()
+                .with_no_padding()
+                .with_intrinsic_height()
+                .with_gap(0.0)
+                .push(Box::new(ready))
+                .push(Box::new(
+                    Container::new().with_no_padding().with_height(16.0),
+                ))
+                .push(Box::new(discover))
+        } else {
+            Column::new()
+                .with_no_padding()
+                .with_intrinsic_height()
+                .with_gap(8.0)
+                .push(Box::new(Text::new("Ready").with_id("ready-heading")))
+                .push(section_grid("ready", 6))
+                .push(Box::new(
+                    Container::new().with_no_padding().with_height(16.0),
+                ))
+                .push(Box::new(Text::new("Discover").with_id("discover-heading")))
+                .push(section_grid("discover", 4))
+        };
+        Box::new(Scrollable::new_vertical().with_child(Box::new(content)))
+    }
+
     fn long_fixture() -> Element {
         Box::new(CardGrid::content_sized(
             (0..3)
@@ -386,6 +505,181 @@ mod tests {
         assert!((rect(last).y1 - 400.0).abs() < 1.0);
     }
 
+    #[test]
+    fn automatic_content_cards_expand_a_short_scroll_stack() {
+        let invocations = Rc::new(Cell::new(0));
+        let mut harness = FrameHarness::new_with_theme(
+            crate::State::new(),
+            standalone_stack_fixture(invocations.clone()),
+            (480, 360),
+            Theme::dark(),
+        );
+        let before = harness.inspection();
+        let content = &before.root.children[0];
+        let cards = &content.children[..8];
+        for (index, card) in cards.iter().enumerate() {
+            assert_contained(card, rect(card));
+            if let Some(next) = cards.get(index + 1) {
+                assert!(
+                    rect(next).y0 >= rect(card).y1 + 7.0,
+                    "card {index} {:?} overlaps next card {:?}",
+                    rect(card),
+                    rect(next)
+                );
+            }
+        }
+        let trailing = rect(find(&before.root, "trailing-heading"));
+        assert!(trailing.y0 >= rect(cards.last().unwrap()).y1 + 7.0);
+        assert!(
+            rect(content).height() > 360.0,
+            "content must own scroll extent"
+        );
+        assert_eq!(rect(&before.root).height(), 360.0, "viewport stays fixed");
+
+        harness.click_at(8.0, 8.0);
+        harness.scroll(0.0, -10_000.0);
+        let final_rect = rect(find(&harness.inspection().root, "final-action"));
+        assert!(
+            final_rect.y0 >= 0.0 && final_rect.y1 <= 360.0,
+            "final action must be reachable after scrolling: {final_rect:?}"
+        );
+        harness.click_named("final-action").unwrap();
+        assert_eq!(invocations.get(), 1, "pointer activation fires once");
+        assert_eq!(
+            harness
+                .tab_through()
+                .last()
+                .and_then(|(_, name)| name.as_deref()),
+            Some("Open all applications")
+        );
+        harness
+            .perform_named("final-action", &crate::a11y::Action::Activate)
+            .unwrap();
+        assert_eq!(invocations.get(), 2, "focused activation fires once");
+    }
+
+    #[test]
+    fn automatic_legacy_card_expands_in_a_short_intrinsic_grid() {
+        let mut rows = Column::new()
+            .with_no_padding()
+            .with_intrinsic_height()
+            .with_gap(12.0);
+        for index in 0..6 {
+            rows = rows.push(Box::new(
+                Container::new()
+                    .with_no_padding()
+                    .with_height(40.0)
+                    .with_child(Box::new(
+                        Text::new(&format!("Format control {index}"))
+                            .with_id(format!("format-{index}")),
+                    )),
+            ));
+        }
+        let content = Column::new()
+            .with_no_padding()
+            .with_intrinsic_height()
+            .with_gap(20.0)
+            .push(Box::new(Card::titled("Region formats", Box::new(rows))))
+            .push(Box::new(Text::new("Preview").with_id("preview-heading")));
+        let harness = FrameHarness::new(
+            crate::State::new(),
+            Box::new(Scrollable::new_vertical().with_child(Box::new(content))),
+            (480, 360),
+        );
+        let snapshot = harness.inspection();
+        let content = &snapshot.root.children[0];
+        let card = &content.children[0];
+        let last_row = rect(find(card, "format-5"));
+        let preview = rect(find(&snapshot.root, "preview-heading"));
+        assert!(
+            last_row.y1 <= rect(card).y1 + 1.0,
+            "{last_row:?} escapes {:?}",
+            rect(card)
+        );
+        assert!(
+            preview.y0 >= rect(card).y1 + 19.0,
+            "preview {preview:?} overlaps legacy card {:?}",
+            rect(card)
+        );
+        assert!(rect(content).height() > 360.0);
+        assert_eq!(rect(&snapshot.root).height(), 360.0);
+    }
+
+    #[test]
+    fn nested_card_grids_propagate_content_minimum_to_following_sections() {
+        for (wide, viewport) in [(false, (480, 360)), (true, (1000, 360))] {
+            let harness = FrameHarness::new_with_theme(
+                crate::State::new(),
+                section_fixture(wide),
+                viewport,
+                Theme::dark(),
+            );
+            let snapshot = harness.inspection();
+            let content = &snapshot.root.children[0];
+            let (ready_grid, discover_grid) = if wide {
+                (
+                    content.children[0].children.last().unwrap(),
+                    content.children[2].children.last().unwrap(),
+                )
+            } else {
+                (&content.children[1], &content.children[4])
+            };
+            let ready_last_bottom = ready_grid
+                .children
+                .iter()
+                .map(|card| rect(card).y1)
+                .fold(f64::NEG_INFINITY, f64::max);
+            let discover_last_bottom = discover_grid
+                .children
+                .iter()
+                .map(|card| rect(card).y1)
+                .fold(f64::NEG_INFINITY, f64::max);
+            assert!(ready_last_bottom <= rect(ready_grid).y1 + 1.0);
+            assert!(discover_last_bottom <= rect(discover_grid).y1 + 1.0);
+            assert!(
+                rect(find(content, "discover-heading")).y0 >= ready_last_bottom + 15.0,
+                "{viewport:?}: discover section begins before ready cards end"
+            );
+            assert!(
+                rect(&snapshot.root.children[0]).height() > f64::from(viewport.1),
+                "{viewport:?}: section content must exceed the fixed viewport"
+            );
+        }
+    }
+
+    #[test]
+    fn short_card_stack_resize_and_text_scale_match_fresh_geometry() {
+        fn geometry(node: &InspectionNode) -> Vec<[f64; 4]> {
+            let mut all = vec![node.rect];
+            for child in &node.children {
+                all.extend(geometry(child));
+            }
+            all
+        }
+
+        for scale in [1.0, 2.0] {
+            let theme = Theme::dark().with_text_scale(scale);
+            let mut resized = FrameHarness::new_with_theme(
+                crate::State::new(),
+                section_fixture(true),
+                (1000, 360),
+                theme.clone(),
+            );
+            resized.resize((480, 360)).unwrap();
+            resized.resize((1000, 360)).unwrap();
+            let fresh = FrameHarness::new_with_theme(
+                crate::State::new(),
+                section_fixture(true),
+                (1000, 360),
+                theme,
+            );
+            assert_eq!(
+                geometry(&resized.inspection().root),
+                geometry(&fresh.inspection().root)
+            );
+        }
+    }
+
     #[test]
     fn actions_keep_manual_sizes_and_secondary_then_primary_order() {
         let actions = Actions::new(Button::new("primary", "Primary", None).with_size(97.0, 35.0))

```

## 93b56dc1f
```diff
commit 93b56dc1fee3668915d9d5e03bf74905b2e73342
Author:     Xaver Emmerling <xaver@Mac.lan>
AuthorDate: Wed Sep 16 07:29:11 2026 -0700
Commit:     Xaver Emmerling <xaver@Mac.lan>
CommitDate: Wed Sep 16 07:29:11 2026 -0700

    test(ui): cover card keyboard activation
---
 ui/src/app.rs                        |  62 +++++++++-------
 ui/src/app/card_composition_tests.rs | 136 ++++++++++++++++++++++++++++++++++-
 2 files changed, 170 insertions(+), 28 deletions(-)

diff --git a/ui/src/app.rs b/ui/src/app.rs
index bf1bd778c..011d69eaa 100644
--- a/ui/src/app.rs
+++ b/ui/src/app.rs
@@ -894,6 +894,41 @@ impl App {
         }
     }
 
+    /// Apply the native host's fallback for an Enter/Space press that the
+    /// focused widget did not consume during normal event dispatch.
+    fn handle_unconsumed_activation_key(&mut self, event: &WindowEvent, handled: &mut bool) {
+        if *handled
+            || !matches!(
+                event,
+                WindowEvent::KeyboardInput {
+                    event: winit::event::KeyEvent {
+                        logical_key: winit::keyboard::Key::Named(
+                            winit::keyboard::NamedKey::Enter | winit::keyboard::NamedKey::Space,
+                        ),
+                        state: winit::event::ElementState::Pressed,
+                        ..
+                    },
+                    ..
+                }
+            )
+        {
+            return;
+        }
+        let Some(focused) = self.focused_node else {
+            return;
+        };
+        let activated = self
+            .dispatch_node(focused, |widget, doc, root| {
+                widget.perform_action(&crate::a11y::Action::Activate, doc, root)
+            })
+            .unwrap_or(false);
+        if activated {
+            *handled = true;
+            self.needs_sync = true;
+            self.layout_dirty = true;
+        }
+    }
+
     fn initial_presence_context() -> PresenceCtx {
         // Own identity, in preference order: the handle announced on `Hello`,
         // then the fallback app id. Anything else is somebody else and gets
@@ -8530,32 +8565,7 @@ impl AppHandler {
 
         // If no widget consumed Enter/Space (text inputs do), activate
         // the focused control the same way a mouse click would.
-        if !handled
-            && let WindowEvent::KeyboardInput {
-                event:
-                    winit::event::KeyEvent {
-                        logical_key:
-                            winit::keyboard::Key::Named(
-                                winit::keyboard::NamedKey::Enter | winit::keyboard::NamedKey::Space,
-                            ),
-                        state: winit::event::ElementState::Pressed,
-                        ..
-                    },
-                ..
-            } = event
-            && let Some(fid) = app.focused_node
-        {
-            let did = app
-                .dispatch_node(fid, |widget, doc, root| {
-                    widget.perform_action(&crate::a11y::Action::Activate, doc, root)
-                })
-                .unwrap_or(false);
-            if did {
-                handled = true;
-                app.needs_sync = true;
-                app.layout_dirty = true;
-            }
-        }
+        app.handle_unconsumed_activation_key(&event, &mut handled);
 
         // A focused range control consumes Left/Right; Up/Down and Tab
         // still move focus. Modifiers scale the step:
diff --git a/ui/src/app/card_composition_tests.rs b/ui/src/app/card_composition_tests.rs
index 0ceda7c51..5aad70243 100644
--- a/ui/src/app/card_composition_tests.rs
+++ b/ui/src/app/card_composition_tests.rs
@@ -1,6 +1,11 @@
 use super::*;
-use crate::widget::{Actions, Button, Card, CardGrid, Element, Text};
+use crate::widget::{Actions, Button, Card, CardGrid, Column, Element, Scrollable, Text};
 use automerge::ReadDoc;
+use std::cell::Cell;
+use std::rc::Rc;
+use winit::dpi::PhysicalPosition;
+use winit::event::{ElementState, KeyEvent, MouseScrollDelta, TouchPhase, WindowEvent};
+use winit::keyboard::{Key, KeyLocation, NamedKey, PhysicalKey};
 
 fn fixture() -> App {
     let cards: Vec<Element> = (0..3)
@@ -35,8 +40,12 @@ fn fixture() -> App {
 }
 
 fn layout(app: &mut App, width: u32) {
+    layout_in(app, width, 1600);
+}
+
+fn layout_in(app: &mut App, width: u32, height: u32) {
     app.layout_dirty = true;
-    run_layout_pass(app, app.root_node.unwrap(), width, 1600, 1.0, false, None).unwrap();
+    run_layout_pass(app, app.root_node.unwrap(), width, height, 1.0, false, None).unwrap();
 }
 
 fn controls(app: &App) -> Vec<(String, KurboRect)> {
@@ -116,3 +125,126 @@ fn content_card_host_geometry_focus_click_and_resize_are_coherent_before_paint()
         }
     }
 }
+
+fn named_key_event(key: NamedKey, state: ElementState) -> WindowEvent {
+    let logical_key = Key::Named(key);
+    let event = KeyEvent::synthetic(
+        winit::event::RawKeyEvent {
+            physical_key: PhysicalKey::Unidentified(winit::keyboard::NativeKeyCode::Unidentified),
+            state,
+        },
+        logical_key.clone(),
+        None,
+        KeyLocation::Standard,
+        false,
+        None,
+        logical_key,
+    );
+    WindowEvent::KeyboardInput {
+        device_id: winit::event::DeviceId::dummy(),
+        event,
+        is_synthetic: false,
+    }
+}
+
+fn send_widget_then_host_fallback(app: &mut App, event: &WindowEvent) -> bool {
+    let mut handled = false;
+    let mut focus_target = None;
+    app.root_widget.handle_event(
+        event,
+        1.0,
+        &app.modifiers,
+        &mut app.state.doc,
+        &app.state.root,
+        &mut handled,
+        &mut focus_target,
+        app.root_node.unwrap(),
+        &app.taffy,
+    );
+    if let Some(target) = focus_target {
+        app.set_focused_node(Some(target));
+    }
+    app.handle_unconsumed_activation_key(event, &mut handled);
+    handled
+}
+
+#[test]
+fn short_card_stack_scroll_and_tab_activate_final_action_once_from_enter() {
+    let invocations = Rc::new(Cell::new(0));
+    let activated = invocations.clone();
+    let mut content = Column::new()
+        .with_no_padding()
+        .with_intrinsic_height()
+        .with_gap(8.0);
+    for index in 0..8 {
+        content = content.push(Box::new(Card::composed(Box::new(Text::new(&format!(
+            "Application {index}: {}",
+            "A useful multi-line description that remains inside its card. ".repeat(3)
+        ))))));
+    }
+    content = content.push(Box::new(
+        Button::new("final-action", "Open all applications", None).on_click(move || {
+            activated.set(activated.get() + 1);
+        }),
+    ));
+    let mut app = App::new_with_controlled_inputs(
+        State::new(),
+        Box::new(Scrollable::new_vertical().with_child(Box::new(content))),
+    );
+    app.init_layout();
+    layout_in(&mut app, 480, 360);
+
+    let final_node = *app
+        .focusable_order
+        .last()
+        .expect("final action is focusable");
+    let before = app
+        .inspect_node(final_node, |widget| widget.get_rect())
+        .unwrap();
+    assert!(before.y0 >= 360.0, "final action starts below the viewport");
+
+    let wheel = WindowEvent::MouseWheel {
+        device_id: winit::event::DeviceId::dummy(),
+        delta: MouseScrollDelta::PixelDelta(PhysicalPosition::new(0.0, -10_000.0)),
+        phase: TouchPhase::Moved,
+    };
+    assert!(send_widget_then_host_fallback(&mut app, &wheel));
+    layout_in(&mut app, 480, 360);
+    let after = app
+        .inspect_node(final_node, |widget| widget.get_rect())
+        .unwrap();
+    assert!(
+        after.y0 >= 0.0 && after.y1 <= 360.0,
+        "final action is reachable after scrolling: {after:?}"
+    );
+
+    for _ in 0..app.focusable_order.len() {
+        assert!(app.focus_tab(false));
+    }
+    assert_eq!(app.focused_node, Some(final_node));
+
+    assert!(send_widget_then_host_fallback(
+        &mut app,
+        &named_key_event(NamedKey::Enter, ElementState::Pressed)
+    ));
+    assert_eq!(invocations.get(), 1, "Enter adds exactly one invocation");
+    send_widget_then_host_fallback(
+        &mut app,
+        &named_key_event(NamedKey::Enter, ElementState::Released),
+    );
+    assert_eq!(
+        invocations.get(),
+        1,
+        "the key release must not invoke the action again"
+    );
+    let mut already_handled = true;
+    app.handle_unconsumed_activation_key(
+        &named_key_event(NamedKey::Enter, ElementState::Pressed),
+        &mut already_handled,
+    );
+    assert_eq!(
+        invocations.get(),
+        1,
+        "a widget-consumed Enter press must not invoke the host fallback"
+    );
+}

```

## 17110d403
```diff
commit 17110d4035b06b7f0893a66743b98077263c10c0
Author:     Xaver Emmerling <xaver@Mac.lan>
AuthorDate: Wed Sep 16 08:29:56 2026 -0700
Commit:     Xaver Emmerling <xaver@Mac.lan>
CommitDate: Wed Sep 16 08:29:56 2026 -0700

    fix(ui): measure resolved empty-state text
---
 ui/src/app/card_composition_tests.rs |  51 +++-
 ui/src/text_render.rs                | 103 ++++++-
 ui/src/widget/empty_state.rs         | 524 +++++++++++++++++++++++++++++++----
 ui/src/widget/text.rs                |  11 +-
 4 files changed, 634 insertions(+), 55 deletions(-)

diff --git a/ui/src/app/card_composition_tests.rs b/ui/src/app/card_composition_tests.rs
index 5aad70243..102d1963c 100644
--- a/ui/src/app/card_composition_tests.rs
+++ b/ui/src/app/card_composition_tests.rs
@@ -1,5 +1,7 @@
 use super::*;
-use crate::widget::{Actions, Button, Card, CardGrid, Column, Element, Scrollable, Text};
+use crate::widget::{
+    Actions, Button, Card, CardGrid, Column, Element, EmptyState, Scrollable, Text,
+};
 use automerge::ReadDoc;
 use std::cell::Cell;
 use std::rc::Rc;
@@ -248,3 +250,50 @@ fn short_card_stack_scroll_and_tab_activate_final_action_once_from_enter() {
         "a widget-consumed Enter press must not invoke the host fallback"
     );
 }
+
+#[test]
+fn scrollable_empty_state_action_uses_the_real_tab_and_enter_host_route() {
+    let root = EmptyState::new("No messages are available")
+        .with_icon(crate::icons::Icon::Inbox)
+        .with_message("Reconnect to load messages.")
+        .with_action("Review connection settings")
+        .with_action_path("empty.review")
+        .into_scrollable()
+        .with_height(50.0);
+    let mut app = App::new_with_controlled_inputs(State::new(), Box::new(root));
+    app.init_layout();
+    layout_in(&mut app, 240, 50);
+
+    let action_node = *app
+        .focusable_order
+        .iter()
+        .find(|&&node| {
+            app.inspect_node(node, |widget| widget.name() == "EmptyState")
+                .unwrap_or(false)
+        })
+        .expect("empty-state action is in host focus order");
+    let wheel = WindowEvent::MouseWheel {
+        device_id: winit::event::DeviceId::dummy(),
+        delta: MouseScrollDelta::PixelDelta(PhysicalPosition::new(0.0, -10_000.0)),
+        phase: TouchPhase::Moved,
+    };
+    assert!(send_widget_then_host_fallback(&mut app, &wheel));
+    layout_in(&mut app, 240, 50);
+
+    for _ in 0..app.focusable_order.len() {
+        if app.focused_node == Some(action_node) {
+            break;
+        }
+        assert!(app.focus_tab(false));
+    }
+    assert_eq!(app.focused_node, Some(action_node));
+    assert!(send_widget_then_host_fallback(
+        &mut app,
+        &named_key_event(NamedKey::Enter, ElementState::Pressed),
+    ));
+    assert!(matches!(
+        app.state.doc.get(automerge::ROOT, "empty.review"),
+        Ok(Some((automerge::Value::Scalar(value), _)))
+            if value.as_ref().to_bool() == Some(true)
+    ));
+}
diff --git a/ui/src/text_render.rs b/ui/src/text_render.rs
index e9e882adf..d58bcc1b9 100644
--- a/ui/src/text_render.rs
+++ b/ui/src/text_render.rs
@@ -329,6 +329,9 @@ impl ParagraphAlign {
 pub enum TextWrapMode {
     #[default]
     Wrap,
+    /// Prefer word boundaries and fall back to glyph boundaries when one word
+    /// is wider than the available measure.
+    WordOrGlyph,
     /// Choose a narrower measure that keeps the same number of lines while
     /// minimizing raggedness, like CSS `text-wrap: balance`.
     Balance,
@@ -1364,6 +1367,21 @@ impl TextRenderer {
         self.text_scale
     }
 
+    /// Convert a fully resolved logical-pixel style into the renderer-relative
+    /// input consumed by [`Self::measure_style`] and [`Self::draw_style`].
+    ///
+    /// Theme typography already includes the active UI and text scales. Both
+    /// size and pixel letter spacing are therefore divided by the renderer's
+    /// sanitized accessibility scale so those final values are applied once.
+    /// Legacy base-size callers should keep passing their styles directly.
+    pub fn renderer_input_style(&self, resolved: &TextStyle) -> TextStyle {
+        let scale = self.text_scale();
+        let mut style = resolved.clone();
+        style.size /= scale;
+        style.letter_spacing /= scale;
+        style
+    }
+
     fn scaled_style(&self, style: &TextStyle) -> TextStyle {
         if (self.text_scale - 1.0).abs() <= f32::EPSILON {
             return style.clone();
@@ -1510,7 +1528,10 @@ impl TextRenderer {
         };
         let layout_width = max_width.map(|width| (width - hyphen_width).max(0.0));
         buffer.set_size(layout_width, None);
-        buffer.set_wrap(Wrap::Word);
+        buffer.set_wrap(match style.wrap_mode {
+            TextWrapMode::WordOrGlyph => Wrap::WordOrGlyph,
+            TextWrapMode::Wrap | TextWrapMode::Balance => Wrap::Word,
+        });
         buffer.shape_until_scroll(&mut self.font_system, false);
         if style.wrap_mode == TextWrapMode::Balance && max_width.is_some() {
             balance_buffer(
@@ -1893,7 +1914,10 @@ impl TextRenderer {
         };
         let layout_width = max_width.map(|width| (width - hyphen_width).max(0.0));
         buffer.set_size(layout_width, None);
-        buffer.set_wrap(Wrap::Word);
+        buffer.set_wrap(match style.wrap_mode {
+            TextWrapMode::WordOrGlyph => Wrap::WordOrGlyph,
+            TextWrapMode::Wrap | TextWrapMode::Balance => Wrap::Word,
+        });
         buffer.shape_until_scroll(&mut self.font_system, false);
         if style.wrap_mode == TextWrapMode::Balance && max_width.is_some() {
             balance_buffer(
@@ -3165,6 +3189,81 @@ mod tests {
             }
         }
     }
+
+    #[test]
+    fn resolved_styles_keep_metrics_and_glyph_geometry_across_renderer_scales() {
+        let text = "Tracked resolved text";
+        let resolved = TextStyle::new(28.0).with_letter_spacing(3.0);
+        let mut renderer = crate::font_catalog::fixture_renderer();
+
+        let legacy_at_one = renderer.measure_style(text, None, &TextStyle::new(14.0));
+        let resolved_at_one = renderer.measure_style(text, None, &resolved);
+        let mut scene_at_one = Scene::new();
+        renderer.draw_style(
+            &mut scene_at_one,
+            text,
+            Color::WHITE,
+            Affine::IDENTITY,
+            None,
+            &resolved,
+        );
+
+        renderer.set_text_scale(2.0);
+        let legacy_at_two = renderer.measure_style(text, None, &TextStyle::new(14.0));
+        assert!((legacy_at_two.1 - legacy_at_one.1 * 2.0).abs() < 0.001);
+
+        let renderer_input = renderer.renderer_input_style(&resolved);
+        assert!((renderer_input.size - 14.0).abs() < 0.001);
+        assert!((renderer_input.letter_spacing - 1.5).abs() < 0.001);
+        let resolved_at_two = renderer.measure_style(text, None, &renderer_input);
+        assert_eq!(resolved_at_two, resolved_at_one);
+
+        let mut scene_at_two = Scene::new();
+        renderer.draw_style(
+            &mut scene_at_two,
+            text,
+            Color::WHITE,
+            Affine::IDENTITY,
+            None,
+            &renderer_input,
+        );
+        let first = scene_at_one.encoding();
+        let second = scene_at_two.encoding();
+        assert_eq!(first.resources.glyphs.len(), second.resources.glyphs.len());
+        for (left, right) in first.resources.glyphs.iter().zip(&second.resources.glyphs) {
+            assert_eq!(left.id, right.id);
+            assert_eq!(left.x, right.x);
+            assert_eq!(left.y, right.y);
+        }
+        assert_eq!(
+            first.resources.glyph_runs.len(),
+            second.resources.glyph_runs.len()
+        );
+        for (left, right) in first
+            .resources
+            .glyph_runs
+            .iter()
+            .zip(&second.resources.glyph_runs)
+        {
+            assert_eq!(left.font_size, right.font_size);
+            assert_eq!(left.transform, right.transform);
+            assert_eq!(left.glyphs, right.glyphs);
+        }
+    }
+
+    #[test]
+    fn resolved_theme_style_applies_ui_and_text_scale_once() {
+        let base = crate::theme::Theme::dark().tokens.typography.scale.sm;
+        let theme = crate::theme::Theme::dark()
+            .with_ui_scale(1.25)
+            .with_text_scale(2.0);
+        let resolved = TextStyle::new(theme.tokens.typography.scale.sm);
+        let mut renderer = crate::font_catalog::fixture_renderer();
+        renderer.set_text_scale(2.0);
+        let renderer_input = renderer.renderer_input_style(&resolved);
+        let (_, height) = renderer.measure_style("Scale once", None, &renderer_input);
+        assert!((height - base * 1.25 * 2.0 * resolved.line_height).abs() < 0.001);
+    }
 }
 
 #[cfg(test)]
diff --git a/ui/src/widget/empty_state.rs b/ui/src/widget/empty_state.rs
index e512023c7..7e5723efe 100644
--- a/ui/src/widget/empty_state.rs
+++ b/ui/src/widget/empty_state.rs
@@ -31,9 +31,9 @@ use winit::event::{ElementState, MouseButton, WindowEvent};
 use crate::color_compat::ColorCompat;
 use crate::icons::Icon;
 use crate::presence::PresenceCtx;
-use crate::text_render::TextRenderer;
+use crate::text_render::{TextRenderer, TextStyle, TextWrapMode};
 use crate::theme::Theme;
-use crate::widget::{ActionEmitter, TaffyTreeExt, Widget};
+use crate::widget::{ActionEmitter, Scrollable, TaffyTreeExt, Widget};
 
 /// `kurbo::Affine` composition is plain f64 matrix math with no panic
 /// path; `arithmetic_side_effects` flags the `*` operator overload anyway.
@@ -62,8 +62,14 @@ struct Parts {
 /// Measured heights the stack is built from.
 #[derive(Clone, Copy, Debug)]
 struct Metrics {
+    title_w: f64,
     title_h: f64,
+    msg_w: f64,
     msg_h: f64,
+    action_w: f64,
+    action_h: f64,
+    inner_width: f32,
+    pad_x: f64,
     gap: f64,
     btn_h: f64,
 }
@@ -76,6 +82,71 @@ struct Fit {
     total: f64,
 }
 
+fn resolved_styles(
+    text_renderer: &TextRenderer,
+    theme: &Theme,
+) -> (TextStyle, TextStyle, TextStyle) {
+    let typography = &theme.tokens.typography.scale;
+    (
+        text_renderer.renderer_input_style(
+            &TextStyle::new(typography.xl).with_wrap_mode(TextWrapMode::WordOrGlyph),
+        ),
+        text_renderer.renderer_input_style(
+            &TextStyle::new(typography.sm).with_wrap_mode(TextWrapMode::WordOrGlyph),
+        ),
+        text_renderer.renderer_input_style(
+            &TextStyle::new(typography.sm).with_wrap_mode(TextWrapMode::WordOrGlyph),
+        ),
+    )
+}
+
+#[allow(
+    clippy::too_many_arguments,
+    reason = "the strings and their resolved styles are paired inputs to one authoritative measurement pass"
+)]
+fn measure_metrics(
+    text_renderer: &mut TextRenderer,
+    gap: f64,
+    pad_y: f64,
+    width: f64,
+    title: &str,
+    message: Option<&str>,
+    action_label: Option<&str>,
+    title_style: &TextStyle,
+    message_style: &TextStyle,
+    action_style: &TextStyle,
+) -> Metrics {
+    let pad_x = gap;
+    #[allow(
+        clippy::cast_possible_truncation,
+        reason = "window widths are logical pixels well within f32 range"
+    )]
+    let inner_width = (width - gap * 2.0).max(1.0) as f32;
+    let (title_w, title_h) = text_renderer.measure_style(title, Some(inner_width), title_style);
+    let (msg_w, msg_h) = message.map_or((0.0, 0.0), |value| {
+        text_renderer.measure_style(value, Some(inner_width), message_style)
+    });
+    let (action_w, action_h) = action_label.map_or((0.0, 0.0), |value| {
+        text_renderer.measure_style(value, Some(inner_width), action_style)
+    });
+    Metrics {
+        title_w: f64::from(title_w),
+        title_h: f64::from(title_h),
+        msg_w: f64::from(msg_w),
+        msg_h: f64::from(msg_h),
+        action_w: f64::from(action_w),
+        action_h: f64::from(action_h),
+        inner_width,
+        pad_x,
+        gap,
+        btn_h: if action_label.is_some() {
+            34.0_f64.max(f64::from(action_h) + pad_y * 2.0)
+        } else {
+            0.0
+        },
+    }
+}
+
 impl Fit {
     /// Shed decorative elements rather than overflow the rect: the hero disc
     /// is the largest element and carries the least information, so it goes
@@ -139,15 +210,20 @@ fn paint_empty_state(
     if rect.width() <= 0.0 || rect.height() <= 0.0 {
         return None;
     }
-    let gap = f64::from(theme.tokens.spacing.s4);
-    let title_size = theme.tokens.typography.scale.xl;
-    let msg_size = theme.tokens.typography.scale.sm;
-    let btn_size = theme.tokens.typography.scale.sm;
-    let btn_h = 34.0_f64;
-
-    let (title_w, title_h) = text_renderer.measure(title, title_size, None);
-    let (msg_w, msg_h) = message.map_or((0.0, 0.0), |m| text_renderer.measure(m, msg_size, None));
-    let (act_w, _) = action_label.map_or((0.0, 0.0), |a| text_renderer.measure(a, btn_size, None));
+    let (title_style, message_style, action_style) = resolved_styles(text_renderer, theme);
+    let metrics = measure_metrics(
+        text_renderer,
+        f64::from(theme.tokens.spacing.s4),
+        f64::from(theme.tokens.spacing.s2),
+        rect.width(),
+        title,
+        message,
+        action_label,
+        &title_style,
+        &message_style,
+        &action_style,
+    );
+    let gap = metrics.gap;
 
     let fit = Fit::choose(
         rect.height(),
@@ -156,19 +232,18 @@ fn paint_empty_state(
             message: message.is_some(),
             action: action_label.is_some(),
         },
-        Metrics {
-            title_h: f64::from(title_h),
-            msg_h: f64::from(msg_h),
-            gap,
-            btn_h,
-        },
+        metrics,
     );
     let icon = if fit.icon { icon } else { None };
     let message = if fit.message { message } else { None };
     let total = fit.total;
 
     let cx = rect.center().x;
-    let mut y = rect.center().y - total / 2.0;
+    let mut y = if total > rect.height() {
+        rect.y0
+    } else {
+        rect.center().y - total / 2.0
+    };
 
     if let Some(icon) = icon {
         let disc_center = Point::new(cx, y + DISC_D / 2.0);
@@ -185,35 +260,34 @@ fn paint_empty_state(
         y += DISC_D + gap;
     }
 
-    text_renderer.draw_text(
+    text_renderer.draw_style(
         scene,
         title,
-        title_size,
         theme.text_primary,
-        translated(transform, cx - f64::from(title_w) / 2.0, y),
-        None,
+        translated(transform, cx - metrics.title_w / 2.0, y),
+        Some(metrics.inner_width),
+        &title_style,
     );
-    y += f64::from(title_h);
+    y += metrics.title_h;
 
     if let Some(msg) = message {
         y += gap * 0.5;
-        text_renderer.draw_text(
+        text_renderer.draw_style(
             scene,
             msg,
-            msg_size,
             theme.text_dim,
-            translated(transform, cx - f64::from(msg_w) / 2.0, y),
-            None,
+            translated(transform, cx - metrics.msg_w / 2.0, y),
+            Some(metrics.inner_width),
+            &message_style,
         );
-        y += f64::from(msg_h);
+        y += metrics.msg_h;
     }
 
     if let Some(label) = action_label {
         y += gap;
-        let pad_x = f64::from(theme.tokens.spacing.s4);
-        let bw = f64::from(act_w) + pad_x * 2.0;
+        let bw = (metrics.action_w + metrics.pad_x * 2.0).min(rect.width());
         let x0 = cx - bw / 2.0;
-        let action_rect = Rect::new(x0, y, x0 + bw, y + btn_h);
+        let action_rect = Rect::new(x0, y, x0 + bw, y + metrics.btn_h);
         let hovered = action_rect.contains(hover);
         let bg = if hovered {
             theme.accent_hover
@@ -234,16 +308,16 @@ fn paint_empty_state(
                 &pill,
             );
         }
-        let ty = action_rect.y0 + (btn_h - f64::from(btn_size)) / 2.0;
-        text_renderer.draw_text(
+        let ty = action_rect.y0 + (metrics.btn_h - metrics.action_h) / 2.0;
+        text_renderer.draw_style(
             scene,
             label,
-            btn_size,
             Color::WHITE,
-            translated(transform, cx - f64::from(act_w) / 2.0, ty),
-            None,
+            translated(transform, cx - metrics.action_w / 2.0, ty),
+            Some(metrics.inner_width),
+            &action_style,
         );
-        Some(action_rect)
+        (action_rect.y1 > rect.y0 && action_rect.y0 < rect.y1).then_some(action_rect)
     } else {
         None
     }
@@ -272,6 +346,12 @@ pub struct EmptyState {
     /// The action is immediate-mode, but still participates in the normal
     /// Tab / Enter contract through this owning widget.
     action_focused: bool,
+    layout_title_style: TextStyle,
+    layout_message_style: TextStyle,
+    layout_action_style: TextStyle,
+    layout_gap: f64,
+    layout_pad_y: f64,
+    scroll_content: bool,
 }
 
 impl EmptyState {
@@ -279,6 +359,7 @@ impl EmptyState {
     /// [`with_icon`](Self::with_icon) / [`with_message`](Self::with_message) /
     /// [`with_action`](Self::with_action) for the fuller treatment.
     pub fn new(title: impl Into<String>) -> Self {
+        let theme = Theme::default();
         Self {
             icon: None,
             title: title.into(),
@@ -292,6 +373,15 @@ impl EmptyState {
             action_rect: Rect::ZERO,
             last_cursor: Point::ZERO,
             action_focused: false,
+            layout_title_style: TextStyle::new(theme.tokens.typography.scale.xl)
+                .with_wrap_mode(TextWrapMode::WordOrGlyph),
+            layout_message_style: TextStyle::new(theme.tokens.typography.scale.sm)
+                .with_wrap_mode(TextWrapMode::WordOrGlyph),
+            layout_action_style: TextStyle::new(theme.tokens.typography.scale.sm)
+                .with_wrap_mode(TextWrapMode::WordOrGlyph),
+            layout_gap: f64::from(theme.tokens.spacing.s4),
+            layout_pad_y: f64::from(theme.tokens.spacing.s2),
+            scroll_content: false,
         }
     }
 
@@ -373,6 +463,43 @@ impl EmptyState {
         self.action_rect
     }
 
+    /// Wrap this retained empty state in the toolkit's vertical viewport.
+    /// The child keeps at least the viewport height for ordinary centering and
+    /// grows to its measured content height when wrapped text needs more room,
+    /// making a below-fold action reachable by wheel, keyboard, or scrollbar.
+    #[must_use]
+    pub fn into_scrollable(mut self) -> Scrollable {
+        self.scroll_content = true;
+        Scrollable::new_vertical().with_child(Box::new(self))
+    }
+
+    /// Minimum height required to show the title and optional action at
+    /// `width`, after wrapping and accessibility scaling. Immediate-mode
+    /// callers with a shorter viewport must provide scrolling; [`Self::paint`]
+    /// anchors at the top and does not return a wholly offscreen hit target.
+    pub fn minimum_essential_height(
+        text_renderer: &mut TextRenderer,
+        theme: &Theme,
+        width: f64,
+        title: &str,
+        action_label: Option<&str>,
+    ) -> f64 {
+        let (title_style, message_style, action_style) = resolved_styles(text_renderer, theme);
+        let metrics = measure_metrics(
+            text_renderer,
+            f64::from(theme.tokens.spacing.s4),
+            f64::from(theme.tokens.spacing.s2),
+            width,
+            title,
+            None,
+            action_label,
+            &title_style,
+            &message_style,
+            &action_style,
+        );
+        metrics.title_h + action_label.map_or(0.0, |_| metrics.gap + metrics.btn_h)
+    }
+
     /// Place the empty state inside a rect computed by an immediate-mode
     /// parent.
     ///
@@ -387,8 +514,11 @@ impl EmptyState {
     /// Immediate-mode paint of an empty state centered inside `rect`, for the
     /// many apps that render straight to a `Scene` instead of building a
     /// widget tree. Returns the action pill's rect when `action_label` is
-    /// `Some` so the caller can hit-test it against its own pointer state
+    /// visible so the caller can hit-test it against its own pointer state
     /// (pass `hover` for the hover tint, or an off-screen point to suppress).
+    /// Call [`Self::minimum_essential_height`] first when the supplied pane can
+    /// be physically shorter than the title and action; that parent must own
+    /// scrolling, and a wholly offscreen action produces no false hit target.
     #[allow(clippy::too_many_arguments)]
     pub fn paint(
         scene: &mut Scene,
@@ -424,19 +554,28 @@ impl Widget for EmptyState {
     fn build_layout(
         &mut self,
         taffy: &mut TaffyTree<()>,
-        _theme: &Theme,
+        theme: &Theme,
         node_map: &mut HashMap<NodeId, *mut dyn Widget>,
     ) -> NodeId {
-        // Fill the space the parent offers so the content can center inside it.
+        self.layout_title_style = TextStyle::new(theme.tokens.typography.scale.xl)
+            .with_wrap_mode(TextWrapMode::WordOrGlyph);
+        self.layout_message_style = TextStyle::new(theme.tokens.typography.scale.sm)
+            .with_wrap_mode(TextWrapMode::WordOrGlyph);
+        self.layout_action_style = TextStyle::new(theme.tokens.typography.scale.sm)
+            .with_wrap_mode(TextWrapMode::WordOrGlyph);
+        self.layout_gap = f64::from(theme.tokens.spacing.s4);
+        self.layout_pad_y = f64::from(theme.tokens.spacing.s2);
+        // Auto height contributes wrapped content to a Scrollable's extent;
+        // the percentage minimum still fills a normal definite-height pane.
         let node = taffy.leaf_node(Style {
             flex_grow: 1.0,
             size: taffy::Size {
                 width: percent(1.0_f32),
-                height: percent(1.0_f32),
+                height: taffy::Dimension::auto(),
             },
             min_size: taffy::Size {
                 width: percent(0.0_f32),
-                height: percent(0.0_f32),
+                height: percent(1.0_f32),
             },
             ..Default::default()
         });
@@ -446,15 +585,53 @@ impl Widget for EmptyState {
 
     fn measure(
         &mut self,
-        _k: taffy::Size<Option<f32>>,
-        _a: taffy::Size<taffy::AvailableSpace>,
-        _tr: &mut TextRenderer,
+        known: taffy::Size<Option<f32>>,
+        available: taffy::Size<taffy::AvailableSpace>,
+        text_renderer: &mut TextRenderer,
     ) -> taffy::Size<f32> {
-        // A sensible intrinsic block so the widget is visible even in an
-        // auto-sized slot.
+        let width = known.width.or_else(|| match available.width {
+            taffy::AvailableSpace::Definite(width) => Some(width),
+            taffy::AvailableSpace::MinContent | taffy::AvailableSpace::MaxContent => None,
+        });
+        let measured_width = width.unwrap_or(240.0).max(1.0);
+        let title_style = text_renderer.renderer_input_style(&self.layout_title_style);
+        let message_style = text_renderer.renderer_input_style(&self.layout_message_style);
+        let action_style = text_renderer.renderer_input_style(&self.layout_action_style);
+        let metrics = measure_metrics(
+            text_renderer,
+            self.layout_gap,
+            self.layout_pad_y,
+            f64::from(measured_width),
+            &self.title,
+            self.message.as_deref(),
+            self.action_label.as_deref(),
+            &title_style,
+            &message_style,
+            &action_style,
+        );
+        let essential_height = metrics.title_h
+            + self
+                .action_label
+                .as_ref()
+                .map_or(0.0, |_| metrics.gap + metrics.btn_h);
+        let intrinsic_height = if self.scroll_content {
+            essential_height
+        } else {
+            Fit::choose(
+                f64::INFINITY,
+                Parts {
+                    icon: self.icon.is_some(),
+                    message: self.message.is_some(),
+                    action: self.action_label.is_some(),
+                },
+                metrics,
+            )
+            .total
+            .max(220.0)
+        };
         taffy::Size {
-            width: 240.0,
-            height: 220.0,
+            width: measured_width,
+            height: intrinsic_height as f32,
         }
     }
 
@@ -732,8 +909,14 @@ mod tests {
     /// the spacing scale a docked panel is drawn with.
     fn metrics() -> Metrics {
         Metrics {
+            title_w: 0.0,
             title_h: 24.0,
+            msg_w: 0.0,
             msg_h: 18.0,
+            action_w: 0.0,
+            action_h: 0.0,
+            inner_width: 0.0,
+            pad_x: 0.0,
             gap: 16.0,
             btn_h: 34.0,
         }
@@ -1018,6 +1201,249 @@ mod tests {
         assert!(none.is_none());
     }
 
+    #[test]
+    fn long_localized_content_wraps_inside_a_narrow_scaled_pane() {
+        for width in [240.0, 480.0] {
+            for scale in [1.0, 2.0] {
+                let theme = Theme::dark().with_text_scale(scale);
+                let mut tr = crate::font_catalog::fixture_renderer();
+                tr.set_text_scale(scale);
+                let mut scene = Scene::new();
+                let rect = Rect::new(20.0, 30.0, 20.0 + width, 1330.0);
+                let action = EmptyState::paint(
+                    &mut scene,
+                    Affine::IDENTITY,
+                    &mut tr,
+                    &theme,
+                    rect,
+                    Some(Icon::Inbox),
+                    "Keine synchronisierten Nachrichten in diesem Arbeitsbereich",
+                    Some(
+                        "Sobald eine Verbindung verfügbar ist, erscheinen neue Nachrichten automatisch.",
+                    ),
+                    Some(
+                        "Verbindungseinstellungen jetzt vollständig überprüfen und sichere Wiederherstellung vorbereiten",
+                    ),
+                    Point::new(-1.0, -1.0),
+                )
+                .expect("action remains available");
+
+                assert!(action.x0 >= rect.x0 && action.x1 <= rect.x1, "{action:?}");
+                assert!(action.height() > 34.0, "wrapped action grows: {action:?}");
+                let encoding = scene.encoding();
+                for run in &encoding.resources.glyph_runs {
+                    for glyph in &encoding.resources.glyphs[run.glyphs.clone()] {
+                        let x = f64::from(run.transform.translation[0] + glyph.x);
+                        assert!(
+                            x >= rect.x0 && x <= rect.x1,
+                            "{width}px/{scale}x glyph x={x} outside {rect:?}"
+                        );
+                    }
+                }
+            }
+        }
+    }
+
+    #[test]
+    fn tiny_immediate_pane_exposes_required_height_without_offscreen_hit_geometry() {
+        let theme = Theme::dark().with_text_scale(2.0);
+        let mut tr = crate::font_catalog::fixture_renderer();
+        tr.set_text_scale(2.0);
+        let mut scene = Scene::new();
+        let rect = Rect::new(10.0, 20.0, 250.0, 45.0);
+        let minimum = EmptyState::minimum_essential_height(
+            &mut tr,
+            &theme,
+            rect.width(),
+            "No messages are available",
+            Some("Review connection settings"),
+        );
+        assert!(minimum > rect.height());
+        let action = EmptyState::paint(
+            &mut scene,
+            Affine::IDENTITY,
+            &mut tr,
+            &theme,
+            rect,
+            Some(Icon::Inbox),
+            "No messages are available",
+            Some("Reconnect to load messages."),
+            Some("Review connection settings"),
+            Point::new(-1.0, -1.0),
+        );
+
+        assert!(
+            action.is_none(),
+            "a wholly offscreen action is not exposed as a usable hit target"
+        );
+    }
+
+    #[test]
+    fn retained_empty_state_has_a_scrollable_route_to_essential_content() {
+        use automerge::{ReadDoc as _, Value, transaction::Transactable as _};
+
+        let mut scroll = EmptyState::new("No messages are available")
+            .with_icon(Icon::Inbox)
+            .with_message("Reconnect to load messages.")
+            .with_action("Review connection settings")
+            .with_action_path("empty.review")
+            .into_scrollable()
+            .with_height(50.0);
+        let theme = Theme::dark();
+        let mut taffy = TaffyTree::<()>::new();
+        let mut node_map: HashMap<NodeId, *mut dyn Widget> = HashMap::new();
+        let mut tr = crate::font_catalog::fixture_renderer();
+        let node = scroll.build_layout(&mut taffy, &theme, &mut node_map);
+        taffy
+            .compute_layout_with_measure(
+                node,
+                taffy::Size {
+                    width: taffy::AvailableSpace::Definite(240.0),
+                    height: taffy::AvailableSpace::Definite(50.0),
+                },
+                |known, available, id, _, _| {
+                    node_map.get(&id).map_or(taffy::Size::ZERO, |&ptr| unsafe {
+                        (*ptr).measure(known, available, &mut tr)
+                    })
+                },
+            )
+            .unwrap();
+        scroll.apply_layout(&taffy, node, Point::ZERO);
+
+        assert!(scroll.vertical_overflows());
+        assert!(scroll.max_offset_y() > 0.0);
+        scroll.scroll_by(0.0, scroll.max_offset_y());
+        scroll.apply_layout(&taffy, node, Point::ZERO);
+        let mut scene = Scene::new();
+        scroll.draw(
+            &mut scene,
+            Affine::IDENTITY,
+            &mut tr,
+            &theme,
+            &PresenceCtx::default(),
+        );
+        let action = scroll.children()[0]
+            .synthetic_accessibility_rect(&[0])
+            .expect("retained action geometry");
+        assert!(
+            scroll.content_viewport_rect().contains(action.center()),
+            "scrolled action is visible: {action:?}"
+        );
+
+        let mut doc = AutoCommit::new();
+        let root = automerge::ROOT;
+        let mut handled = false;
+        let mut focus = None;
+        for event in [cursor(action.center()), press()] {
+            scroll.handle_event(
+                &event,
+                1.0,
+                &winit::event::Modifiers::default(),
+                &mut doc,
+                &root,
+                &mut handled,
+                &mut focus,
+                node,
+                &taffy,
+            );
+        }
+        assert!(
+            handled,
+            "visible scrolled action accepts pointer activation"
+        );
+        assert!(matches!(
+            doc.get(&root, "empty.review"),
+            Ok(Some((Value::Scalar(value), _))) if value.as_ref().to_bool() == Some(true)
+        ));
+
+        let _ = doc.put(&root, "empty.review", false);
+        let child = scroll.children_mut().remove(0);
+        child.set_focus(true);
+        assert!(child.perform_action(&crate::a11y::Action::Activate, &mut doc, &root));
+        assert!(matches!(
+            doc.get(&root, "empty.review"),
+            Ok(Some((Value::Scalar(value), _))) if value.as_ref().to_bool() == Some(true)
+        ));
+    }
+
+    #[test]
+    fn roomy_scrollable_retains_the_icon_and_explanatory_message() {
+        let make = |icon| {
+            let mut scroll = EmptyState::new("No messages")
+                .with_message("Reconnect to load messages.")
+                .with_action("Review settings");
+            if icon {
+                scroll = scroll.with_icon(Icon::Inbox);
+            }
+            scroll.into_scrollable().with_height(400.0)
+        };
+        let mut decorated = make(true);
+        lay_out(&mut decorated, 480.0, 400.0);
+        let decorated_scene = draw(&mut decorated);
+        let decorated_encoding = decorated_scene.encoding();
+        assert!(
+            decorated_encoding.resources.glyph_runs.len() >= 3,
+            "title, explanatory message, and action all remain painted"
+        );
+
+        let mut plain = make(false);
+        lay_out(&mut plain, 480.0, 400.0);
+        let plain_scene = draw(&mut plain);
+        let decorated_colors = decorated_encoding
+            .draw_tags
+            .iter()
+            .filter(|tag| **tag == DrawTag::COLOR)
+            .count();
+        let plain_colors = plain_scene
+            .encoding()
+            .draw_tags
+            .iter()
+            .filter(|tag| **tag == DrawTag::COLOR)
+            .count();
+        assert!(
+            decorated_colors > plain_colors,
+            "roomy scrollable keeps the icon disc and strokes"
+        );
+    }
+
+    #[test]
+    fn roomy_manual_pane_keeps_the_essential_block_centered() {
+        let theme = Theme::dark();
+        let mut tr = crate::font_catalog::fixture_renderer();
+        let rect = Rect::new(15.0, 25.0, 495.0, 425.0);
+        let minimum = EmptyState::minimum_essential_height(
+            &mut tr,
+            &theme,
+            rect.width(),
+            "No messages",
+            Some("Compose"),
+        );
+        let mut scene = Scene::new();
+        let action = EmptyState::paint(
+            &mut scene,
+            Affine::IDENTITY,
+            &mut tr,
+            &theme,
+            rect,
+            None,
+            "No messages",
+            None,
+            Some("Compose"),
+            Point::new(-1.0, -1.0),
+        )
+        .expect("roomy pane exposes action");
+        let top = action.y1 - minimum;
+        assert!(((top - rect.y0) - (rect.y1 - action.y1)).abs() < 0.001);
+
+        let mut retained = EmptyState::new("No messages").with_action("Compose");
+        lay_out(&mut retained, 480.0, 400.0);
+        assert_eq!(retained.get_rect(), Rect::new(0.0, 0.0, 480.0, 400.0));
+        let _ = draw(&mut retained);
+        let retained_action = retained.action_rect();
+        let retained_top = retained_action.y1 - minimum;
+        assert!((retained_top - (400.0 - retained_action.y1)).abs() < 0.001);
+    }
+
     #[test]
     fn accessibility_is_a_named_group() {
         use crate::a11y::Role;
diff --git a/ui/src/widget/text.rs b/ui/src/widget/text.rs
index c9f60ae7c..41c852353 100644
--- a/ui/src/widget/text.rs
+++ b/ui/src/widget/text.rs
@@ -373,11 +373,16 @@ impl Text {
     }
 
     fn renderer_input_style(&self, renderer: &TextRenderer) -> TextStyle {
-        let mut style = self.style.clone();
         if self.follows_role_style || self.scales_with_theme || self.has_fixed_size {
-            style.size /= renderer.text_scale();
+            let mut style = renderer.renderer_input_style(&self.style);
+            // Text's public modifiers have always defined pixel spacing as a
+            // renderer-relative value, including fixed-size text. Preserve
+            // that contract while sharing the resolved font-size boundary.
+            style.letter_spacing = self.style.letter_spacing;
+            style
+        } else {
+            self.style.clone()
         }
-        style
     }
 
     fn observe_renderer_text_scale(&mut self, renderer: &TextRenderer) {

```

## 3f13fb4eb
```diff
commit 3f13fb4eb8a2ce061a205bcaa1f30feaf7880ac1
Author:     Xaver Emmerling <xaver@Mac.lan>
AuthorDate: Wed Sep 16 09:20:58 2026 -0700
Commit:     Xaver Emmerling <xaver@Mac.lan>
CommitDate: Wed Sep 16 09:20:58 2026 -0700

    fix(ui): unify rich editor text geometry
---
 ui/src/widget/block_editor.rs   | 116 +++++++++++++-
 ui/src/widget/code_editor.rs    |  63 ++++++++
 ui/src/widget/rich_text_line.rs |  74 ++++++++-
 ui/src/widget/text_input.rs     | 346 +++++++++++++++++++++++++++++++++++++---
 4 files changed, 565 insertions(+), 34 deletions(-)

diff --git a/ui/src/widget/block_editor.rs b/ui/src/widget/block_editor.rs
index 173574066..b41855bc5 100644
--- a/ui/src/widget/block_editor.rs
+++ b/ui/src/widget/block_editor.rs
@@ -3376,21 +3376,39 @@ fn draw_numbered_prefix(
     let num = ctx.ordinals.get(idx).copied().unwrap_or(1).max(1);
     let label = format!("{num}.");
     let (label_w, _) = ctx.text_renderer.measure(&label, font_size, None);
-    // Matches RichTextLine's line height so the ordinal
-    // sits on the item text's baseline.
-    let line_height = f64::from(font_size * ctx.theme.text_scale) * 1.25;
-    let text_y = line_rect.y0 + (line_rect.height() - line_height) / 2.0;
-    let x = (line_rect.x0 - 6.0 - f64::from(label_w)).max(prefix_x0);
+    let origin = numbered_prefix_origin(
+        line_rect,
+        prefix_x0,
+        f64::from(label_w),
+        font_size,
+        ctx.theme.text_scale,
+    );
     ctx.text_renderer.draw_text(
         ctx.scene,
         &label,
         font_size,
         ctx.theme.tokens.colors.text_primary,
-        translated(ctx.transform, x, text_y),
+        translated(ctx.transform, origin.x, origin.y),
         None,
     );
 }
 
+fn numbered_prefix_origin(
+    line_rect: Rect,
+    prefix_x0: f64,
+    label_width: f64,
+    font_size: f32,
+    text_scale: f32,
+) -> Point {
+    // Matches RichTextLine's resolved shaped line height so the ordinal sits
+    // on the item text's baseline at every accessibility scale.
+    let line_height = f64::from(font_size * text_scale) * 1.25;
+    Point::new(
+        (line_rect.x0 - 6.0 - label_width).max(prefix_x0),
+        line_rect.y0 + (line_rect.height() - line_height) / 2.0,
+    )
+}
+
 fn draw_checklist_prefix(
     done: bool,
     line_rect: Rect,
@@ -5579,6 +5597,92 @@ mod tests {
         assert!(!Block::paragraph("hi").line.inner().is_mono());
     }
 
+    fn layout_and_draw_editor(editor: &mut BlockEditor, theme: &Theme) {
+        let mut taffy = TaffyTree::<()>::new();
+        let mut node_map: HashMap<NodeId, *mut dyn Widget> = HashMap::new();
+        let node = editor.build_layout(&mut taffy, theme, &mut node_map);
+        taffy
+            .compute_layout(
+                node,
+                Size {
+                    width: taffy::AvailableSpace::Definite(640.0),
+                    height: taffy::AvailableSpace::MaxContent,
+                },
+            )
+            .expect("block editor layout");
+        editor.apply_layout(&taffy, node, Point::ZERO);
+        let mut renderer = TextRenderer::new();
+        renderer.set_text_scale(theme.text_scale);
+        editor.draw(
+            &mut Scene::new(),
+            Affine::IDENTITY,
+            &mut renderer,
+            theme,
+            &PresenceCtx::empty(),
+        );
+    }
+
+    #[test]
+    fn heading_paragraph_inline_code_and_numbered_prefix_scale_once() {
+        let heading = Block::heading(1, "Heading");
+        let mut paragraph = Block::paragraph("inline code");
+        paragraph
+            .line
+            .set_marks(vec![MarkSpan::new(0..6, Mark::Code)]);
+        paragraph.line.inner_mut().set_selection(0, 6);
+        let numbered = Block::numbered(0, "numbered");
+        let mut editor = BlockEditor::new();
+        editor.set_blocks(vec![heading, paragraph, numbered]);
+
+        layout_and_draw_editor(&mut editor, &Theme::dark());
+        assert_eq!(
+            editor.blocks[0].line.inner().shaped_font_size_for_test(),
+            Some(28.0)
+        );
+        assert_eq!(
+            editor.blocks[1].line.inner().shaped_font_size_for_test(),
+            Some(16.0)
+        );
+
+        let large = Theme::dark().with_text_scale(2.0);
+        layout_and_draw_editor(&mut editor, &large);
+        assert_eq!(
+            editor.blocks[0].line.inner().shaped_font_size_for_test(),
+            Some(56.0)
+        );
+        for index in [1, 2] {
+            assert_eq!(
+                editor.blocks[index]
+                    .line
+                    .inner()
+                    .shaped_font_size_for_test(),
+                Some(32.0)
+            );
+        }
+        let selection = editor.blocks[1].line.selection_rect(&large, 0, 6);
+        assert!((selection.height() - 40.0).abs() < 0.1);
+
+        let numbered_line = &editor.blocks[2].line;
+        let line_rect = numbered_line.get_rect();
+        let gutter = prefix_gutter_for(&editor.blocks[2].kind) * 2.0;
+        let mut renderer = TextRenderer::new();
+        renderer.set_text_scale(2.0);
+        let (label_width, _) = renderer.measure("1.", 16.0, None);
+        let origin = numbered_prefix_origin(
+            line_rect,
+            line_rect.x0 - gutter,
+            f64::from(label_width),
+            16.0,
+            2.0,
+        );
+        let caret = numbered_line.caret_rect(&large, 0);
+        assert!(
+            (origin.y - caret.y0).abs() < 0.1,
+            "numbered prefix and shaped item share a baseline band"
+        );
+        assert!(origin.x < line_rect.x0);
+    }
+
     #[test]
     fn high_text_checklist_and_code_rows_leave_full_scaled_line_bands() {
         let mut editor = BlockEditor::new();
diff --git a/ui/src/widget/code_editor.rs b/ui/src/widget/code_editor.rs
index 5c3fd693b..125cee27c 100644
--- a/ui/src/widget/code_editor.rs
+++ b/ui/src/widget/code_editor.rs
@@ -1934,4 +1934,67 @@ mod tests {
             "the gutter shifts the caret right ({caret_with} vs {caret_without})",
         );
     }
+
+    #[test]
+    fn scaled_gutter_and_wrapped_rows_share_the_shaped_editor_geometry() {
+        let text = "first logical line wraps across several visual rows because the editor is narrow\nsecond";
+        let mut normal = CodeEditor::local().with_initial_value(text);
+        normal.set_rect(Rect::new(0.0, 0.0, 190.0, 420.0));
+        draw_once(&mut normal, &Theme::dark());
+        let normal_gutter = normal.gutter_width();
+        let normal_line_height = normal.line_height();
+
+        let theme = Theme::dark().with_text_scale(2.0);
+        let mut large = CodeEditor::local().with_initial_value(text);
+        large.set_rect(Rect::new(0.0, 0.0, 190.0, 900.0));
+        draw_once(&mut large, &theme);
+        assert!(
+            large.gutter_width() >= normal_gutter * 1.8,
+            "measured gutter grows with its line-number glyphs ({} vs {})",
+            large.gutter_width(),
+            normal_gutter,
+        );
+        assert!(
+            large.line_height() >= normal_line_height * 1.9,
+            "wrapper reports the shaped 2× row height"
+        );
+
+        let first_end = text.find('\n').expect("hard line break");
+        let wrapped = large.selection_rects(&theme, 0, first_end);
+        assert!(wrapped.len() >= 2, "first logical line wraps visually");
+        assert!(wrapped.iter().all(|rect| {
+            (rect.height() - large.line_height()).abs() < 0.1
+                && rect.x0 >= large.rect().x0 + large.gutter_width()
+        }));
+        let second_start = first_end + 1;
+        let caret = large.caret_rect(&theme, second_start);
+        assert!(caret.x0 >= large.rect().x0 + large.gutter_width());
+        let point = Point::new(caret.x0 + 1.0, caret.y0 + caret.height() / 2.0);
+        assert_eq!(large.byte_at_point(point), second_start);
+        let mut doc = AutoCommit::new();
+        drive(
+            &mut large,
+            &mut doc,
+            &WindowEvent::CursorMoved {
+                device_id: unsafe { std::mem::zeroed() },
+                position: winit::dpi::PhysicalPosition::new(point.x, point.y),
+            },
+            mods(false, false),
+        );
+        assert!(drive(
+            &mut large,
+            &mut doc,
+            &WindowEvent::MouseInput {
+                device_id: unsafe { std::mem::zeroed() },
+                state: ElementState::Pressed,
+                button: winit::event::MouseButton::Left,
+            },
+            mods(false, false),
+        ));
+        assert_eq!(
+            large.cursor_pos(),
+            second_start,
+            "pointer event places the caret on the logical second line through wrapped rows"
+        );
+    }
 }
diff --git a/ui/src/widget/rich_text_line.rs b/ui/src/widget/rich_text_line.rs
index c5f0e4827..027402787 100644
--- a/ui/src/widget/rich_text_line.rs
+++ b/ui/src/widget/rich_text_line.rs
@@ -434,12 +434,11 @@ impl Widget for RichTextLine {
         theme: &Theme,
         node_map: &mut HashMap<NodeId, *mut dyn Widget>,
     ) -> NodeId {
-        // The inner input owns the shaped document text (which bypasses
-        // `TextRenderer`'s global scale), so hand it the effective size here.
-        // Keeping its row height on the same scale prevents large-text lines
-        // from painting into their neighbours.
+        // Font overrides remain base values. TextInput's shaped layout applies
+        // the theme scale exactly once; the row height is resolved here because
+        // this wrapper owns the surrounding document geometry.
         let scale = theme.text_scale;
-        self.inner.set_font_size(self.font_size * scale);
+        self.inner.set_font_size(self.font_size);
         // font_size * 1.5 so headings end up taller than paragraph rows without a measure pass.
         let height = (self.font_size * scale * 1.5).max(20.0 * scale);
         let node = taffy.leaf_node(Style {
@@ -924,6 +923,7 @@ pub fn link_at_byte(marks_list: &[MarkSpan], byte: usize) -> Option<PageId> {
 #[cfg(test)]
 mod tests {
     use super::*;
+    use crate::widget::marks::Mark;
     use winit::event::KeyEvent;
     use winit::keyboard::{
         Key, KeyLocation, ModifiersKeyState, ModifiersState, NamedKey, PhysicalKey, SmolStr,
@@ -985,6 +985,70 @@ mod tests {
         );
     }
 
+    fn layout_and_draw(line: &mut RichTextLine, theme: &Theme, width: f32) {
+        let mut taffy = TaffyTree::<()>::new();
+        let mut node_map = HashMap::new();
+        let node = line.build_layout(&mut taffy, theme, &mut node_map);
+        taffy
+            .compute_layout(
+                node,
+                Size {
+                    width: taffy::AvailableSpace::Definite(width),
+                    height: taffy::AvailableSpace::MaxContent,
+                },
+            )
+            .expect("rich line layout");
+        line.apply_layout(&taffy, node, Point::ZERO);
+
+        let mut renderer = TextRenderer::new();
+        renderer.set_text_scale(theme.text_scale);
+        let mut scene = Scene::new();
+        line.draw(
+            &mut scene,
+            Affine::IDENTITY,
+            &mut renderer,
+            theme,
+            &PresenceCtx::empty(),
+        );
+    }
+
+    #[test]
+    fn base_font_override_scales_once_across_relayout_caret_selection_and_pointer() {
+        let mut line = RichTextLine::new().with_text("alpha beta").with_size(16.0);
+        line.set_marks(vec![MarkSpan::new(0..5, Mark::Code)]);
+        line.inner_mut().set_selection(0, 5);
+
+        let normal = Theme::dark();
+        layout_and_draw(&mut line, &normal, 320.0);
+        assert_eq!(line.inner().shaped_font_size_for_test(), Some(16.0));
+        assert!((line.caret_rect(&normal, 5).height() - 20.0).abs() < 0.1);
+        assert!((line.selection_rect(&normal, 0, 5).height() - 20.0).abs() < 0.1);
+
+        let large = Theme::dark().with_text_scale(2.0);
+        layout_and_draw(&mut line, &large, 320.0);
+        assert_eq!(line.inner().shaped_font_size_for_test(), Some(32.0));
+        let caret = line.caret_rect(&large, 5);
+        assert!(
+            (caret.height() - 40.0).abs() < 0.1,
+            "scaled caret height was {}",
+            caret.height()
+        );
+        let selection = line.selection_rect(&large, 0, 5);
+        assert!(
+            (selection.height() - 40.0).abs() < 0.1,
+            "scaled selection height was {}",
+            selection.height()
+        );
+
+        let target = 6;
+        let x = line.pixel_x_for_byte(&large, target);
+        assert_eq!(
+            line.byte_for_pixel_x(&large, x),
+            target,
+            "pointer inverse lands on the scaled shaped caret stop"
+        );
+    }
+
     #[test]
     fn bound_line_reads_text_from_doc() {
         use automerge::{ObjType, ROOT, transaction::Transactable};
diff --git a/ui/src/widget/text_input.rs b/ui/src/widget/text_input.rs
index 8020dd81d..f92ea5b5c 100644
--- a/ui/src/widget/text_input.rs
+++ b/ui/src/widget/text_input.rs
@@ -131,8 +131,6 @@ const SPELL_EDIT_SETTLE: Duration = Duration::from_millis(250);
 const EXTERNAL_SPELLCHECK_DELAY: Duration = Duration::from_millis(100);
 const ML_PAD_X: f64 = 10.0;
 const ML_PAD_Y: f64 = 8.0;
-/// Approximate glyph advance; used identically for gutter geometry and
-/// drawing so both stay aligned despite being approximate.
 const GUTTER_DIGIT_RATIO: f64 = 0.62;
 const GUTTER_PAD_L: f64 = 8.0;
 const GUTTER_PAD_R: f64 = 12.0;
@@ -220,6 +218,9 @@ pub struct TextInput {
     scroll_x: f64,
     last_edit_time: Option<Instant>,
     font_size_override: Option<f32>,
+    /// Theme scale captured during `build_layout`; direct measurement falls
+    /// back to the renderer when no themed layout pass has occurred.
+    layout_text_scale: Option<f32>,
     /// Renders without the rounded-rect chrome, for block-editor cells that
     /// should read as document copy, not a form field.
     plain: bool,
@@ -284,6 +285,8 @@ pub struct TextInput {
     goal_x: Option<f64>,
     scroll_y: f64,
     gutter: bool,
+    /// Width measured from the same scaled line-number style used to paint.
+    measured_gutter_width: f64,
     highlight_current_line: bool,
     /// `None` renders the whole body in one colour; `Some` colours per [`Span`] via `token_color`.
     highlighter: Option<Box<dyn Highlighter>>,
@@ -385,6 +388,7 @@ impl TextInput {
             path_was_present: false,
             external_buffer: None,
             font_size_override: None,
+            layout_text_scale: None,
             plain: false,
             bound_text: None,
             local_author: None,
@@ -419,6 +423,7 @@ impl TextInput {
             goal_x: None,
             scroll_y: 0.0,
             gutter: false,
+            measured_gutter_width: 0.0,
             highlight_current_line: false,
             highlighter: None,
             tab_spaces: None,
@@ -1019,6 +1024,13 @@ impl TextInput {
         self.code_gutter_w()
     }
 
+    #[cfg(test)]
+    pub(crate) fn shaped_font_size_for_test(&self) -> Option<f32> {
+        self.single_layout
+            .as_ref()
+            .map(|layout| layout.buffer.metrics().font_size)
+    }
+
     /// Requires a prior `draw` to have built the metrics.
     pub fn byte_at_point(&self, point: Point) -> usize {
         self.position_at_point(point).byte
@@ -1053,6 +1065,15 @@ impl TextInput {
 
     /// Single source of truth for both the local and any peer caret, so they line up.
     pub fn text_band(&self) -> (f64, f64) {
+        if !self.multiline
+            && !self.masked()
+            && let Some(layout) = &self.single_layout
+        {
+            return (
+                self.single_origin.y,
+                f64::from(layout.buffer.metrics().line_height),
+            );
+        }
         let text_size = self.font_size_override.unwrap_or(FONT_SIZE);
         let line_height = f64::from(text_size * LINE_HEIGHT_RATIO);
         let text_y = self.rect.y0 + (self.rect.height() - line_height) / 2.0;
@@ -1209,6 +1230,11 @@ impl TextInput {
     }
 
     fn line_height(&self) -> f64 {
+        if self.multiline_shaped
+            && let Some(layout) = &self.single_layout
+        {
+            return f64::from(layout.buffer.metrics().line_height);
+        }
         f64::from(self.effective_font_size() * LINE_HEIGHT_RATIO)
     }
 
@@ -1565,23 +1591,9 @@ impl TextInput {
         &mut self,
         tr: &mut TextRenderer,
         theme: &Theme,
-        size: f32,
+        style: &TextStyle,
         available_width: f32,
-    ) -> TextStyle {
-        let family = self.family.clone().unwrap_or(if self.mono {
-            FontChoice::Monospace
-        } else {
-            FontChoice::SansSerif
-        });
-        // RichTextLayout owns its own cosmic-text shaping metrics rather than
-        // going through TextRenderer::draw_text, so it must receive the
-        // accessibility scale explicitly. Without this, multiline editors
-        // stayed visually tiny while the surrounding chrome and static text
-        // correctly followed Theme::text_scale.
-        let layout_size = size * theme.text_scale;
-        let style = TextStyle::new(layout_size)
-            .with_line_height(LINE_HEIGHT_RATIO)
-            .with_family(family.clone());
+    ) {
         self.refresh_highlight();
         let display = self.layout_display_text();
         let spans = self.highlighted_display_spans(theme);
@@ -1593,7 +1605,7 @@ impl TextInput {
             display
         );
         let signature = Self::attributed_signature(
-            self.shaped_signature(&display, &family, layout_size, Some(available_width)),
+            self.shaped_signature(&display, &style.family, style.size, Some(available_width)),
             &spans,
         );
         if self.single_layout.is_none() || self.shaped_layout_signature != signature {
@@ -1613,7 +1625,39 @@ impl TextInput {
             self.single_layout = Some(layout);
             self.shaped_layout_signature = signature;
         }
-        style
+    }
+
+    fn multiline_style(&self, scale: f32) -> TextStyle {
+        let family = self.family.clone().unwrap_or(if self.mono {
+            FontChoice::Monospace
+        } else {
+            FontChoice::SansSerif
+        });
+        TextStyle::new(self.effective_font_size() * scale)
+            .with_line_height(LINE_HEIGHT_RATIO)
+            .with_family(family)
+    }
+
+    fn update_gutter_metrics(
+        &mut self,
+        tr: &mut TextRenderer,
+        renderer_style: &TextStyle,
+        scale: f32,
+    ) {
+        if !self.gutter || !self.multiline {
+            self.measured_gutter_width = 0.0;
+            return;
+        }
+        let lines = self
+            .text
+            .bytes()
+            .filter(|&byte| byte == b'\n')
+            .count()
+            .saturating_add(1);
+        let label = lines.max(10).to_string();
+        let (number_width, _) = tr.measure_style(&label, None, renderer_style);
+        self.measured_gutter_width =
+            f64::from(number_width) + (GUTTER_PAD_L + GUTTER_PAD_R) * f64::from(scale);
     }
 
     /// Keeps the caret in view by adjusting `self.scroll_y`. Only re-centres
@@ -1781,13 +1825,16 @@ impl TextInput {
         shape: &RoundedRect,
     ) {
         let size = self.effective_font_size();
+        let style = self.multiline_style(theme.text_scale);
+        let renderer_style = tr.renderer_input_style(&style);
+        self.update_gutter_metrics(tr, &renderer_style, theme.text_scale);
         let left = self.ml_left();
         #[allow(
             clippy::cast_possible_truncation,
             reason = "widget width is a bounded on-screen size for vello/layout math, never near f32's range"
         )]
         let available_width = (self.rect.width() - left - ML_PAD_X).max(1.0) as f32;
-        let style = self.ensure_shaped_layout(tr, theme, size, available_width);
+        self.ensure_shaped_layout(tr, theme, &style, available_width);
 
         let caret_position = if self.preedit.is_empty() {
             self.text_to_layout_position(self.caret_position())
@@ -1861,7 +1908,7 @@ impl TextInput {
             transform,
             tr,
             theme,
-            &style,
+            &renderer_style,
             caret_byte,
             gutter_width,
         );
@@ -2235,6 +2282,16 @@ impl TextInput {
     /// with no presence path or permission scope.
     pub fn apply_layout_external(&mut self, rect: Rect) {
         self.rect = rect;
+        self.refresh_multiline_origin();
+    }
+
+    fn refresh_multiline_origin(&mut self) {
+        if self.multiline && self.multiline_shaped {
+            self.single_origin = Point::new(
+                self.rect.x0 + self.ml_left(),
+                self.rect.y0 + ML_PAD_Y - self.scroll_y,
+            );
+        }
     }
 
     #[must_use]
@@ -2375,6 +2432,9 @@ impl TextInput {
         if !self.gutter || !self.multiline {
             return 0.0;
         }
+        if self.measured_gutter_width > 0.0 {
+            return self.measured_gutter_width;
+        }
         let lines = self
             .text
             .bytes()
@@ -3511,9 +3571,13 @@ impl Widget for TextInput {
     fn build_layout(
         &mut self,
         taffy: &mut TaffyTree<()>,
-        _theme: &Theme,
+        theme: &Theme,
         node_map: &mut std::collections::HashMap<NodeId, *mut dyn Widget>,
     ) -> NodeId {
+        if self.layout_text_scale != Some(theme.text_scale) {
+            self.layout_text_scale = Some(theme.text_scale);
+            self.model_layout_dirty |= self.multiline;
+        }
         // Multiline is measured (grows with content, see `measure`); single-line is a fixed 40px row.
         let height = if self.multiline {
             Dimension::auto()
@@ -3539,6 +3603,7 @@ impl Widget for TextInput {
             origin.x + f64::from(layout.location.x) + f64::from(layout.size.width),
             origin.y + f64::from(layout.location.y) + f64::from(layout.size.height),
         );
+        self.refresh_multiline_origin();
     }
 
     /// Single-line keeps its fixed row height from `build_layout` (ZERO
@@ -3557,6 +3622,51 @@ impl Widget for TextInput {
             taffy::AvailableSpace::Definite(w) => w,
             _ => 400.0,
         });
+        if !self.masked() {
+            let scale = self
+                .layout_text_scale
+                .unwrap_or_else(|| text_renderer.text_scale());
+            let style = self.multiline_style(scale);
+            let renderer_style = text_renderer.renderer_input_style(&style);
+            self.update_gutter_metrics(text_renderer, &renderer_style, scale);
+            let available_width = (f64::from(width) - self.ml_left() - ML_PAD_X).max(1.0) as f32;
+            let display = self.layout_display_text();
+            let signature =
+                self.shaped_signature(&display, &style.family, style.size, Some(available_width));
+            if self.single_layout.is_none() || self.shaped_layout_signature != signature {
+                let mut layout = RichTextLayout::shape_plain(
+                    &mut text_renderer.font_system,
+                    &display,
+                    &style,
+                    Some(available_width),
+                );
+                if !self.preedit.is_empty() {
+                    let start = self.cursor_pos.min(self.text.len());
+                    layout.add_underline(start..start.saturating_add(self.preedit.len()));
+                }
+                self.single_layout = Some(layout);
+                self.shaped_layout_signature = signature;
+            }
+            self.multiline_shaped = true;
+            self.lines.clear();
+            self.refresh_multiline_origin();
+            let height = self
+                .single_layout
+                .as_ref()
+                .map_or(f64::from(style.line_height_px()), |layout| {
+                    f64::from(layout.height())
+                })
+                + ML_PAD_Y * 2.0;
+            self.model_layout_dirty = false;
+            #[allow(
+                clippy::cast_possible_truncation,
+                reason = "content height is a bounded on-screen size for taffy layout, never near f32's range"
+            )]
+            return taffy::Size {
+                width,
+                height: height as f32,
+            };
+        }
         let avail_w = (f64::from(width) - self.ml_left() - ML_PAD_X).max(1.0);
         self.build_lines(text_renderer, avail_w);
         #[allow(
@@ -6749,6 +6859,196 @@ mod tests {
         );
     }
 
+    #[test]
+    fn multiline_measure_uses_the_same_scaled_shaped_rows_as_draw() {
+        let text = "A long wrapping line whose measured height must match the caret rows produced by the shaped draw path at large text.";
+        let mut input = TextInput::local()
+            .multiline(true)
+            .with_font_size(14.0)
+            .with_initial_value(text);
+        let mut renderer = TextRenderer::new();
+        renderer.set_text_scale(2.0);
+        let measured = Widget::measure(
+            &mut input,
+            taffy::Size {
+                width: Some(180.0),
+                height: None,
+            },
+            taffy::Size {
+                width: taffy::AvailableSpace::Definite(180.0),
+                height: taffy::AvailableSpace::MaxContent,
+            },
+            &mut renderer,
+        );
+
+        input.apply_layout_external(Rect::new(0.0, 0.0, 180.0, f64::from(measured.height)));
+        let theme = Theme::dark().with_text_scale(2.0);
+        draw_with_theme(&mut input, &theme);
+        let layout = input
+            .single_layout
+            .as_ref()
+            .expect("shaped multiline layout");
+        let expected_height = layout.height() + (ML_PAD_Y * 2.0) as f32;
+        assert!(
+            (measured.height - expected_height).abs() < 0.1,
+            "measure {measured:?} must use drawn shaped height {expected_height}"
+        );
+        let last_row = layout.visual_line_index(input.text_to_layout_byte(text.len()));
+        let caret = input.caret_rect(&theme, text.len());
+        assert_eq!(
+            (caret.y0 / caret.height()).floor() as usize,
+            last_row,
+            "caret row and shaped visual row index agree"
+        );
+    }
+
+    #[test]
+    fn multiline_measure_uses_build_layout_theme_scale_when_renderer_is_stale() {
+        let text = "The layout theme owns accessibility scale even when a retained renderer still carries its previous frame value.";
+        let mut input = TextInput::local().multiline(true).with_initial_value(text);
+        let large = Theme::dark().with_text_scale(2.0);
+        let mut taffy = TaffyTree::<()>::new();
+        let mut node_map = std::collections::HashMap::new();
+        let _ = Widget::build_layout(&mut input, &mut taffy, &large, &mut node_map);
+
+        let mut renderer = TextRenderer::new();
+        assert_eq!(renderer.text_scale(), 1.0, "stale renderer precondition");
+        let measured_large = Widget::measure(
+            &mut input,
+            taffy::Size {
+                width: Some(180.0),
+                height: None,
+            },
+            taffy::Size {
+                width: taffy::AvailableSpace::Definite(180.0),
+                height: taffy::AvailableSpace::MaxContent,
+            },
+            &mut renderer,
+        );
+        input.apply_layout_external(Rect::new(0.0, 0.0, 180.0, f64::from(measured_large.height)));
+        draw_with_theme(&mut input, &large);
+        let drawn_large = input.content_height() as f32;
+        assert!((measured_large.height - drawn_large).abs() < 0.1);
+
+        let normal = Theme::dark();
+        let mut taffy = TaffyTree::<()>::new();
+        let mut node_map = std::collections::HashMap::new();
+        let _ = Widget::build_layout(&mut input, &mut taffy, &normal, &mut node_map);
+        let measured_normal = Widget::measure(
+            &mut input,
+            taffy::Size {
+                width: Some(180.0),
+                height: None,
+            },
+            taffy::Size {
+                width: taffy::AvailableSpace::Definite(180.0),
+                height: taffy::AvailableSpace::MaxContent,
+            },
+            &mut renderer,
+        );
+        input.apply_layout_external(Rect::new(
+            0.0,
+            0.0,
+            180.0,
+            f64::from(measured_normal.height),
+        ));
+        draw_with_theme(&mut input, &normal);
+        assert!((measured_normal.height - input.content_height() as f32).abs() < 0.1);
+        assert!(
+            measured_large.height > measured_normal.height * 1.8,
+            "same instance remeasures from large text back to normal"
+        );
+    }
+
+    #[test]
+    fn measured_multiline_pointer_geometry_tracks_applied_origin_before_draw() {
+        let text = "first wrapped row continues for a while before the second hard line\nsecond";
+        let mut input = TextInput::local().multiline(true).with_initial_value(text);
+        let mut renderer = TextRenderer::new();
+        renderer.set_text_scale(2.0);
+        let measured = Widget::measure(
+            &mut input,
+            taffy::Size {
+                width: Some(180.0),
+                height: None,
+            },
+            taffy::Size {
+                width: taffy::AvailableSpace::Definite(180.0),
+                height: taffy::AvailableSpace::MaxContent,
+            },
+            &mut renderer,
+        );
+        input.apply_layout_external(Rect::new(
+            100.0,
+            50.0,
+            280.0,
+            50.0 + f64::from(measured.height),
+        ));
+        let second = text.find('\n').expect("hard break") + 1;
+        let (x, top, height) = input
+            .single_layout
+            .as_ref()
+            .expect("measurement retained shaped rows")
+            .caret_geometry(input.text_to_layout_byte(second));
+        let point = Point::new(
+            input.rect.x0 + input.ml_left() + f64::from(x) + 1.0,
+            input.rect.y0 + ML_PAD_Y + f64::from(top + height / 2.0),
+        );
+        assert_eq!(
+            input.byte_at_point(point),
+            second,
+            "pointer uses the applied widget origin before the first draw"
+        );
+    }
+
+    #[test]
+    fn scaled_multiline_geometry_refreshes_across_model_undo_redo_replay() {
+        let long = "undo and redo replay model text through the same widget, including a long line that wraps at large text";
+        let theme = Theme::dark().with_text_scale(2.0);
+        let mut input = TextInput::local().multiline(true).with_initial_value(long);
+        input.apply_layout_external(Rect::new(0.0, 0.0, 180.0, 400.0));
+        draw_with_theme(&mut input, &theme);
+        let long_height = input.content_height();
+        let long_rows = input
+            .single_layout
+            .as_ref()
+            .expect("redo source layout")
+            .buffer
+            .layout_runs()
+            .count();
+        assert!(long_rows > 1, "precondition: large text wraps");
+
+        input.set_text("undo");
+        input.set_cursor_pos(input.value().len());
+        draw_with_theme(&mut input, &theme);
+        assert_eq!(
+            input
+                .single_layout
+                .as_ref()
+                .expect("undo layout")
+                .buffer
+                .layout_runs()
+                .count(),
+            1
+        );
+        assert!(input.content_height() < long_height);
+
+        input.set_text(long);
+        input.set_cursor_pos(long.len());
+        draw_with_theme(&mut input, &theme);
+        assert_eq!(
+            input
+                .single_layout
+                .as_ref()
+                .expect("redo layout")
+                .buffer
+                .layout_runs()
+                .count(),
+            long_rows
+        );
+        assert!((input.content_height() - long_height).abs() < 0.1);
+    }
+
     /// Mirrors the handler's own `padding_x = 10.0`; assumes `scroll_x == 0`.
     fn x_for_byte(ti: &TextInput, b: usize) -> f64 {
         ti.rect.x0 + 10.0 + ti.char_x_positions()[b]

```

## 83c269dac
```diff
commit 83c269dac5d2fa49078472887d9c4dda530c2ae6
Author:     Xaver Emmerling <xaver@Mac.lan>
AuthorDate: Wed Sep 16 10:11:21 2026 -0700
Commit:     Xaver Emmerling <xaver@Mac.lan>
CommitDate: Wed Sep 16 10:11:21 2026 -0700

    fix(ui): propagate editor layout invalidation
---
 ui/src/widget/code_editor.rs |  82 +++++++++++++++++++++++-
 ui/src/widget/text_input.rs  | 148 +++++++++++++++++++++++++++----------------
 2 files changed, 176 insertions(+), 54 deletions(-)

diff --git a/ui/src/widget/code_editor.rs b/ui/src/widget/code_editor.rs
index 125cee27c..f9289635b 100644
--- a/ui/src/widget/code_editor.rs
+++ b/ui/src/widget/code_editor.rs
@@ -443,6 +443,7 @@ impl Widget for CodeEditor {
         theme: &Theme,
         node_map: &mut std::collections::HashMap<NodeId, *mut dyn Widget>,
     ) -> NodeId {
+        self.inner.capture_layout_text_scale(theme.text_scale);
         // Registers *this* widget (not the inner input) so the host
         // drives CodeEditor's own passes.
         let node = taffy.leaf_node(Style {
@@ -452,7 +453,6 @@ impl Widget for CodeEditor {
             },
             ..Default::default()
         });
-        let _ = theme;
         node_map.insert(node, std::ptr::from_mut::<dyn Widget>(self));
         node
     }
@@ -1696,6 +1696,39 @@ mod tests {
         Widget::draw(ed, &mut scene, Affine::IDENTITY, &mut tr, theme, &presence);
     }
 
+    fn lay_out_and_draw(
+        ed: &mut CodeEditor,
+        theme: &Theme,
+        renderer: &mut TextRenderer,
+        width: f32,
+    ) -> f32 {
+        let mut taffy = TaffyTree::<()>::new();
+        let mut node_map = std::collections::HashMap::new();
+        let node = Widget::build_layout(ed, &mut taffy, theme, &mut node_map);
+        taffy
+            .compute_layout_with_measure(
+                node,
+                taffy::Size {
+                    width: taffy::AvailableSpace::Definite(width),
+                    height: taffy::AvailableSpace::MaxContent,
+                },
+                |known, available, id, _, _| {
+                    node_map
+                        .get(&id)
+                        .map_or(taffy::Size::ZERO, |&widget| unsafe {
+                            (*widget).measure(known, available, renderer)
+                        })
+                },
+            )
+            .expect("code editor layout computes");
+        let height = taffy.layout(node).expect("code editor layout").size.height;
+        Widget::apply_layout(ed, &taffy, node, Point::ZERO);
+        let presence = PresenceCtx::default();
+        let mut scene = Scene::new();
+        Widget::draw(ed, &mut scene, Affine::IDENTITY, renderer, theme, &presence);
+        height
+    }
+
     use crate::text_render::TextRenderer;
 
     #[test]
@@ -1997,4 +2030,51 @@ mod tests {
             "pointer event places the caret on the logical second line through wrapped rows"
         );
     }
+
+    #[test]
+    fn wrapper_layout_uses_theme_scale_with_a_stale_renderer_and_reverses_to_normal() {
+        let text = "a long source line wraps over several visual rows while the wrapper owns the themed layout lifecycle";
+        let mut editor = CodeEditor::local().with_initial_value(text);
+        let mut renderer = TextRenderer::new();
+        assert_eq!(renderer.text_scale(), 1.0, "stale renderer precondition");
+
+        let large_theme = Theme::dark().with_text_scale(2.0);
+        let large_height = lay_out_and_draw(&mut editor, &large_theme, &mut renderer, 190.0);
+        let large_gutter = editor.gutter_width();
+        let large_font = editor
+            .inner()
+            .shaped_font_size_for_test()
+            .expect("large shaped font");
+        assert!(
+            (f64::from(large_height) - editor.inner().content_height()).abs() < 0.1,
+            "wrapper measure and draw must share the 2x paragraph height"
+        );
+
+        let normal_theme = Theme::dark();
+        let mut taffy = TaffyTree::<()>::new();
+        let mut node_map = std::collections::HashMap::new();
+        let _ = Widget::build_layout(&mut editor, &mut taffy, &normal_theme, &mut node_map);
+        assert!(
+            Widget::layout_needs_measure(&editor),
+            "the same wrapper becomes measure-dirty when theme scale returns to 1x"
+        );
+        let normal_height = lay_out_and_draw(&mut editor, &normal_theme, &mut renderer, 190.0);
+        let normal_gutter = editor.gutter_width();
+        let normal_font = editor
+            .inner()
+            .shaped_font_size_for_test()
+            .expect("normal shaped font");
+        assert!(
+            (f64::from(normal_height) - editor.inner().content_height()).abs() < 0.1,
+            "wrapper measure and draw must share the restored 1x paragraph height"
+        );
+        assert!(large_height > normal_height * 1.8);
+        assert!(large_gutter >= normal_gutter * 1.8);
+        assert!(large_font >= normal_font * 1.9);
+        assert_eq!(
+            renderer.text_scale(),
+            1.0,
+            "renderer stayed stale throughout"
+        );
+    }
 }
diff --git a/ui/src/widget/text_input.rs b/ui/src/widget/text_input.rs
index f92ea5b5c..fd61d5070 100644
--- a/ui/src/widget/text_input.rs
+++ b/ui/src/widget/text_input.rs
@@ -465,8 +465,7 @@ impl TextInput {
         let text = state
             .text(obj)
             .map_err(|e| crate::view::ThawError::State(e.to_string()))?;
-        if self.text != text {
-            self.text = text;
+        if self.adopt_model_text(text) {
             self.dirty = true;
         }
         self.clamp_to_text();
@@ -474,6 +473,26 @@ impl TextInput {
         Ok(())
     }
 
+    /// Replace text read from model state without reporting a user edit.
+    /// Returns whether the value changed so direct bindings can preserve
+    /// their existing reconciliation signal.
+    fn adopt_model_text(&mut self, text: String) -> bool {
+        if self.text == text {
+            return false;
+        }
+        self.text = text;
+        self.model_layout_dirty |= self.multiline;
+        true
+    }
+
+    /// Capture the resolved theme scale before a renderer-backed measurement.
+    pub(super) fn capture_layout_text_scale(&mut self, text_scale: f32) {
+        if self.layout_text_scale != Some(text_scale) {
+            self.layout_text_scale = Some(text_scale);
+            self.model_layout_dirty |= self.multiline;
+        }
+    }
+
     /// Keep the binding readable while an owning action bridge handles user writes.
     pub fn set_direct_crdt_writes(&mut self, enabled: bool) {
         self.direct_crdt_writes = enabled;
@@ -1585,8 +1604,7 @@ impl TextInput {
     /// the same shaped paragraph for paint, wrapping, carets, selection,
     /// hit-testing, vertical movement, and IME composition.
     /// Rebuilds `self.single_layout` (and its signature) if the shaped
-    /// spans, family or size changed since the last draw. Returns the
-    /// `TextStyle` used, so gutter line numbers reuse the exact metrics.
+    /// spans, family, size, or available width changed.
     fn ensure_shaped_layout(
         &mut self,
         tr: &mut TextRenderer,
@@ -2427,7 +2445,8 @@ impl TextInput {
         self.tab_spaces = Some(n);
     }
 
-    /// Pure function of line count + font size, so geometry and painting stay identical.
+    /// Uses measured line-number glyphs after layout, with a font-size
+    /// estimate only before the first measurement.
     fn code_gutter_w(&self) -> f64 {
         if !self.gutter || !self.multiline {
             return 0.0;
@@ -3541,12 +3560,12 @@ impl Widget for TextInput {
                 match val {
                     Value::Scalar(s) => {
                         if let automerge::ScalarValue::Str(text) = s.as_ref() {
-                            self.text = text.to_string();
+                            self.adopt_model_text(text.to_string());
                         }
                     }
                     Value::Object(ObjType::Text) => {
                         if let Ok(text) = state.text(&obj_id) {
-                            self.text = text;
+                            self.adopt_model_text(text);
                         }
                     }
                     Value::Object(_) => {}
@@ -3554,7 +3573,7 @@ impl Widget for TextInput {
             }
             Ok(None) if self.path_was_present => {
                 self.path_was_present = false;
-                self.text.clear();
+                self.adopt_model_text(String::new());
                 self.cursor_pos = 0;
                 self.selection_anchor = None;
                 self.goal_x = None;
@@ -3574,10 +3593,7 @@ impl Widget for TextInput {
         theme: &Theme,
         node_map: &mut std::collections::HashMap<NodeId, *mut dyn Widget>,
     ) -> NodeId {
-        if self.layout_text_scale != Some(theme.text_scale) {
-            self.layout_text_scale = Some(theme.text_scale);
-            self.model_layout_dirty |= self.multiline;
-        }
+        self.capture_layout_text_scale(theme.text_scale);
         // Multiline is measured (grows with content, see `measure`); single-line is a fixed 40px row.
         let height = if self.multiline {
             Dimension::auto()
@@ -7002,51 +7018,77 @@ mod tests {
     }
 
     #[test]
-    fn scaled_multiline_geometry_refreshes_across_model_undo_redo_replay() {
-        let long = "undo and redo replay model text through the same widget, including a long line that wraps at large text";
+    fn crdt_sync_undo_redo_invalidates_multiline_measurement() {
+        let short = "short";
+        let long = "undo and redo replay real CRDT text through the same widget, including a long line that wraps at large text";
         let theme = Theme::dark().with_text_scale(2.0);
-        let mut input = TextInput::local().multiline(true).with_initial_value(long);
-        input.apply_layout_external(Rect::new(0.0, 0.0, 180.0, 400.0));
-        draw_with_theme(&mut input, &theme);
-        let long_height = input.content_height();
-        let long_rows = input
-            .single_layout
-            .as_ref()
-            .expect("redo source layout")
-            .buffer
-            .layout_runs()
-            .count();
-        assert!(long_rows > 1, "precondition: large text wraps");
+        let mut state = crate::State::new();
+        let text_obj = state
+            .doc
+            .put_object(&state.root, "body", ObjType::Text)
+            .expect("create document text");
+        state
+            .doc
+            .splice_text(&text_obj, 0, 0, short)
+            .expect("seed document text");
+        state.commit_action(None, None);
+
+        let mut input = TextInput::from_document_string("body").multiline(true);
+        Widget::sync(&mut input, &mut state.doc, &state.root);
+        let mut renderer = TextRenderer::new();
+        let mut taffy = TaffyTree::<()>::new();
+        let mut node_map = std::collections::HashMap::new();
+        let _ = Widget::build_layout(&mut input, &mut taffy, &theme, &mut node_map);
+        let measure = |input: &mut TextInput, renderer: &mut TextRenderer| {
+            Widget::measure(
+                input,
+                taffy::Size {
+                    width: Some(180.0),
+                    height: None,
+                },
+                taffy::Size {
+                    width: taffy::AvailableSpace::Definite(180.0),
+                    height: taffy::AvailableSpace::MaxContent,
+                },
+                renderer,
+            )
+            .height
+        };
+        let short_height = measure(&mut input, &mut renderer);
+        input.apply_layout_external(Rect::new(0.0, 0.0, 180.0, f64::from(short_height)));
+        assert!(!Widget::layout_needs_measure(&input));
 
-        input.set_text("undo");
-        input.set_cursor_pos(input.value().len());
-        draw_with_theme(&mut input, &theme);
-        assert_eq!(
-            input
-                .single_layout
-                .as_ref()
-                .expect("undo layout")
-                .buffer
-                .layout_runs()
-                .count(),
-            1
+        let old_len = state.doc.length(&text_obj);
+        state
+            .doc
+            .splice_text(
+                &text_obj,
+                0,
+                isize::try_from(old_len).expect("test text length fits isize"),
+                long,
+            )
+            .expect("replace with wrapping text");
+        state.commit_action(None, None);
+        Widget::sync(&mut input, &mut state.doc, &state.root);
+        assert_eq!(input.take_dirty(), None, "model sync is not a user edit");
+        assert!(
+            Widget::layout_needs_measure(&input),
+            "CRDT text growth invalidates retained measurement"
         );
-        assert!(input.content_height() < long_height);
+        let long_height = measure(&mut input, &mut renderer);
+        assert!(long_height > short_height * 1.8, "long text wraps at 2x");
 
-        input.set_text(long);
-        input.set_cursor_pos(long.len());
-        draw_with_theme(&mut input, &theme);
-        assert_eq!(
-            input
-                .single_layout
-                .as_ref()
-                .expect("redo layout")
-                .buffer
-                .layout_runs()
-                .count(),
-            long_rows
-        );
-        assert!((input.content_height() - long_height).abs() < 0.1);
+        state.undo(None, None).expect("undo long text");
+        Widget::sync(&mut input, &mut state.doc, &state.root);
+        assert!(Widget::layout_needs_measure(&input));
+        let undo_height = measure(&mut input, &mut renderer);
+        assert!((undo_height - short_height).abs() < 0.1);
+
+        state.redo(None, None).expect("redo long text");
+        Widget::sync(&mut input, &mut state.doc, &state.root);
+        assert!(Widget::layout_needs_measure(&input));
+        let redo_height = measure(&mut input, &mut renderer);
+        assert!((redo_height - long_height).abs() < 0.1);
     }
 
     /// Mirrors the handler's own `padding_x = 10.0`; assumes `scroll_x == 0`.

```

## fba9ea50f
```diff
commit fba9ea50f0e0547237ac4c3d7151c04b5e6ec145
Author:     Xaver Emmerling <xaver@Mac.lan>
AuthorDate: Wed Sep 16 10:39:12 2026 -0700
Commit:     Xaver Emmerling <xaver@Mac.lan>
CommitDate: Wed Sep 16 10:39:12 2026 -0700

    Add opt-in full-height writing surfaces to Scrollable
---
 ui/src/widget/scrollable.rs | 226 ++++++++++++++++++++++++++++++++++++--
 ui/src/widget/text_input.rs |   5 +-
 ui/tests/scrollable_test.rs | 258 ++++++++++++++++++++++++++++++++++++++++++++
 3 files changed, 482 insertions(+), 7 deletions(-)

diff --git a/ui/src/widget/scrollable.rs b/ui/src/widget/scrollable.rs
index 399e6c6ca..37d623340 100644
--- a/ui/src/widget/scrollable.rs
+++ b/ui/src/widget/scrollable.rs
@@ -116,6 +116,8 @@ pub struct Scrollable {
     /// Absorbs the parent's remaining flex height instead of claiming
     /// `percent(1.0)`. `fixed_height` wins if both are set.
     fill_parent_height: bool,
+    /// Opt-in inherited decision, consumed by the retained content wrapper.
+    content_min_viewport_height: Option<Rc<Cell<f32>>>,
     child: Option<Element>,
     /// Retained Taffy identity for `child`; refreshed with the layout tree so
     /// event and scroll-layout paths never allocate `taffy.children()`.
@@ -194,6 +196,7 @@ impl Scrollable {
             fixed_height: None,
             max_height: None,
             fill_parent_height: false,
+            content_min_viewport_height: None,
             child: None,
             child_node: None,
             rect: Rect::ZERO,
@@ -227,9 +230,32 @@ impl Scrollable {
     }
     #[must_use]
     pub fn with_child(mut self, c: Element) -> Self {
-        self.child = Some(c);
+        self.child = Some(match &self.content_min_viewport_height {
+            Some(minimum) => Box::new(ViewportContent::new(c, Rc::clone(minimum))),
+            None => c,
+        });
         self
     }
+    /// Let auto-height content fill at least the measured viewport height,
+    /// retaining its intrinsic height when it overflows. This does not change
+    /// an explicitly sized child's authored height. Ordinary form fields stay
+    /// content-sized unless their Scrollable opts in.
+    ///
+    /// Adds a presentational single-child wrapper to normal widget traversal;
+    /// the content keeps its identity, focus and action bindings. Hosts must
+    /// use the shared measured layout solver to resolve the viewport minimum.
+    #[must_use]
+    pub fn with_content_min_viewport_height(mut self) -> Self {
+        if self.content_min_viewport_height.is_none() {
+            let minimum = Rc::new(Cell::new(0.0));
+            if let Some(child) = self.child.take() {
+                self.child = Some(Box::new(ViewportContent::new(child, Rc::clone(&minimum))));
+            }
+            self.content_min_viewport_height = Some(minimum);
+        }
+        self
+    }
+
     #[must_use]
     pub fn with_sticky_header(mut self, h: f32) -> Self {
         self.sticky_header_height = h;
@@ -921,6 +947,164 @@ impl Scrollable {
     }
 }
 
+/// A presentational Grid surface. Container supplies the ordinary single-child
+/// lifecycle; we register its layout node as this wrapper's own node so only
+/// this hook adjusts its minimum. The child style is never rewritten.
+struct ViewportContent {
+    inner: crate::widget::Container,
+    minimum: Rc<Cell<f32>>,
+}
+
+impl ViewportContent {
+    fn new(child: Element, minimum: Rc<Cell<f32>>) -> Self {
+        Self {
+            inner: crate::widget::Container::new()
+                .with_no_padding()
+                .with_child(child),
+            minimum,
+        }
+    }
+}
+
+impl Widget for ViewportContent {
+    fn sync(&mut self, state: &mut AutoCommit, path: &ObjId) {
+        self.inner.sync(state, path);
+    }
+
+    fn update(&mut self, state: &mut AutoCommit, path: &ObjId) -> bool {
+        self.inner.update(state, path)
+    }
+
+    fn build_layout(
+        &mut self,
+        taffy: &mut TaffyTree<()>,
+        theme: &Theme,
+        nodes: &mut std::collections::HashMap<NodeId, *mut dyn Widget>,
+    ) -> NodeId {
+        use taffy::style_helpers::{fr, length, min_content, minmax};
+        let node = self.inner.build_layout(taffy, theme, nodes);
+        let _ = taffy.set_style(
+            node,
+            Style {
+                display: taffy::Display::Grid,
+                // The flexible track fills short content; its intrinsic minimum
+                // keeps a long measured editor taller than the viewport.
+                grid_template_rows: vec![minmax(min_content(), fr(1.0_f32))],
+                grid_template_columns: vec![minmax(length(0.0_f32), fr(1.0_f32))],
+                size: Size {
+                    width: Dimension::percent(1.0),
+                    height: Dimension::auto(),
+                },
+                min_size: Size {
+                    width: Dimension::length(0.0),
+                    height: Dimension::length(self.minimum.get()),
+                },
+                flex_shrink: 0.0,
+                ..Default::default()
+            },
+        );
+        nodes.insert(node, std::ptr::from_mut::<dyn Widget>(self));
+        node
+    }
+
+    fn adjust_layout_style(&mut self, taffy: &mut TaffyTree<()>, node: NodeId) -> bool {
+        let Ok(style) = taffy.style(node) else {
+            return false;
+        };
+        let height = Dimension::length(self.minimum.get());
+        if style.min_size.height == height {
+            return false;
+        }
+        let mut style = style.clone();
+        style.min_size.height = height;
+        taffy.set_style(node, style).is_ok()
+    }
+
+    fn apply_layout(&mut self, taffy: &TaffyTree<()>, node: NodeId, origin: Point) {
+        self.inner.apply_layout(taffy, node, origin);
+    }
+
+    fn draw(
+        &mut self,
+        scene: &mut Scene,
+        transform: Affine,
+        text: &mut TextRenderer,
+        theme: &Theme,
+        presence: &PresenceCtx,
+    ) {
+        self.inner.draw(scene, transform, text, theme, presence);
+    }
+
+    fn draw_with_presence(
+        &mut self,
+        scene: &mut Scene,
+        transform: Affine,
+        text: &mut TextRenderer,
+        theme: &Theme,
+        presence: &PresenceCtx,
+        permissions: &crate::permissions::PermissionContext,
+    ) {
+        self.inner
+            .draw_with_presence(scene, transform, text, theme, presence, permissions);
+    }
+
+    fn handle_event(
+        &mut self,
+        event: &WindowEvent,
+        scale: f64,
+        mods: &winit::event::Modifiers,
+        state: &mut AutoCommit,
+        path: &ObjId,
+        handled: &mut bool,
+        focus: &mut Option<NodeId>,
+        node: NodeId,
+        taffy: &TaffyTree<()>,
+    ) {
+        self.inner
+            .handle_event(event, scale, mods, state, path, handled, focus, node, taffy);
+    }
+
+    fn children(&self) -> Vec<&dyn Widget> {
+        self.inner.children()
+    }
+    fn for_each_child(&self, visitor: &mut dyn FnMut(&dyn Widget)) {
+        self.inner.for_each_child(visitor);
+    }
+    fn children_mut(&mut self) -> Vec<&mut (dyn Widget + '_)> {
+        self.inner.children_mut()
+    }
+    fn take_structure_dirty(&mut self) -> bool {
+        self.inner.take_structure_dirty()
+    }
+    fn wants_pointer_capture(&self) -> bool {
+        self.inner.wants_pointer_capture()
+    }
+    fn get_rect(&self) -> Rect {
+        self.inner.get_rect()
+    }
+    fn name(&self) -> &str {
+        "ScrollableContent"
+    }
+
+    fn start_resource_operation_with_document(
+        &mut self,
+        invocation: qos_actions::InvocationId,
+        kind: qos_actions::OperationKind,
+        type_id: &str,
+        payload: &[u8],
+        doc: &mut AutoCommit,
+        path: &ObjId,
+    ) -> Result<Option<crate::widget::ResourceOperationStart>, String> {
+        self.inner
+            .start_resource_operation_with_document(invocation, kind, type_id, payload, doc, path)
+    }
+
+    fn collect_damage(&self, regions: &mut Vec<Rect>) {
+        self.inner
+            .for_each_child(&mut |child| child.collect_damage(regions));
+    }
+}
+
 /// Maximum `rect.y1` across a widget subtree, for finding the true bottom
 /// edge when taffy's `content_size` under-reports.
 fn max_bottom_edge(w: &dyn Widget) -> f64 {
@@ -1013,6 +1197,23 @@ impl Widget for Scrollable {
         node
     }
 
+    fn adjust_layout_style(&mut self, taffy: &mut TaffyTree<()>, node: NodeId) -> bool {
+        let Some(minimum) = &self.content_min_viewport_height else {
+            return false;
+        };
+        let Ok(layout) = taffy.layout(node) else {
+            return false;
+        };
+        let height = layout.size.height.max(0.0);
+        if (minimum.get() - height).abs() < f32::EPSILON {
+            return false;
+        }
+        // Inherited decision only. The wrapper's hook changes its OWN style,
+        // regardless of the host's node visitation order.
+        minimum.set(height);
+        true
+    }
+
     fn apply_layout(&mut self, taffy: &TaffyTree<()>, node: NodeId, origin: Point) {
         // Geometry may have moved beneath a stationary pointer. The next
         // same-position event must therefore be routed once again.
@@ -1156,13 +1357,9 @@ impl Widget for Scrollable {
                 ..
             } => {
                 let cur = self.last_cursor;
-                // A child that consumes the press overwrites `focus_target`
-                // afterward, so focus still lands on the deepest target.
-                if self.content_viewport_rect().contains(cur) {
-                    *focus_target = Some(node_id);
-                }
                 // Thumb press → drag; track press → page + hold.
                 if self.on_track_or_thumb_press(cur) {
+                    *focus_target = Some(node_id);
                     *handled = true;
                     return;
                 }
@@ -1268,6 +1465,23 @@ impl Widget for Scrollable {
                 taffy,
             );
         }
+        // An already-focused editor can consume a press without requesting
+        // focus again. Only use the pane as a fallback for an unhandled
+        // background press; never displace the child's existing focus.
+        if !*handled
+            && focus_target.is_none()
+            && pointer_in_content
+            && matches!(
+                event,
+                WindowEvent::MouseInput {
+                    state: ElementState::Pressed,
+                    button: MouseButton::Left,
+                    ..
+                }
+            )
+        {
+            *focus_target = Some(node_id);
+        }
     }
 
     fn children(&self) -> Vec<&dyn Widget> {
diff --git a/ui/src/widget/text_input.rs b/ui/src/widget/text_input.rs
index fd61d5070..6139dad74 100644
--- a/ui/src/widget/text_input.rs
+++ b/ui/src/widget/text_input.rs
@@ -3680,7 +3680,10 @@ impl Widget for TextInput {
             )]
             return taffy::Size {
                 width,
-                height: height as f32,
+                // Taffy rounds layout boxes to pixels. Never round intrinsic
+                // text below its last row: subpixel inner overflow would eat
+                // the first wheel event instead of scrolling the outer pane.
+                height: height.ceil() as f32,
             };
         }
         let avail_w = (f64::from(width) - self.ml_left() - ML_PAD_X).max(1.0);
diff --git a/ui/tests/scrollable_test.rs b/ui/tests/scrollable_test.rs
index 5b02773e2..68f893e0a 100644
--- a/ui/tests/scrollable_test.rs
+++ b/ui/tests/scrollable_test.rs
@@ -44,3 +44,261 @@ fn scrollable_momentum_decays() {
     assert!(after > before);
     assert!(s.momentum_speed() < 10.0);
 }
+
+use ui::State;
+use ui::headless::Driver;
+use ui::local_state::LocalState;
+use ui::theme::Theme;
+use ui::widget::{Button, Column, Container, Text, TextInput};
+
+fn editor_driver(text: &LocalState<String>, fill: bool, scale: f32) -> Driver {
+    let mut scroll = Scrollable::new_vertical().fill_parent_height();
+    if fill {
+        scroll = scroll.with_content_min_viewport_height();
+    }
+    let root = Column::new()
+        .with_no_padding()
+        .with_gap(0.0)
+        .push(Box::new(
+            scroll.with_child(Box::new(
+                TextInput::from_state(text)
+                    .multiline(true)
+                    .with_id("editor"),
+            )),
+        ))
+        .push(Box::new(Button::new("footer", "Save", None)));
+    let theme = Theme::dark().with_text_scale(scale);
+    Driver::new_with_theme(State::new(), Box::new(root), (600, 400), theme)
+}
+
+#[test]
+fn empty_writing_surface_fills_viewport_and_accepts_lower_click() {
+    for scale in [1.0, 2.0] {
+        let text = LocalState::new(String::new());
+        let mut driver = editor_driver(&text, true, scale);
+        let targets = driver.targets();
+        let editor = *targets.get("editor").unwrap();
+        let footer = *targets.get("footer").unwrap();
+        assert!(
+            (editor.y1 - footer.y0).abs() < 1.0,
+            "editor {editor:?}, footer {footer:?}"
+        );
+        assert!(editor.height() > 250.0);
+        driver.click_at(editor.x0 + 30.0, editor.y1 - 30.0);
+        driver.type_text("lower click");
+        assert_eq!(text.get(), "lower click");
+        driver.click_at(editor.x1 - 30.0, editor.y1 - 30.0);
+        driver.type_text(" at end");
+        assert_eq!(text.get(), "lower click at end");
+        assert!(driver.targets().get("footer").unwrap().y1 <= 400.0);
+    }
+}
+
+#[test]
+fn default_short_multiline_remains_content_sized() {
+    let text = LocalState::new(String::new());
+    let driver = editor_driver(&text, false, 1.0);
+    let targets = driver.targets();
+    assert!(targets.get("editor").unwrap().height() < 60.0);
+    assert!(targets.get("footer").unwrap().y0 > 300.0);
+}
+
+#[test]
+fn long_writing_surface_retains_overflow_and_footer() {
+    let text = LocalState::new("A line of the document.\n".repeat(80));
+    let mut driver = editor_driver(&text, true, 1.0);
+    let initial = *driver.targets().get("editor").unwrap();
+    let footer = *driver.targets().get("footer").unwrap();
+    assert!(initial.height() > 1000.0, "{initial:?}");
+    driver.click_at(30.0, 100.0);
+    driver.scroll(0.0, -800.0);
+    let moved = *driver.targets().get("editor").unwrap();
+    assert!(
+        moved.y0 < initial.y0 - 100.0,
+        "before {initial:?}, after {moved:?}"
+    );
+    assert_eq!(*driver.targets().get("footer").unwrap(), footer);
+    assert!(footer.y1 <= 400.0);
+}
+
+#[test]
+fn writing_surface_settles_resize_and_short_long_short_changes() {
+    let text = LocalState::new(String::new());
+    let mut driver = editor_driver(&text, true, 1.0);
+    for width in [280, 760, 280, 760] {
+        driver.resize((width, 400)).unwrap();
+        for body in [
+            String::new(),
+            "Wrapping document text with some words. ".repeat(100),
+            String::new(),
+        ] {
+            let long = !body.is_empty();
+            text.set(body);
+            driver.relayout();
+            let targets = driver.targets();
+            let editor = targets.get("editor").unwrap();
+            let footer = targets.get("footer").unwrap();
+            assert!(
+                (editor.width() - f64::from(width)).abs() < 1.0,
+                "{editor:?}"
+            );
+            if long {
+                assert!(editor.height() > 400.0, "{editor:?}");
+            } else {
+                assert!(
+                    (editor.y1 - footer.y0).abs() < 1.0,
+                    "editor {editor:?}, footer {footer:?}"
+                );
+            }
+        }
+    }
+}
+
+#[test]
+fn writing_surface_preserves_explicit_child_height() {
+    // The explicit Container remains 72px even though its wrapper fills 300px.
+    let root = Scrollable::new_vertical()
+        .with_height(300.0)
+        .with_content_min_viewport_height()
+        .with_child(Box::new(
+            Container::new()
+                .with_no_padding()
+                .with_height(72.0)
+                .with_child(Box::new(Text::new("Fixed content").with_id("fixed"))),
+        ));
+    let driver = Driver::new(State::new(), Box::new(root), (500, 300));
+    assert!((driver.targets().get("fixed").unwrap().height() - 72.0).abs() < 1.0);
+}
+
+#[test]
+fn writing_surface_retained_tree_settles_without_changing_child_style() {
+    use std::collections::HashMap;
+    use taffy::{AvailableSpace, Dimension, Size, TaffyTree};
+    use ui::bound_dispatch::BoundNodeMap;
+    use ui::text_render::TextRenderer;
+    use ui::widget::{Widget, compute_widget_layout};
+    use vello::kurbo::Point;
+
+    let text = LocalState::new(String::new());
+    // Also exercise child-before-opt-in builder ordering and repeated opt-in.
+    let mut scroll = Scrollable::new_vertical()
+        .with_child(Box::new(TextInput::from_state(&text).multiline(true)))
+        .with_content_min_viewport_height()
+        .with_content_min_viewport_height();
+    let mut tree = TaffyTree::new();
+    let mut nodes = HashMap::new();
+    let root = scroll.build_layout(&mut tree, &Theme::dark(), &mut nodes);
+    let wrapper = *tree.children(root).unwrap().first().unwrap();
+    let editor = *tree.children(wrapper).unwrap().first().unwrap();
+    let child_style = tree.style(editor).unwrap().clone();
+    let mut bindings = BoundNodeMap::new();
+    // SAFETY: one stable tree, exclusively owned throughout the test.
+    unsafe {
+        bindings.rebuild(&scroll, &tree, root, &nodes);
+    }
+    let mut renderer = TextRenderer::new();
+    let mut doc = automerge::AutoCommit::new();
+    for (width, height) in [(280.0, 180.0), (760.0, 420.0), (280.0, 300.0)] {
+        let mut style = tree.style(root).unwrap().clone();
+        style.size.height = Dimension::length(height);
+        tree.set_style(root, style).unwrap();
+        for body in [
+            String::new(),
+            "A document line.\n".repeat(80),
+            String::new(),
+        ] {
+            let long = !body.is_empty();
+            text.set(body);
+            scroll.sync(&mut doc, &automerge::ROOT);
+            tree.mark_dirty(editor).unwrap();
+            // SAFETY: no widgets move or change topology during settlement.
+            unsafe {
+                compute_widget_layout(
+                    &mut tree,
+                    root,
+                    Size {
+                        width: AvailableSpace::Definite(width),
+                        height: AvailableSpace::Definite(height),
+                    },
+                    &nodes,
+                    &bindings,
+                    &mut renderer,
+                )
+            }
+            .unwrap();
+            scroll.apply_layout(&tree, root, Point::ZERO);
+            assert_eq!(tree.style(editor).unwrap(), &child_style);
+            let editor_height = tree.layout(editor).unwrap().size.height;
+            if long {
+                assert!(editor_height > 1000.0);
+                assert!(scroll.max_offset_y() > 500.0);
+            } else {
+                assert!((editor_height - height).abs() < 1.0);
+                assert_eq!(scroll.max_offset_y(), 0.0);
+            }
+        }
+    }
+}
+
+#[test]
+fn fractional_height_editor_routes_first_wheel_to_outer_scrollable() {
+    // 47 nonempty rows at 22.625px plus padding end in .375px; rounding
+    // down must not create an inner scroll range in a fully laid-out input.
+    let root = Scrollable::new_vertical()
+        .with_height(300.0)
+        .with_content_min_viewport_height()
+        .with_child(Box::new(
+            TextInput::local()
+                .with_id("fractional-editor")
+                .multiline(true)
+                .with_font_size(18.1)
+                .with_initial_value(&("A line of text.\n".repeat(46) + "Final line")),
+        ));
+    let mut driver = Driver::new(State::new(), Box::new(root), (416, 300));
+    driver.click_at(30.0, 30.0);
+    let before = *driver.targets().get("fractional-editor").unwrap();
+    driver.scroll(0.0, -3.0);
+    let after = *driver.targets().get("fractional-editor").unwrap();
+    assert!(
+        after.y0 < before.y0 - 100.0,
+        "first wheel must move outer content: before {before:?}, after {after:?}"
+    );
+}
+
+#[test]
+fn repeated_click_keeps_default_scrollable_editor_focused() {
+    let text = LocalState::new(String::new());
+    let mut driver = editor_driver(&text, false, 1.0);
+    let editor = *driver.targets().get("editor").unwrap();
+    driver.click_at(editor.x0 + 25.0, editor.center().y);
+    driver.type_text("first");
+    driver.click_at(editor.x1 - 25.0, editor.center().y);
+    driver.type_text(" again");
+    assert_eq!(text.get(), "first again");
+}
+
+#[test]
+fn pane_background_and_scrollbar_press_still_focus_the_scrollable() {
+    for x in [250.0, 394.0] {
+        let root = Scrollable::new_vertical()
+            .with_height(300.0)
+            .with_child(Box::new(
+                Container::new()
+                    .with_no_padding()
+                    .with_size(100.0, 900.0)
+                    .with_child(Box::new(
+                        Text::new("Tall narrow content").with_id("content"),
+                    )),
+            ));
+        let mut driver = Driver::new(State::new(), Box::new(root), (400, 300));
+        // x=250 hits empty pane background; x=394 hits the scrollbar thumb.
+        driver.click_at(x, 20.0);
+        assert_eq!(
+            driver.focused_access_node().unwrap().role,
+            ui::a11y::Role::Group
+        );
+        let before = driver.targets().get("content").unwrap().y0;
+        driver.key("ArrowDown");
+        assert!(driver.targets().get("content").unwrap().y0 < before);
+    }
+}

```

## 1b3eac1b4
```diff
commit 1b3eac1b426b691cb48c47b1662cfd81bd9f9daf
Author:     Xaver Emmerling <xaver@Mac.lan>
AuthorDate: Wed Sep 16 11:08:13 2026 -0700
Commit:     Xaver Emmerling <xaver@Mac.lan>
CommitDate: Wed Sep 16 11:08:13 2026 -0700

    Fix measured toolbar layout and reachable command overflow
---
 ui/src/widget/context_menu.rs |  350 ++++++++-
 ui/src/widget/toolbar.rs      | 1728 ++++++++++++++++++++++++++++++-----------
 2 files changed, 1596 insertions(+), 482 deletions(-)

diff --git a/ui/src/widget/context_menu.rs b/ui/src/widget/context_menu.rs
index 0675df1c2..641a7e550 100644
--- a/ui/src/widget/context_menu.rs
+++ b/ui/src/widget/context_menu.rs
@@ -1,7 +1,7 @@
 //! `ContextMenu` primitive — a right-click / long-press invoked list of
-//! actions with optional separators, backed visually by `overlay::Popover`
-//! so it participates in the overlay stack, scrim dismissal, and focus
-//! contract.
+//! actions with optional separators. Standalone owners draw it in their
+//! overlay pass. `open_anchored` opts into measured, viewport-bounded geometry;
+//! legacy `open_at` callers retain their point placement and fixed rows.
 //!
 //! Callers push `MenuItem::action(label, fn)` and optional
 //! `MenuItem::separator()` entries, then call `open_at` on right-click.
@@ -11,11 +11,11 @@ use std::sync::Arc;
 use taffy::{Dimension, NodeId, Size, Style, TaffyTree};
 use vello::Scene;
 use vello::kurbo::{Affine, Point, Rect, RoundedRect, Stroke, Vec2};
-use winit::event::{ElementState, KeyEvent, MouseButton, WindowEvent};
+use winit::event::{ElementState, KeyEvent, MouseButton, MouseScrollDelta, WindowEvent};
 use winit::keyboard::{Key, NamedKey};
 
 use crate::presence::PresenceCtx;
-use crate::text_render::TextRenderer;
+use crate::text_render::{TextRenderer, TextStyle};
 use crate::theme::Theme;
 use crate::widget::TaffyTreeExt;
 use crate::widget::Widget;
@@ -82,6 +82,10 @@ pub struct ContextMenu {
     /// `take_selection()` after dispatching the event and mutates itself.
     /// The legacy `Arc` callback still fires too.
     selection: Option<usize>,
+    bounds: Option<(Rect, Rect)>,
+    row_height: f64,
+    measured_width: f64,
+    scroll_offset: f64,
 }
 
 impl Default for ContextMenu {
@@ -100,6 +104,10 @@ impl ContextMenu {
             hovered: None,
             last_cursor: Point::ZERO,
             selection: None,
+            bounds: None,
+            row_height: ROW_HEIGHT,
+            measured_width: MENU_WIDTH,
+            scroll_offset: 0.0,
         }
     }
 
@@ -118,16 +126,157 @@ impl ContextMenu {
     /// consumers (like `TextInput`) that route a click to a row in the same
     /// input batch the menu opened in.
     pub fn open_at(&mut self, position: [f32; 2]) {
+        self.bounds = None;
+        self.scroll_offset = 0.0;
         self.open = true;
         self.position = Some(position);
         self.layout_at_position();
     }
 
+    /// Open a shared menu inside a host viewport. Geometry is immediately usable;
+    /// call `layout_within` with the renderer before painting to settle text metrics.
+    pub fn open_anchored(&mut self, anchor: Rect, viewport: Rect) {
+        self.open = true;
+        self.hovered = None;
+        self.scroll_offset = 0.0;
+        self.reanchor(anchor, viewport);
+    }
+
+    pub fn reanchor(&mut self, anchor: Rect, viewport: Rect) {
+        self.bounds = Some((anchor, viewport));
+        self.layout_at_position();
+    }
+
+    pub fn layout_within(&mut self, text: &mut TextRenderer, theme: &Theme) {
+        let style = text.renderer_input_style(&TextStyle::new(theme.tokens.typography.scale.sm));
+        let mut width: f64 = 0.0;
+        let mut height: f64 = 0.0;
+        for item in &self.items {
+            if let Some(label) = item.label() {
+                let (w, h) = text.measure_style(label, None, &style);
+                width = width.max(f64::from(w));
+                height = height.max(f64::from(h));
+            }
+        }
+        self.measured_width = width + 20.0;
+        self.row_height = (height + 12.0).max(ROW_HEIGHT);
+        self.layout_at_position();
+        self.ensure_hover_visible();
+    }
+
+    fn row_height(&self, item: &MenuItem) -> f64 {
+        if self.bounds.is_some() && matches!(item, MenuItem::Action { .. }) {
+            self.row_height
+        } else {
+            item_height(item)
+        }
+    }
+
+    fn content_height(&self) -> f64 {
+        self.items.iter().map(|item| self.row_height(item)).sum()
+    }
+
+    fn body_rect(&self) -> Rect {
+        let inset = if self.bounds.is_some() {
+            PADDING.min(self.rect.height() / 4.0)
+        } else {
+            PADDING
+        };
+        Rect::new(
+            self.rect.x0,
+            self.rect.y0 + inset,
+            self.rect.x1,
+            self.rect.y1 - inset,
+        )
+    }
+
+    fn max_scroll(&self) -> f64 {
+        (self.content_height() - self.body_rect().height()).max(0.0)
+    }
+
+    /// Painted (clipped) geometry of an action row, in host coordinates.
+    pub fn item_rect(&self, index: usize) -> Option<Rect> {
+        if !self.open || !matches!(self.items.get(index), Some(MenuItem::Action { .. })) {
+            return None;
+        }
+        let body = self.body_rect();
+        let top = body.y0 - self.scroll_offset
+            + self
+                .items
+                .iter()
+                .take(index)
+                .map(|item| self.row_height(item))
+                .sum::<f64>();
+        let rect = Rect::new(
+            body.x0,
+            top,
+            body.x1,
+            top + self.row_height(self.items.get(index)?),
+        )
+        .intersect(body);
+        (!rect.is_zero_area()).then_some(rect)
+    }
+
+    pub fn focus_item(&mut self, index: usize) -> bool {
+        if !matches!(self.items.get(index), Some(MenuItem::Action { .. })) {
+            return false;
+        }
+        self.hovered = Some(index);
+        self.ensure_hover_visible();
+        true
+    }
+
+    pub fn focus_first_action(&mut self) {
+        self.hovered = None;
+        self.move_hover(1);
+    }
+
+    fn ensure_hover_visible(&mut self) {
+        if self.bounds.is_none() {
+            return;
+        }
+        if let Some(index) = self.hovered {
+            let top = self
+                .items
+                .iter()
+                .take(index)
+                .map(|item| self.row_height(item))
+                .sum::<f64>();
+            let height = self
+                .items
+                .get(index)
+                .map_or(0.0, |item| self.row_height(item));
+            let body_height = self.body_rect().height();
+            if top < self.scroll_offset {
+                self.scroll_offset = top;
+            } else if top + height > self.scroll_offset + body_height {
+                self.scroll_offset = top + height.min(body_height) - body_height;
+            }
+        }
+        self.scroll_offset = self.scroll_offset.clamp(0.0, self.max_scroll());
+    }
+
     /// Mirrors the `build_layout` + `apply_layout` geometry without a taffy
     /// round-trip. A no-op when the menu has never been positioned. Lets a
     /// standalone consumer (one that owns a `ContextMenu` as a field rather
     /// than a tree node) hit-test and draw the menu directly.
     pub fn layout_at_position(&mut self) {
+        if let Some((anchor, viewport)) = self.bounds {
+            let width = self.measured_width.min(viewport.width().max(0.0));
+            let height = (self.content_height() + PADDING * 2.0).min(viewport.height().max(0.0));
+            let x = anchor
+                .x0
+                .clamp(viewport.x0, (viewport.x1 - width).max(viewport.x0));
+            let preferred_y = if anchor.y1 + height <= viewport.y1 {
+                anchor.y1
+            } else {
+                anchor.y0 - height
+            };
+            let y = preferred_y.clamp(viewport.y0, (viewport.y1 - height).max(viewport.y0));
+            self.rect = Rect::new(x, y, x + width, y + height);
+            self.scroll_offset = self.scroll_offset.clamp(0.0, self.max_scroll());
+            return;
+        }
         let Some([px, py]) = self.position else {
             return;
         };
@@ -164,17 +313,11 @@ impl ContextMenu {
         if !self.open {
             return None;
         }
-        let [px, py] = point;
-        if px < self.rect.x0 || px > self.rect.x1 || py < self.rect.y0 || py > self.rect.y1 {
-            return None;
-        }
-        let mut y = self.rect.y0 + PADDING;
-        for (idx, item) in self.items.iter().enumerate() {
-            let h = item_height(item);
-            if matches!(item, MenuItem::Action { .. }) && py >= y && py < y + h {
+        let point = Point::new(point[0], point[1]);
+        for idx in 0..self.items.len() {
+            if self.item_rect(idx).is_some_and(|rect| rect.contains(point)) {
                 return Some(idx);
             }
-            y += h;
         }
         None
     }
@@ -234,6 +377,7 @@ impl ContextMenu {
         for _ in 0..n {
             if matches!(self.items.get(idx), Some(MenuItem::Action { .. })) {
                 self.hovered = Some(idx);
+                self.ensure_hover_visible();
                 return;
             }
             idx = wrapping_step(idx, n, down);
@@ -303,6 +447,10 @@ impl Widget for ContextMenu {
     }
 
     fn apply_layout(&mut self, taffy: &TaffyTree<()>, node: NodeId, origin: Point) {
+        if self.bounds.is_some() {
+            self.layout_at_position();
+            return;
+        }
         // The caller-provided anchor wins when open; otherwise the
         // taffy-assigned position keeps offscreen/closed menus sensible.
         let l = taffy.layout(node).copied().unwrap_or_default();
@@ -334,6 +482,9 @@ impl Widget for ContextMenu {
             return;
         }
 
+        if self.bounds.is_some() {
+            self.layout_within(text_renderer, theme);
+        }
         let shape = RoundedRect::from_rect(self.rect, f64::from(theme.tokens.radii.md));
         // The near-black overlay tier, so the menu reads as an opaque
         // raised sheet, never bleeding the content beneath.
@@ -353,8 +504,17 @@ impl Widget for ContextMenu {
         );
 
         let text_size = theme.tokens.typography.scale.sm;
-        let mut y = self.rect.y0 + PADDING;
+        let style = text_renderer.renderer_input_style(&TextStyle::new(text_size));
+        scene.push_layer(
+            vello::peniko::Fill::NonZero,
+            vello::peniko::BlendMode::default(),
+            1.0,
+            transform,
+            &self.body_rect(),
+        );
+        let mut y = self.body_rect().y0 - self.scroll_offset;
         for (idx, item) in self.items.iter().enumerate() {
+            let row_height = self.row_height(item);
             match item {
                 MenuItem::Action { label, .. } => {
                     if self.hovered == Some(idx) {
@@ -362,7 +522,7 @@ impl Widget for ContextMenu {
                             self.rect.x0 + 4.0,
                             y + 1.0,
                             self.rect.x1 - 4.0,
-                            y + ROW_HEIGHT - 1.0,
+                            y + row_height - 1.0,
                         );
                         let hl_shape = RoundedRect::from_rect(hl, f64::from(theme.tokens.radii.sm));
                         // Matches the dropdown / autocomplete row hover.
@@ -374,16 +534,28 @@ impl Widget for ContextMenu {
                             &hl_shape,
                         );
                     }
-                    let label_y = y + (ROW_HEIGHT - f64::from(text_size)) / 2.0;
-                    text_renderer.draw_text(
-                        scene,
-                        label,
-                        text_size,
-                        theme.tokens.colors.text_primary,
-                        transform.pre_translate(Vec2::new(self.rect.x0 + 10.0, label_y)),
-                        None,
-                    );
-                    y += ROW_HEIGHT;
+                    let (_, label_height) = text_renderer.measure_style(label, None, &style);
+                    let label_y = y + (row_height - f64::from(label_height)) / 2.0;
+                    if self.bounds.is_some() {
+                        text_renderer.draw_style(
+                            scene,
+                            label,
+                            theme.tokens.colors.text_primary,
+                            transform.pre_translate(Vec2::new(self.rect.x0 + 10.0, label_y)),
+                            None,
+                            &style,
+                        );
+                    } else {
+                        text_renderer.draw_text(
+                            scene,
+                            label,
+                            text_size,
+                            theme.tokens.colors.text_primary,
+                            transform.pre_translate(Vec2::new(self.rect.x0 + 10.0, label_y)),
+                            None,
+                        );
+                    }
+                    y += row_height;
                 }
                 MenuItem::Separator => {
                     let sep_y = y + SEPARATOR_HEIGHT / 2.0;
@@ -404,6 +576,7 @@ impl Widget for ContextMenu {
                 }
             }
         }
+        scene.pop_layer();
     }
 
     fn handle_event(
@@ -457,6 +630,15 @@ impl Widget for ContextMenu {
                 }
                 _ => {}
             },
+            WindowEvent::MouseWheel { delta, .. } if self.bounds.is_some() => {
+                let delta = match delta {
+                    MouseScrollDelta::LineDelta(_, y) => f64::from(*y) * self.row_height,
+                    MouseScrollDelta::PixelDelta(p) => p.y / scale_factor,
+                };
+                self.scroll_offset = (self.scroll_offset - delta).clamp(0.0, self.max_scroll());
+                self.hovered = self.item_at([self.last_cursor.x, self.last_cursor.y]);
+                *handled = true;
+            }
             WindowEvent::MouseInput {
                 state: ElementState::Pressed,
                 button: MouseButton::Left,
@@ -757,6 +939,46 @@ mod tests {
         assert_eq!(m.hovered(), None, "cursor over a separator clears hover");
     }
 
+    #[test]
+    fn bounded_wheel_hit_testing_and_keyboard_activation_share_scroll_offset() {
+        let mut menu = ContextMenu::new();
+        for index in 0..20 {
+            menu.push(MenuItem::action(format!("Command {index}"), || {}));
+        }
+        menu.open_anchored(
+            Rect::new(10.0, 10.0, 30.0, 30.0),
+            Rect::new(0.0, 0.0, 180.0, 100.0),
+        );
+        menu.layout_within(&mut TextRenderer::new(), &Theme::dark());
+        let point = menu.get_rect().center();
+        dispatch(&mut menu, &cursor_at(point));
+        let wheel = |y| WindowEvent::MouseWheel {
+            device_id: synth_device(),
+            delta: MouseScrollDelta::LineDelta(0.0, y),
+            phase: winit::event::TouchPhase::Moved,
+        };
+        assert!(dispatch(&mut menu, &wheel(-100.0)));
+        assert_eq!(menu.scroll_offset, menu.max_scroll());
+        let last = menu.item_rect(19).unwrap().center();
+        assert_eq!(menu.item_at([last.x, last.y]), Some(19));
+        dispatch(&mut menu, &cursor_at(last));
+        dispatch(&mut menu, &left_press());
+        assert_eq!(menu.take_selection(), Some(19));
+        assert_eq!(menu.take_selection(), None);
+        menu.open_anchored(Rect::ZERO, Rect::new(0.0, 0.0, 180.0, 100.0));
+        menu.focus_first_action();
+        for _ in 0..19 {
+            dispatch(&mut menu, &key(NamedKey::ArrowDown));
+        }
+        assert_eq!(menu.hovered(), Some(19));
+        assert!(menu.item_rect(19).is_some());
+        dispatch(&mut menu, &key(NamedKey::Enter));
+        assert_eq!(menu.take_selection(), Some(19));
+        menu.open_anchored(Rect::ZERO, Rect::new(0.0, 0.0, 180.0, 100.0));
+        dispatch(&mut menu, &wheel(100.0));
+        assert_eq!(menu.scroll_offset, 0.0);
+    }
+
     #[test]
     fn modal_capture_when_open() {
         let (m, _f) = open_menu();
@@ -768,3 +990,79 @@ mod tests {
         assert!(Widget::modal_capture(&closed).is_none());
     }
 }
+
+#[cfg(test)]
+mod bounded_tests {
+    use super::*;
+
+    #[test]
+    fn bounded_menu_measures_scales_and_clamps_at_all_edges() {
+        let viewport = Rect::new(10.0, 20.0, 110.0, 95.0);
+        for anchor in [
+            Rect::new(10.0, 20.0, 30.0, 40.0),
+            Rect::new(90.0, 20.0, 110.0, 40.0),
+            Rect::new(10.0, 75.0, 30.0, 95.0),
+            Rect::new(90.0, 75.0, 110.0, 95.0),
+        ] {
+            let mut menu = ContextMenu::new();
+            for _ in 0..8 {
+                menu.push(MenuItem::action(
+                    "Sehr lange übersetzte Aktion 共有 العربية",
+                    || {},
+                ));
+            }
+            menu.open_anchored(anchor, viewport);
+            let mut text = TextRenderer::new();
+            text.set_text_scale(2.0);
+            menu.layout_within(&mut text, &Theme::dark().with_text_scale(2.0));
+            assert_eq!(menu.get_rect().intersect(viewport), menu.get_rect());
+            assert!(menu.row_height > ROW_HEIGHT);
+            menu.focus_item(7);
+            assert!(menu.scroll_offset > 0.0);
+            let last = menu.item_rect(7).unwrap();
+            assert_eq!(menu.item_at([last.center().x, last.center().y]), Some(7));
+            assert!(menu.item_rect(0).is_none());
+            menu.move_hover(1);
+            assert_eq!(menu.hovered(), Some(0));
+            assert_eq!(menu.scroll_offset, 0.0);
+        }
+    }
+    #[test]
+    fn width_uses_shaping_and_legacy_open_resets_bounded_geometry() {
+        let mut narrow = ContextMenu::new();
+        narrow.push(MenuItem::action("iii", || {}));
+        let mut wide = ContextMenu::new();
+        wide.push(MenuItem::action("WWW", || {}));
+        let mut text = TextRenderer::new();
+        for menu in [&mut narrow, &mut wide] {
+            menu.open_anchored(Rect::ZERO, Rect::new(0.0, 0.0, 1000.0, 1000.0));
+            menu.layout_within(&mut text, &Theme::dark());
+        }
+        assert!(wide.get_rect().width() > narrow.get_rect().width());
+        wide.open_at([900.0, 950.0]);
+        assert_eq!(
+            wide.get_rect(),
+            Rect::new(
+                900.0,
+                950.0,
+                900.0 + MENU_WIDTH,
+                950.0 + ROW_HEIGHT + 2.0 * PADDING
+            )
+        );
+        assert_eq!(wide.scroll_offset, 0.0);
+    }
+    #[test]
+    fn tiny_viewport_keeps_focused_rows_reachable() {
+        let mut menu = ContextMenu::new();
+        menu.push(MenuItem::action("First", || {}));
+        menu.push(MenuItem::separator());
+        menu.push(MenuItem::action("Last", || {}));
+        let viewport = Rect::new(0.0, 0.0, 4.0, 4.0);
+        menu.open_anchored(viewport, viewport);
+        menu.layout_within(&mut TextRenderer::new(), &Theme::dark());
+        menu.focus_item(2);
+        assert_eq!(menu.get_rect(), viewport);
+        let last = menu.item_rect(2).unwrap();
+        assert_eq!(menu.item_at([last.center().x, last.center().y]), Some(2));
+    }
+}
diff --git a/ui/src/widget/toolbar.rs b/ui/src/widget/toolbar.rs
index aab2ad83f..51f2e8064 100644
--- a/ui/src/widget/toolbar.rs
+++ b/ui/src/widget/toolbar.rs
@@ -1,43 +1,19 @@
-//! Toolbar widget — a horizontal or vertical strip of buttons, separators
-//! and greedy spacers, with overflow collapse into a `…` chip when the
-//! computed item extent exceeds the toolbar's rect along its orientation
-//! axis.
-//!
-//! Owns its layout end-to-end rather than delegating child sizing to Taffy:
-//! `build_layout` measures each item (GPU-free `TextRenderer`-style
-//! approximations) and writes the visible-count + overflow flag
-//! `apply_layout` places rects from. Spacers soak the residual axis space;
-//! the overflow chip always wins a trailing slot once visibility drops
-//! below the item count. See `tabs.rs` for the strip-of-rects precedent.
-
+//! A measured command strip with a shared ContextMenu for overflow.
+//! The extent cache is the sole source for intrinsic sizing, fitting and placement.
 use automerge::{AutoCommit, ObjId};
 use std::collections::HashMap;
 use taffy::{Dimension, NodeId, Size, Style, TaffyTree};
 use vello::Scene;
-use vello::kurbo::{Affine, Point, Rect, RoundedRect};
+use vello::kurbo::{Affine, Point, Rect, RoundedRect, Stroke};
 use winit::event::{ElementState, MouseButton, WindowEvent};
+use winit::keyboard::{Key, NamedKey};
 
+use super::context_menu::{ContextMenu, MenuItem};
+use crate::a11y::{AccessNode, AccessState, Action, Role};
 use crate::presence::PresenceCtx;
-use crate::text_render::TextRenderer;
+use crate::text_render::{TextRenderer, TextStyle};
 use crate::theme::Theme;
-use crate::widget::TaffyTreeExt;
-use crate::widget::Widget;
-
-/// Approximate per-character width used by `build_layout` to size button
-/// labels without invoking `TextRenderer`. Matches `tabs.rs::apply_layout`'s
-/// heuristic so a Toolbar reads at the same density as a `TabBar` beside it.
-const APPROX_CHAR_W: f64 = 7.0;
-
-/// Width (Horizontal) or height (Vertical) of a Separator line. Always
-/// 1 logical pixel — a thinner divider reads as a hairline, a thicker
-/// one starts to look like a rule.
-const SEPARATOR_LINE_PX: f64 = 1.0;
-
-/// Width of the overflow `…` chip on the trailing edge of an overflowing
-/// toolbar. Sized to comfortably fit the three-dot glyph plus padding;
-/// chosen to roughly match a one-character button so the chip doesn't
-/// dominate the visible items it's replacing.
-const OVERFLOW_CHIP_AXIS_PX: f64 = 24.0;
+use crate::widget::{TaffyTreeExt, Widget};
 
 #[derive(Clone, Copy, PartialEq, Eq, Debug)]
 pub enum Orientation {
@@ -54,26 +30,34 @@ pub enum ToolbarItem {
     Spacer,
 }
 
+#[derive(Clone, Copy, PartialEq, Eq, Debug)]
+enum Target {
+    Item(usize),
+    Overflow,
+}
+
 pub struct Toolbar {
     items: Vec<ToolbarItem>,
     orientation: Orientation,
-    overflow_open: bool,
     rect: Rect,
     item_rects: Vec<Rect>,
     visible_count: usize,
-    /// Per-item hover flag, populated by `handle_event`. Aligned 1:1 with
-    /// `items`. Kept independent of `visible_count` so a hover that
-    /// happened pre-overflow doesn't latch on after the items collapse.
-    item_hover: Vec<bool>,
-    /// True while the pointer is over the overflow chip. Drives the
-    /// chip's hover background like a regular button. Painted only when
-    /// `has_overflow()` is true.
-    overflow_hover: bool,
-    /// Cached overflow-chip hit rect (only meaningful when
-    /// `has_overflow()` is true). Populated alongside `item_rects` in
-    /// `apply_layout` so `handle_event` can hit-test without re-deriving
-    /// the chip's position.
+    extents: Vec<Size<f32>>,
+    chip_extent: Size<f32>,
+    intrinsic: Size<f32>,
+    font: TextStyle,
+    padding: f32,
+    minimum: f32,
+    separator: f32,
     overflow_rect: Rect,
+    hovered: Option<Target>,
+    pressed: Option<Target>,
+    focused: bool,
+    focus: Option<Target>,
+    menu: ContextMenu,
+    menu_indices: Vec<Option<usize>>,
+    viewport: Option<Rect>,
+    swallow_release: bool,
 }
 
 impl Toolbar {
@@ -81,13 +65,25 @@ impl Toolbar {
         Self {
             items: Vec::new(),
             orientation,
-            overflow_open: false,
             rect: Rect::ZERO,
             item_rects: Vec::new(),
             visible_count: 0,
-            item_hover: Vec::new(),
-            overflow_hover: false,
+            extents: Vec::new(),
+            chip_extent: Size::ZERO,
+            intrinsic: Size::ZERO,
+            font: TextStyle::new(14.0),
+            padding: 8.0,
+            minimum: 32.0,
+            separator: 9.0,
             overflow_rect: Rect::ZERO,
+            hovered: None,
+            pressed: None,
+            focused: false,
+            focus: None,
+            menu: ContextMenu::new(),
+            menu_indices: Vec::new(),
+            viewport: None,
+            swallow_release: false,
         }
     }
 
@@ -97,513 +93,629 @@ impl Toolbar {
             label: label.to_string(),
             on_click: Box::new(on_click),
         });
-        self.item_hover.push(false);
         self
     }
-
     #[must_use]
     pub fn push_separator(mut self) -> Self {
         self.items.push(ToolbarItem::Separator);
-        self.item_hover.push(false);
         self
     }
-
     #[must_use]
     pub fn push_spacer(mut self) -> Self {
         self.items.push(ToolbarItem::Spacer);
-        self.item_hover.push(false);
         self
     }
 
-    /// True if the toolbar's computed item extent exceeded its rect's
-    /// extent along the orientation axis on the last layout pass. While
-    /// true, items past `visible_count` are collapsed into a single
-    /// overflow chip on the trailing edge.
     pub fn has_overflow(&self) -> bool {
-        self.visible_count < self.items.len()
+        self.items
+            .iter()
+            .skip(self.visible_count)
+            .any(|item| matches!(item, ToolbarItem::Button { .. }))
     }
-
-    /// Number of items currently rendered as their own rect (i.e. *not*
-    /// folded into the overflow chip). Always `<= items.len()`. When
-    /// `has_overflow()` is true this is strictly less.
     pub fn visible_count(&self) -> usize {
         self.visible_count
     }
-
-    /// Number of `ToolbarItem::Separator` entries in the toolbar. Cheap
-    /// accessor for the divider-paint test — keeps the test stable
-    /// against future scene-encoding refactors that might shuffle which
-    /// primitive emits the divider stroke.
     pub fn separator_count(&self) -> usize {
         self.items
             .iter()
-            .filter(|i| matches!(i, ToolbarItem::Separator))
+            .filter(|item| matches!(item, ToolbarItem::Separator))
             .count()
     }
-
-    /// Axis extent one item occupies: a button's label plus padding, a
-    /// separator's hairline plus its surrounding air, and zero for a
-    /// spacer (which is sized from the residual, not measured).
-    fn measure_item_axis(&self, item: &ToolbarItem, theme: &Theme) -> f64 {
-        match item {
-            ToolbarItem::Spacer => 0.0,
-            ToolbarItem::Separator => SEPARATOR_LINE_PX + 2.0 * f64::from(theme.tokens.spacing.s2),
-            ToolbarItem::Button { label, .. } => {
-                let pad = 2.0 * f64::from(theme.tokens.spacing.s3);
-                let text_axis = match self.orientation {
-                    Orientation::Horizontal => count_to_f64(label.chars().count()) * APPROX_CHAR_W,
-                    Orientation::Vertical => f64::from(theme.tokens.typography.scale.sm),
-                };
-                (text_axis + pad).max(f64::from(theme.tokens.spacing.s8))
-            }
-        }
+    pub fn is_overflow_open(&self) -> bool {
+        self.menu.is_open()
     }
 
-    /// Decide how many leading items fit inside `axis_extent`, writing
-    /// [`Self::visible_count`] (and therefore [`Self::has_overflow`]).
-    ///
-    /// Greedy from the leading edge: take items while they fit. The moment
-    /// one doesn't, the trailing edge has to give up
-    /// [`OVERFLOW_CHIP_AXIS_PX`] to the `…` chip, so the fit is re-checked
-    /// against the smaller budget — otherwise the last item admitted would
-    /// sit underneath the chip. Spacers measure zero and are always
-    /// admitted; they soak the residual in `apply_layout`.
+    /// Compatibility estimate for callers without a renderer. Real lifecycle layout
+    /// always replaces this decision with the measured extent cache.
     pub fn recompute_visible(&mut self, axis_extent: f64, theme: &Theme) {
-        if self.items.is_empty() {
-            self.visible_count = 0;
-            return;
-        }
-        let extents: Vec<f64> = self
+        let mut used = 0.0;
+        let axes: Vec<f64> = self
             .items
             .iter()
-            .map(|it| self.measure_item_axis(it, theme))
+            .map(|item| match item {
+                ToolbarItem::Spacer => 0.0,
+                ToolbarItem::Separator => f64::from(1.0 + 2.0 * theme.tokens.spacing.s2),
+                ToolbarItem::Button { label, .. } => {
+                    let text = match self.orientation {
+                        Orientation::Horizontal => count_to_f64(label.chars().count()) * 7.0,
+                        Orientation::Vertical => f64::from(theme.tokens.typography.scale.sm),
+                    };
+                    (text + 2.0 * f64::from(theme.tokens.spacing.s3))
+                        .max(f64::from(theme.tokens.spacing.s8))
+                }
+            })
             .collect();
-        let total: f64 = extents.iter().sum();
-        if total <= axis_extent {
-            self.visible_count = self.items.len();
-            return;
-        }
-        let budget = (axis_extent - OVERFLOW_CHIP_AXIS_PX).max(0.0);
-        let mut used = 0.0;
-        let mut n = 0usize;
-        for e in &extents {
-            if used + e > budget {
-                break;
-            }
-            used += e;
-            n = n.saturating_add(1);
-        }
-        // Collapsing everything leaves a toolbar that is only a `…` chip —
-        // honest for a genuinely tiny strip, but never collapse when the
-        // items would have fit without the chip's own reservation.
-        self.visible_count = n.min(self.items.len().saturating_sub(1));
+        let budget = if axes.iter().sum::<f64>() <= axis_extent {
+            axis_extent
+        } else {
+            (axis_extent - 24.0).max(0.0)
+        };
+        self.visible_count = axes
+            .iter()
+            .take_while(|axis| {
+                used += **axis;
+                used <= budget
+            })
+            .count();
     }
 
-    /// True while the overflow popover is open. (The popover itself is
-    /// not painted by this widget — `WindowGroup`-style hosts paint it
-    /// in a later pass.)
-    pub fn is_overflow_open(&self) -> bool {
-        self.overflow_open
+    fn axis(&self, size: Size<f32>) -> f64 {
+        f64::from(match self.orientation {
+            Orientation::Horizontal => size.width,
+            Orientation::Vertical => size.height,
+        })
     }
 
-    /// `build_layout` only has the theme (not the final width);
-    /// `apply_layout` has the post-taffy width, so the overflow fit is
-    /// decided here, using the same approximate, theme-free extents as
-    /// [`Self::place_visible_items`] below so the two agree. Split out of
-    /// `apply_layout` to keep it under clippy's line budget.
-    fn decide_visible_count(&self, axis_total: f64) -> usize {
-        let item_axis = |it: &ToolbarItem| -> f64 {
-            match it {
-                ToolbarItem::Spacer => 0.0,
-                ToolbarItem::Separator => SEPARATOR_LINE_PX + 8.0,
-                ToolbarItem::Button { label, .. } => {
-                    let text_axis = match self.orientation {
-                        Orientation::Horizontal => {
-                            count_to_f64(label.chars().count()) * APPROX_CHAR_W
-                        }
-                        Orientation::Vertical => 16.0,
-                    };
-                    (text_axis + 16.0).max(32.0)
-                }
+    fn update_measurements(&mut self, text: &mut TextRenderer) -> bool {
+        let style = text.renderer_input_style(&self.font);
+        let button = |label: &str, text: &mut TextRenderer| {
+            let (width, height) = text.measure_style(label, None, &style);
+            Size {
+                width: (width + self.padding * 2.0).max(self.minimum),
+                height: (height + self.padding * 2.0).max(self.minimum),
             }
         };
-        let total_extent: f64 = self.items.iter().map(&item_axis).sum();
-        if total_extent <= axis_total {
-            return self.items.len();
-        }
-        let budget = (axis_total - OVERFLOW_CHIP_AXIS_PX).max(0.0);
-        let mut acc = 0.0;
-        let mut fit = 0usize;
-        for it in &self.items {
-            let e = item_axis(it);
-            if acc + e > budget {
-                break;
-            }
-            acc += e;
-            fit = fit.saturating_add(1);
-        }
-        fit
-    }
-
-    /// Per-item axis extent for the first `n_visible` items, plus how many
-    /// of them are spacers — the two inputs [`Self::place_visible_items`]
-    /// needs to turn a visible-count decision into rects. Split out of
-    /// `place_visible_items` to keep it under clippy's line budget.
-    fn measure_visible_axes(&self, n_visible: usize) -> (Vec<f64>, usize) {
-        let mut measured_axes = vec![0.0_f64; n_visible];
-        let mut spacer_count = 0usize;
-        for (i, it) in self.items.iter().take(n_visible).enumerate() {
-            match it {
-                ToolbarItem::Spacer => {
-                    spacer_count = spacer_count.saturating_add(1);
-                }
-                ToolbarItem::Separator => {
-                    if let Some(slot) = measured_axes.get_mut(i) {
-                        *slot = SEPARATOR_LINE_PX + 8.0;
-                    }
-                }
-                ToolbarItem::Button { label, .. } => {
-                    let pad = 16.0;
-                    let text_axis = match self.orientation {
-                        Orientation::Horizontal => {
-                            count_to_f64(label.chars().count()) * APPROX_CHAR_W
-                        }
-                        Orientation::Vertical => 16.0,
-                    };
-                    if let Some(slot) = measured_axes.get_mut(i) {
-                        *slot = (text_axis + pad).max(32.0);
-                    }
-                }
-            }
+        let chip = button("…", text);
+        let extents: Vec<_> = self
+            .items
+            .iter()
+            .map(|item| match item {
+                ToolbarItem::Button { label, .. } => button(label, text),
+                ToolbarItem::Spacer => Size::ZERO,
+                ToolbarItem::Separator => match self.orientation {
+                    Orientation::Horizontal => Size {
+                        width: self.separator,
+                        height: self.minimum,
+                    },
+                    Orientation::Vertical => Size {
+                        width: self.minimum,
+                        height: self.separator,
+                    },
+                },
+            })
+            .collect();
+        let changed = extents != self.extents || chip != self.chip_extent;
+        self.extents = extents;
+        self.chip_extent = chip;
+        self.intrinsic =
+            self.extents
+                .iter()
+                .fold(Size::ZERO, |size, item| match self.orientation {
+                    Orientation::Horizontal => Size {
+                        width: size.width + item.width,
+                        height: size.height.max(item.height),
+                    },
+                    Orientation::Vertical => Size {
+                        width: size.width.max(item.width),
+                        height: size.height + item.height,
+                    },
+                });
+        changed
+    }
+
+    fn fit(&self, budget: f64) -> usize {
+        let mut used = 0.0;
+        self.extents
+            .iter()
+            .take_while(|size| {
+                used += self.axis(**size);
+                used <= budget
+            })
+            .count()
+    }
+
+    fn place(&mut self) {
+        let axis_total = match self.orientation {
+            Orientation::Horizontal => self.rect.width(),
+            Orientation::Vertical => self.rect.height(),
+        }
+        .max(0.0);
+        self.visible_count = self.fit(axis_total);
+        if self.has_overflow() {
+            self.visible_count = self.fit((axis_total - self.axis(self.chip_extent)).max(0.0));
         }
-        (measured_axes, spacer_count)
-    }
-
-    /// Places `item_rects` (and the overflow chip rect) for the
-    /// `self.visible_count` decided by [`Self::decide_visible_count`].
-    /// `apply_layout` has no `Theme`, so extents are recomputed here with
-    /// the same hardcoded constants as `decide_visible_count` rather than
-    /// calling `measure_item_axis` — approximate, but deterministic and
-    /// consistent with the overflow decision just made. Split out of
-    /// `apply_layout` to keep it under clippy's line budget.
-    fn place_visible_items(&mut self, axis_total: f64) {
-        let n_visible = self.visible_count.min(self.items.len());
-        let overflow = self.has_overflow();
-
-        let (measured_axes, spacer_count) = self.measure_visible_axes(n_visible);
-        let used: f64 = measured_axes.iter().sum();
-        let chip_reserve = if overflow { OVERFLOW_CHIP_AXIS_PX } else { 0.0 };
-        let residual = (axis_total - used - chip_reserve).max(0.0);
-        let per_spacer = if spacer_count > 0 {
-            residual / count_to_f64(spacer_count)
+        let chip = if self.has_overflow() {
+            self.axis(self.chip_extent).min(axis_total)
         } else {
             0.0
         };
-
-        let cross_start = match self.orientation {
-            Orientation::Horizontal => self.rect.y0,
-            Orientation::Vertical => self.rect.x0,
-        };
-        let cross_end = match self.orientation {
-            Orientation::Horizontal => self.rect.y1,
-            Orientation::Vertical => self.rect.x1,
+        let used: f64 = self
+            .extents
+            .iter()
+            .take(self.visible_count)
+            .map(|size| self.axis(*size))
+            .sum();
+        let spacers = self
+            .items
+            .iter()
+            .take(self.visible_count)
+            .filter(|item| matches!(item, ToolbarItem::Spacer))
+            .count();
+        let spacer = if spacers == 0 {
+            0.0
+        } else {
+            (axis_total - used - chip).max(0.0) / count_to_f64(spacers)
         };
-
-        let mut axis_cursor = match self.orientation {
+        self.item_rects = vec![Rect::ZERO; self.items.len()];
+        let mut cursor = match self.orientation {
             Orientation::Horizontal => self.rect.x0,
             Orientation::Vertical => self.rect.y0,
         };
-
-        for (i, item) in self.items.iter().take(n_visible).enumerate() {
+        for (index, item) in self.items.iter().take(self.visible_count).enumerate() {
             let extent = if matches!(item, ToolbarItem::Spacer) {
-                per_spacer
+                spacer
             } else {
-                measured_axes.get(i).copied().unwrap_or(0.0)
+                self.extents.get(index).map_or(0.0, |size| self.axis(*size))
             };
-            let r = match self.orientation {
+            let rect = match self.orientation {
                 Orientation::Horizontal => {
-                    Rect::new(axis_cursor, cross_start, axis_cursor + extent, cross_end)
+                    Rect::new(cursor, self.rect.y0, cursor + extent, self.rect.y1)
                 }
                 Orientation::Vertical => {
-                    Rect::new(cross_start, axis_cursor, cross_end, axis_cursor + extent)
+                    Rect::new(self.rect.x0, cursor, self.rect.x1, cursor + extent)
                 }
             };
-            if let Some(slot) = self.item_rects.get_mut(i) {
-                *slot = r;
+            if let Some(slot) = self.item_rects.get_mut(index) {
+                *slot = rect;
             }
-            axis_cursor += extent;
+            cursor += extent;
         }
-        // Items beyond `visible_count` keep `Rect::ZERO`: not rendered as
-        // their own rect, and any hover targeting them is silently
-        // dropped on the next `handle_event` (CursorMoved reads
-        // `item_rects`).
-        for r in self.item_rects.iter_mut().skip(n_visible) {
-            *r = Rect::ZERO;
-        }
-
-        if overflow {
-            self.overflow_rect = match self.orientation {
+        self.overflow_rect = if self.has_overflow() {
+            match self.orientation {
                 Orientation::Horizontal => Rect::new(
-                    self.rect.x1 - OVERFLOW_CHIP_AXIS_PX,
-                    cross_start,
+                    self.rect.x1 - chip,
+                    self.rect.y0,
                     self.rect.x1,
-                    cross_end,
+                    self.rect.y1,
                 ),
                 Orientation::Vertical => Rect::new(
-                    cross_start,
-                    self.rect.y1 - OVERFLOW_CHIP_AXIS_PX,
-                    cross_end,
+                    self.rect.x0,
+                    self.rect.y1 - chip,
+                    self.rect.x1,
                     self.rect.y1,
                 ),
-            };
+            }
         } else {
-            self.overflow_rect = Rect::ZERO;
+            Rect::ZERO
+        };
+        self.reconcile_menu();
+        let targets = self.targets();
+        if self.focus.is_some_and(|target| !targets.contains(&target)) {
+            self.focus = targets.last().copied();
         }
+        self.hovered = self.hovered.filter(|target| targets.contains(target));
+        self.pressed = self.pressed.filter(|target| targets.contains(target));
     }
-}
 
-/// Composes a paint transform with a translation. `Affine`'s `Mul` impl is
-/// pure `f64` matrix multiply-add with no overflow trap, so it cannot
-/// panic regardless of operand magnitude.
-#[allow(
-    clippy::arithmetic_side_effects,
-    reason = "Affine composition is float matrix math and cannot panic"
-)]
-fn translated(transform: Affine, x: f64, y: f64) -> Affine {
-    transform * Affine::translate((x, y))
+    fn reconcile_menu(&mut self) {
+        let mut indices = Vec::new();
+        let mut separator = false;
+        for (index, item) in self.items.iter().enumerate().skip(self.visible_count) {
+            match item {
+                ToolbarItem::Button { .. } => {
+                    if separator && !indices.is_empty() {
+                        indices.push(None);
+                    }
+                    indices.push(Some(index));
+                    separator = false;
+                }
+                ToolbarItem::Separator => separator = true,
+                ToolbarItem::Spacer => {}
+            }
+        }
+        if indices != self.menu_indices {
+            let open = self.menu.is_open();
+            let focused_index = self
+                .menu
+                .hovered()
+                .and_then(|row| self.menu_indices.get(row).copied().flatten());
+            self.menu = ContextMenu::new();
+            for index in &indices {
+                self.menu
+                    .push(match index.and_then(|index| self.items.get(index)) {
+                        Some(ToolbarItem::Button { label, .. }) => {
+                            MenuItem::action(label.clone(), || {})
+                        }
+                        _ => MenuItem::separator(),
+                    });
+            }
+            self.menu_indices = indices;
+            if open && self.has_overflow() {
+                self.open_menu(true);
+                if let Some(row) = self
+                    .menu_indices
+                    .iter()
+                    .position(|index| *index == focused_index)
+                {
+                    self.menu.focus_item(row);
+                }
+            }
+        }
+        if !self.has_overflow() {
+            self.menu.close();
+        }
+        if let Some(viewport) = self.viewport {
+            self.menu.reanchor(self.overflow_rect, viewport);
+        }
+    }
+
+    fn open_menu(&mut self, keyboard: bool) {
+        if !self.has_overflow() {
+            return;
+        }
+        self.menu
+            .open_anchored(self.overflow_rect, self.viewport.unwrap_or(self.rect));
+        self.focus = Some(Target::Overflow);
+        if keyboard {
+            self.menu.focus_first_action();
+        }
+    }
+    fn invoke(&mut self, index: usize) {
+        if let Some(ToolbarItem::Button { on_click, .. }) = self.items.get_mut(index) {
+            on_click();
+        }
+    }
+    fn drain_menu(&mut self) {
+        if let Some(index) = self
+            .menu
+            .take_selection()
+            .and_then(|row| self.menu_indices.get(row).copied().flatten())
+        {
+            self.invoke(index);
+        }
+        if !self.menu.is_open() {
+            self.focus = Some(Target::Overflow);
+        }
+    }
+    fn targets(&self) -> Vec<Target> {
+        let mut targets: Vec<_> = self
+            .items
+            .iter()
+            .enumerate()
+            .take(self.visible_count)
+            .filter_map(|(index, item)| {
+                matches!(item, ToolbarItem::Button { .. }).then_some(Target::Item(index))
+            })
+            .collect();
+        if self.has_overflow() {
+            targets.push(Target::Overflow);
+        }
+        targets
+    }
+    fn target_rect(&self, target: Target) -> Option<Rect> {
+        match target {
+            Target::Item(index) => self.item_rects.get(index).copied(),
+            Target::Overflow => Some(self.overflow_rect),
+        }
+    }
+    fn activate(&mut self, target: Target) {
+        match target {
+            Target::Item(index) => self.invoke(index),
+            Target::Overflow => self.open_menu(true),
+        }
+    }
+    fn move_focus(&mut self, forward: bool) {
+        let targets = self.targets();
+        if targets.is_empty() {
+            return;
+        }
+        let index = self
+            .focus
+            .and_then(|focus| targets.iter().position(|target| *target == focus));
+        let next = match index {
+            None => 0,
+            Some(index) if forward => index.saturating_add(1) % targets.len(),
+            Some(index) => index
+                .checked_sub(1)
+                .unwrap_or_else(|| targets.len().saturating_sub(1)),
+        };
+        self.focus = targets.get(next).copied();
+    }
+    fn semantic_target(&self, path: &[usize]) -> Option<Target> {
+        let targets = self.targets();
+        match path {
+            [child] => targets.get(*child).copied(),
+            [menu, child] if self.menu.is_open() && *menu == targets.len() => self
+                .menu_indices
+                .iter()
+                .flatten()
+                .nth(*child)
+                .map(|index| Target::Item(*index)),
+            _ => None,
+        }
+    }
+    fn focus_target(&mut self, target: Target) {
+        self.focused = true;
+        match target {
+            Target::Item(index) if index >= self.visible_count => {
+                self.open_menu(true);
+                if let Some(row) = self
+                    .menu_indices
+                    .iter()
+                    .position(|value| *value == Some(index))
+                {
+                    self.menu.focus_item(row);
+                }
+            }
+            _ => self.focus = Some(target),
+        }
+    }
 }
 
-/// Widens a character/spacer count to `f64` for layout math. Goes through
-/// `u32` (exactly representable in `f64`) with a saturating fallback
-/// rather than an `as` cast, so it's lossless for any realistic label
-/// length or item count.
 fn count_to_f64(n: usize) -> f64 {
     f64::from(u32::try_from(n).unwrap_or(u32::MAX))
 }
-
-/// Narrows a layout dimension to `f32` for taffy. Every call site is a
-/// toolbar axis extent, always many orders of magnitude below `f32::MAX`,
-/// so the truncation the lint warns about can't actually occur.
-#[cfg(test)]
 #[allow(
     clippy::cast_possible_truncation,
-    reason = "toolbar axis extents never approach f32::MAX"
+    reason = "bounded logical layout dimensions"
 )]
 #[cfg(test)]
-fn to_f32(v: f64) -> f32 {
-    v as f32
+fn to_f32(value: f64) -> f32 {
+    value as f32
+}
+#[allow(
+    clippy::arithmetic_side_effects,
+    reason = "affine composition is non-panicking float math"
+)]
+fn translated(transform: Affine, x: f64, y: f64) -> Affine {
+    transform * Affine::translate((x, y))
 }
 
 impl Widget for Toolbar {
     fn sync(&mut self, _state: &mut AutoCommit, _path: &ObjId) {}
-
     fn build_layout(
         &mut self,
-        taffy: &mut TaffyTree<()>,
+        tree: &mut TaffyTree<()>,
         theme: &Theme,
-        node_map: &mut HashMap<NodeId, *mut dyn Widget>,
+        nodes: &mut HashMap<NodeId, *mut dyn Widget>,
     ) -> NodeId {
-        // Fixed cross-axis size, derived from the button padding + sm
-        // typography slug so the strip reads as compact chrome.
-        let cross_axis_size = theme.tokens.typography.scale.sm + 2.0 * theme.tokens.spacing.s2;
-        let (w, h) = match self.orientation {
-            Orientation::Horizontal => (Dimension::auto(), Dimension::length(cross_axis_size)),
-            Orientation::Vertical => (Dimension::length(cross_axis_size), Dimension::auto()),
+        self.font = TextStyle::new(theme.tokens.typography.scale.sm);
+        self.padding = theme.tokens.spacing.s3;
+        self.minimum = theme.tokens.spacing.s8;
+        self.separator = 1.0 + 2.0 * theme.tokens.spacing.s2;
+        // Bootstrap only for legacy callers that skip renderer settlement.
+        self.extents = self
+            .items
+            .iter()
+            .map(|item| match item {
+                ToolbarItem::Button { .. } => Size {
+                    width: self.minimum,
+                    height: self.minimum,
+                },
+                ToolbarItem::Separator => match self.orientation {
+                    Orientation::Horizontal => Size {
+                        width: self.separator,
+                        height: self.minimum,
+                    },
+                    Orientation::Vertical => Size {
+                        width: self.minimum,
+                        height: self.separator,
+                    },
+                },
+                ToolbarItem::Spacer => Size::ZERO,
+            })
+            .collect();
+        self.chip_extent = Size {
+            width: self.minimum,
+            height: self.minimum,
         };
-        let node = taffy.leaf_node(Style {
-            size: Size {
-                width: w,
-                height: h,
+        let node = tree.leaf_node(Style {
+            flex_shrink: 1.0,
+            min_size: Size {
+                width: Dimension::length(0.0),
+                height: Dimension::length(0.0),
             },
-            flex_shrink: 0.0,
             ..Default::default()
         });
-        node_map.insert(node, std::ptr::from_mut::<dyn Widget>(self));
-        // Measure against whatever axis extent the last layout gave us.
-        // On the very first pass `self.rect` is empty, so fall back to
-        // "everything fits" rather than collapsing the whole strip into
-        // an overflow chip before the toolbar has ever been sized.
-        let axis_extent = match self.orientation {
-            Orientation::Horizontal => self.rect.width(),
-            Orientation::Vertical => self.rect.height(),
-        };
-        if axis_extent > 0.0 {
-            self.recompute_visible(axis_extent, theme);
-        } else if self.visible_count == 0 {
-            self.visible_count = self.items.len();
-        }
+        nodes.insert(node, std::ptr::from_mut::<dyn Widget>(self));
         node
     }
-
-    fn apply_layout(&mut self, taffy: &TaffyTree<()>, node: NodeId, origin: Point) {
-        let layout = taffy.layout(node).copied().unwrap_or_default();
+    fn measure(
+        &mut self,
+        known: Size<Option<f32>>,
+        _available: Size<taffy::AvailableSpace>,
+        text: &mut TextRenderer,
+    ) -> Size<f32> {
+        self.update_measurements(text);
+        Size {
+            width: known.width.unwrap_or(self.intrinsic.width),
+            height: known.height.unwrap_or(self.intrinsic.height),
+        }
+    }
+    fn adjust_layout_with_measure(
+        &mut self,
+        tree: &mut TaffyTree<()>,
+        node: NodeId,
+        text: &mut TextRenderer,
+    ) -> bool {
+        let changed = self.update_measurements(text);
+        if changed {
+            let _ = tree.mark_dirty(node);
+        }
+        changed
+    }
+    fn apply_layout(&mut self, tree: &TaffyTree<()>, node: NodeId, origin: Point) {
+        let layout = tree.layout(node).copied().unwrap_or_default();
+        let x = origin.x + f64::from(layout.location.x);
+        let y = origin.y + f64::from(layout.location.y);
         self.rect = Rect::new(
-            origin.x + f64::from(layout.location.x),
-            origin.y + f64::from(layout.location.y),
-            origin.x + f64::from(layout.location.x) + f64::from(layout.size.width),
-            origin.y + f64::from(layout.location.y) + f64::from(layout.size.height),
+            x,
+            y,
+            x + f64::from(layout.size.width),
+            y + f64::from(layout.size.height),
         );
-
-        self.item_rects.clear();
-        self.item_rects.resize(self.items.len(), Rect::ZERO);
-        if self.items.is_empty() {
-            self.visible_count = 0;
-            self.overflow_rect = Rect::ZERO;
-            return;
-        }
-
-        let axis_total = match self.orientation {
-            Orientation::Horizontal => self.rect.width(),
-            Orientation::Vertical => self.rect.height(),
-        };
-
-        self.visible_count = self.decide_visible_count(axis_total);
-        self.place_visible_items(axis_total);
+        self.place();
     }
-
     fn draw(
         &mut self,
         scene: &mut Scene,
         transform: Affine,
-        text_renderer: &mut TextRenderer,
+        text: &mut TextRenderer,
         theme: &Theme,
-        _presence: &PresenceCtx,
+        presence: &PresenceCtx,
     ) {
-        let tokens = &theme.tokens;
-        let radius = f64::from(tokens.radii.sm);
-        let font_size = tokens.typography.scale.sm;
-        let n_visible = self.visible_count.min(self.items.len());
-
-        for (i, (item, &r)) in self
-            .items
-            .iter()
-            .zip(self.item_rects.iter())
-            .enumerate()
-            .take(n_visible)
-        {
-            if r.is_zero_area() {
+        self.viewport = presence.viewport.get().or(self.viewport);
+        if let Some(viewport) = self.viewport {
+            self.menu.reanchor(self.overflow_rect, viewport);
+        }
+        self.menu.layout_within(text, theme);
+        let style = text.renderer_input_style(&self.font);
+        // Explicit tiny allocations remain authoritative, including for glyph paint.
+        scene.push_layer(
+            vello::peniko::Fill::NonZero,
+            vello::peniko::BlendMode::default(),
+            1.0,
+            transform,
+            &self.rect,
+        );
+        for (index, item) in self.items.iter().enumerate().take(self.visible_count) {
+            let Some(rect) = self
+                .item_rects
+                .get(index)
+                .copied()
+                .filter(|rect| !rect.is_zero_area())
+            else {
                 continue;
-            }
+            };
             match item {
-                ToolbarItem::Button { label, .. } => {
-                    let hovered = self.item_hover.get(i).copied().unwrap_or(false);
-                    let bg = if hovered {
-                        theme.bg_hover
-                    } else {
-                        tokens.colors.surfaces.raised
-                    };
-                    let shape = RoundedRect::from_rect(r, radius);
-                    scene.fill(vello::peniko::Fill::NonZero, transform, bg, None, &shape);
-                    let (tw, th) = text_renderer.measure(label, font_size, None);
-                    let tx = r.center().x - f64::from(tw) / 2.0;
-                    let ty = r.center().y - f64::from(th) / 2.0;
-                    text_renderer.draw_text(
-                        scene,
-                        label,
-                        font_size,
-                        tokens.colors.text_primary,
-                        translated(transform, tx, ty),
-                        None,
-                    );
-                }
+                ToolbarItem::Button { label, .. } => self.draw_button(
+                    scene,
+                    transform,
+                    text,
+                    theme,
+                    &style,
+                    Target::Item(index),
+                    rect,
+                    label,
+                ),
                 ToolbarItem::Separator => {
-                    // Hairline divider perpendicular to the orientation
-                    // axis. Margin `s2` from each end along the cross
-                    // axis (so the line doesn't kiss the toolbar edge).
-                    let margin = f64::from(tokens.spacing.s2);
-                    let line_rect = match self.orientation {
-                        Orientation::Horizontal => {
-                            let cx = r.center().x;
-                            Rect::new(
-                                cx - SEPARATOR_LINE_PX / 2.0,
-                                r.y0 + margin,
-                                cx + SEPARATOR_LINE_PX / 2.0,
-                                r.y1 - margin,
-                            )
-                        }
-                        Orientation::Vertical => {
-                            let cy = r.center().y;
-                            Rect::new(
-                                r.x0 + margin,
-                                cy - SEPARATOR_LINE_PX / 2.0,
-                                r.x1 - margin,
-                                cy + SEPARATOR_LINE_PX / 2.0,
-                            )
-                        }
+                    let margin = f64::from(theme.tokens.spacing.s2);
+                    let line = match self.orientation {
+                        Orientation::Horizontal => Rect::new(
+                            rect.center().x - 0.5,
+                            rect.y0 + margin,
+                            rect.center().x + 0.5,
+                            (rect.y1 - margin).max(rect.y0 + margin),
+                        ),
+                        Orientation::Vertical => Rect::new(
+                            rect.x0 + margin,
+                            rect.center().y - 0.5,
+                            (rect.x1 - margin).max(rect.x0 + margin),
+                            rect.center().y + 0.5,
+                        ),
                     };
                     scene.fill(
                         vello::peniko::Fill::NonZero,
                         transform,
-                        tokens.colors.border_standard,
+                        theme.tokens.colors.border_standard,
                         None,
-                        &line_rect,
+                        &line,
                     );
                 }
-                ToolbarItem::Spacer => {
-                    // Greedy spacer — soaks remaining space, paints
-                    // nothing. Stays in `item_rects` so apply_layout
-                    // bookkeeping is uniform.
-                }
+                ToolbarItem::Spacer => {}
             }
         }
-
-        if self.has_overflow() && !self.overflow_rect.is_zero_area() {
-            let bg = if self.overflow_hover {
-                theme.bg_hover
-            } else {
-                tokens.colors.surfaces.raised
-            };
-            let shape = RoundedRect::from_rect(self.overflow_rect, radius);
-            scene.fill(vello::peniko::Fill::NonZero, transform, bg, None, &shape);
-            let label = "…";
-            let (tw, th) = text_renderer.measure(label, font_size, None);
-            let tx = self.overflow_rect.center().x - f64::from(tw) / 2.0;
-            let ty = self.overflow_rect.center().y - f64::from(th) / 2.0;
-            text_renderer.draw_text(
+        if self.has_overflow() {
+            self.draw_button(
                 scene,
-                label,
-                font_size,
-                tokens.colors.text_primary,
-                translated(transform, tx, ty),
-                None,
+                transform,
+                text,
+                theme,
+                &style,
+                Target::Overflow,
+                self.overflow_rect,
+                "…",
             );
         }
+        scene.pop_layer();
+    }
+    fn draw_overlay(
+        &mut self,
+        scene: &mut Scene,
+        transform: Affine,
+        text: &mut TextRenderer,
+        theme: &Theme,
+        presence: &PresenceCtx,
+    ) {
+        self.menu.draw(scene, transform, text, theme, presence);
     }
-
     fn handle_event(
         &mut self,
         event: &WindowEvent,
-        scale_factor: f64,
-        _modifiers: &winit::event::Modifiers,
-        _state: &mut AutoCommit,
-        _path: &ObjId,
+        scale: f64,
+        modifiers: &winit::event::Modifiers,
+        state: &mut AutoCommit,
+        path: &ObjId,
         handled: &mut bool,
-        _focus_target: &mut Option<NodeId>,
-        _node_id: NodeId,
-        _taffy: &TaffyTree<()>,
+        focus_target: &mut Option<NodeId>,
+        node: NodeId,
+        tree: &TaffyTree<()>,
     ) {
+        if self.menu.is_open() {
+            self.menu.handle_event(
+                event,
+                scale,
+                modifiers,
+                state,
+                path,
+                handled,
+                focus_target,
+                node,
+                tree,
+            );
+            if matches!(
+                event,
+                WindowEvent::MouseInput {
+                    state: ElementState::Pressed,
+                    ..
+                }
+            ) {
+                self.swallow_release = true;
+            }
+            self.drain_menu();
+            return;
+        }
         match event {
             WindowEvent::CursorMoved { position, .. } => {
-                let pos = Point::new(position.x / scale_factor, position.y / scale_factor);
-                let n_visible = self.visible_count.min(self.items.len());
-                if self.item_hover.len() != self.items.len() {
-                    self.item_hover.resize(self.items.len(), false);
-                }
-                for (i, h) in self.item_hover.iter_mut().enumerate() {
-                    let new_h = i < n_visible
-                        && self
-                            .items
-                            .get(i)
-                            .is_some_and(|it| matches!(it, ToolbarItem::Button { .. }))
-                        && self.item_rects.get(i).is_some_and(|r| r.contains(pos));
-                    if new_h != *h {
-                        *h = new_h;
-                        *handled = true;
-                    }
+                let point = Point::new(position.x / scale, position.y / scale);
+                let hovered = self.targets().into_iter().find(|target| {
+                    self.target_rect(*target)
+                        .is_some_and(|rect| rect.contains(point))
+                });
+                if hovered != self.hovered {
+                    self.hovered = hovered;
+                    *handled = true;
                 }
-                let new_oh = self.has_overflow() && self.overflow_rect.contains(pos);
-                if new_oh != self.overflow_hover {
-                    self.overflow_hover = new_oh;
+            }
+            WindowEvent::MouseInput {
+                state: ElementState::Pressed,
+                button: MouseButton::Left,
+                ..
+            } => {
+                self.pressed = self.hovered;
+                if let Some(target) = self.pressed {
+                    self.focus_target(target);
+                    *focus_target = Some(node);
                     *handled = true;
                 }
             }
@@ -612,42 +724,272 @@ impl Widget for Toolbar {
                 button: MouseButton::Left,
                 ..
             } => {
-                let n_visible = self.visible_count.min(self.items.len());
-                for i in 0..n_visible {
-                    if self.item_hover.get(i).copied().unwrap_or(false)
-                        && let Some(ToolbarItem::Button { on_click, .. }) = self.items.get_mut(i)
+                if self.swallow_release {
+                    self.swallow_release = false;
+                    self.pressed = None;
+                    *handled = true;
+                    return;
+                }
+                if let Some(target) = self
+                    .pressed
+                    .take()
+                    .filter(|target| Some(*target) == self.hovered)
+                {
+                    self.activate(target);
+                    *handled = true;
+                }
+            }
+            WindowEvent::KeyboardInput { event, .. }
+                if self.focused && event.state == ElementState::Pressed =>
+            {
+                match &event.logical_key {
+                    Key::Named(NamedKey::Enter | NamedKey::Space) => {
+                        if let Some(target) = self.focus {
+                            self.activate(target);
+                        }
+                        *handled = true;
+                    }
+                    Key::Named(NamedKey::ArrowRight)
+                        if self.orientation == Orientation::Horizontal =>
                     {
-                        on_click();
+                        self.move_focus(true);
                         *handled = true;
                     }
-                }
-                if self.overflow_hover && self.has_overflow() {
-                    self.overflow_open = !self.overflow_open;
-                    *handled = true;
+                    Key::Named(NamedKey::ArrowLeft)
+                        if self.orientation == Orientation::Horizontal =>
+                    {
+                        self.move_focus(false);
+                        *handled = true;
+                    }
+                    Key::Named(NamedKey::ArrowDown)
+                        if self.orientation == Orientation::Vertical =>
+                    {
+                        self.move_focus(true);
+                        *handled = true;
+                    }
+                    Key::Named(NamedKey::ArrowUp) if self.orientation == Orientation::Vertical => {
+                        self.move_focus(false);
+                        *handled = true;
+                    }
+                    _ => {}
                 }
             }
             _ => {}
         }
     }
-
+    fn is_focusable(&self) -> bool {
+        self.items
+            .iter()
+            .any(|item| matches!(item, ToolbarItem::Button { .. }))
+    }
+    fn set_focus(&mut self, focused: bool) {
+        self.focused = focused;
+        if focused && self.focus.is_none() {
+            self.focus = self.targets().first().copied();
+        }
+        if !focused {
+            self.menu.close();
+            self.pressed = None;
+        }
+    }
+    fn is_focused(&self) -> bool {
+        self.focused
+    }
+    fn traps_focus(&self) -> bool {
+        self.menu.is_open()
+    }
+    fn wants_pointer_capture(&self) -> bool {
+        self.menu.is_open() || self.pressed.is_some() || self.swallow_release
+    }
+    fn modal_capture(&self) -> Option<Rect> {
+        self.menu.modal_capture()
+    }
     fn name(&self) -> &'static str {
         "Toolbar"
     }
-
-    /// The toolbar reports [`Role::Toolbar`] — a strip of controls. Its
-    /// items are drawn directly (not child widgets), so they don't flow
-    /// through `children()`; the container itself stands in for the strip.
-    /// It carries no name of its own (a labelling host would supply one).
-    fn accessibility(&self) -> Option<crate::a11y::AccessNode> {
-        use crate::a11y::{AccessNode, Role};
-        Some(AccessNode::new(Role::Toolbar))
-    }
-
     fn get_rect(&self) -> Rect {
         self.rect
     }
+    fn accessibility(&self) -> Option<AccessNode> {
+        let mut children: Vec<_> = self
+            .targets()
+            .iter()
+            .map(|target| {
+                let (name, route, expanded) = match target {
+                    Target::Item(index) => (
+                        match self.items.get(*index) {
+                            Some(ToolbarItem::Button { label, .. }) => label.clone(),
+                            _ => String::new(),
+                        },
+                        format!("toolbar.item.{index}"),
+                        None,
+                    ),
+                    Target::Overflow => (
+                        "More commands".to_owned(),
+                        "toolbar.overflow".to_owned(),
+                        Some(self.menu.is_open()),
+                    ),
+                };
+                AccessNode::new(Role::Button)
+                    .with_name(name)
+                    .with_action_target(route)
+                    .with_state(AccessState {
+                        focusable: true,
+                        focused: self.focused
+                            && !self.menu.is_open()
+                            && self.focus == Some(*target),
+                        expanded,
+                        ..Default::default()
+                    })
+            })
+            .collect();
+        if self.menu.is_open() {
+            let rows = self
+                .menu_indices
+                .iter()
+                .enumerate()
+                .filter_map(|(row, index)| {
+                    let index = (*index)?;
+                    let ToolbarItem::Button { label, .. } = self.items.get(index)? else {
+                        return None;
+                    };
+                    Some(
+                        AccessNode::new(Role::MenuItem)
+                            .with_name(label.clone())
+                            .with_action_target(format!("toolbar.item.{index}"))
+                            .with_state(AccessState {
+                                focusable: true,
+                                focused: self.focused && self.menu.hovered() == Some(row),
+                                ..Default::default()
+                            }),
+                    )
+                })
+                .collect();
+            children.push(AccessNode::new(Role::Menu).with_children(rows));
+        }
+        Some(
+            AccessNode::new(Role::Toolbar)
+                .with_state(AccessState {
+                    focusable: self.is_focusable(),
+                    focused: self.focused,
+                    ..Default::default()
+                })
+                .with_children(children),
+        )
+    }
+    fn synthetic_accessibility_rect(&self, path: &[usize]) -> Option<Rect> {
+        match self.semantic_target(path)? {
+            Target::Item(index) if index >= self.visible_count => self
+                .menu_indices
+                .iter()
+                .position(|value| *value == Some(index))
+                .and_then(|row| self.menu.item_rect(row)),
+            target => self.target_rect(target),
+        }
+    }
+    fn focus_synthetic_accessibility(&mut self, path: &[usize]) -> bool {
+        let Some(target) = self.semantic_target(path) else {
+            return false;
+        };
+        self.focus_target(target);
+        true
+    }
+    fn perform_semantic_action(
+        &mut self,
+        target: &str,
+        action: &Action,
+        _state: &mut AutoCommit,
+        _path: &ObjId,
+    ) -> bool {
+        let target = if target == "toolbar.overflow" && self.has_overflow() {
+            Target::Overflow
+        } else if let Some(index) = target
+            .strip_prefix("toolbar.item.")
+            .and_then(|index| index.parse::<usize>().ok())
+        {
+            if !matches!(self.items.get(index), Some(ToolbarItem::Button { .. }))
+                || (index >= self.visible_count && !self.menu.is_open())
+            {
+                return false;
+            }
+            Target::Item(index)
+        } else {
+            return false;
+        };
+        match action {
+            Action::Focus => self.focus_target(target),
+            Action::Activate => {
+                if let Target::Item(index) = target
+                    && index >= self.visible_count
+                {
+                    if let Some(row) = self
+                        .menu_indices
+                        .iter()
+                        .position(|value| *value == Some(index))
+                    {
+                        self.menu.click_item(row);
+                        self.drain_menu();
+                    }
+                } else {
+                    self.activate(target);
+                }
+            }
+            _ => return false,
+        }
+        true
+    }
 }
 
+impl Toolbar {
+    #[allow(
+        clippy::too_many_arguments,
+        reason = "paint inputs and an immediate-mode button's geometry"
+    )]
+    fn draw_button(
+        &self,
+        scene: &mut Scene,
+        transform: Affine,
+        text: &mut TextRenderer,
+        theme: &Theme,
+        style: &TextStyle,
+        target: Target,
+        rect: Rect,
+        label: &str,
+    ) {
+        if rect.is_zero_area() {
+            return;
+        }
+        let shape = RoundedRect::from_rect(rect, f64::from(theme.tokens.radii.sm));
+        let color = if self.hovered == Some(target) {
+            theme.bg_hover
+        } else {
+            theme.tokens.colors.surfaces.raised
+        };
+        scene.fill(vello::peniko::Fill::NonZero, transform, color, None, &shape);
+        if self.focused && self.focus == Some(target) && !self.menu.is_open() {
+            scene.stroke(
+                &Stroke::new(2.0),
+                transform,
+                theme.tokens.colors.border_focus,
+                None,
+                &shape,
+            );
+        }
+        let (width, height) = text.measure_style(label, None, style);
+        text.draw_style(
+            scene,
+            label,
+            theme.tokens.colors.text_primary,
+            translated(
+                transform,
+                rect.center().x - f64::from(width) / 2.0,
+                rect.center().y - f64::from(height) / 2.0,
+            ),
+            None,
+            style,
+        );
+    }
+}
 // =====================================================================
 // Tests
 // =====================================================================
@@ -723,6 +1065,73 @@ mod tests {
             .count()
     }
 
+    #[test]
+    fn measured_labels_and_tiny_overflow_follow_lifecycle() {
+        let mut tb = Toolbar::new(Orientation::Horizontal)
+            .push_button("WWW", || {})
+            .push_button("iii", || {});
+        let theme = Theme::dark();
+        let mut text = TextRenderer::new();
+        let mut tree = TaffyTree::new();
+        let node = tb.build_layout(&mut tree, &theme, &mut HashMap::new());
+        tb.adjust_layout_with_measure(&mut tree, node, &mut text);
+        tree.set_style(
+            node,
+            Style {
+                size: Size {
+                    width: Dimension::length(500.0),
+                    height: Dimension::length(40.0),
+                },
+                ..Default::default()
+            },
+        )
+        .unwrap();
+        tree.compute_layout(
+            node,
+            Size {
+                width: taffy::AvailableSpace::MaxContent,
+                height: taffy::AvailableSpace::MaxContent,
+            },
+        )
+        .unwrap();
+        tb.apply_layout(&tree, node, Point::ZERO);
+        assert!(
+            tb.item_rects[0].width() > tb.item_rects[1].width(),
+            "renderer widths must replace character counting"
+        );
+        tree.set_style(
+            node,
+            Style {
+                size: Size {
+                    width: Dimension::length(5.0),
+                    height: Dimension::length(40.0),
+                },
+                ..Default::default()
+            },
+        )
+        .unwrap();
+        tree.compute_layout(
+            node,
+            Size {
+                width: taffy::AvailableSpace::MaxContent,
+                height: taffy::AvailableSpace::MaxContent,
+            },
+        )
+        .unwrap();
+        tb.apply_layout(&tree, node, Point::ZERO);
+        assert!(tb.overflow_rect.x0 >= tb.rect.x0);
+        assert!(tb.item_rects.iter().all(|r| *r == Rect::ZERO));
+    }
+
+    #[test]
+    fn toolbar_exposes_focusable_named_commands() {
+        let tb = lay_out(n_button_toolbar(3), 100.0);
+        assert!(tb.is_focusable());
+        let node = tb.accessibility().unwrap();
+        assert!(!node.children.is_empty());
+        assert!(node.children.iter().all(|c| c.name.is_some()));
+    }
+
     #[test]
     fn accessibility_reports_toolbar_role() {
         use crate::a11y::Role;
@@ -840,3 +1249,410 @@ mod tests {
         );
     }
 }
+
+#[cfg(test)]
+mod lifecycle_tests {
+    use super::*;
+    use std::cell::RefCell;
+    use std::rc::Rc;
+    use winit::event::{DeviceId, KeyEvent};
+
+    fn settle(tb: &mut Toolbar, width: f32, height: f32, scale: f32) {
+        let theme = Theme::dark().with_text_scale(scale);
+        let mut text = TextRenderer::new();
+        text.set_text_scale(scale);
+        let mut tree = TaffyTree::new();
+        let mut nodes = HashMap::new();
+        let node = tb.build_layout(&mut tree, &theme, &mut nodes);
+        let mut style = tree.style(node).unwrap().clone();
+        style.size = Size {
+            width: Dimension::length(width),
+            height: Dimension::length(height),
+        };
+        tree.set_style(node, style).unwrap();
+        let mut bindings = crate::bound_dispatch::BoundNodeMap::default();
+        unsafe {
+            bindings.rebuild(tb, &tree, node, &nodes);
+            crate::widget::layout::compute_widget_layout(
+                &mut tree,
+                node,
+                Size {
+                    width: taffy::AvailableSpace::Definite(width),
+                    height: taffy::AvailableSpace::Definite(height),
+                },
+                &nodes,
+                &bindings,
+                &mut text,
+            )
+            .unwrap();
+        }
+        tb.apply_layout(&tree, node, Point::new(10.0, 10.0));
+        let presence = PresenceCtx::default();
+        presence
+            .viewport
+            .set(Some(Rect::new(0.0, 0.0, 360.0, 220.0)));
+        let mut scene = Scene::new();
+        tb.draw(&mut scene, Affine::IDENTITY, &mut text, &theme, &presence);
+        tb.draw_overlay(&mut scene, Affine::IDENTITY, &mut text, &theme, &presence);
+    }
+    fn dispatch(tb: &mut Toolbar, event: WindowEvent) -> bool {
+        let mut tree = TaffyTree::new();
+        let node = tree.leaf_node(Style::default());
+        let mut handled = false;
+        tb.handle_event(
+            &event,
+            1.0,
+            &Default::default(),
+            &mut AutoCommit::new(),
+            &automerge::ROOT,
+            &mut handled,
+            &mut None,
+            node,
+            &tree,
+        );
+        handled
+    }
+    fn cursor(tb: &mut Toolbar, p: Point) {
+        dispatch(
+            tb,
+            WindowEvent::CursorMoved {
+                device_id: unsafe { std::mem::zeroed::<DeviceId>() },
+                position: winit::dpi::PhysicalPosition::new(p.x, p.y),
+            },
+        );
+    }
+    fn mouse(tb: &mut Toolbar, state: ElementState) -> bool {
+        dispatch(
+            tb,
+            WindowEvent::MouseInput {
+                device_id: unsafe { std::mem::zeroed::<DeviceId>() },
+                state,
+                button: MouseButton::Left,
+            },
+        )
+    }
+    fn key(tb: &mut Toolbar, key: NamedKey) -> bool {
+        let mut event: KeyEvent = unsafe { std::mem::zeroed() };
+        event.logical_key = Key::Named(key);
+        event.physical_key = winit::keyboard::PhysicalKey::Unidentified(
+            winit::keyboard::NativeKeyCode::Unidentified,
+        );
+        event.location = winit::keyboard::KeyLocation::Standard;
+        event.state = ElementState::Pressed;
+        event.text = None;
+        dispatch(
+            tb,
+            WindowEvent::KeyboardInput {
+                device_id: unsafe { std::mem::zeroed() },
+                event,
+                is_synthetic: true,
+            },
+        )
+    }
+    fn counted(n: usize) -> (Toolbar, Rc<RefCell<Vec<usize>>>) {
+        let counts = Rc::new(RefCell::new(vec![0; n]));
+        let mut tb = Toolbar::new(Orientation::Horizontal);
+        for index in 0..n {
+            let counts = counts.clone();
+            tb = tb.push_button(&format!("Command {index}"), move || {
+                counts.borrow_mut()[index] += 1
+            });
+        }
+        (tb, counts)
+    }
+    #[test]
+    fn pointer_survives_layout_between_press_and_release() {
+        let (mut tb, counts) = counted(2);
+        settle(&mut tb, 350.0, 45.0, 1.0);
+        let p = tb.item_rects[0].center();
+        cursor(&mut tb, p);
+        mouse(&mut tb, ElementState::Pressed);
+        settle(&mut tb, 350.0, 45.0, 1.0);
+        mouse(&mut tb, ElementState::Released);
+        assert_eq!(*counts.borrow(), vec![1, 0]);
+    }
+    #[test]
+    fn tab_focus_starts_at_first_command_and_arrows_skip_decoration() {
+        let mut tb = Toolbar::new(Orientation::Horizontal)
+            .push_button("First", || {})
+            .push_separator()
+            .push_spacer()
+            .push_button("Last", || {});
+        settle(&mut tb, 350.0, 45.0, 1.0);
+        tb.set_focus(true);
+        assert_eq!(tb.focus, Some(Target::Item(0)));
+        key(&mut tb, NamedKey::ArrowRight);
+        assert_eq!(tb.focus, Some(Target::Item(3)));
+    }
+    #[test]
+    fn every_callback_is_reachable_once_by_each_input_route() {
+        for route in 0..3 {
+            let (mut tb, counts) = counted(8);
+            settle(&mut tb, 180.0, 45.0, 1.0);
+            tb.set_focus(true);
+            for index in 0..8 {
+                if index < tb.visible_count {
+                    match route {
+                        0 => {
+                            let p = tb.item_rects[index].center();
+                            cursor(&mut tb, p);
+                            mouse(&mut tb, ElementState::Pressed);
+                            mouse(&mut tb, ElementState::Released);
+                        }
+                        1 => {
+                            tb.focus = Some(Target::Item(index));
+                            key(&mut tb, NamedKey::Enter);
+                        }
+                        _ => {
+                            assert!(tb.perform_semantic_action(
+                                &format!("toolbar.item.{index}"),
+                                &Action::Activate,
+                                &mut AutoCommit::new(),
+                                &automerge::ROOT
+                            ));
+                        }
+                    }
+                } else {
+                    tb.focus = Some(Target::Overflow);
+                    key(&mut tb, NamedKey::Space);
+                    settle(&mut tb, 180.0, 45.0, 1.0);
+                    let row = tb
+                        .menu_indices
+                        .iter()
+                        .position(|entry| *entry == Some(index))
+                        .unwrap();
+                    while tb.menu.hovered() != Some(row) {
+                        key(&mut tb, NamedKey::ArrowDown);
+                    }
+                    match route {
+                        0 => {
+                            let p = tb.menu.item_rect(row).unwrap().center();
+                            cursor(&mut tb, p);
+                            mouse(&mut tb, ElementState::Pressed);
+                            mouse(&mut tb, ElementState::Released);
+                        }
+                        1 => {
+                            key(&mut tb, NamedKey::Enter);
+                        }
+                        _ => {
+                            assert!(tb.perform_semantic_action(
+                                &format!("toolbar.item.{index}"),
+                                &Action::Activate,
+                                &mut AutoCommit::new(),
+                                &automerge::ROOT
+                            ));
+                        }
+                    }
+                    assert!(!tb.menu.is_open());
+                    assert_eq!(tb.focus, Some(Target::Overflow));
+                }
+            }
+            assert_eq!(*counts.borrow(), vec![1; 8], "route {route}");
+        }
+    }
+    #[test]
+    fn measured_unicode_scale_orientation_and_resize() {
+        for orientation in [Orientation::Horizontal, Orientation::Vertical] {
+            let mut tb = Toolbar::new(orientation)
+                .push_button("WWW", || {})
+                .push_button("iii", || {})
+                .push_button("共有 العربية e\u{301} 😀", || {})
+                .push_button("Eine sehr lange übersetzte Aktion", || {});
+            settle(&mut tb, 140.0, 90.0, 1.0);
+            assert!(tb.extents[0].width > tb.extents[1].width);
+            let small = tb.extents.clone();
+            tb.open_menu(true);
+            settle(&mut tb, 140.0, 90.0, 2.0);
+            assert!(tb.extents[2].width > small[2].width);
+            assert!(tb.extents[2].height > small[2].height);
+            assert!(
+                tb.item_rects
+                    .iter()
+                    .skip(tb.visible_count)
+                    .all(|rect| *rect == Rect::ZERO)
+            );
+            assert!(tb.menu.is_open());
+            assert!(tb.menu.get_rect().x0 >= 0.0 && tb.menu.get_rect().x1 <= 360.0);
+            settle(&mut tb, 2000.0, 1000.0, 2.0);
+            assert!(!tb.has_overflow());
+            assert!(!tb.menu.is_open());
+            assert!(tb.targets().contains(&tb.focus.unwrap()));
+        }
+    }
+    #[test]
+    fn decorations_never_create_an_overflow_menu() {
+        let mut tb = Toolbar::new(Orientation::Horizontal)
+            .push_button("A", || {})
+            .push_separator()
+            .push_spacer();
+        settle(&mut tb, 100.0, 45.0, 1.0);
+        let exact = tb.extents[0].width;
+        settle(&mut tb, exact, 45.0, 1.0);
+        assert_eq!(tb.visible_count, 1);
+        assert!(!tb.has_overflow());
+        assert_eq!(tb.overflow_rect, Rect::ZERO);
+        settle(&mut tb, exact - 1.0, 45.0, 1.0);
+        assert!(tb.has_overflow());
+        assert!(tb.menu_indices.iter().all(Option::is_some));
+    }
+    #[test]
+    fn escape_and_outside_press_restore_focus_without_click_through() {
+        let (mut tb, counts) = counted(5);
+        settle(&mut tb, 180.0, 45.0, 1.0);
+        tb.set_focus(true);
+        tb.focus = Some(Target::Overflow);
+        key(&mut tb, NamedKey::Enter);
+        assert!(tb.traps_focus() && tb.wants_pointer_capture());
+        key(&mut tb, NamedKey::Escape);
+        assert!(!tb.traps_focus());
+        assert!(tb.is_focused());
+        assert_eq!(tb.focus, Some(Target::Overflow));
+        key(&mut tb, NamedKey::Enter);
+        let p = tb.item_rects[0].center();
+        cursor(&mut tb, p);
+        mouse(&mut tb, ElementState::Pressed);
+        mouse(&mut tb, ElementState::Released);
+        assert_eq!(*counts.borrow(), vec![0; 5]);
+    }
+    #[test]
+    fn resize_reconciles_original_indices_and_meaningful_separators() {
+        let mut tb = Toolbar::new(Orientation::Horizontal)
+            .push_separator()
+            .push_button("One", || {})
+            .push_separator()
+            .push_separator()
+            .push_spacer()
+            .push_button("Two", || {})
+            .push_separator()
+            .push_button("Three", || {})
+            .push_separator();
+        settle(&mut tb, 5.0, 45.0, 1.0);
+        assert_eq!(tb.menu_indices, vec![Some(1), None, Some(5), None, Some(7)]);
+        assert!(tb.overflow_rect.x0 >= tb.rect.x0);
+        tb.open_menu(true);
+        tb.menu.focus_item(4);
+        let width = tb
+            .extents
+            .iter()
+            .take(5)
+            .map(|size| size.width)
+            .sum::<f32>()
+            + tb.chip_extent.width;
+        settle(&mut tb, width, 45.0, 1.0);
+        assert!(tb.menu.is_open());
+        assert_eq!(tb.menu_indices, vec![Some(5), None, Some(7)]);
+        assert_eq!(tb.menu.hovered(), Some(2));
+        assert!(tb.menu.get_rect().x0 >= 0.0 && tb.menu.get_rect().x1 <= 360.0);
+    }
+
+    #[test]
+    fn vertical_navigation_and_tiny_chip_stay_inside_allocation() {
+        let mut tb = Toolbar::new(Orientation::Vertical)
+            .push_button("One", || {})
+            .push_separator()
+            .push_button("Two", || {});
+        settle(&mut tb, 120.0, 180.0, 1.0);
+        tb.set_focus(true);
+        key(&mut tb, NamedKey::ArrowDown);
+        assert_eq!(tb.focus, Some(Target::Item(2)));
+        key(&mut tb, NamedKey::ArrowUp);
+        assert_eq!(tb.focus, Some(Target::Item(0)));
+        settle(&mut tb, 120.0, 5.0, 2.0);
+        assert!(tb.has_overflow());
+        assert!(tb.overflow_rect.y0 >= tb.rect.y0 && tb.overflow_rect.y1 <= tb.rect.y1);
+        assert!(tb.item_rects.iter().all(|rect| *rect == Rect::ZERO));
+    }
+
+    #[test]
+    fn accessibility_menu_rows_have_routes_bounds_and_focus() {
+        let (mut tb, _) = counted(12);
+        settle(&mut tb, 120.0, 45.0, 1.0);
+        tb.set_focus(true);
+        tb.open_menu(true);
+        let menu_child = tb.targets().len();
+        let node = tb.accessibility().unwrap();
+        assert_eq!(node.children[menu_child].role, Role::Menu);
+        assert!(
+            node.children[menu_child]
+                .children
+                .iter()
+                .all(|child| child.action_target.is_some())
+        );
+        let last = node.children[menu_child].children.len() - 1;
+        assert!(tb.focus_synthetic_accessibility(&[menu_child, last]));
+        let rect = tb
+            .synthetic_accessibility_rect(&[menu_child, last])
+            .unwrap();
+        assert!(rect.y0 >= tb.menu.get_rect().y0 && rect.y1 <= tb.menu.get_rect().y1);
+        assert!(
+            tb.accessibility().unwrap().children[menu_child].children[last]
+                .state
+                .focused
+        );
+    }
+    #[test]
+    #[ignore = "manual offscreen evidence; set QUICK_UI_SCREENSHOT_DIR"]
+    fn rendered_toolbar_overflow_fixtures() {
+        let dir = std::env::var("QUICK_UI_SCREENSHOT_DIR").unwrap();
+        std::fs::create_dir_all(&dir).unwrap();
+        for (name, width, height, scale, toolbar_width) in [
+            ("toolbar-ordinary-100", 720u32, 340u32, 1.0, 530.0),
+            ("toolbar-narrow-200", 320u32, 260u32, 2.0, 290.0),
+        ] {
+            let labels = [
+                "New",
+                "Open",
+                "Save",
+                "WWW",
+                "iii",
+                "共有",
+                "العربية",
+                "Übersetzte Aktion",
+                "Export",
+                "Last hidden command",
+            ];
+            let fired = Rc::new(RefCell::new(0));
+            let mut tb = Toolbar::new(Orientation::Horizontal);
+            for (index, label) in labels.iter().enumerate() {
+                let fired = fired.clone();
+                tb = tb.push_button(label, move || {
+                    if index == 9 {
+                        *fired.borrow_mut() += 1;
+                    }
+                });
+            }
+            settle(&mut tb, toolbar_width, 44.0 * scale, scale);
+            let theme = Theme::dark().with_text_scale(scale);
+            let mut text = TextRenderer::new();
+            text.set_text_scale(scale);
+            let presence = PresenceCtx::default();
+            presence.viewport.set(Some(Rect::new(
+                0.0,
+                0.0,
+                f64::from(width),
+                f64::from(height),
+            )));
+            let mut scene = Scene::new();
+            tb.draw(&mut scene, Affine::IDENTITY, &mut text, &theme, &presence);
+            tb.set_focus(true);
+            tb.focus = Some(Target::Overflow);
+            key(&mut tb, NamedKey::Enter);
+            let last = tb.menu_indices.len() - 1;
+            while tb.menu.hovered() != Some(last) {
+                key(&mut tb, NamedKey::ArrowDown);
+            }
+            scene.reset();
+            tb.draw(&mut scene, Affine::IDENTITY, &mut text, &theme, &presence);
+            tb.draw_overlay(&mut scene, Affine::IDENTITY, &mut text, &theme, &presence);
+            assert!(tb.menu.item_rect(last).is_some());
+            let mut renderer = crate::offscreen::OffscreenRenderer::new(width, height);
+            let path = format!("{dir}/{name}.png");
+            renderer.render_png(&scene, theme.bg_app, &path);
+            key(&mut tb, NamedKey::Enter);
+            assert_eq!(*fired.borrow(), 1);
+            eprintln!(
+                "capture {path}; viewport={width}x{height}; toolbar_width={toolbar_width}; Theme::dark().with_text_scale({scale}); last command fired once"
+            );
+        }
+    }
+}

```

## c7b2d576b
```diff
commit c7b2d576b0fa59cb21f83a881fefba9aa6ecf75d
Author:     Xaver Emmerling <xaver@MacBook-Pro-von-Xaver.local>
AuthorDate: Wed Sep 16 11:28:35 2026 -0700
Commit:     Xaver Emmerling <xaver@MacBook-Pro-von-Xaver.local>
CommitDate: Wed Sep 16 11:28:35 2026 -0700

    Fix toolbar popup pointer state and exported accessibility bounds
---
 ui/src/widget/toolbar.rs | 275 +++++++++++++++++++++++++++++++++++++++++++----
 1 file changed, 254 insertions(+), 21 deletions(-)

diff --git a/ui/src/widget/toolbar.rs b/ui/src/widget/toolbar.rs
index 51f2e8064..a757ebd8e 100644
--- a/ui/src/widget/toolbar.rs
+++ b/ui/src/widget/toolbar.rs
@@ -51,6 +51,7 @@ pub struct Toolbar {
     separator: f32,
     overflow_rect: Rect,
     hovered: Option<Target>,
+    pointer: Option<Point>,
     pressed: Option<Target>,
     focused: bool,
     focus: Option<Target>,
@@ -77,6 +78,7 @@ impl Toolbar {
             separator: 9.0,
             overflow_rect: Rect::ZERO,
             hovered: None,
+            pointer: None,
             pressed: None,
             focused: false,
             focus: None,
@@ -303,7 +305,7 @@ impl Toolbar {
         if self.focus.is_some_and(|target| !targets.contains(&target)) {
             self.focus = targets.last().copied();
         }
-        self.hovered = self.hovered.filter(|target| targets.contains(target));
+        self.refresh_hover();
         self.pressed = self.pressed.filter(|target| targets.contains(target));
     }
 
@@ -366,6 +368,8 @@ impl Toolbar {
         self.menu
             .open_anchored(self.overflow_rect, self.viewport.unwrap_or(self.rect));
         self.focus = Some(Target::Overflow);
+        self.hovered = None;
+        self.pressed = None;
         if keyboard {
             self.menu.focus_first_action();
         }
@@ -385,8 +389,29 @@ impl Toolbar {
         }
         if !self.menu.is_open() {
             self.focus = Some(Target::Overflow);
+            self.pressed = None;
+            self.refresh_hover();
         }
     }
+
+    /// Popup routing still updates `pointer`, so closing or relayout cannot
+    /// arm a command using a hover target from before the popup opened.
+    fn refresh_hover(&mut self) -> bool {
+        let hovered = if self.menu.is_open() {
+            None
+        } else {
+            self.pointer.and_then(|point| {
+                self.targets().into_iter().find(|target| {
+                    self.target_rect(*target)
+                        .is_some_and(|rect| rect.contains(point))
+                })
+            })
+        };
+        let changed = hovered != self.hovered;
+        self.hovered = hovered;
+        changed
+    }
+
     fn targets(&self) -> Vec<Target> {
         let mut targets: Vec<_> = self
             .items
@@ -671,6 +696,9 @@ impl Widget for Toolbar {
         node: NodeId,
         tree: &TaffyTree<()>,
     ) {
+        if let WindowEvent::CursorMoved { position, .. } = event {
+            self.pointer = Some(Point::new(position.x / scale, position.y / scale));
+        }
         if self.menu.is_open() {
             self.menu.handle_event(
                 event,
@@ -687,6 +715,7 @@ impl Widget for Toolbar {
                 event,
                 WindowEvent::MouseInput {
                     state: ElementState::Pressed,
+                    button: MouseButton::Left,
                     ..
                 }
             ) {
@@ -696,22 +725,15 @@ impl Widget for Toolbar {
             return;
         }
         match event {
-            WindowEvent::CursorMoved { position, .. } => {
-                let point = Point::new(position.x / scale, position.y / scale);
-                let hovered = self.targets().into_iter().find(|target| {
-                    self.target_rect(*target)
-                        .is_some_and(|rect| rect.contains(point))
-                });
-                if hovered != self.hovered {
-                    self.hovered = hovered;
-                    *handled = true;
-                }
+            WindowEvent::CursorMoved { .. } => {
+                *handled |= self.refresh_hover();
             }
             WindowEvent::MouseInput {
                 state: ElementState::Pressed,
                 button: MouseButton::Left,
                 ..
             } => {
+                self.refresh_hover();
                 self.pressed = self.hovered;
                 if let Some(target) = self.pressed {
                     self.focus_target(target);
@@ -724,6 +746,7 @@ impl Widget for Toolbar {
                 button: MouseButton::Left,
                 ..
             } => {
+                self.refresh_hover();
                 if self.swallow_release {
                     self.swallow_release = false;
                     self.pressed = None;
@@ -790,6 +813,7 @@ impl Widget for Toolbar {
         if !focused {
             self.menu.close();
             self.pressed = None;
+            self.refresh_hover();
         }
     }
     fn is_focused(&self) -> bool {
@@ -833,6 +857,7 @@ impl Widget for Toolbar {
                 AccessNode::new(Role::Button)
                     .with_name(name)
                     .with_action_target(route)
+                    .with_bounds(self.target_rect(*target).unwrap_or(Rect::ZERO))
                     .with_state(AccessState {
                         focusable: true,
                         focused: self.focused
@@ -857,6 +882,9 @@ impl Widget for Toolbar {
                         AccessNode::new(Role::MenuItem)
                             .with_name(label.clone())
                             .with_action_target(format!("toolbar.item.{index}"))
+                            // Keep scrolled-out actions focusable so semantic focus
+                            // can reveal them, but export no fabricated painted area.
+                            .with_bounds(self.menu.item_rect(row).unwrap_or(Rect::ZERO))
                             .with_state(AccessState {
                                 focusable: true,
                                 focused: self.focused && self.menu.hovered() == Some(row),
@@ -865,7 +893,11 @@ impl Widget for Toolbar {
                     )
                 })
                 .collect();
-            children.push(AccessNode::new(Role::Menu).with_children(rows));
+            children.push(
+                AccessNode::new(Role::Menu)
+                    .with_bounds(self.menu.get_rect())
+                    .with_children(rows),
+            );
         }
         Some(
             AccessNode::new(Role::Toolbar)
@@ -1331,7 +1363,7 @@ mod lifecycle_tests {
             },
         )
     }
-    fn key(tb: &mut Toolbar, key: NamedKey) -> bool {
+    fn key_event(key: NamedKey) -> WindowEvent {
         let mut event: KeyEvent = unsafe { std::mem::zeroed() };
         event.logical_key = Key::Named(key);
         event.physical_key = winit::keyboard::PhysicalKey::Unidentified(
@@ -1340,14 +1372,14 @@ mod lifecycle_tests {
         event.location = winit::keyboard::KeyLocation::Standard;
         event.state = ElementState::Pressed;
         event.text = None;
-        dispatch(
-            tb,
-            WindowEvent::KeyboardInput {
-                device_id: unsafe { std::mem::zeroed() },
-                event,
-                is_synthetic: true,
-            },
-        )
+        WindowEvent::KeyboardInput {
+            device_id: unsafe { std::mem::zeroed() },
+            event,
+            is_synthetic: true,
+        }
+    }
+    fn key(tb: &mut Toolbar, key: NamedKey) -> bool {
+        dispatch(tb, key_event(key))
     }
     fn counted(n: usize) -> (Toolbar, Rc<RefCell<Vec<usize>>>) {
         let counts = Rc::new(RefCell::new(vec![0; n]));
@@ -1655,4 +1687,205 @@ mod lifecycle_tests {
             );
         }
     }
+    #[test]
+    fn review_emitted_accessibility_bounds_match_paint_and_scrolling() {
+        let (mut tb, _) = counted(12);
+        settle(&mut tb, 180.0, 45.0, 1.0);
+        let node = tb.accessibility().unwrap();
+        for (child, target) in node.children.iter().zip(tb.targets()) {
+            assert_eq!(
+                child.bounds.map(|bounds| bounds.to_rect()),
+                tb.target_rect(target)
+            );
+        }
+        tb.open_menu(true);
+        let menu_child = tb.targets().len();
+        let first_height = tb.menu.item_rect(0).unwrap().height();
+        tb.menu.focus_item(tb.menu_indices.len() - 1);
+        let node = tb.accessibility().unwrap();
+        let menu = &node.children[menu_child];
+        assert_eq!(menu.bounds.unwrap().to_rect(), tb.menu.get_rect());
+        let mut clipped = false;
+        for (child, row) in menu.children.iter().zip(
+            tb.menu_indices
+                .iter()
+                .enumerate()
+                .filter_map(|(row, index)| index.map(|_| row)),
+        ) {
+            let expected = tb.menu.item_rect(row).unwrap_or(Rect::ZERO);
+            assert_eq!(child.bounds.unwrap().to_rect(), expected);
+            clipped |= expected.height() > 0.0 && expected.height() < first_height;
+        }
+        assert!(clipped);
+        assert_eq!(menu.children[0].bounds.unwrap().to_rect(), Rect::ZERO);
+        assert!(
+            !menu.children[0].state.hidden,
+            "offscreen commands retain semantic focus access"
+        );
+        assert!(tb.focus_synthetic_accessibility(&[menu_child, 0]));
+        assert!(
+            !tb.accessibility().unwrap().children[menu_child].children[0]
+                .bounds
+                .unwrap()
+                .to_rect()
+                .is_zero_area()
+        );
+    }
+
+    #[test]
+    fn review_popup_close_rehits_pointer_before_second_click() {
+        for pointer_open in [false, true] {
+            for relayout in [false, true] {
+                let (mut tb, counts) = counted(8);
+                settle(&mut tb, 180.0, 45.0, 1.0);
+                let point = if pointer_open {
+                    tb.overflow_rect.center()
+                } else {
+                    tb.item_rects[0].center()
+                };
+                cursor(&mut tb, point);
+                if pointer_open {
+                    mouse(&mut tb, ElementState::Pressed);
+                    mouse(&mut tb, ElementState::Released);
+                } else {
+                    tb.set_focus(true);
+                    while tb.focus != Some(Target::Overflow) {
+                        key(&mut tb, NamedKey::ArrowRight);
+                    }
+                    key(&mut tb, NamedKey::Space);
+                }
+                let hidden = tb.menu_indices[0].unwrap();
+                let point = tb.menu.item_rect(0).unwrap().center();
+                assert!(!tb.rect.contains(point));
+                cursor(&mut tb, point);
+                mouse(&mut tb, ElementState::Pressed);
+                mouse(&mut tb, ElementState::Released);
+                if relayout {
+                    settle(&mut tb, 180.0, 45.0, 1.0);
+                }
+                mouse(&mut tb, ElementState::Pressed);
+                mouse(&mut tb, ElementState::Released);
+                let mut expected = vec![0; 8];
+                expected[hidden] = 1;
+                assert_eq!(
+                    *counts.borrow(),
+                    expected,
+                    "pointer_open={pointer_open}, relayout={relayout}"
+                );
+                assert!(
+                    !tb.menu.is_open(),
+                    "stale overflow hover must not reopen the menu"
+                );
+            }
+        }
+    }
+
+    #[test]
+    fn review_nonleft_popup_press_does_not_capture_next_sibling_click() {
+        for button in [MouseButton::Right, MouseButton::Middle] {
+            let (toolbar, _) = counted(8);
+            let (sibling, count) = counted(1);
+            let mut host = crate::widget::Row::new()
+                .no_wrap()
+                .push(Box::new(toolbar))
+                .push(Box::new(sibling));
+            let mut tree = TaffyTree::new();
+            let mut nodes = HashMap::new();
+            let theme = Theme::dark();
+            let node = host.build_layout(&mut tree, &theme, &mut nodes);
+            let children = tree.children(node).unwrap();
+            for (child, width) in children.iter().zip([180.0, 150.0]) {
+                let mut style = tree.style(*child).unwrap().clone();
+                style.size = Size {
+                    width: Dimension::length(width),
+                    height: Dimension::length(45.0),
+                };
+                tree.set_style(*child, style).unwrap();
+            }
+            let mut text = TextRenderer::new();
+            let mut bindings = crate::bound_dispatch::BoundNodeMap::default();
+            unsafe {
+                bindings.rebuild(&host, &tree, node, &nodes);
+                crate::widget::compute_widget_layout(
+                    &mut tree,
+                    node,
+                    Size {
+                        width: taffy::AvailableSpace::Definite(360.0),
+                        height: taffy::AvailableSpace::Definite(220.0),
+                    },
+                    &nodes,
+                    &bindings,
+                    &mut text,
+                )
+                .unwrap();
+            }
+            host.apply_layout(&tree, node, Point::ZERO);
+            let presence = PresenceCtx::default();
+            presence
+                .viewport
+                .set(Some(Rect::new(0.0, 0.0, 360.0, 220.0)));
+            host.draw(
+                &mut Scene::new(),
+                Affine::IDENTITY,
+                &mut text,
+                &theme,
+                &presence,
+            );
+            assert!(host.children_mut()[0].perform_semantic_action(
+                "toolbar.overflow",
+                &Action::Activate,
+                &mut AutoCommit::new(),
+                &automerge::ROOT
+            ));
+            let send = |host: &mut crate::widget::Row, event: WindowEvent| {
+                host.handle_event(
+                    &event,
+                    1.0,
+                    &Default::default(),
+                    &mut AutoCommit::new(),
+                    &automerge::ROOT,
+                    &mut false,
+                    &mut None,
+                    node,
+                    &tree,
+                );
+            };
+            let mouse_event = |button, state| WindowEvent::MouseInput {
+                device_id: unsafe { std::mem::zeroed() },
+                button,
+                state,
+            };
+            send(&mut host, mouse_event(button, ElementState::Pressed));
+            send(&mut host, mouse_event(button, ElementState::Released));
+            send(&mut host, key_event(NamedKey::Escape));
+            assert!(
+                !host.wants_pointer_capture(),
+                "{button:?} must not leave capture stuck"
+            );
+            let point = host.children()[1]
+                .synthetic_accessibility_rect(&[0])
+                .unwrap()
+                .center();
+            send(
+                &mut host,
+                WindowEvent::CursorMoved {
+                    device_id: unsafe { std::mem::zeroed() },
+                    position: winit::dpi::PhysicalPosition::new(point.x, point.y),
+                },
+            );
+            send(
+                &mut host,
+                mouse_event(MouseButton::Left, ElementState::Pressed),
+            );
+            send(
+                &mut host,
+                mouse_event(MouseButton::Left, ElementState::Released),
+            );
+            assert_eq!(
+                *count.borrow(),
+                vec![1],
+                "next sibling click must arrive through Row"
+            );
+        }
+    }
 }

```

## fd7b0964f
```diff
commit fd7b0964f4a6a508b69c66e33fd5817837631e46
Author:     Xaver Emmerling <xaver@MacBook-Pro-von-Xaver.local>
AuthorDate: Wed Sep 16 11:55:22 2026 -0700
Commit:     Xaver Emmerling <xaver@MacBook-Pro-von-Xaver.local>
CommitDate: Wed Sep 16 11:55:22 2026 -0700

    fix(ui): preserve attributed trailing empty line
---
 ui/src/richtext.rs          | 130 +++++++++++++++++++++++++++++++++++++++++++-
 ui/src/widget/text_input.rs |  80 +++++++++++++++++++++++++++
 2 files changed, 208 insertions(+), 2 deletions(-)

diff --git a/ui/src/richtext.rs b/ui/src/richtext.rs
index f8e277391..793cbc29e 100644
--- a/ui/src/richtext.rs
+++ b/ui/src/richtext.rs
@@ -5,8 +5,8 @@
 //! [`crate::text_render::TextRenderer::draw_rich`].
 
 use cosmic_text::{
-    Affinity, Align, Attrs, Buffer, Cursor, Family, FontSystem, Metrics, Shaping, Style, Weight,
-    Wrap,
+    Affinity, Align, Attrs, AttrsList, Buffer, BufferLine, Cursor, Family, FontSystem, LineEnding,
+    Metrics, Shaping, Style, Weight, Wrap,
 };
 
 use crate::text_break::OffsetMap;
@@ -355,6 +355,22 @@ impl RichTextLayout {
             Shaping::Advanced,
             align.to_cosmic(),
         );
+        // cosmic-text 0.19's rich setter omits the final empty paragraph after
+        // an LF, unlike its plain setter. Restore that line at this boundary so
+        // attributed and plain layouts expose the same bytes and geometry.
+        if full_text.ends_with('\n') {
+            let terminal_attrs = built
+                .last()
+                .map_or_else(|| base.clone(), |(_, attrs)| attrs.clone());
+            let mut terminal_line = BufferLine::new(
+                "",
+                LineEnding::None,
+                AttrsList::new(&terminal_attrs),
+                Shaping::Advanced,
+            );
+            terminal_line.set_align(align.to_cosmic());
+            buffer.lines.push(terminal_line);
+        }
         let reserved_hyphen_width = if align == TextAlign::Left {
             discretionary_hyphen_width
         } else {
@@ -820,6 +836,13 @@ impl RichTextLayout {
 mod tests {
     use super::*;
 
+    fn assert_near(actual: f32, expected: f32, message: &str) {
+        assert!(
+            (actual - expected).abs() < 0.01,
+            "{message}: expected {expected}, got {actual}"
+        );
+    }
+
     fn layout(text: &str, width: f32) -> RichTextLayout {
         let mut fs = crate::font_catalog::fixture_font_system();
         RichTextLayout::shape(
@@ -862,6 +885,109 @@ mod tests {
         assert!(rects[0].2 > rects[0].0);
     }
 
+    #[test]
+    fn attributed_terminal_lf_preserves_the_plain_layout_final_row() {
+        use crate::text_render::TextStyle;
+
+        for scale in [1.0, 2.0] {
+            let style = TextStyle::new(16.0 * scale).with_line_height(1.25);
+            let fixtures = [
+                ("x", vec![RichSpan::new("x")], 1usize),
+                ("x\ny", vec![RichSpan::new("x\ny")], 2),
+                ("x\n", vec![RichSpan::new("x\n")], 2),
+                ("\n", vec![RichSpan::new("\n")], 2),
+                ("x\n\n", vec![RichSpan::new("x\n\n")], 3),
+                (
+                    "x\n",
+                    vec![
+                        RichSpan::new("x").bold(true),
+                        RichSpan::new("\n").italic(true),
+                    ],
+                    2,
+                ),
+            ];
+
+            for (text, spans, expected_rows) in fixtures {
+                let mut fs = crate::font_catalog::fixture_font_system();
+                let plain = RichTextLayout::shape_plain(&mut fs, text, &style, Some(300.0));
+                let styled = RichTextLayout::shape_styled(
+                    &mut fs,
+                    &spans,
+                    &style,
+                    Some(300.0),
+                    TextAlign::Left,
+                    vec![],
+                    vec![],
+                );
+
+                assert_near(
+                    styled.height(),
+                    plain.height(),
+                    &format!("{text:?} styled and plain heights at {scale}x"),
+                );
+                let plain_eof = plain.caret_geometry(text.len());
+                let styled_eof = styled.caret_geometry(text.len());
+                assert_near(
+                    styled_eof.1,
+                    plain_eof.1,
+                    &format!("{text:?} EOF caret top at {scale}x"),
+                );
+                assert_near(
+                    styled_eof.2,
+                    plain_eof.2,
+                    &format!("{text:?} EOF caret height at {scale}x"),
+                );
+                assert_eq!(
+                    styled.visual_line_index(text.len()),
+                    expected_rows - 1,
+                    "{text:?} EOF visual row at {scale}x"
+                );
+                assert_eq!(
+                    styled.logical_line_bands(text.len()).len(),
+                    1,
+                    "{text:?} EOF logical line has one shaped band at {scale}x"
+                );
+                assert_eq!(
+                    styled.hit(0.0, styled.height() + style.line_height_px()),
+                    text.len(),
+                    "{text:?} hit below content resolves to EOF at {scale}x"
+                );
+            }
+        }
+    }
+
+    #[test]
+    fn terminal_empty_row_inherits_the_final_run_metrics_and_alignment() {
+        use crate::text_render::TextStyle;
+
+        let style = TextStyle::new(16.0).with_line_height(1.25);
+        let mut final_run = RichSpan::new("\n").bold(true).italic(true);
+        final_run.size = Some(24.0);
+        let mut fs = crate::font_catalog::fixture_font_system();
+        let layout = RichTextLayout::shape_styled(
+            &mut fs,
+            &[RichSpan::new("x"), final_run],
+            &style,
+            Some(300.0),
+            TextAlign::Center,
+            vec![],
+            vec![],
+        );
+
+        let final_line = layout.buffer.lines.last().expect("terminal empty line");
+        let attrs = final_line.attrs_list().defaults();
+        assert_eq!(final_line.text(), "");
+        assert_eq!(final_line.ending(), cosmic_text::LineEnding::None);
+        assert_eq!(final_line.align(), Some(Align::Center));
+        assert_eq!(attrs.weight, Weight::BOLD);
+        assert_eq!(attrs.style, Style::Italic);
+        assert_eq!(
+            attrs.metrics_opt,
+            Some(Metrics::new(24.0, 30.0).into()),
+            "the final empty row keeps the last effective run's metrics"
+        );
+    }
+
     #[test]
     fn rtl_caret_geometry_follows_visual_direction() {
         let text = "שלום";
diff --git a/ui/src/widget/text_input.rs b/ui/src/widget/text_input.rs
index 6139dad74..172d79260 100644
--- a/ui/src/widget/text_input.rs
+++ b/ui/src/widget/text_input.rs
@@ -6921,6 +6921,86 @@ mod tests {
         );
     }
 
+    #[test]
+    fn multiline_trailing_lf_keeps_measure_draw_hit_and_caret_scroll_in_sync() {
+        let text = "let value = 1;\n";
+        for scale in [1.0, 2.0] {
+            let theme = Theme::dark().with_text_scale(scale);
+            let mut input = TextInput::local()
+                .multiline(true)
+                .with_mono()
+                .with_gutter(true)
+                .with_current_line_highlight(true)
+                .with_initial_value(text);
+            input.set_highlighter(crate::widget::code_editor::Language::Rust.highlighter());
+            input.set_focus(true);
+            input.set_cursor_pos(text.len());
+
+            let mut renderer = TextRenderer::new();
+            renderer.set_text_scale(theme.text_scale);
+            let measured = Widget::measure(
+                &mut input,
+                taffy::Size {
+                    width: Some(240.0),
+                    height: None,
+                },
+                taffy::Size {
+                    width: taffy::AvailableSpace::Definite(240.0),
+                    height: taffy::AvailableSpace::MaxContent,
+                },
+                &mut renderer,
+            );
+            let viewport_height =
+                f64::from(input.multiline_style(scale).line_height_px()) + ML_PAD_Y * 2.0;
+            input.apply_layout_external(Rect::new(0.0, 0.0, 240.0, viewport_height));
+            draw_with_theme(&mut input, &theme);
+
+            let drawn_height = input.content_height() as f32;
+            assert!(
+                measured.height >= drawn_height && measured.height - drawn_height < 1.0,
+                "pixel-ceiled measure {measured:?} agrees with attributed draw height {drawn_height} at {scale}x"
+            );
+            let layout = input
+                .single_layout
+                .as_ref()
+                .expect("draw retained attributed multiline layout");
+            let (_, eof_top, eof_height) =
+                layout.caret_geometry(input.text_to_layout_byte(text.len()));
+            assert_eq!(
+                layout.visual_line_index(text.len()).saturating_add(1),
+                layout.buffer.layout_runs().count(),
+                "EOF stays on the final visual row even when large text wraps"
+            );
+            assert_eq!(layout.logical_line_origins().len(), 2);
+            assert!(
+                (eof_top + eof_height - layout.height()).abs() < 0.01,
+                "EOF caret reaches the bottom of the final row"
+            );
+
+            let caret = input.caret_rect(&theme, text.len());
+            assert_eq!(
+                input.byte_at_point(Point::new(caret.x0 + 1.0, caret.center().y)),
+                text.len(),
+                "clicking the final empty row returns EOF"
+            );
+            let view_height = input.rect.height() - ML_PAD_Y * 2.0;
+            let expected_scroll = (f64::from(layout.height()) - view_height).max(0.0);
+            assert!(expected_scroll > 0.0);
+            assert!(
+                (input.scroll_y() - expected_scroll).abs() < 0.01,
+                "caret-follow scroll remains at the EOF row"
+            );
+            assert!(input.gutter_width() > 0.0);
+            assert!(
+                input
+                    .code_row_colors(&theme)
+                    .iter()
+                    .any(|(_, color)| *color != theme.text_primary),
+                "syntax attribution survives terminal-row normalization"
+            );
+        }
+    }
+
     #[test]
     fn multiline_measure_uses_build_layout_theme_scale_when_renderer_is_stale() {
         let text = "The layout theme owns accessibility scale even when a retained renderer still carries its previous frame value.";

```

## 73dde03c6
```diff
commit 73dde03c6fade2ed5fbc418bcb912271f9020b7e
Author:     Xaver Emmerling <xaver@MacBook-Pro-von-Xaver.local>
AuthorDate: Wed Sep 16 13:13:58 2026 -0700
Commit:     Xaver Emmerling <xaver@MacBook-Pro-von-Xaver.local>
CommitDate: Wed Sep 16 13:13:58 2026 -0700

    fix(ui): shape rich inline marks once for paint and interaction
---
 ui/src/widget/block_editor.rs   |  90 +++++++-
 ui/src/widget/rich_text_line.rs | 410 +++++++++++++---------------------
 ui/src/widget/text_input.rs     | 480 ++++++++++++++++++++++++++++++++++++++--
 3 files changed, 701 insertions(+), 279 deletions(-)

diff --git a/ui/src/widget/block_editor.rs b/ui/src/widget/block_editor.rs
index b41855bc5..c0a0ff487 100644
--- a/ui/src/widget/block_editor.rs
+++ b/ui/src/widget/block_editor.rs
@@ -1565,12 +1565,15 @@ impl BlockEditor {
                 let Mark::Link(id) = &span.mark else {
                     continue;
                 };
-                let x0 = line.pixel_x_for_byte(theme, span.range.start);
-                let x1 = line.pixel_x_for_byte(theme, span.range.end);
-                if x1 > x0 {
-                    let rect = line.get_rect();
-                    self.live_link_hits
-                        .push((Rect::new(x0, rect.y0, x1, rect.y1), *id));
+                for band in line
+                    .inner()
+                    .selection_rects(theme, span.range.start, span.range.end)
+                {
+                    if band.width() > 0.0 {
+                        let rect = line.get_rect();
+                        self.live_link_hits
+                            .push((Rect::new(band.x0, rect.y0, band.x1, rect.y1), *id));
+                    }
                 }
             }
         }
@@ -3835,7 +3838,6 @@ impl Widget for BlockEditor {
         presence: &PresenceCtx,
     ) {
         let tokens = &theme.tokens;
-        self.refresh_live_link_hits(theme);
 
         // Painted BEFORE block content so the live caret stays on top.
         if self.blocks.len() == 1
@@ -3930,6 +3932,8 @@ impl Widget for BlockEditor {
         for (i, b) in self.blocks.iter().enumerate() {
             self.draw_block_presence(i, b, &mut ctx);
         }
+        // Link routing must use the same freshly shaped advances as paint.
+        self.refresh_live_link_hits(theme);
     }
 
     fn handle_event(
@@ -5622,6 +5626,78 @@ mod tests {
         );
     }
 
+    #[test]
+    fn rich_link_hits_follow_current_draw_on_first_frame_style_and_scale_changes() {
+        let target = PageId::from_u128(42);
+        let mut block = Block::paragraph("WWW end");
+        block
+            .line
+            .set_marks(vec![MarkSpan::new(0..3, Mark::Link(target))]);
+        let mut editor = BlockEditor::new();
+        editor.set_blocks(vec![block]);
+        for (scale, bold) in [(1.0, false), (1.0, true), (2.0, true), (1.0, false)] {
+            let mut marks = vec![MarkSpan::new(0..3, Mark::Link(target))];
+            if bold {
+                marks.push(MarkSpan::new(0..3, Mark::Bold));
+            }
+            editor.blocks[0].line.set_marks(marks);
+            let theme = Theme::dark().with_text_scale(scale);
+            layout_and_draw_editor(&mut editor, &theme);
+            let line = &editor.blocks[0].line;
+            let right = line.pixel_x_for_byte(&theme, 3);
+            let y = line.get_rect().center().y;
+            assert_eq!(
+                editor.link_at_point(Point::new(right - 0.1, y)),
+                Some(target),
+                "the final painted sliver must link on this frame at {scale}x, bold={bold}"
+            );
+            assert_eq!(editor.link_at_point(Point::new(right + 0.1, y)), None);
+        }
+    }
+
+    #[test]
+    fn rich_link_hits_cover_the_shaped_rtl_range() {
+        let target = PageId::from_u128(43);
+        let mut block = Block::paragraph("אבג rest");
+        block.line.set_marks(vec![
+            MarkSpan::new(0..6, Mark::Link(target)),
+            MarkSpan::new(0..6, Mark::Bold),
+        ]);
+        let mut editor = BlockEditor::new();
+        editor.set_blocks(vec![block]);
+        let theme = Theme::dark();
+        layout_and_draw_editor(&mut editor, &theme);
+        let band = editor.blocks[0].line.selection_rect(&theme, 0, 6);
+        assert_eq!(editor.link_at_point(band.center()), Some(target));
+    }
+
+    #[test]
+    fn rich_link_hits_exclude_the_gap_between_mixed_direction_segments() {
+        let target = PageId::from_u128(44);
+        let mut block = Block::paragraph("ab אבג cd");
+        block.line.set_marks(vec![
+            MarkSpan::new(0..2, Mark::Link(target)),
+            MarkSpan::new(10..12, Mark::Link(target)),
+            MarkSpan::new(0..12, Mark::Bold),
+        ]);
+        let mut editor = BlockEditor::new();
+        editor.set_blocks(vec![block]);
+        let theme = Theme::dark();
+        layout_and_draw_editor(&mut editor, &theme);
+        let line = &editor.blocks[0].line;
+        let first = line.selection_rect(&theme, 0, 2);
+        let last = line.selection_rect(&theme, 10, 12);
+        assert_eq!(editor.link_at_point(first.center()), Some(target));
+        assert_eq!(editor.link_at_point(last.center()), Some(target));
+        let gap = line.selection_rect(&theme, 3, 9);
+        assert!(gap.x0 >= first.x1 && gap.x1 <= last.x0);
+        assert_eq!(
+            editor.link_at_point(gap.center()),
+            None,
+            "unmarked Hebrew remains outside the link"
+        );
+    }
+
     #[test]
     fn heading_paragraph_inline_code_and_numbered_prefix_scale_once() {
         let heading = Block::heading(1, "Heading");
diff --git a/ui/src/widget/rich_text_line.rs b/ui/src/widget/rich_text_line.rs
index 027402787..4f5ebc898 100644
--- a/ui/src/widget/rich_text_line.rs
+++ b/ui/src/widget/rich_text_line.rs
@@ -12,11 +12,13 @@
 
 use std::collections::HashMap;
 
+use crate::color_compat::ColorCompat;
+use crate::richtext::RichSpan;
+use crate::widget::text_input::SingleLineAttributes;
 use automerge::{AutoCommit, ObjId, ReadDoc, ScalarValue};
 use taffy::{Dimension, NodeId, Size, Style, TaffyTree};
 use vello::Scene;
 use vello::kurbo::{Affine, Point, Rect};
-use vello::peniko::BlendMode;
 use winit::event::{ElementState, KeyEvent, Modifiers, WindowEvent};
 use winit::keyboard::{Key, NamedKey};
 
@@ -66,19 +68,6 @@ pub enum LineSignal {
 /// Matches the body baseline the rest of the UI uses for `TextInput`.
 const DEFAULT_FONT_SIZE: f32 = 16.0;
 
-/// Geometry shared by every mark segment `draw` paints in one frame, so
-/// `paint_mark_segment` doesn't need a fistful of separate parameters.
-struct MarkDrawCtx<'a> {
-    text: &'a str,
-    xs: &'a [f64],
-    rect: Rect,
-    pad: f64,
-    scroll_x: f64,
-    text_y: f64,
-    line_height: f64,
-    text_size: f32,
-}
-
 pub struct RichTextLine {
     inner: TextInput,
     /// At most one signal in flight per frame; new signals overwrite the slot.
@@ -86,6 +75,7 @@ pub struct RichTextLine {
     font_size: f32,
     /// Kept sorted by `range.start`.
     marks: Vec<MarkSpan>,
+    accent_rgb: Option<[u8; 3]>,
     /// Drained once `handle_event` observes a text-input edit.
     pending_marks: Vec<Mark>,
     /// Snapshot used to detect splice direction + length so `marks` stays
@@ -110,6 +100,7 @@ impl RichTextLine {
             signal: None,
             font_size: DEFAULT_FONT_SIZE,
             marks: Vec::new(),
+            accent_rgb: None,
             pending_marks: Vec::new(),
             prev_text: String::new(),
             prev_cursor: 0,
@@ -160,6 +151,7 @@ impl RichTextLine {
     ) -> Result<(), crate::view::ThawError> {
         self.inner.adopt_bound_text(state)?;
         self.align_bound_projection(state);
+        self.refresh_attributes();
         Ok(())
     }
 
@@ -216,6 +208,7 @@ impl RichTextLine {
         self.pending_marks.clear();
         self.prev_text = s.to_string();
         self.prev_cursor = s.len();
+        self.refresh_attributes();
     }
 
     pub fn take_dirty(&mut self) -> Option<String> {
@@ -276,11 +269,13 @@ impl RichTextLine {
     pub fn set_marks(&mut self, marks: Vec<MarkSpan>) {
         self.marks = marks;
         self.marks.sort_by_key(|s| s.range.start);
+        self.refresh_attributes();
     }
 
     pub fn add_mark(&mut self, span: MarkSpan) {
         self.marks.push(span);
         self.marks.sort_by_key(|s| s.range.start);
+        self.refresh_attributes();
     }
 
     pub fn pending_marks(&self) -> &[Mark] {
@@ -292,6 +287,7 @@ impl RichTextLine {
     pub fn toggle_mark(&mut self, mark: Mark) {
         if let Some((s, e)) = self.inner.selection_range_public() {
             marks::toggle_mark_range(&mut self.marks, s..e, mark);
+            self.refresh_attributes();
         } else {
             // Pushing the same mark twice cancels it (Notion-style).
             if let Some(idx) = self.pending_marks.iter().position(|m| m.same_kind(&mark)) {
@@ -323,24 +319,10 @@ impl RichTextLine {
         self.inner.selection_rect(theme, start, end)
     }
 
-    /// Inverse of [`pixel_x_for_byte`]; for the click-on-link hit-test.
-    pub fn byte_for_pixel_x(&self, theme: &Theme, x: f64) -> usize {
-        let xs = self.inner.char_x_positions();
-        if xs.is_empty() {
-            return 0;
-        }
-        let pad = self.inner.text_padding_x(theme);
-        let relative = x - self.inner.get_rect().x0 - pad + self.inner.scroll_x();
-        let mut best = 0usize;
-        let mut best_d = f64::MAX;
-        for (i, px) in xs.iter().enumerate() {
-            let d = (relative - *px).abs();
-            if d < best_d {
-                best_d = d;
-                best = i;
-            }
-        }
-        best
+    /// Inverse of [`pixel_x_for_byte`], using the shaped caret stops.
+    pub fn byte_for_pixel_x(&self, _theme: &Theme, x: f64) -> usize {
+        self.inner
+            .byte_at_point(Point::new(x, self.inner.get_rect().center().y))
     }
 
     /// Prefers [`Mark::Link`] over other kinds so link hit-tests still
@@ -372,6 +354,58 @@ impl RichTextLine {
         &self.inner
     }
 
+    fn refresh_attributes(&mut self) {
+        let text = self.inner.value();
+        // Ignore malformed mark endpoints while still retaining every UTF-8
+        // byte in the complete run list.
+        let marks: Vec<_> = self
+            .marks
+            .iter()
+            .filter(|mark| {
+                mark.range.start < mark.range.end
+                    && mark.range.end <= text.len()
+                    && text.is_char_boundary(mark.range.start)
+                    && text.is_char_boundary(mark.range.end)
+            })
+            .cloned()
+            .collect();
+        let mut attributes = SingleLineAttributes::default();
+        for segment in marks::segments_for(text.len(), &marks) {
+            let range = (segment.range.start, segment.range.end);
+            let Some(slice) = text.get(segment.range.clone()) else {
+                continue;
+            };
+            let span = RichSpan::new(slice)
+                .bold(segment.bold)
+                .italic(segment.italic)
+                .color(if segment.code || segment.link.is_some() {
+                    self.accent_rgb
+                } else {
+                    None
+                });
+            attributes.spans.push(span);
+            if segment.underline {
+                attributes.underlines.push(range);
+            }
+            if segment.strikethrough {
+                attributes.strikes.push(range);
+            }
+            if segment.code {
+                attributes.chips.push(range);
+            }
+            if segment.link.is_some() && !segment.underline {
+                attributes.links.push(range);
+            }
+        }
+        self.inner.set_single_line_attributes(attributes);
+    }
+
+    fn prepare_attributes(&mut self, theme: &Theme) {
+        let color = theme.tokens.colors.accent[5];
+        self.accent_rgb = Some([color.r(), color.g(), color.b()]);
+        self.refresh_attributes();
+    }
+
     /// Ctrl/Super + b/i/e/u toggles the corresponding mark. Returns `true`
     /// when `c` matched one of the shortcuts (case-insensitively).
     fn handle_mark_shortcut(&mut self, c: &str) -> bool {
@@ -426,6 +460,7 @@ impl Widget for RichTextLine {
         // from being misread as a local splice on the next keystroke.
         self.inner.sync(state, path);
         self.align_bound_projection(state);
+        self.refresh_attributes();
     }
 
     fn build_layout(
@@ -437,6 +472,8 @@ impl Widget for RichTextLine {
         // Font overrides remain base values. TextInput's shaped layout applies
         // the theme scale exactly once; the row height is resolved here because
         // this wrapper owns the surrounding document geometry.
+        self.prepare_attributes(theme);
+        self.inner.capture_layout_text_scale(theme.text_scale);
         let scale = theme.text_scale;
         self.inner.set_font_size(self.font_size);
         // font_size * 1.5 so headings end up taller than paragraph rows without a measure pass.
@@ -452,6 +489,20 @@ impl Widget for RichTextLine {
         node
     }
 
+    fn measure(
+        &mut self,
+        known: Size<Option<f32>>,
+        available: Size<taffy::AvailableSpace>,
+        text_renderer: &mut TextRenderer,
+    ) -> Size<f32> {
+        self.refresh_attributes();
+        self.inner.measure(known, available, text_renderer)
+    }
+
+    fn layout_needs_measure(&self) -> bool {
+        self.inner.layout_needs_measure()
+    }
+
     fn apply_layout(&mut self, taffy: &TaffyTree<()>, node: NodeId, origin: Point) {
         let layout = taffy.layout(node).copied().unwrap_or_default();
         let rect = Rect::new(
@@ -471,62 +522,9 @@ impl Widget for RichTextLine {
         theme: &Theme,
         presence: &PresenceCtx,
     ) {
-        // The inner TextInput draws the plain text first; mark-styled
-        // segments are then overpainted on top only where styling differs.
+        self.prepare_attributes(theme);
         self.inner
             .draw(scene, transform, text_renderer, theme, presence);
-
-        if self.marks.is_empty() {
-            return;
-        }
-
-        let text = self.inner.value().to_string();
-        let segments = marks::segments_for(text.len(), &self.marks);
-        if segments.is_empty() {
-            return;
-        }
-
-        // Styled runs are painted through `TextRenderer` and therefore take
-        // its global accessibility scale themselves. Their geometry still
-        // needs the physical line height used by the scaled inner input.
-        let text_size = self.font_size;
-        let line_height = f64::from(text_size * theme.text_scale) * 1.25;
-        let rect = self.inner.get_rect();
-        let pad = self.inner.text_padding_x(theme);
-        let scroll_x = self.inner.scroll_x();
-        let text_y = rect.y0 + (rect.height() - line_height) / 2.0;
-        let xs = self.inner.char_x_positions();
-        if xs.is_empty() {
-            // First frame — inner input hasn't populated char_x_positions yet.
-            return;
-        }
-
-        // Clips overpaint so a scrolled long line doesn't bleed glyphs past the column.
-        let clip_shape =
-            vello::kurbo::RoundedRect::from_rect(rect, f64::from(theme.tokens.radii.md));
-        scene.push_layer(
-            vello::peniko::Fill::NonZero,
-            BlendMode::default(),
-            1.0,
-            transform,
-            &clip_shape,
-        );
-
-        let ctx = MarkDrawCtx {
-            text: &text,
-            xs,
-            rect,
-            pad,
-            scroll_x,
-            text_y,
-            line_height,
-            text_size,
-        };
-        for seg in &segments {
-            paint_mark_segment(scene, transform, text_renderer, theme, seg, &ctx);
-        }
-
-        scene.pop_layer();
     }
 
     fn handle_event(
@@ -630,6 +628,7 @@ impl Widget for RichTextLine {
         if new_text != self.prev_text {
             self.reconcile_marks_after_edit(&new_text);
             self.prev_text = new_text;
+            self.refresh_attributes();
         }
         self.prev_cursor = self.inner.cursor_pos();
     }
@@ -683,179 +682,12 @@ impl Widget for RichTextLine {
             self.pending_marks.clear();
             self.prev_text = self.inner.value().to_string();
             self.prev_cursor = self.inner.cursor_pos();
+            self.refresh_attributes();
         }
         handled
     }
 }
 
-/// Paints one mark segment's overpaint (code chip, link/underline/strike
-/// rules, and restyled glyphs) inside the clip layer `draw` already pushed.
-/// A pure function of its inputs — no `self` needed.
-fn paint_mark_segment(
-    scene: &mut Scene,
-    transform: Affine,
-    text_renderer: &mut TextRenderer,
-    theme: &Theme,
-    seg: &MarkSegment,
-    ctx: &MarkDrawCtx<'_>,
-) {
-    if seg.range.start >= ctx.text.len() {
-        return;
-    }
-    // A mark's byte range might not land on a char boundary after an edit
-    // races the mark-shift logic; skip rather than panic.
-    let Some(slice) = ctx
-        .text
-        .get(seg.range.start..seg.range.end.min(ctx.text.len()))
-    else {
-        return;
-    };
-    if slice.is_empty() {
-        return;
-    }
-
-    let x_offset = ctx.xs.get(seg.range.start).copied().unwrap_or(0.0);
-    let x = ctx.rect.x0 + ctx.pad + x_offset - ctx.scroll_x;
-    let sans_end_x_offset = ctx
-        .xs
-        .get(seg.range.end.min(ctx.xs.len().saturating_sub(1)))
-        .copied()
-        .unwrap_or(x_offset);
-    let sans_end_x = ctx.rect.x0 + ctx.pad + sans_end_x_offset - ctx.scroll_x;
-
-    paint_segment_decorations(scene, transform, theme, seg, ctx, x, sans_end_x);
-
-    let needs_overpaint = seg.bold
-        || seg.italic
-        || seg.code
-        || seg.underline
-        || seg.strikethrough
-        || seg.link.is_some();
-    if !needs_overpaint {
-        return;
-    }
-
-    let tokens = &theme.tokens;
-    let color = if seg.link.is_some() || seg.code {
-        tokens.colors.accent[5]
-    } else {
-        tokens.colors.text_primary
-    };
-
-    let weight = if seg.bold {
-        TextWeight::Bold
-    } else {
-        TextWeight::Regular
-    };
-    let italic = seg.italic;
-    let mono = false;
-
-    text_renderer.draw_text_styled(
-        scene,
-        slice,
-        ctx.text_size,
-        color,
-        translated(transform, x, ctx.text_y),
-        None,
-        weight,
-        italic,
-        mono,
-    );
-}
-
-/// Draws the code-chip background and the link/underline/strikethrough
-/// rules for one segment — the parts of `paint_mark_segment` that don't
-/// depend on the restyled text run itself.
-fn paint_segment_decorations(
-    scene: &mut Scene,
-    transform: Affine,
-    theme: &Theme,
-    seg: &MarkSegment,
-    ctx: &MarkDrawCtx<'_>,
-    x: f64,
-    sans_end_x: f64,
-) {
-    let tokens = &theme.tokens;
-
-    if seg.code {
-        // Inline code renders in the document font (`mono = false` in
-        // `paint_mark_segment`) so its extent matches the sans layout slot
-        // exactly; a wider monospace measurement would overlap next chars.
-        let bg_rect = Rect::new(
-            x - 2.0,
-            ctx.text_y + 1.0,
-            sans_end_x + 2.0,
-            ctx.text_y + ctx.line_height - 1.0,
-        );
-        let bg = vello::kurbo::RoundedRect::from_rect(bg_rect, 3.0);
-        scene.fill(
-            vello::peniko::Fill::NonZero,
-            transform,
-            tokens.colors.surfaces.raised,
-            None,
-            &bg,
-        );
-    }
-
-    if seg.link.is_some() {
-        let underline = Rect::new(
-            x,
-            ctx.text_y + ctx.line_height - 2.0,
-            sans_end_x,
-            ctx.text_y + ctx.line_height - 1.0,
-        );
-        scene.fill(
-            vello::peniko::Fill::NonZero,
-            transform,
-            tokens.colors.accent[5],
-            None,
-            &underline,
-        );
-    }
-
-    // In text colour, distinct from the accent-coloured link underline above.
-    if seg.underline {
-        let rule = Rect::new(
-            x,
-            ctx.text_y + ctx.line_height - 2.0,
-            sans_end_x,
-            ctx.text_y + ctx.line_height - 1.0,
-        );
-        scene.fill(
-            vello::peniko::Fill::NonZero,
-            transform,
-            tokens.colors.text_primary,
-            None,
-            &rule,
-        );
-    }
-
-    if seg.strikethrough {
-        let mid = ctx.text_y + ctx.line_height * 0.5;
-        let rule = Rect::new(x, mid - 0.5, sans_end_x, mid + 0.5);
-        scene.fill(
-            vello::peniko::Fill::NonZero,
-            transform,
-            tokens.colors.text_primary,
-            None,
-            &rule,
-        );
-    }
-}
-
-/// Composes `transform` with a translation by `(dx, dy)`. `kurbo::Affine`'s
-/// `Mul` impl trips `arithmetic_side_effects` like any operator overload,
-/// but composing two f64-based affine transforms cannot meaningfully
-/// overflow — same reasoning clippy already exempts bare `f64` arithmetic
-/// for.
-#[allow(
-    clippy::arithmetic_side_effects,
-    reason = "Affine::mul composes f64 transform matrices; cannot meaningfully overflow"
-)]
-fn translated(transform: Affine, dx: f64, dy: f64) -> Affine {
-    transform * Affine::translate((dx, dy))
-}
-
 /// Clamps to the end. Converts Automerge marks (char-indexed) to the byte
 /// offsets `pixel_x_for_byte` uses.
 fn char_to_byte(text: &str, char_idx: usize) -> usize {
@@ -872,7 +704,10 @@ pub(crate) fn diff_splice(old: &str, new: &str) -> (usize, usize, usize) {
     let na = new.as_bytes();
 
     // Longest common prefix.
-    let prefix = oa.iter().zip(na.iter()).take_while(|(o, n)| o == n).count();
+    let mut prefix = oa.iter().zip(na.iter()).take_while(|(o, n)| o == n).count();
+    while !old.is_char_boundary(prefix) || !new.is_char_boundary(prefix) {
+        prefix = prefix.saturating_sub(1);
+    }
 
     let o_rest = oa.len().saturating_sub(prefix);
     let n_rest = na.len().saturating_sub(prefix);
@@ -880,7 +715,7 @@ pub(crate) fn diff_splice(old: &str, new: &str) -> (usize, usize, usize) {
     // Longest common suffix within the bytes past the prefix. `zip` already
     // stops at the shorter of the two (reversed, prefix-skipped) iterators,
     // matching the original bound of `min(o_rest, n_rest)`.
-    let suffix = oa
+    let mut suffix = oa
         .iter()
         .skip(prefix)
         .rev()
@@ -888,6 +723,11 @@ pub(crate) fn diff_splice(old: &str, new: &str) -> (usize, usize, usize) {
         .take_while(|(o, n)| o == n)
         .count();
 
+    while !old.is_char_boundary(old.len().saturating_sub(suffix))
+        || !new.is_char_boundary(new.len().saturating_sub(suffix))
+    {
+        suffix = suffix.saturating_sub(1);
+    }
     let removed = o_rest.saturating_sub(suffix);
     let inserted = n_rest.saturating_sub(suffix);
     (prefix, inserted, removed)
@@ -985,7 +825,7 @@ mod tests {
         );
     }
 
-    fn layout_and_draw(line: &mut RichTextLine, theme: &Theme, width: f32) {
+    fn layout_and_draw(line: &mut RichTextLine, theme: &Theme, width: f32) -> Scene {
         let mut taffy = TaffyTree::<()>::new();
         let mut node_map = HashMap::new();
         let node = line.build_layout(&mut taffy, theme, &mut node_map);
@@ -1010,6 +850,62 @@ mod tests {
             theme,
             &PresenceCtx::empty(),
         );
+        scene
+    }
+
+    #[test]
+    fn rich_marks_utf8_replacement_keeps_complete_boundaries() {
+        assert_eq!(diff_splice("éx", "êx"), (0, 2, 2));
+        assert_eq!(diff_splice("xé", "xê"), (1, 2, 2));
+    }
+
+    #[test]
+    fn rich_marks_paint_each_glyph_once() {
+        let mut line = RichTextLine::new().with_text("aBz");
+        line.set_marks(vec![MarkSpan::new(1..2, Mark::Bold)]);
+        let scene = layout_and_draw(&mut line, &Theme::dark(), 320.0);
+        assert_eq!(scene.encoding().resources.glyphs.len(), 3);
+    }
+
+    #[test]
+    fn rich_marks_style_only_changes_refresh_authoritative_geometry() {
+        for scale in [1.0, 2.0] {
+            let theme = Theme::dark().with_text_scale(scale);
+            let mut line = RichTextLine::new().with_text("WWW end");
+            layout_and_draw(&mut line, &theme, 400.0);
+            let plain = line.pixel_x_for_byte(&theme, 3);
+            line.set_marks(vec![MarkSpan::new(0..3, Mark::Bold)]);
+            layout_and_draw(&mut line, &theme, 400.0);
+            let bold = line.pixel_x_for_byte(&theme, 3);
+            assert!(
+                (bold - plain).abs() > 0.1,
+                "bold must change the authoritative advances"
+            );
+            assert!((line.caret_rect(&theme, 3).x0 - bold).abs() < 0.01);
+            assert!((line.selection_rect(&theme, 0, 3).x1 - bold).abs() < 0.01);
+            assert_eq!(line.byte_for_pixel_x(&theme, bold), 3);
+            line.set_marks(vec![]);
+            layout_and_draw(&mut line, &theme, 400.0);
+            assert!((line.pixel_x_for_byte(&theme, 3) - plain).abs() < 0.01);
+        }
+    }
+
+    #[test]
+    fn rich_marks_scrolled_selection_and_pointer_share_the_painted_end() {
+        for scale in [1.0, 2.0] {
+            let theme = Theme::dark().with_text_scale(scale);
+            let mut line = RichTextLine::new().with_text("prefix WWW tail");
+            line.set_marks(vec![MarkSpan::new(7..10, Mark::Bold)]);
+            line.set_focus(true);
+            line.inner_mut().set_selection(7, 10);
+            layout_and_draw(&mut line, &theme, 80.0);
+            assert!(line.inner().scroll_x() > 0.0);
+            let x = line.pixel_x_for_byte(&theme, 10);
+            assert!(x <= line.get_rect().x1);
+            assert!((line.caret_rect(&theme, 10).x0 - x).abs() < 0.01);
+            assert!((line.selection_rect(&theme, 7, 10).x1 - x).abs() < 0.01);
+            assert_eq!(line.byte_for_pixel_x(&theme, x), 10);
+        }
     }
 
     #[test]
diff --git a/ui/src/widget/text_input.rs b/ui/src/widget/text_input.rs
index 172d79260..f090271e0 100644
--- a/ui/src/widget/text_input.rs
+++ b/ui/src/widget/text_input.rs
@@ -145,6 +145,17 @@ enum DragUnit {
 
 type TextChangeCallback = Box<dyn FnMut(&str)>;
 
+/// Complete committed-text runs for an unmasked single line. Decorations use
+/// byte ranges in that same text; IME insertion remaps them only for display.
+#[derive(Clone, Debug, Default)]
+pub(super) struct SingleLineAttributes {
+    pub spans: Vec<RichSpan>,
+    pub underlines: Vec<(usize, usize)>,
+    pub strikes: Vec<(usize, usize)>,
+    pub chips: Vec<(usize, usize)>,
+    pub links: Vec<(usize, usize)>,
+}
+
 #[allow(
     clippy::struct_excessive_bools,
     reason = "each bool is an independent widget-configuration or ephemeral-UI-state flag (hover/focus/drag/dirty/secret/etc), not a state machine; grouping them would misrepresent orthogonal concerns and ripple through every accessor in this file"
@@ -209,6 +220,7 @@ pub struct TextInput {
     /// Authoritative cosmic-text geometry for a visible, unmasked single-line
     /// value. Painting, carets, selection, and hit-testing all consume it.
     single_layout: Option<RichTextLayout>,
+    single_attributes: Option<SingleLineAttributes>,
     single_origin: Point,
     shaped_layout_signature: u64,
     /// In-progress IME composition. It is inserted only in the display
@@ -371,6 +383,7 @@ impl TextInput {
             last_mouse_pos: Point::ZERO,
             char_x_positions: Vec::new(),
             single_layout: None,
+            single_attributes: None,
             single_origin: Point::ZERO,
             shaped_layout_signature: u64::MAX,
             preedit: String::new(),
@@ -481,7 +494,7 @@ impl TextInput {
             return false;
         }
         self.text = text;
-        self.model_layout_dirty |= self.multiline;
+        self.model_layout_dirty |= self.multiline || self.single_attributes.is_some();
         true
     }
 
@@ -489,7 +502,7 @@ impl TextInput {
     pub(super) fn capture_layout_text_scale(&mut self, text_scale: f32) {
         if self.layout_text_scale != Some(text_scale) {
             self.layout_text_scale = Some(text_scale);
-            self.model_layout_dirty |= self.multiline;
+            self.model_layout_dirty |= self.multiline || self.single_attributes.is_some();
         }
     }
 
@@ -554,7 +567,10 @@ impl TextInput {
     }
 
     pub fn set_font_size(&mut self, size: f32) {
-        self.font_size_override = Some(size);
+        if self.font_size_override != Some(size) {
+            self.model_layout_dirty |= self.single_attributes.is_some();
+            self.font_size_override = Some(size);
+        }
     }
 
     pub fn set_plain_chrome(&mut self, plain: bool) {
@@ -569,6 +585,9 @@ impl TextInput {
     }
 
     pub fn set_mono(&mut self, mono: bool) {
+        if self.mono != mono {
+            self.model_layout_dirty |= self.single_attributes.is_some();
+        }
         self.mono = mono;
         if mono {
             self.set_kind(TextInputKind::Code);
@@ -690,7 +709,10 @@ impl TextInput {
     }
 
     pub fn set_font_family(&mut self, family: Option<FontChoice>) {
-        self.family = family;
+        if self.family != family {
+            self.model_layout_dirty |= self.single_attributes.is_some();
+            self.family = family;
+        }
     }
 
     pub fn font_family(&self) -> Option<&FontChoice> {
@@ -736,6 +758,14 @@ impl TextInput {
         let mut hash = DefaultHasher::new();
         base.hash(&mut hash);
         for span in spans {
+            span.text.hash(&mut hash);
+            span.size.map(f32::to_bits).hash(&mut hash);
+            std::mem::discriminant(&span.family).hash(&mut hash);
+            if let Some(family) = span.family {
+                std::mem::discriminant(&family).hash(&mut hash);
+            }
+            span.background.hash(&mut hash);
+            std::mem::discriminant(&span.baseline).hash(&mut hash);
             span.color.hash(&mut hash);
             span.bold.hash(&mut hash);
             span.italic.hash(&mut hash);
@@ -799,6 +829,10 @@ impl TextInput {
             spans.push(RichSpan::new(tail));
         }
 
+        self.insert_preedit_span(spans)
+    }
+
+    fn insert_preedit_span(&self, spans: Vec<RichSpan>) -> Vec<RichSpan> {
         if self.preedit.is_empty() {
             return spans;
         }
@@ -844,6 +878,67 @@ impl TextInput {
         display
     }
 
+    pub(super) fn set_single_line_attributes(&mut self, attributes: SingleLineAttributes) {
+        let signature = Self::single_attributes_signature(&attributes);
+        if self
+            .single_attributes
+            .as_ref()
+            .is_none_or(|old| Self::single_attributes_signature(old) != signature)
+        {
+            self.single_attributes = Some(attributes);
+            self.single_layout = None;
+            self.model_layout_dirty = true;
+        }
+    }
+
+    fn single_attributes_signature(attributes: &SingleLineAttributes) -> u64 {
+        use std::hash::{Hash, Hasher};
+        let mut hash = std::collections::hash_map::DefaultHasher::new();
+        Self::attributed_signature(0, &attributes.spans).hash(&mut hash);
+        attributes.underlines.hash(&mut hash);
+        attributes.strikes.hash(&mut hash);
+        attributes.chips.hash(&mut hash);
+        attributes.links.hash(&mut hash);
+        hash.finish()
+    }
+
+    fn valid_single_attributes(&self) -> Option<&SingleLineAttributes> {
+        self.single_attributes.as_ref().filter(|attributes| {
+            attributes
+                .spans
+                .iter()
+                .map(|s| s.text.as_str())
+                .collect::<String>()
+                == self.text
+        })
+    }
+
+    /// Preedit is its own run: adjacent committed decorations do not expand
+    /// over it. An insertion inside a marked run splits its decoration.
+    fn display_ranges(&self, ranges: &[(usize, usize)]) -> Vec<(usize, usize)> {
+        let at = self.cursor_pos.min(self.text.len());
+        let extra = self.preedit.len();
+        let mut display = Vec::new();
+        for &(start, end) in ranges {
+            if start >= end
+                || end > self.text.len()
+                || !self.text.is_char_boundary(start)
+                || !self.text.is_char_boundary(end)
+            {
+                continue;
+            }
+            if extra == 0 || end <= at {
+                display.push((start, end));
+            } else if start >= at {
+                display.push((start.saturating_add(extra), end.saturating_add(extra)));
+            } else {
+                display.push((start, at));
+                display.push((at.saturating_add(extra), end.saturating_add(extra)));
+            }
+        }
+        display
+    }
+
     /// No CRDT integration — for a field with no CRDT path to spend.
     pub fn local() -> Self {
         let mut s = Self::new(Vec::new());
@@ -927,7 +1022,7 @@ impl TextInput {
         self.selection_anchor = None;
         self.clamp_to_text();
         self.dirty = false;
-        self.model_layout_dirty = self.multiline;
+        self.model_layout_dirty = self.multiline || self.single_attributes.is_some();
         self.last_edit_time = None;
         self.last_notified_text.clone_from(&self.text);
         if self.action.is_none() {
@@ -3631,6 +3726,18 @@ impl Widget for TextInput {
         text_renderer: &mut TextRenderer,
     ) -> taffy::Size<f32> {
         if !self.multiline {
+            if !self.masked() && self.single_attributes.is_some() {
+                let scale = self
+                    .layout_text_scale
+                    .unwrap_or_else(|| text_renderer.text_scale());
+                let display = self.layout_display_text();
+                self.build_single_line_metrics(
+                    text_renderer,
+                    &display,
+                    self.effective_font_size(),
+                    scale,
+                );
+            }
             self.model_layout_dirty = false;
             return taffy::Size::ZERO;
         }
@@ -3741,7 +3848,8 @@ impl Widget for TextInput {
         // used for paint and hit-testing. Masked fields keep the prefix path
         // because bullet byte offsets intentionally differ from the secret.
         let display = self.layout_display_text();
-        let total_w = self.build_single_line_metrics(text_renderer, &display, text_size, theme);
+        let total_w =
+            self.build_single_line_metrics(text_renderer, &display, text_size, theme.text_scale);
         self.single_origin = Point::new(self.rect.x0 + padding_x, text_y);
 
         let cursor_x_offset = self.single_line_cursor_x_offset(total_w);
@@ -3755,6 +3863,7 @@ impl Widget for TextInput {
             &shape,
         );
 
+        self.draw_single_line_decorations(scene, transform, theme, true);
         self.draw_single_line_selection(scene, transform, theme);
 
         let text_color = if self.effectively_disabled() {
@@ -3774,6 +3883,7 @@ impl Widget for TextInput {
             text_color,
         );
 
+        self.draw_single_line_decorations(scene, transform, theme, false);
         if self.is_focused && !self.effectively_disabled() {
             self.draw_single_line_caret(scene, transform, theme);
         }
@@ -4335,7 +4445,7 @@ impl TextInput {
         text_renderer: &mut TextRenderer,
         display: &str,
         text_size: f32,
-        theme: &Theme,
+        text_scale: f32,
     ) -> f32 {
         self.char_x_positions.clear();
         self.char_x_positions
@@ -4360,18 +4470,34 @@ impl TextInput {
             } else {
                 FontChoice::SansSerif
             });
-            let layout_size = text_size * theme.text_scale;
+            let layout_size = text_size * text_scale;
             let style = TextStyle::new(layout_size)
                 .with_line_height(LINE_HEIGHT_RATIO)
                 .with_family(family.clone());
-            let signature = self.shaped_signature(display, &family, layout_size, None);
+            let base = self.shaped_signature(display, &family, layout_size, None);
+            let attributes = self.valid_single_attributes();
+            let signature = attributes.map_or(base, |a| {
+                Self::attributed_signature(base ^ Self::single_attributes_signature(a), &a.spans)
+            });
             if self.single_layout.is_none() || self.shaped_layout_signature != signature {
-                let mut layout = RichTextLayout::shape_plain(
-                    &mut text_renderer.font_system,
-                    display,
-                    &style,
-                    None,
-                );
+                let mut layout = if let Some(attributes) = attributes {
+                    RichTextLayout::shape_styled(
+                        &mut text_renderer.font_system,
+                        &self.insert_preedit_span(attributes.spans.clone()),
+                        &style,
+                        None,
+                        TextAlign::Left,
+                        self.display_ranges(&attributes.underlines),
+                        self.display_ranges(&attributes.strikes),
+                    )
+                } else {
+                    RichTextLayout::shape_plain(
+                        &mut text_renderer.font_system,
+                        display,
+                        &style,
+                        None,
+                    )
+                };
                 if !self.preedit.is_empty() {
                     let start = self.cursor_pos.min(self.text.len());
                     layout.add_underline(start..start.saturating_add(self.preedit.len()));
@@ -4457,6 +4583,63 @@ impl TextInput {
         }
     }
 
+    /// Code chips precede selection and glyphs; accent link rules follow
+    /// glyphs. All bounds come from the exact layout used for interaction.
+    fn draw_single_line_decorations(
+        &self,
+        scene: &mut Scene,
+        transform: Affine,
+        theme: &Theme,
+        backgrounds: bool,
+    ) {
+        if self.masked() {
+            return;
+        }
+        let (Some(attributes), Some(layout)) =
+            (self.valid_single_attributes(), &self.single_layout)
+        else {
+            return;
+        };
+        let ranges = if backgrounds {
+            &attributes.chips
+        } else {
+            &attributes.links
+        };
+        for (start, end) in self.display_ranges(ranges) {
+            for (x0, y0, x1, y1) in layout.selection_rects(start, end) {
+                let x = self.single_origin.x - self.scroll_x;
+                let y = self.single_origin.y;
+                let rect = if backgrounds {
+                    Rect::new(
+                        x + f64::from(x0) - 2.0,
+                        y + f64::from(y0) + 1.0,
+                        x + f64::from(x1) + 2.0,
+                        y + f64::from(y1) - 1.0,
+                    )
+                } else {
+                    Rect::new(
+                        x + f64::from(x0),
+                        y + f64::from(y1) - 2.0,
+                        x + f64::from(x1),
+                        y + f64::from(y1) - 1.0,
+                    )
+                };
+                let color = if backgrounds {
+                    theme.tokens.colors.surfaces.raised
+                } else {
+                    theme.tokens.colors.accent[5]
+                };
+                scene.fill(
+                    vello::peniko::Fill::NonZero,
+                    transform,
+                    color,
+                    None,
+                    &RoundedRect::from_rect(rect, if backgrounds { 3.0 } else { 0.0 }),
+                );
+            }
+        }
+    }
+
     #[allow(clippy::too_many_arguments, reason = "internal draw-pass helper")]
     fn draw_single_line_text(
         &self,
@@ -5188,6 +5371,273 @@ impl TextInput {
 mod tests {
     use super::*;
 
+    #[test]
+    fn attributed_single_line_is_shaped_during_measure_before_draw() {
+        use crate::widget::marks::{Mark, MarkSpan};
+        use crate::widget::rich_text_line::RichTextLine;
+        for scale in [1.0, 2.0] {
+            let theme = Theme::dark().with_text_scale(scale);
+            let mut line = RichTextLine::new().with_text("aBz");
+            line.set_marks(vec![MarkSpan::new(1..2, Mark::Bold)]);
+            let mut taffy = TaffyTree::new();
+            line.build_layout(&mut taffy, &theme, &mut Default::default());
+            let mut renderer = TextRenderer::new(); // intentionally stale 1x
+            line.measure(
+                Size::NONE,
+                Size {
+                    width: taffy::AvailableSpace::MaxContent,
+                    height: taffy::AvailableSpace::MaxContent,
+                },
+                &mut renderer,
+            );
+            let layout = line
+                .inner()
+                .single_layout
+                .as_ref()
+                .expect("measurement must shape styled text");
+            let weights: Vec<_> = layout
+                .buffer
+                .layout_runs()
+                .flat_map(|r| r.glyphs.iter().map(|g| g.font_weight.0))
+                .collect();
+            assert_eq!(weights, [400, 700, 400]);
+            assert_eq!(layout.buffer.metrics().font_size, 16.0 * scale);
+        }
+    }
+
+    fn draw_rich_line_for_test(line: &mut crate::widget::RichTextLine, theme: &Theme) -> Scene {
+        let mut renderer = TextRenderer::new();
+        renderer.set_text_scale(theme.text_scale);
+        let mut scene = Scene::new();
+        line.draw(
+            &mut scene,
+            Affine::IDENTITY,
+            &mut renderer,
+            theme,
+            &crate::presence::PresenceCtx::empty(),
+        );
+        scene
+    }
+
+    #[test]
+    fn attributed_single_line_preedit_preserves_utf8_marks_and_commit_route() {
+        use crate::widget::marks::{Mark, MarkSpan};
+        for scale in [1.0, 2.0] {
+            let theme = Theme::dark().with_text_scale(scale);
+            let mut line = crate::widget::RichTextLine::new().with_text("éW");
+            line.set_marks(vec![
+                MarkSpan::new(0..3, Mark::Bold),
+                MarkSpan::new(0..3, Mark::Code),
+                MarkSpan::new(0..3, Mark::Underline),
+                MarkSpan::new(0..3, Mark::Strikethrough),
+            ]);
+            line.apply_layout_external(Rect::new(0.0, 0.0, 400.0, 60.0));
+            line.set_focus(true);
+            line.set_cursor_pos(2);
+            let mut doc = AutoCommit::new();
+            let (taffy, node) = test_node();
+            let mut send = |line: &mut crate::widget::RichTextLine, event: WindowEvent| {
+                line.handle_event(
+                    &event,
+                    1.0,
+                    &Modifiers::default(),
+                    &mut doc,
+                    &automerge::ROOT,
+                    &mut false,
+                    &mut None,
+                    node,
+                    &taffy,
+                );
+            };
+            send(
+                &mut line,
+                WindowEvent::Ime(winit::event::Ime::Preedit("漢".into(), Some((3, 3)))),
+            );
+            draw_rich_line_for_test(&mut line, &theme);
+            assert_eq!(line.value(), "éW");
+            let input = line.inner();
+            let layout = input.single_layout.as_ref().unwrap();
+            assert_eq!(layout.buffer.lines[0].text(), "é漢W");
+            assert_eq!(layout.underlines, [(0, 2), (5, 6), (2, 5)]);
+            assert_eq!(layout.strikes, [(0, 2), (5, 6)]);
+            let weights: Vec<_> = layout
+                .buffer
+                .layout_runs()
+                .flat_map(|r| r.glyphs.iter().map(|g| g.font_weight.0))
+                .collect();
+            assert_eq!(weights, [700, 400, 700]);
+            let anchor = input.ime_cursor_rect().unwrap();
+            assert!(anchor.x0 > line.caret_rect(&theme, 2).x0);
+            assert_eq!(
+                input.display_ranges(&input.single_attributes.as_ref().unwrap().chips),
+                [(0, 2), (5, 6)]
+            );
+            send(
+                &mut line,
+                WindowEvent::Ime(winit::event::Ime::Commit("漢".into())),
+            );
+            let scene = draw_rich_line_for_test(&mut line, &theme);
+            assert_eq!(line.value(), "é漢W");
+            assert_eq!(line.cursor_pos(), 5);
+            assert_eq!(scene.encoding().resources.glyphs.len(), 3);
+            assert!(
+                line.marks()
+                    .iter()
+                    .all(|m| line.value().is_char_boundary(m.range.start)
+                        && line.value().is_char_boundary(m.range.end))
+            );
+        }
+    }
+
+    #[test]
+    fn attributed_single_line_chip_and_link_rules_follow_shaped_ranges() {
+        use crate::widget::marks::{Mark, MarkSpan};
+        for scale in [1.0, 2.0] {
+            let theme = Theme::dark().with_text_scale(scale);
+            let mut line = crate::widget::RichTextLine::new().with_text("aWWWz");
+            line.set_marks(vec![
+                MarkSpan::new(1..4, Mark::Bold),
+                MarkSpan::new(1..4, Mark::Code),
+                MarkSpan::new(1..4, Mark::Link(uuid::Uuid::from_u128(1))),
+                MarkSpan::new(1..4, Mark::Strikethrough),
+            ]);
+            line.apply_layout_external(Rect::new(10.0, 20.0, 400.0, 90.0));
+            let scene = draw_rich_line_for_test(&mut line, &theme);
+            assert_eq!(scene.encoding().resources.glyphs.len(), 5);
+            let input = line.inner();
+            let left = input.caret_rect(&theme, 1).x0;
+            let right = input.caret_rect(&theme, 4).x0;
+            let layout = input.single_layout.as_ref().unwrap();
+            assert_eq!(layout.strikes, [(1, 4)]);
+            assert!(
+                layout
+                    .buffer
+                    .layout_runs()
+                    .flat_map(|r| r.glyphs.iter())
+                    .all(|g| g.font_size == 16.0 * scale)
+            );
+            for (background, pad) in [(true, 2.0), (false, 0.0)] {
+                let mut decorations = Scene::new();
+                input.draw_single_line_decorations(
+                    &mut decorations,
+                    Affine::IDENTITY,
+                    &theme,
+                    background,
+                );
+                let xs: Vec<_> = decorations
+                    .encoding()
+                    .path_data
+                    .chunks_exact(2)
+                    .map(|xy| f64::from(f32::from_bits(xy[0])))
+                    .collect();
+                let min = xs.iter().copied().fold(f64::INFINITY, f64::min);
+                let max = xs.iter().copied().fold(f64::NEG_INFINITY, f64::max);
+                assert!((min - (left - pad)).abs() < 0.01);
+                assert!((max - (right + pad)).abs() < 0.01);
+                assert_eq!(
+                    decorations.encoding().resources.glyphs.len(),
+                    0,
+                    "decorations never repaint text"
+                );
+            }
+        }
+    }
+
+    #[test]
+    fn attributed_single_line_style_inputs_invalidate_cached_shape() {
+        use crate::richtext::{BaselineShift, FontFamily};
+        let mut input = TextInput::local().with_initial_value("WWW");
+        input.apply_layout_external(Rect::new(0.0, 0.0, 400.0, 60.0));
+        let mut attributes = SingleLineAttributes {
+            spans: vec![RichSpan::new("WWW")],
+            ..Default::default()
+        };
+        input.set_single_line_attributes(attributes.clone());
+        draw_to_populate(&mut input);
+        let original_width = input.single_layout.as_ref().unwrap().width();
+        attributes.spans[0].size = Some(28.0);
+        input.set_single_line_attributes(attributes.clone());
+        draw_to_populate(&mut input);
+        let sized_width = input.single_layout.as_ref().unwrap().width();
+        assert!(sized_width > original_width * 1.5);
+        attributes.spans[0].family = Some(FontFamily::Mono);
+        input.set_single_line_attributes(attributes.clone());
+        draw_to_populate(&mut input);
+        assert!((input.single_layout.as_ref().unwrap().width() - sized_width).abs() > 1.0);
+        attributes.spans[0].background = Some([40, 50, 60]);
+        attributes.spans[0].baseline = BaselineShift::Super;
+        attributes.spans[0].color = Some([100, 110, 120]);
+        attributes.underlines = vec![(0, 1)];
+        attributes.strikes = vec![(1, 3)];
+        input.set_single_line_attributes(attributes);
+        draw_to_populate(&mut input);
+        let layout = input.single_layout.as_ref().unwrap();
+        assert_eq!(layout.backgrounds, [(0, 3, [40, 50, 60])]);
+        assert_eq!(layout.baselines, [(0, 3, BaselineShift::Super)]);
+        assert_eq!(layout.underlines, [(0, 1)]);
+        assert_eq!(layout.strikes, [(1, 3)]);
+        assert!(
+            layout
+                .buffer
+                .layout_runs()
+                .flat_map(|r| r.glyphs.iter())
+                .all(|g| g.color_opt == Some(cosmic_text::Color::rgb(100, 110, 120)))
+        );
+    }
+
+    #[test]
+    fn attributed_single_line_sync_undo_redo_rebuilds_runs() {
+        use crate::widget::marks::{Mark, MarkSpan};
+        let mut state = crate::State::new();
+        let text = state
+            .doc
+            .put_object(&state.root, "body", ObjType::Text)
+            .unwrap();
+        state.doc.splice_text(&text, 0, 0, "WWW").unwrap();
+        state.commit_action(None, None);
+        let mut line = crate::widget::RichTextLine::new();
+        line.bind_text(text.clone());
+        line.sync(&mut state.doc, &state.root);
+        line.set_marks(vec![MarkSpan::new(0..3, Mark::Bold)]);
+        line.apply_layout_external(Rect::new(0.0, 0.0, 400.0, 60.0));
+        let theme = Theme::dark().with_text_scale(2.0);
+        draw_rich_line_for_test(&mut line, &theme);
+        let wide = line.pixel_x_for_byte(&theme, 3);
+        state.doc.splice_text(&text, 0, 3, "iii").unwrap();
+        state.commit_action(None, None);
+        for (step, expected) in [(0, "iii"), (1, "WWW"), (2, "iii")] {
+            if step == 1 {
+                state.undo(None, None).unwrap();
+            }
+            if step == 2 {
+                state.redo(None, None).unwrap();
+            }
+            line.sync(&mut state.doc, &state.root);
+            let _ = line.take_dirty(); // preserve direct-binding reconciliation semantics
+            assert!(line.layout_needs_measure());
+            draw_rich_line_for_test(&mut line, &theme);
+            assert_eq!(line.value(), expected);
+            let input = line.inner();
+            assert!(
+                input
+                    .single_layout
+                    .as_ref()
+                    .unwrap()
+                    .buffer
+                    .layout_runs()
+                    .flat_map(|r| r.glyphs.iter())
+                    .all(|g| g.font_weight.0 == 700)
+            );
+            let x = line.pixel_x_for_byte(&theme, 3);
+            if expected == "WWW" {
+                assert!((x - wide).abs() < 0.01);
+            } else {
+                assert!(x < wide * 0.6);
+            }
+            assert_eq!(line.byte_for_pixel_x(&theme, x), 3);
+        }
+    }
+
     #[test]
     fn programmatic_caret_never_splits_a_grapheme() {
         let mut combining = TextInput::local().with_initial_value("a\u{301}b");

```
