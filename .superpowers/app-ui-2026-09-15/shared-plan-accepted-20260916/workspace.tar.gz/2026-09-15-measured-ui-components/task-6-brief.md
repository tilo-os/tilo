# Measured UI Components Implementation Plan

> **For agentic workers:** REQUIRED SUB-SKILL: Use superpowers:subagent-driven-development (recommended) or superpowers:executing-plans to implement this plan task-by-task. Steps use checkbox (`- [ ]`) syntax for tracking.

**Goal:** Repair shared sizing and interaction contracts so app authors get readable, balanced layouts with fewer manual measurements.

**Architecture:** Add one resolved-text normalization boundary while preserving existing relative APIs. Repair EmptyState, rich editor, opt-in scrolling editor fill and measured actionable Toolbar overflow. App composition migrations consume existing Card/Actions/FormPage rather than inventing another layout system.

**Tech Stack:** Rust, Taffy, cosmic-text, Vello and qOS Widget lifecycle.

**Spec:** `docs/superpowers/specs/2026-09-15-app-ui-balance.md`

## Global Constraints

- Reuse the repository Cargo target cache; do not rebuild all dependencies into a new target directory without a concrete build-isolation need. Isolate runtime captures with task-specific HOME and XDG_CONFIG_HOME/XDG_DATA_HOME/XDG_CACHE_HOME/XDG_STATE_HOME, separately from build caches.

- Prioritize ordinary100% and narrow layout as well as200% text.
- Preserve primary actions, keyboard access, state and explicit manual dimensions.
- Keep legacy renderer-relative font APIs compatible; theme-resolved fonts must scale once.
- Do not globally change primitive padding or reinterpret explicit fixed sizes.
- Preserve unrelated working changes and untracked Scratchpad ownership.
- No pushes, merges, publishing or dependency upgrades.
- Existing linked worktree /Users/xaver/dev/qos-macos-shell; sequential implementers and scoped reviews.
- Focused RED/GREEN behavior regressions before implementation; run relevant existing UI tests once before scoped commit. CARGO_BUILD_JOBS=4, CARGO_PROFILE_DEV_DEBUG=0, CARGO_PROFILE_TEST_DEBUG=0.
- Every task report includes exact commands/results, self-review, screenshot paths if requested, and remaining gaps. No subagents from implementers.


### Task 6: Single shaped source for rich inline marks

**Dependency:** Tasks2 and7 accepted before dispatch. Preserve Task7 final-empty-line normalization and its regressions when consuming shape_styled. Confirmed ordinary-size Notes defect, not a speculative typography redesign.
**Files:** `ui/src/widget/rich_text_line.rs`, scoped `ui/src/widget/text_input.rs` attributed single-line support, and narrowly `ui/src/widget/block_editor.rs` current-frame link-hit refresh plus regression (see ruling below). Only extend `ui/src/richtext.rs` or `ui/src/text_render.rs` if existing range decoration support cannot preserve behavior. Report architectural need before widening production scope.
**Evidence:** `.superpowers/app-ui-2026-09-15/rich-mark-diagnosis.md`, actual Notes images in `task2-after-20260916/captures/notes/`. Inner plain text is painted then marked substrings painted again from a separate shape with different advances.

- [ ] Feed complete mark-derived RichSpan runs plus underline/strike information into TextInput's authoritative unmasked single-line RichTextLayout, using existing shape_styled/draw_rich and rich_text_editor.rs conversion as examples. Normal TextInput remains plain by default. No new editor implementation and no opaque eraser/repaint workaround.
- [ ] Paint glyphs once. Caret, selection, horizontal scrolling, pointer-byte inversion, peer presence and link hit geometry all consume the same styled layout. Keep existing code span sans face/color/chip appearance for this repair; don't add a separate product font change. Derive decoration bounds from actual shaped ranges, with backgrounds before glyphs and rules after.
- [ ] Make attributed styles available before relevant measurement and painting, not only after plain measurement. Mark-only changes, theme/renderer scale, text edits and actual model/undo/redo adoption invalidate correct caches. Preserve complete UTF-8 spans and IME preedit behavior; any reused signature must cover all accepted style/decor inputs.
- [ ] Focused RED/GREEN: glyph-count/weights show no duplicate plain run; add/remove bold on unchanged text refreshes layout; marked end caret/selection/pixel-byte inversion agree at1×/2×; overlapping bold/link click at true edge; UTF-8/preedit adjacent to marked text; code background and underline/strike follow shaped ranges. Reuse existing tests and don't mirror implementation without an observable invariant.
- [ ] Actual Notes link route: BlockEditor currently refreshes live_link_hits before draw_block shapes current line geometry, while peer presence intentionally runs after. Move the narrow link-hit refresh to after current-frame block draw and test first draw plus style-only/scale change at the true overlapping bold/link edge. Derive hit bands from the existing authoritative selection rectangles, including reversed/mixed-direction ranges, rather than two caret endpoints; preserve the existing full-line vertical hit target. Test actual link segments and exclusion of unrelated gaps. Preserve existing BlockEditor behavior; no wider redesign. This source-backed scope ruling is necessary for the existing actual-link acceptance, not an additional app feature.
- [ ] Run affected TextInput/RichTextLine/BlockEditor module tests, relevant rich-text tests and scoped check. Fresh Notes normal/narrow/2× screenshot acceptance plus actual caret/selection/link route; root independently inspects pixels. Preserve ordinary writing density.


Use git commit --only with exact owned paths; verify the commit file list.
