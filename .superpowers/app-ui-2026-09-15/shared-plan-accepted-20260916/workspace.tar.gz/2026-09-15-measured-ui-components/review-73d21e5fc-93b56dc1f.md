# Task review package

Plan: docs/superpowers/plans/2026-09-15-measured-ui-components.md
Base: 73d21e5fc
Head: 93b56dc1f

## Commits

```
93b56dc1f test(ui): cover card keyboard activation
```

## Files

```
 .../task-5-fix-1-report.md                         |  41 +++++++
 ui/src/app.rs                                      |  62 ++++++----
 ui/src/app/card_composition_tests.rs               | 136 ++++++++++++++++++++-
 3 files changed, 211 insertions(+), 28 deletions(-)
```

## Diff

```diff
diff --git a/.superpowers/sdd/2026-09-15-measured-ui-components/task-5-fix-1-report.md b/.superpowers/sdd/2026-09-15-measured-ui-components/task-5-fix-1-report.md
new file mode 100644
index 000000000..852d54b05
--- /dev/null
+++ b/.superpowers/sdd/2026-09-15-measured-ui-components/task-5-fix-1-report.md
@@ -0,0 +1,41 @@
+# Task 5 fix 1 report — Native keyboard activation coverage
+
+Status: **DONE**. The short intrinsic card stack now has app-host coverage for a real Enter key event activating its final action exactly once.
+
+The fix began from `cec5c10c7`. The unrelated browser commit `73d21e5fc` advanced the shared branch during validation and is outside this fix's diff.
+
+## Review finding addressed
+
+The first Task 5 regression proved pointer activation, Tab reachability, and accessibility semantic activation. It did not exercise the native host's separate Enter/Space fallback. This fix adds that missing keyboard-path evidence while retaining the original semantic coverage under its accurate accessibility label.
+
+## Implementation
+
+- Added `short_card_stack_scroll_and_tab_activate_final_action_once_from_enter` to `ui/src/app/card_composition_tests.rs`.
+- The fixture uses a 360px viewport, a vertical Scrollable, an intrinsic Column, eight automatic ContentCards, and a trailing action.
+- The test verifies the action begins below the viewport, sends a real wheel event to reach it, moves host focus to it through Tab order, and sends a synthetic winit Enter press.
+- The test asserts the Enter press adds exactly one invocation. It also verifies that the release and an already handled Enter press add no invocation.
+- Extracted the existing live `AppHandler` Enter/Space fallback into private `App::handle_unconsumed_activation_key`. The live handler calls that helper at the same point in its event precedence. Its conditions and effects are unchanged: only unhandled Enter/Space presses with a focused actionable widget activate, then mark the event handled and set sync/layout dirty.
+- No card sizing, widget behavior, public API, application source, or unrelated routing changed.
+
+## RED/GREEN evidence
+
+RED after adding the host regression first:
+
+- `CARGO_BUILD_JOBS=4 CARGO_PROFILE_DEV_DEBUG=0 CARGO_PROFILE_TEST_DEBUG=0 cargo test -p ui app::card_composition_tests::short_card_stack_scroll_and_tab_activate_final_action_once_from_enter --lib`
+- Compilation failed with `E0599`: `App` had no `handle_unconsumed_activation_key` test seam for the live fallback.
+
+GREEN after extracting the unchanged fallback and completing the duplicate guards:
+
+- `CARGO_BUILD_JOBS=4 CARGO_PROFILE_DEV_DEBUG=0 CARGO_PROFILE_TEST_DEBUG=0 cargo test -p ui app::card_composition_tests --lib`
+- 2 passed: the new short-stack Enter regression and the existing `content_card_host_geometry_focus_click_and_resize_are_coherent_before_paint` regression.
+- `rustfmt --edition 2024 --check ui/src/app.rs ui/src/app/card_composition_tests.rs` — passed.
+- `git diff --check -- ui/src/app.rs ui/src/app/card_composition_tests.rs` — passed.
+
+Per the fix brief, the broad UI suite and visual captures were not repeated. Task 5's production sizing change remains unchanged from `cec5c10c7`.
+
+## Self-review
+
+- The test does not duplicate the activation fallback: both the live native handler and test route call the same private helper.
+- The test sends a real `WindowEvent::KeyboardInput` with `NamedKey::Enter`, `Pressed`, through widget dispatch before the host fallback.
+- Release and pre-handled-event assertions protect the exactly-once contract.
+- No push or merge was performed.
diff --git a/ui/src/app.rs b/ui/src/app.rs
index bf1bd778c..011d69eaa 100644
--- a/ui/src/app.rs
+++ b/ui/src/app.rs
@@ -887,20 +887,55 @@ impl App {
                 &self.bindings,
                 &self.node_map,
                 node,
                 &mut self.state.doc,
                 &self.state.root,
                 callback,
             )
         }
     }
 
+    /// Apply the native host's fallback for an Enter/Space press that the
+    /// focused widget did not consume during normal event dispatch.
+    fn handle_unconsumed_activation_key(&mut self, event: &WindowEvent, handled: &mut bool) {
+        if *handled
+            || !matches!(
+                event,
+                WindowEvent::KeyboardInput {
+                    event: winit::event::KeyEvent {
+                        logical_key: winit::keyboard::Key::Named(
+                            winit::keyboard::NamedKey::Enter | winit::keyboard::NamedKey::Space,
+                        ),
+                        state: winit::event::ElementState::Pressed,
+                        ..
+                    },
+                    ..
+                }
+            )
+        {
+            return;
+        }
+        let Some(focused) = self.focused_node else {
+            return;
+        };
+        let activated = self
+            .dispatch_node(focused, |widget, doc, root| {
+                widget.perform_action(&crate::a11y::Action::Activate, doc, root)
+            })
+            .unwrap_or(false);
+        if activated {
+            *handled = true;
+            self.needs_sync = true;
+            self.layout_dirty = true;
+        }
+    }
+
     fn initial_presence_context() -> PresenceCtx {
         // Own identity, in preference order: the handle announced on `Hello`,
         // then the fallback app id. Anything else is somebody else and gets
         // painted.
         let mut context = PresenceCtx::empty();
         context.set_own_identity(
             crate::collaboration::presence_handle_env()
                 .into_iter()
                 .chain(std::iter::once(crate::collaboration::local_user_id().0)),
         );
@@ -8523,46 +8558,21 @@ impl AppHandler {
                         ..
                     }
                 )
             {
                 handled = true;
             }
         }
 
         // If no widget consumed Enter/Space (text inputs do), activate
         // the focused control the same way a mouse click would.
-        if !handled
-            && let WindowEvent::KeyboardInput {
-                event:
-                    winit::event::KeyEvent {
-                        logical_key:
-                            winit::keyboard::Key::Named(
-                                winit::keyboard::NamedKey::Enter | winit::keyboard::NamedKey::Space,
-                            ),
-                        state: winit::event::ElementState::Pressed,
-                        ..
-                    },
-                ..
-            } = event
-            && let Some(fid) = app.focused_node
-        {
-            let did = app
-                .dispatch_node(fid, |widget, doc, root| {
-                    widget.perform_action(&crate::a11y::Action::Activate, doc, root)
-                })
-                .unwrap_or(false);
-            if did {
-                handled = true;
-                app.needs_sync = true;
-                app.layout_dirty = true;
-            }
-        }
+        app.handle_unconsumed_activation_key(&event, &mut handled);
 
         // A focused range control consumes Left/Right; Up/Down and Tab
         // still move focus. Modifiers scale the step:
         //   plain  → one step       Shift → four steps (coarse)
         //   Ctrl   → jump to min/max (Left = min, Right = max)
         // Other widgets ignore the action, falling through to
         // directional navigation below.
         if !handled
             && let WindowEvent::KeyboardInput {
                 event:
diff --git a/ui/src/app/card_composition_tests.rs b/ui/src/app/card_composition_tests.rs
index 0ceda7c51..5aad70243 100644
--- a/ui/src/app/card_composition_tests.rs
+++ b/ui/src/app/card_composition_tests.rs
@@ -1,13 +1,18 @@
 use super::*;
-use crate::widget::{Actions, Button, Card, CardGrid, Element, Text};
+use crate::widget::{Actions, Button, Card, CardGrid, Column, Element, Scrollable, Text};
 use automerge::ReadDoc;
+use std::cell::Cell;
+use std::rc::Rc;
+use winit::dpi::PhysicalPosition;
+use winit::event::{ElementState, KeyEvent, MouseScrollDelta, TouchPhase, WindowEvent};
+use winit::keyboard::{Key, KeyLocation, NamedKey, PhysicalKey};
 
 fn fixture() -> App {
     let cards: Vec<Element> = (0..3)
         .map(|index| {
             Box::new(
                 Card::composed(Box::new(Text::new(
                     &"Useful description. ".repeat(index + 1),
                 )))
                 .with_title("Connection")
                 .with_footer(Box::new(
@@ -28,22 +33,26 @@ fn fixture() -> App {
             ) as Element
         })
         .collect();
     let mut app =
         App::new_with_controlled_inputs(State::new(), Box::new(CardGrid::content_sized(cards)));
     app.init_layout();
     app
 }
 
 fn layout(app: &mut App, width: u32) {
+    layout_in(app, width, 1600);
+}
+
+fn layout_in(app: &mut App, width: u32, height: u32) {
     app.layout_dirty = true;
-    run_layout_pass(app, app.root_node.unwrap(), width, 1600, 1.0, false, None).unwrap();
+    run_layout_pass(app, app.root_node.unwrap(), width, height, 1.0, false, None).unwrap();
 }
 
 fn controls(app: &App) -> Vec<(String, KurboRect)> {
     app.focusable_order
         .iter()
         .map(|&node| {
             app.inspect_node(node, |widget| {
                 (widget.test_id().unwrap().to_string(), widget.get_rect())
             })
             .unwrap()
@@ -109,10 +118,133 @@ fn content_card_host_geometry_focus_click_and_resize_are_coherent_before_paint()
                 .to_string())
                 .unwrap(),
             "primary-1"
         );
         for (_, rect) in controls(&app) {
             assert!(rect.x0 >= -1.0 && rect.x1 <= f64::from(width) + 1.0);
             assert!(rect.height() >= 40.0);
         }
     }
 }
+
+fn named_key_event(key: NamedKey, state: ElementState) -> WindowEvent {
+    let logical_key = Key::Named(key);
+    let event = KeyEvent::synthetic(
+        winit::event::RawKeyEvent {
+            physical_key: PhysicalKey::Unidentified(winit::keyboard::NativeKeyCode::Unidentified),
+            state,
+        },
+        logical_key.clone(),
+        None,
+        KeyLocation::Standard,
+        false,
+        None,
+        logical_key,
+    );
+    WindowEvent::KeyboardInput {
+        device_id: winit::event::DeviceId::dummy(),
+        event,
+        is_synthetic: false,
+    }
+}
+
+fn send_widget_then_host_fallback(app: &mut App, event: &WindowEvent) -> bool {
+    let mut handled = false;
+    let mut focus_target = None;
+    app.root_widget.handle_event(
+        event,
+        1.0,
+        &app.modifiers,
+        &mut app.state.doc,
+        &app.state.root,
+        &mut handled,
+        &mut focus_target,
+        app.root_node.unwrap(),
+        &app.taffy,
+    );
+    if let Some(target) = focus_target {
+        app.set_focused_node(Some(target));
+    }
+    app.handle_unconsumed_activation_key(event, &mut handled);
+    handled
+}
+
+#[test]
+fn short_card_stack_scroll_and_tab_activate_final_action_once_from_enter() {
+    let invocations = Rc::new(Cell::new(0));
+    let activated = invocations.clone();
+    let mut content = Column::new()
+        .with_no_padding()
+        .with_intrinsic_height()
+        .with_gap(8.0);
+    for index in 0..8 {
+        content = content.push(Box::new(Card::composed(Box::new(Text::new(&format!(
+            "Application {index}: {}",
+            "A useful multi-line description that remains inside its card. ".repeat(3)
+        ))))));
+    }
+    content = content.push(Box::new(
+        Button::new("final-action", "Open all applications", None).on_click(move || {
+            activated.set(activated.get() + 1);
+        }),
+    ));
+    let mut app = App::new_with_controlled_inputs(
+        State::new(),
+        Box::new(Scrollable::new_vertical().with_child(Box::new(content))),
+    );
+    app.init_layout();
+    layout_in(&mut app, 480, 360);
+
+    let final_node = *app
+        .focusable_order
+        .last()
+        .expect("final action is focusable");
+    let before = app
+        .inspect_node(final_node, |widget| widget.get_rect())
+        .unwrap();
+    assert!(before.y0 >= 360.0, "final action starts below the viewport");
+
+    let wheel = WindowEvent::MouseWheel {
+        device_id: winit::event::DeviceId::dummy(),
+        delta: MouseScrollDelta::PixelDelta(PhysicalPosition::new(0.0, -10_000.0)),
+        phase: TouchPhase::Moved,
+    };
+    assert!(send_widget_then_host_fallback(&mut app, &wheel));
+    layout_in(&mut app, 480, 360);
+    let after = app
+        .inspect_node(final_node, |widget| widget.get_rect())
+        .unwrap();
+    assert!(
+        after.y0 >= 0.0 && after.y1 <= 360.0,
+        "final action is reachable after scrolling: {after:?}"
+    );
+
+    for _ in 0..app.focusable_order.len() {
+        assert!(app.focus_tab(false));
+    }
+    assert_eq!(app.focused_node, Some(final_node));
+
+    assert!(send_widget_then_host_fallback(
+        &mut app,
+        &named_key_event(NamedKey::Enter, ElementState::Pressed)
+    ));
+    assert_eq!(invocations.get(), 1, "Enter adds exactly one invocation");
+    send_widget_then_host_fallback(
+        &mut app,
+        &named_key_event(NamedKey::Enter, ElementState::Released),
+    );
+    assert_eq!(
+        invocations.get(),
+        1,
+        "the key release must not invoke the action again"
+    );
+    let mut already_handled = true;
+    app.handle_unconsumed_activation_key(
+        &named_key_event(NamedKey::Enter, ElementState::Pressed),
+        &mut already_handled,
+    );
+    assert_eq!(
+        invocations.get(),
+        1,
+        "a widget-consumed Enter press must not invoke the host fallback"
+    );
+}
```
