# SDD ledger — plan: docs/superpowers/plans/2026-09-15-measured-ui-components.md

Not started. Depends on capture-fidelity completion/review. Existing isolated linkedworktree codex/macos-shell.

| Pair/task | Interface/consistency check | Ruling |
|---|---|---|
| Task1 internal | Resolved-style API + EmptyState first consumer | Legacy APIs unchanged; don't replace Text's renderer-relative letter spacing |
| Task2 internal | RichTextLine base override + TextInput shaping | Remove verified second multiplier; test actual glyph/caret geometry |
| Task3 internal | Scrollable viewport minimum + explicit child size | Opt-in only, fixed dimensions win; long content remains intrinsic |
| Task4 internal | Measurement + hidden callbacks + a11y | One deliverable; toggled boolean alone insufficient |
| Task1→2 | TextRenderer normalization available; RichTextLine base contract distinct | Don't normalize base input fonts |
| Task1→4 | Toolbar uses resolved theme fonts and normalized measure/draw | Same cached measured metrics for paint/hit/overflow |
| Task2→3 | Both exercise TextInput; ownership differs | Task2 owns shaping, Task3 owns parent viewport minimum; execute sequentially |
| Capture→all | Truthful scaled renderer and layout | Do not compensate for previously invalid screenshots |

Ruling: no new header/spacing DSL before real migrations establish need. Existing Card/Actions/FormPage satisfy normal-size composition. Shared Toolbar substantial interaction task receives most capable implementer and scoped review.

Ruling: add Task5 intrinsic Card/CardGrid minimum propagation and execute it before Tasks1–4. App Task3 fresh narrow capture still overlaps entire sections after local content-sized grids; source-backed diagnosis identifies shared minimum-height contract. App worker saves independent edits first, shared Task5 fixes dependency, then app acceptance proceeds. No additional app pixel-height workarounds.

| Added pair/task | Interface check | Ruling |
|---|---|---|
| Task5 internal | Automatic minimum contribution vs fixed rows | RED first; retain exact authored rows and zero min-width |
| Task5→App3 | Cards/grids nested in intrinsic scrolling stacks | Shared fix must prove full catalogue sections and Region controls; app acceptance depends on it |
| Task5→Tasks1–4 | Same UI test crate, no production file overlap expected | Execute sequentially; no text contract changes in minimum fix |
| Task5→Column | Parent implicit rows expose contribution defect | Preserve Column defaults and pre-existing format diff; don't globally add padding/minimums |

Task5 active: /root/intrinsic_card_fix, gpt-5.6-sol high, BASE5ca1d1d83. App Task3 saved d3591fe85 +report5ca1d1d83; tests full_narrow_catalogue_keeps_discover_section_below_ready_cards and region_preview_follows_every_format_control RED awaiting shared fix.

Ruling: external concurrent commit19f65aab7 only adds Chromium browser plan/spec after Task5 BASE5ca1d1d83. Preserve unrelated commit. Task5 review may use19f65aab7 as effective base because git show verified exactly two docs and no UI/app source, excluding unrelated work from package; original dispatch base remains recorded. Worker notified.

Task5 implementation cec5c10c7 complete, review pending /root/intrinsic_card_review (sol medium). Effective review base5673a5e67 excludes concurrent Chromium-only commits19f65aab7/736da9dc7/5673a5e67. Package review-5673a5e67-cec5c10c7.md verified scoped3files. Card10+13, Column15, Scrollable34, Store/Settings dependent regressions pass. Broad UI3070lib +294integration pass;3 integration failures reproduced identically in isolated no-task comparison. Root visual notes task5-controller-visual.md pass overlap. Do not mark complete before review.

Task5 review: no production defect, spec NEEDS FOLLOW-UP / quality PASS WITH CONCERN because semantic Activate does not test actual Enter/Space host fallback. Fix round1 resumed /root/intrinsic_card_fix, FIX_BASEcec5c10c7, narrowly allowed ui/src/app/card_composition_tests.rs host regression + report labels. No broad suite or captures repeat. Themes fix remains queued until gatepasses.

Ruling fixround1: allow a private App::handle_unconsumed_activation_key extraction from live native handler to expose the exact existing Enter/Space fallback to host tests; app.rs now in scoped review. Must preserve handled/release behavior and keep live handler calling same helper; no duplicated test-only fallback or wider routing changes. Root inspected diff and authorized narrow seam.

Task5 fixround1 commit93b56dc1f; privateAppnativefallbackextract +hostEnterregression;2appcardtestspass,formatdiffclean,no sizingchange. Concurrent browser-only73d21e5fc excluded by effectivefixreviewbase73d21e5fc, verified filelist. /root/intrinsic_card_review reactivated scoped re-review, report expected task-5-fix-1-review.md. Wait gate then resumeThemesfix /root/browse_composition_resume.

Task 5: complete — cec5c10c7 +93b56dc1f; initial review keyboard gap addressed fixround1, task-5-fix-1-review.md PASS spec/PASS quality/no findings. Root8PNGvisualpass. Tasks1–4 still not started.

Task1 active /root/resolved_text_empty_state (solhigh), BASE7231a8170 pendingverificationofconcurrentHEAD. Requirements task-1-brief.md; publicresolvedstyle +EmptyStatemeasurement. Task5complete;Tasks2–4notstarted. Existingunrelated renderer_regressions.rsdirty mustpreserve.

Task1 initial gates14text_scale+1theme_resolved pass. Text's private normalization preserves renderer-relative letter spacing; public fully-resolved helper must not change that legacy contract. Tiny-pane ruling reiterated toworker: retained actualscrollroute required, immediate paint minimum essential height documented/exposed; entirelybelowpane actionrect is not usable visible target. Preservemanualparentdimensions, noaction/fontdrop/shrink. WorkercheckingScrollable lifecycle, may sendboundedoptions; helper/wrapping proceed independently.

Task1 tiny-pane design approved: EmptyState intrinsic autoheight +min-height100% retains normalcentering andessentialheight, into_scrollable() usesexistingScrollable explicitroute, minimum_essential_height exposesimmediatecontract; whollyoutsidevisibleactionreturnsnohit target. Requirevisible+pointer/realkeyboard activationafter scroll, notonlyoffset advancement; docsopt-in/mannualbounds. No globalscrollbehaviorchange.

Task1 self-review found semanticActivate-only scroll regression; controller reiterated realhostTab/Enter requirement before completion. Worker now adds host test to ui/src/app/card_composition_tests.rs usingexistingprivatefallback; allowed scope extension. Additional unrelated browser commits bfae6f8ca/f1af3ca83 and guidedsetup docs4821b02a4/8fe8026dd/18dd6af2f filelists verified, no Task1 overlap; exclude from upcoming scoped package.

Task1 implementation committed17110d403; scoped review active /root/resolved_text_review (solhigh), package review-12c7cc90c-17110d403.md. Effectivebase12c7cc90c verified unrelated files from7231a8170 throughparent; alltracked inownedmanifest. Focused16EmptyState+15scale+1resolvedtheme+1geometry+2spacing+1hostkeyboard pass, check/format pass. Broad3090pass/1concurrentChromiumfailure/2ignored, integration notrun. Root3PNGchecked; keepVPNheaderresidual. Waitreviewgate. Task2brief regenerated+globalconstraints ready; no Task2 dispatch yet.

Task 1: complete —17110d403, task-1-review.md specPASS/qualityAPPROVED/no findings; root3VPNPNGs verified. Public TextRenderer::renderer_input_style and WordOrGlyph available, EmptyState::into_scrollable/minimum_essential_height accepted. VPNTorheaderresidual Task22. Task2 ready for dispatch.

Task2 active /root/editor_measurement (solhigh), BASE0e1ad3bb6, task-2-brief.md. Scope ui rich_text_line/text_input/block_editor +code_editorwrappertestsalsoexplicitlyallowed; noappcode/Scrollableedits. BroadUIalreadyrun, focusededitorregressions+checkonlyunlessnewconcern. Task1accepted;Tasks3/4pending.

Read-only preparation while Task2 runs: /root/toolbar_preflight (sol high) checks Task4 concrete ContextMenu/overlay contracts; no production edits or tests. Root Task3 source-backed candidate recorded in task-3-preflight.md; it is an unverified hypothesis, not a substitute for RED/GREEN. Only Task2 remains active production work.

Ruling: Task4 preflight found ContextMenu lacks bounded placement/scrolling. Permit a scoped opt-in anchored route in context_menu.rs, shared by Toolbar; preserve legacy placement behavior and existing tests. Reuse existing Widget focus/overlay/modal/synthetic-action hooks, no trait expansion or second popup system. Plan and Task4 brief updated with preflight pointer. Cost if wrong: bounded menu behavior must be revised; no existing menu caller migration is assumed. Task4 remains not started.

Task2 progress: RED confirmed double-scaling (16px→64px at2x), multiline height208.5 vs shaped401, unchanged gutter39.84 at1/2x. Focused RichTextLine25, CodeEditor22, multiline21 passed before final checks. Transient unrelated Chromium/profiling compile errors observed; worker preserves those files. Controller identified theme/renderer mismatch in new measure path versus draw; worker asked to cover actual build(theme2)/measure(renderer1)/draw(theme2) and cache theme contract as needed. Full TextInput module requested once because single-line text_band also touched. Direct last-successful exact test executable allowed only if Task2 source unchanged since that build, with explicit provenance and no claim current full compilation passes.

Concurrent commits through5e0d447f3 inspected: browser/guided-setup only except owned documentatione6bdeb72f. No Task2 source file overlap; owned-commits.json updated exclusions.

Task2 implementation committed3f13fb4eb; review active /root/editor_measurement_review (sol high), package review-4446ad236-3f13fb4eb.md and task-2-review-context.md. All four final module filters pass (99/25/22/69), current cargo check/format pass. Root app build/captures in task2-after-20260916 pending. Task2 not complete until review.

Shared-index race resolved: an external bare commit briefly swept staged Task2 files into c0780f77a, then external owner repaired to docs-only4446ad236 and restored Task2 index entries. Root verified source preserved; worker committed exact paths via --only to3f13fb4eb. No history rewrite by this task. Future worker commits must use explicit pathspec/--only and verify file list; do not assume shared index belongs to one worker.

Task 2: fix round 1/5 dispatched to editor_measurement after task-2-review.md found CodeEditor theme propagation and actual CRDT sync/history measurement invalidation. FIX_BASE3f13fb4eb. Root app captures generated; visual acceptance pending. Minor stale comments included in fix. Atomic path-only commits required.

Task6: added from root-confirmed Notes glyph overdraw and read-only diagnosis. DependsTask2, sharesTextInput/RichTextLine; execute sequentially after existing shared tasks. Reuses existing RichTextLayout styled APIs, preserves code-face appearance. No new source edits yet. Ruling: repair styled text through one authoritative shaped buffer rather than erasing underlying glyphs; avoids incorrect caret/link geometry, cost if wrong is revising narrow attributed input API.

Task2fixround1 execution recovery: nocheckpoint for>15min after sourceedits09:52andREDmessage. Controller verified no active task Cargo process; interrupt returnedprevious_status=pending_init although roster saidrunning. Resumed sameworker fromsavedsource, noREDrepeat; waitingGREEN/report/commit. Do not confuse execution restart with next review fixround.

Task2fixround1 complete83c269dac: exact2sources+report; CodeEditor23/TextInput99 and2exactregressions/checkpass. Scopedre-review activeeditor_measurement_review vi review-task2-fix1-83c269dac.md; gitlog confirms noothereditorchanges since3f13fb4eb. Root rebuiltNotes/Calendar/Typst successfully, newwide/narrow/largecapturesrunningtask2-fix1-20260916. NoTask3dispatchuntilreviewandimages.

Task 2: complete —3f13fb4eb +83c269dac, fixround1reviewPASSspec/qualityApproved/all4findingsaddressed. Root rebuilt3apps and individuallyinspected9freshwide/narrow/largeimages task2-fix1-20260916, no newregression; explicitlyqueuedNotesstyledoverdrawTask6, CalendarappchromeTextGeometry23, Typsttoolbar/statusComposition6. Finalallappinteractionsstillpending.

Task3active/root/writing_surface gpt6astrahigh, BASE83c269dac, task-3-brief/preflight. Soleproductionworker. Need scopedreview+rootactualScratchpadimages afterreport; preexistingapp untrackedonlyone-linepatchnotcommitted. Shared4then6queued.

Task3RED verified via public Driver integrationtests ui/tests/scrollable_test.rs:8tests6pass2fail, emptyeditorbottom36 vsfooter360 (normal+narrowdynamic). Temporarytestmodule removed; integrationplacementaccepted. Externalheadlesscfgtestcompileerrors brieflyblocked, externalownerfixed; preservedall. Worker nowimplementsownedwrapper, appoptinonlyafterGREEN.

Task3 Ruling: integrationfound firstwheel swallowed by TextInput subpixeloverflow (content1073.6/Taffy1073). Permit narrowlytested intrinsicmultilinemeasure containment correction intext_input.rs; no manualheights/singleline/scrollconsumptionchange. Candidateceil intrinsicheight; requireactualfirstwheelRED/GREENandcurrentgeometrytests. Costifwrong: revert/refine rounding correction, nothidewithrepeatedwheel. Addedbrief/planexplicitly. Wrapper9testsGREENbeforeextension, Scratchpad7testsGREEN, v2supplementalimages provisional.

Task3correction: isolated18/18.1fontfirstwheel tests pass, fractional-heightcauseNOTestablished. Worker instructed diagnoseactualharnessevent/focussequence beforeTextInputchange. Priorrulingisscopepermissionforverifiedcorrectiononly, notmandateceil. Brief/plan/closureprovisionalwordingcorrected; noTextInputproductioneditmade.

Task3 actualRED bothestablished: visiblefinalline fixture rect1079/content1079.375 consumes0.375 firstwheel, outerunchangedwhilefocused; secondlowerclicktyping lostbecauseScrollableprefocusoverwritesalreadyfocusedchild. Ruling: allowdeferred backgroundfocusfallback afterunhandledchilddispatch, retainingbarfocus/explicitchildfocus/outsidebehavior. Requireoptin+defaultrepeatclick andexistingpane/barchecks. Costifwrong: reviseeventfallback; do notgatebehindwritingoptionbecausegenericroutingbugconfirmed. Ceil intrinsicheighthasverifiedREDnow. Themehelpersalsochangedtowith_text_scalefortruthful2×.

Task3candidatecommittedfba9ea50f exact4paths,app1linepatchuntrackedpreserved. Scope reviewactivewriting_surface_review astrhigh vi review-task3-fba9ea50f.md (includesapppatch). Green12integration/34Scrollable/99TextInput/23CodeEditor/7Scratchpad/4layoutharness/check. Rootstandard6PNGs capturedtask3-writing-20260916allviewed;4finalharnesslong-bottomPNGsalsoallviewed, finallinevisibleandSavefixed. Do notclosebeforeindependentreview. Separatetrailing_line_diagnosis readonlyactive.

Task 3: complete —fba9ea50f pluspreserveduntrackedScratchpadone-linepatch; task-3-review.md specPASS/qualityApproved, noneCriticalImportant. Root6standard+4finallongbottomPNGvisualgatepassed. Minor(deferred): existingmacOS__eh_framewarning, baselineunrelated; pointfinalreviewatit, noTask3fixneeded. Ruling: originalScratchpadhierarchyimbalance resolvedbyexpandedwritingregion; retain readabletagline/manual-savehint because editornowdominant, costifwrongfuturecopyrefinement. Separatetrailingnewlineinvestigationstillopenandnotclaimedfixed.

Task4active/root/measured_toolbar gpt6astrahigh, BASEfba9ea50f. Soleproductionworker; requirements task-4-brief.md/preflight. Shared3accepted, Shared6pending, trailingnewlineinvestigationreadonlyrunning.

Ruling: confirmed trailing-LF attributed shaping defect becomes Shared Task7, after4 before6, isolated richtext boundary+TextInput tests. Task6 consumes repaired shape_styled; no simultaneous source writers. Preflight:7↔2/3 same TextInput tests, preserve accepted measurement/ceil/focus;7↔6 same RichTextLayout dependency, sequence7first;7↔4 no shared production file;7 self-check tests match final empty row/attrs contract, no LF-decoration redesign. Cost if wrong: revise normalization, never mask with shorter measurement. Diagnosis has runtime proof; Scratchpad new finding remains open, its four prior findings stay closed.

Task4checkpoint: boundedmenucompiles,initial6ToolbarchecksGREEN; lifecycle/callback/focus/resize testsactive. Controllerrequestedexistingtestfixturerender normal+narrow2×/openoverflow/finalcommand forvisualgate; briefamended, noapp/sourceextension.

Shared4candidate1b3eac1b4exact3pathsverified; independent/root/measured_toolbar_review astrhigh active via review-task4-1b3eac1b4.md. OriginalBASEfba9ea50f effectiveBASEd02c1ade3 after verifiedinterveningpathhistory (onlyTask4changes toolbar/context_menu). Root2fixturePNGspass; focusedworkerchecksallgreen; noTask4closureyet. NextproductionShared7then6, thenremainingappplans.

Task4fixround1 activeBASE2aff2e6c7822276508c60d7e414aee212141a3df; review has3Important (exportedbounds, stalehoverwrongtarget, nonleftstuckcapture). Rootcheckedactualeventbranches+AccessKitbounds, acceptsall. Brief task-4-fix-1.md; sameworkerresume, scopedre-reviewafter. No otherproductionworker.

Task4fixround1 REDconfirmedall3: emittedboundsNone, samepositionsecondclick firesA, rightclick+Escape retainsRowcapture. RegressionusesactualRowdispatch andpartial/offscreenbounds. Workerimplementingtoolbar.rsonly; ContextMenuunchanged.

Shared4fixround1c7b2d576b committedexactToolbar+report; re-reviewactive measured_toolbar_review. Use review-task4-fix1-scoped-c7b2d576b.md ONLY (effectivec66ec996c excludesverifiedImagercommit); unscopedpackagecontainsunrelatedcommit. RED0/3→GREEN3/3,Toolbar18/menu15/layout7/checkformatpass; no paint/layoutchange,capturescarried. NextShared7then6 onlyaftergate.

Task 4: complete —1b3eac1b4+c7b2d576b; task-4-fix-1-review.md all3findingsADDRESSED/specPASS/qualityApproved, nonewissues. Rootnormal+narrow2×fixturespass (archivedtask4-candidate-captures). Onlyknownbaseline__eh_framewarning, liveOSaccessibilitynotclaimed. Shared7soleproduction/root/trailing_empty_line_fix solhigh BASEc7b2d576b dispatched; thenShared6, thenallremainingappwork.

Shared7candidatefd7b0964f exact3ownedpaths verified (richtext production/TextInput regressions/report), independenttrailing_empty_line_review solhigh active via review-task7-fd7b0964f.md. OriginalBASEc7b2d576b effectiveca5b92f36 excludesverifiedexternalbrowser/docs; onlytaskcommit touchedownedpaths. richtext20/TextInput100/CodeEditor23/Scrollable12/check/format/new3postformatpass. Reportlabelsadditionalmutationchecksassourcereasoning, not executed. NextShared6afterreviewgate.

Task 7: complete —fd7b0964f, independenttask-7-review.md specPASS/qualityApproved/no findings. Scopedrichtext20/TextInput100/CodeEditor23/Scrollable12/check/format/new3postformatGREEN. ClosesScratchpadfinal-empty-line runtimefinding; original4closedstayclosed, finalappmatrixpending. Shared6soleproduction/root/single_shape_rich_marks astrhigh BASE90e68a2e9 active; briefwithaccepted7dependency, preserveitsnormalization. RootagainviewedNoteswide+2×task2-fix1PNGs, boldoverdrawconfirmed.

Task6firstGREEN: glyphcount3vsold4; mark-onlyboldtogglechangescaret/selection1×/2×. ChipprepassbeforeTextInputselection; BlockEditorpeerpresenceafterlinespreserved. Furthermeasure-before-draw/UTF8IME/fullsignature/modelreplaytests+actualNotesinteraction/capturespending. ExistingNotes--shotsroutesavailable; noappsourceextensionapproved.

Task6Ruling: approve narrowblock_editor.rs current-frame link-hit refresh/test. Rootverifiedrefresh_live_link_hits atdrawstart3838 vsdraw_blockloop3925; peerpresencealreadyafterloopforfreshcharpositions. MovinglinkrefreshafterdrawnecessaryforactualNoteslinkacceptance; firstdrawpreviouslyempty, style/scalepreviousframeedge. Ownedfilecleanbeforeaddition. RequireRED/GREENfirstdraw+style/scaleedge, nootherBlockEditor/appredesign. Costifwrong: adjustphaseplacement/narrowinvalidation, notstalehitapproximation. Brief/planupdated.

Task6transientexternalcfgtestblocker: Chromiumtests NavigationDirection missing/NavigationHistory+RequestNavigationHistory directionfieldsabsent. EarlierownfocusedglyphGREEN/measurementUTF8REDcompiled. RootinstructedpreserveChromium, continueindependentsource/library/appcapturework, retryonceexternalsource settles; noisolatedtarget/blindloops. Task6gateremainspending.

Task6blockerclearedononere try (Chromiumownerresolved; noownedchanges). ActualBlockEditorlinkREDfirstdrawNone→GREENrefreshaftercurrentdraw/presence. Attributed5testsGREENmeasureweights400/700/400at1×/2×,UTF8IMEeventcommit,chip/linkgeometry,fullstyles,actualCRDTsync/undo/redo. Notesnormalbuildsucceeded; workerstandaloneNotesAppharnessinevidencedir(noappsourceedits) checkingcaret/dragcodeselection/boldlinkedge navigation1×/2×. Rootownsstandardcapturematrixafterfinalbinaryhash; workerownsinteractioncaptures.

Task6 ruling: use existing TextInput selection rectangles for BlockEditor link hit bands, preserving the full-line vertical target. Worker self-review found that two caret endpoints still fail reversed/mixed-direction ranges. This is within the approved live-link scope and authoritative-shaped-range requirement; no new API. Require a focused regression for actual segments and exclusion of unrelated gaps. If the change is wrong, revise the range mapping rather than retain endpoint approximation.

Task6 candidate73dde03c6 exact3production+report verified. OriginalBASE90e68a2e9, effectivefe4908e59 excludesverifiedconcurrentcommits; ownedpathhistoryonlyTask6. Independent /root/single_shape_review astrahigh active, review-task6-73dde03c6.md. Root6standard+10interactionimagesPASS; finalbinaryc1f09... final6PNGsbyteidentical;265tests/checkpass. No closure before gate.

Task 6: complete —73dde03c6, task-6-review.md specPASS/qualityApproved; no Critical/Important. Controller resolves visual/provenance caveat with six final standard PNGs and ten interaction PNGs individually inspected via byte-identical final recapture/hashes; current three source hashes match capture provenance. Prior Task2/7 invariants confirmed by retained regression modules and scoped reviewer checks. Minor deferred: existing compact-unwind warning and optionalClippy100errors/12warnings, no cleanlintclaim; finalwholeplanreview must see this baseline. All7sharedtasks accepted; wholeplanreview/finalappmatrix stillpending.

Wholeplanreviewcheckpoint: existingClippybaseline wording is task-relative. /root/measured_ui_final_review found owned sharedTasks1–4 added lines among diagnostics (TextInput3755/3779,Scrollable1085,Toolbar1/452/687,EmptyState634). Ruling: disclose as cumulative shared-plan lint debt, not claim all100errorsunrelated. Await finalseverity/assessment; no rootproductioncleanup. Costifwrong: scopedlintfix/review, not concealment of validation limits.

Whole shared plan: accepted — final-review.md specPASS/Approvedwithminorlintdebt; noCritical/Important. Existing broad-suite failures and current finalallapp/UX/Linux gaps remain explicit. Minor lint diagnostics from Tasks1–4 are owned cumulative debt, not all outsidebaseline. No productionfixwave required by verdict. Retain task workspace until finalallappacceptance archives/links are finalized; user evidence must survive cleanup.
