# Review package: 2aff2e6c7..c7b2d576b

## Commits
c7b2d576b Fix toolbar popup pointer state and exported accessibility bounds
c66ec996c fix(imager): protect migration destination namespaces

## Files changed
 .../task-4-report.md                               |  36 ++
 .../2026-09-16-guided-folder-copy/task-1-report.md |  44 +-
 Cargo.lock                                         |   1 +
 apps/imager/Cargo.toml                             |   3 +
 .../src/setup/destination_security/macos_acl.rs    | 136 ++++++
 apps/imager/src/setup/destination_security/mod.rs  |  22 +
 apps/imager/src/setup/destination_security/unix.rs | 127 ++++++
 .../src/setup/destination_security/windows.rs      | 473 +++++++++++++++++++++
 apps/imager/src/setup/migration.rs                 | 282 ++++++++++--
 apps/imager/src/setup/mod.rs                       |   1 +
 ui/src/widget/toolbar.rs                           | 275 +++++++++++-
 11 files changed, 1350 insertions(+), 50 deletions(-)

## Diff
diff --git a/.superpowers/sdd/2026-09-15-measured-ui-components/task-4-report.md b/.superpowers/sdd/2026-09-15-measured-ui-components/task-4-report.md
index 47edd9aca..f686d557a 100644
--- a/.superpowers/sdd/2026-09-15-measured-ui-components/task-4-report.md
+++ b/.superpowers/sdd/2026-09-15-measured-ui-components/task-4-report.md
@@ -85,10 +85,46 @@ b9b87e5052b19b95137fc0cdfadbd982730c44164685e50a3f730696cbaa5e36  ui/src/widget/
 - Confirmed `Widget` remains unchanged and existing ContextMenu/TextInput route tests pass.
 - Confirmed actual shared host admission/settlement is exercised, not just manually seeded geometry.
 - Confirmed explicit narrow allocations and menu viewport containment with ordinary and 200% rendered evidence.
 - App-specific consumer migrations and live OS focus/assistive-technology acceptance are outside this shared-widget task. No full workspace suite, app startup, or end-user app screenshot claims are made.
 - `open_anchored` is an owned-menu route; callers should run `layout_within` before paint (Toolbar does this in normal draw, then uses the same geometry in overlay/input). Existing retained legacy ContextMenu sizing remains unchanged.
 - No known blocking issue remains from scoped tests/self-review. Independent controller code review remains the next gate.
 
 ## Commit discipline
 
 Commit only `ui/src/widget/toolbar.rs`, `ui/src/widget/context_menu.rs`, and this report with `git commit --only`. Verify the resulting commit file list; preserve all unrelated working-tree and index content. The returned task status records the resulting commit ID.
+
+## Fix round 1 — accepted review findings
+
+Verified starting HEAD `2aff2e6c7` and read `task-4-fix-1.md` plus `task-4-review.md`. Used receiving-code-review/systematic-debugging to check the named event branches and AccessKit export contract before implementing the accepted fixes. Production scope for this round is **Toolbar only**; ContextMenu, the Widget trait and AccessKit bridge are unchanged. Concurrent non-owned work was preserved.
+
+### Resolutions
+
+1. **Exported accessibility geometry:** visible command/overflow nodes now use `with_bounds` from their authoritative painted rects. The menu node exports its popup rect; menu items export the clipped ContextMenu row rect. Scrolled-out actions export `Rect::ZERO`, remain semantically focusable/visible, and receive real clipped bounds when semantic focus reveals them. The regression asserts the emitted AccessNode fields themselves, including a partially clipped row, zero-area offscreen row and focus-to-reveal transition.
+2. **Stale pointer targets after popup routing:** Toolbar stores the current logical pointer position even while ContextMenu consumes events. Opening clears its old hover/armed target; closing and relayout re-hit-test the stored position. Press/release also re-hit-test before arming/activating. Regression covers keyboard opening from hovered A and pointer opening from hovered Overflow, selection of hidden B, a same-position second click with no CursorMoved, and variants with/without intervening layout. Only B fires once and Overflow stays closed.
+3. **Non-left release suppression:** only a left press routed through the popup arms its matching release suppression. Right/middle press-release followed by Escape leaves no pointer capture. A regression uses a real Row with two retained Toolbars, admitted shared layout and Row event dispatch; the subsequent sibling left click reaches its callback once. Existing outside-left-dismiss suppression remains covered by the full Toolbar group.
+
+### Focused RED / GREEN and final verification
+
+Every Cargo command retained the repository target cache and used `CARGO_BUILD_JOBS=4 CARGO_PROFILE_DEV_DEBUG=0 CARGO_PROFILE_TEST_DEBUG=0`.
+
+- `cargo test -p ui --lib widget::toolbar::lifecycle_tests::review_ -- --nocapture`
+  - **RED: 0 passed, 3 failed** for the exact accepted defects: exported bounds `None` versus painted rect; callback counts `[1,1,0,…]` versus `[0,1,0,…]`; stuck capture after a right press-release and Escape.
+  - **GREEN: 3 passed** after the fixes. All requested variants are contained in those tests, including real Row sibling routing.
+- `cargo test -p ui --lib widget::toolbar -- --nocapture`: **18 passed, 1 existing manual GPU fixture ignored**.
+- `cargo test -p ui --lib context_menu -- --nocapture`: **15 passed**, including legacy TextInput copy/cut routes.
+- `cargo test -p ui --lib widget::layout -- --nocapture`: **7 passed**.
+- `cargo check -p ui --lib`: **passed**.
+- `rustfmt --edition 2024 --check ui/src/widget/toolbar.rs`: **passed**.
+- `git diff --check -- ui/src/widget/toolbar.rs`: **passed**.
+
+The known macOS `__eh_frame` lib-test linker warning remains. Shared-target/package-cache lock waits and recompilation of concurrent vendor changes occurred; no build cache isolation or dependency changes were introduced by this worker. The current lib-test binary path is `target/debug/deps/ui-c93bc6d5c202339c`.
+
+Validated Toolbar source SHA-256: `ce4f839a59fb02e1ba0ddf0785722af0c25b1476dd5ffe9d10c17b03a618585e`.
+
+### Self-review and limits
+
+Checked that platform-exported bounds now come from AccessNode output, while fallback click bounds and semantic action routes remain intact. Checked that popup cursor events update the same pointer used after close/layout, and every left press/release activation revalidates geometry. Verified that right/middle events cannot create unmatched release suppression and that the host regression actually reaches the sibling callback through Row.
+
+No layout, typography, popup paint or callback ownership changes were made in this fix round; the accepted rendered captures/provenance above remain retained and were not regenerated. No broad suite or live macOS accessibility/focus acceptance claim is added. Independent scoped re-review remains the next gate.
+
+Round-1 commit is restricted with `git commit --only` to `ui/src/widget/toolbar.rs` and this report; verify its exact file list after committing. Returned worker status records the commit ID.
diff --git a/.superpowers/sdd/2026-09-16-guided-folder-copy/task-1-report.md b/.superpowers/sdd/2026-09-16-guided-folder-copy/task-1-report.md
index b1b4af10c..b9470800d 100644
--- a/.superpowers/sdd/2026-09-16-guided-folder-copy/task-1-report.md
+++ b/.superpowers/sdd/2026-09-16-guided-folder-copy/task-1-report.md
@@ -1,42 +1,42 @@
 # Task 1: verified fresh-destination folder copy
 
-Status: implemented and locally verified; native Fedora verification passed. Native Windows runtime verification remains a release gate.
+Status: implemented, including review fix round 1; native macOS/Fedora verification passed. Ready for namespace-security re-review. Native Windows runtime verification remains a release gate.
 
 ## Scope and implementation
 
 Implemented `copy_folder(source, destination, cancelled, progress)` in `apps/imager/src/setup/migration.rs`, exported from `setup/mod.rs`.
 
 - Explicit native absolute grants are independently opened. Every path component is pinned with a no-follow handle and observed identity; source/destination ancestry is revalidated before output creation and publication. Symlink components and overlapping source/destination grants are refused. Destination creation is exclusive and never merges into existing content.
 - Moved the scanner's unchanged `metadata_nofollow`, `open_directory_nofollow`, and identity comparison into focused `setup/nofollow.rs`. Existing scanner callsites and race tests still use those exact checks. No native-installation or view changes.
 - Recursively handles ordinary files and empty directories through pinned parent capabilities. Access failures, changed entries, links, special entries, unsupported Windows reparse/cloud-placeholder attributes, and destination name errors become explicit relative-path outcomes. `OsString` names are preserved without lossy conversion.
 - Copies through a bounded 64 KiB buffer to an exclusive operation-owned temporary file. Flushes/syncs, rereads the destination, compares SHA-256, rereads source content, and revalidates source identity, length, modification time, permissions and relevant platform metadata before publication. Source handles are read-only.
 - Publishes with an atomic hard link that cannot clobber an existing destination. A conflicting entry is retained unchanged; the source remains unchanged. A filesystem without hard links fails explicitly.
 - Cancellation is checked between entries and stream chunks and before publication. Verified output remains in place. Temporary cleanup first checks the pinned parent and exact temporary-file identity and never deliberately unlinks a replacement or recursively removes output.
 - Copies access/modification times for files and directories and verifies exact timestamp preservation. Linux O_PATH directory handles and Windows read-only scanner handles require a separate destination-only no-follow open with identity checking; Windows requests FILE_WRITE_ATTRIBUTES only for this destination handle.
-- New Unix directories/files use private 0700/0600 permissions, subject to the process umask. Windows uses destination security inheritance. Foreign ownership and original permission modes are never restored.
+- New Unix directories/files use private 0700/0600 permissions, subject to the process umask. Windows directories receive an explicit protected private DACL at creation; their children inherit only that private policy. Foreign ownership and original permission modes are never restored.
 - `CopyReport` lists verified paths and bytes, skipped/failed relative paths, interruption/enumeration state and fidelity disclosures. `CopyProgress` reports only verified counts/bytes plus the current relative path. General metadata limitations are disclosed separately; timestamp failures make the report incomplete.
 
 ## Verification
 
 All fixtures use real native absolute temporary paths; no personal files were imported.
 
 ### Red/green evidence
 
 - Initial `cargo test -p imager --lib setup::migration`: compiling stub, 0 passed / 5 expected failures. Log: `/tmp/imager-migration-red.log`.
 - Expanded initial tests: 0 passed / 7 expected failures before implementation. Log: `/tmp/imager-migration-red-2.log`.
 - Implemented engine: 7 passed / 0 failed. Log: `/tmp/imager-migration-green-1.log`.
 - Actual copy/stage/publication boundary tests: 15 passed / 0 failed. Log: `/tmp/imager-migration-boundaries.log`.
 - Mutation check disabling destination digest rejection: corruption test failed on unsafe successful publication (14 passed / 1 failed), then production checks restored. Log: `/tmp/imager-migration-mutation-red.log`.
 - Mutation check disabling source digest/metadata rejection: same-length content edit with restored mtime failed on unsafe successful publication (0 passed / 1 failed), then production checks restored. Log: `/tmp/imager-migration-source-red.log`.
 
-### Final results
+### Initial implementation results
 
 - macOS ARM64: `cargo test -p imager --lib setup::`: **59 passed, 0 failed**, including all 15 migration tests and the scanner tests after extraction. Log: `/tmp/imager-migration-setup-green.log`.
 - Fedora ARM64, native VM verification performed by root after syncing the stable four source files: `cargo test --locked -p imager --lib setup::`: **58 passed, 0 failed**, including all 15 migration tests and directory timestamp preservation; no warnings. Root session: `48855`. The different total reflects platform-gated existing setup tests / workspace snapshot.
 - `cargo clippy -p imager --lib --no-deps`: exit 0; no migration/scanner errors or warnings. Existing unrelated `apps/imager/src/model.rs:285` needless-return warning remains. Log: `/tmp/imager-migration-clippy-lib.log`.
 - `cargo clippy -p imager --lib --tests --no-deps -- -A clippy::panic_in_result_fn -A clippy::float_cmp`: exit 0. Exact command-level allowances are for unrelated test errors in `setup/view.rs:1288` (panic worker spy returns Result) and `main.rs:293–294` (screenshot-theme float assertions). Existing main.rs needless-borrow/model.rs needless-return warnings remain. No migration lint suppressions beyond the justified non-Windows Result-return helper cfg allowance. Log: `/tmp/imager-migration-clippy-tests.log`.
 - Unsuppressed test clippy identified the unrelated issues above; root has been informed and owns the follow-up. No unrelated files were edited to address them.
 - `git diff --check -- apps/imager/src/setup`: clean.
 
 Tests cover copied bytes, empty directories, unchanged originals, overlap/existing destinations, cancelled initial grants, symlink roots, replaced destination parent, unsupported link/socket entries, private Unix modes, timestamp/fidelity reporting, corrupt staged bytes, changed source content despite restored mtime, publication conflicts, replaced temporary files, retention of verified output after cancellation, cancellation after staging, Unicode names / multiple chunks, and a descendant swapped to a link. Windows has a platform-specific parent-pinning test: cap directory handles deny rename rather than allowing the Unix replacement fixture.
 
@@ -47,10 +47,48 @@ Tests cover copied bytes, empty directories, unchanged originals, overlap/existi
 - The source is not a filesystem snapshot or locked against writers. A detected change is incomplete/retryable; copying does not establish atomic consistency across multiple files or prevent later external edits. Filesystem-managed access-time updates can occur when reading originals.
 - Ownership, original permissions, ACLs, extended attributes, alternate streams, creation times, sparse allocation and hard-link relationships are not preserved, and this is explicitly disclosed in every report. Supported timestamp failures are not silently downgraded.
 - Known Windows reparse/offline/recall placeholder flags are refused; there is no general provider-specific POSIX cloud-placeholder adapter. Ordinary readable files are verified as exposed by the host filesystem.
 - Hard-link support and exact access/modification timestamp preservation are required for success. Filesystems that lack these semantics return explicit failures. Nesting beyond 128 traversed levels is explicitly incomplete; file descriptors track active ancestors rather than all discovered descendants.
 - Cleanup conservatively leaves a temporary entry if its parent/path identity can no longer be trusted or removal fails. It never cleans an entire partially copied destination; already verified files remain for an explicitly authorized later resume.
 - This is unprivileged copying into user-controlled fresh directories. Source/destination validation does not grant collaboration sharing, cloud upload, synchronization, execution or privilege escalation.
 
 ## Repository hygiene
 
 Initial base was `b7c998714`; resumed after independent view fixes at `2fdba6dbc`. Unrelated working-tree changes and concurrent commits were preserved. Only `migration.rs`, `nofollow.rs`, `folders.rs`, `setup/mod.rs`, and this report belong to the scoped commit. Cargo manifests/lockfile were not staged or changed for this task.
+
+
+## Review fix round 1: protected destination namespace (latest)
+
+Both P1 findings are addressed by establishing the destination namespace's permissions before the first creation and revalidating that protection before subsequent name-based writes. A post-mkdir identity observation alone was not sufficient: another account with parent write access could swap the child before observation; the same access could race link/unlink after validation. These findings were reproduced and are superseded by the controls below.
+
+### Protection and trust boundary
+
+- New focused `setup/destination_security/{mod,unix,macos_acl,windows}.rs` modules hold platform permission logic. Source permissions, source compatibility and the reviewed scanner primitives are unchanged.
+- `PinnedDirectory::validate_destination` examines the full pinned ancestor chain, including the protected next child's actual observed metadata. It runs before mkdir, before temporary creation, before verification/publication/cleanup, and before destination timestamp writes. Created directories are marked as requiring private security, with additional checks on every new temporary file.
+- Unix requires root/current-effective-user ownership throughout the destination ancestry. Group/other-writable ancestors are refused unless sticky semantics protect a root/current-user-owned child. Sticky bits alone do not authorize foreign-owned descendants. Every fresh directory/file must be current-user-owned with no group/other mode permissions.
+- Linux explicitly supports ext-family, XFS, Btrfs, tmpfs and overlay filesystem permission semantics, where POSIX ACL masks limit inherited grants to the 0700/0600 creation mode. Unknown/network/FUSE/FAT semantics are refused rather than treated as mode-enforced privacy.
+- macOS requires local APFS/HFS with ownership enforcement enabled (`MNT_IGNORE_OWNERSHIP` is refused). Native handle-based Darwin extended ACL inspection rejects foreign mutation grants, inherit-only mutation grants, inheritable foreign disclosure grants, unknown allow types/permission bits, and any nontrusted access on new private objects. Harmless non-inheritable read or deny ACLs remain compatible. Native APFS fixtures established that an open descriptor without an extended ACL returns NULL/ENOENT; that specific no-ACL result is accepted only after supported-filesystem verification.
+- Windows queries owner/DACL using `GetSecurityInfo` on pinned handles. It trusts the current user, SYSTEM, Administrators and the known privileged TrustedInstaller owner for OS ancestry; NULL/unavailable/unknown/conditional ACL forms fail closed. Nontrusted mutation rights (including DELETE_CHILD, WRITE_DAC, WRITE_OWNER, data/attribute/EA writes) are refused. Ordinary ADD_SUBDIRECTORY-only ancestor rights remain allowed because they cannot replace a protected existing child, and exclusive creation refuses collisions.
+- Windows creation uses `CreateDirectoryW` with an explicit protected SDDL descriptor granting current user/SYSTEM/Administrators with child inheritance. There is no permissive inherited-ACL window before a later chmod/ACL fix. The spelling is derived from the pinned parent handle while the whole cap directory chain denies rename/delete; the result is reopened no-follow and checked for expected ownership, private DACL and protected status. Only local fixed/removable volumes reporting persistent ACL support are considered; remote/unknown volume types are refused.
+- **Threat boundary:** malicious processes already running as the same account or with administrator privileges are excluded. Such principals can alter final output regardless of this protocol. Identity checks still detect controlled same-account replacements at observable boundaries, but this implementation does not claim unconditional immutability against those actors. Other-account writable namespaces are refused before adoption, publication or cleanup.
+- No source or pre-existing parent permission mutations were introduced. Unsupported security returns an explicit error, leaving unrelated entries untouched. Once a destination loses trusted permissions, publication and cleanup stop; owned temporary entries may remain rather than risk an unsafe unlink.
+
+### Fix-round verification
+
+- Added native filesystem regressions before implementation. The ordinary repository RED command initially hit unrelated shared `ui/src/app.rs` compilation errors; the exact-source isolated harness then produced **1 passed / 5 failed**, catching unsafe direct parent, unsafe ancestor, changed permissions during staging, macOS effective write ACL and macOS inherit-only write ACL. Log: `/tmp/imager-namespace-isolated-red.log`. The initially passing case proved safe sticky paths remained usable.
+- Final macOS repository `cargo test -p imager --lib setup::`: **69 passed / 0 failed / 1 explicitly ignored**. The ignored test requires root solely to create a disposable foreign-owned child. Log: `/tmp/imager-namespace-repo-test-final.log`.
+- Exact-source macOS isolated suite: **22 passed / 0 failed** before adding the opt-in root test, covering all migration cases plus namespace refusals and harmless read-only ACL compatibility. Log: `/tmp/imager-namespace-unix-green.log`.
+- Root's native Fedora full repository setup suite: **65 passed / 0 failed**, no warnings, session `99904`. This was before adding the explicit ignored root-only fixture; no Linux production behavior changed afterward.
+- Root's native Fedora isolated source suite on XFS: **19 passed / 0 failed**, no warnings, session `78542`.
+- Root repeated those same **19 passing** tests with TMPDIR on a freshly formatted disposable 256 MiB Btrfs loop volume. The volume was unmounted/detached/removed afterward; no retained-OS/host disks were used. Repeatability script: `.superpowers/sdd/2026-09-16-guided-folder-copy/test-native-btrfs.sh`.
+- Root built the opt-in sticky/foreign-owner test as the ordinary guest user and ran only its compiled executable as root: `--exact migration::tests::namespace_sticky_parent_does_not_trust_a_foreign_owned_child --ignored`: **1 passed / 0 failed**. This changes ownership only on the newly created empty fixture child. Repeatability script: `.superpowers/sdd/2026-09-16-guided-folder-copy/test-native-sticky.py`.
+- Exact repository sources and all Windows tests compile with `cargo check --manifest-path /var/folders/p6/fg2jh4md76b0fd2s6m_qcpv40000gn/T/qos-copy-windows-check-fu19as05/Cargo.toml --target x86_64-pc-windows-msvc --tests`: exit 0. All **77** harness dependency name/version/source/checksum identities match the repository lock. Log: `/tmp/imager-namespace-windows-check-final.log`.
+- Three native Windows ACL tests are included and compile: unsafe DELETE_CHILD parent rejection before mkdir; safe ADD_SUBDIRECTORY-only ancestor compatibility; and protected child/private copied-file ACLs despite permissive inherit-only parent rules. **These Windows tests have not been executed natively.** The full Windows application cross-check remains separately blocked by native ring/Windows SDK headers; isolated compilation does not substitute for native runtime evidence.
+- Exact-source isolated clippy passes on both macOS and the Windows target with `--lib -- -D clippy::pedantic -A clippy::must_use_candidate -D clippy::arithmetic_side_effects -D clippy::indexing_slicing`. The must-use allowance matches the repository configuration. Logs: `/tmp/imager-namespace-clippy-final.log`, `/tmp/imager-namespace-windows-clippy.log`.
+- Repository `cargo clippy -p imager --lib --tests --no-deps -- -A clippy::float_cmp`: exit 0. The sole allowance is for unrelated `main.rs:293–294` screenshot-theme float assertions. Existing unrelated model.rs needless-return and main.rs needless-borrow warnings remain; the previous view panic-spy lint was fixed by its owning task. No new migration/security lint warnings. Log: `/tmp/imager-namespace-repo-clippy-final.log`.
+- Scoped `git diff --check`: clean.
+
+### Remaining scope and repository hygiene
+
+This closes the reviewed other-account destination replacement windows under the stated trust boundary. It does not add durable resume, UI integration, or installation changes. Native Windows user-temp/NTFS execution and representative permission configurations remain a release gate; unsupported ACL/filesystem configurations must remain explicit refusals until separately validated.
+
+The fix round adds only a narrow Windows-target `windows-sys 0.61.2` dependency with Foundation/Security/Authorization/FileSystem/Threading features, and its single `imager` dependency entry in Cargo.lock. Existing registry package identities are reused. The unrelated scratchpad/root manifest/lockfile work is preserved and not staged. Source changes are limited to migration integration, the private setup module declaration, and the focused destination-security modules, plus this report. Independent commits that appeared during implementation were preserved.
diff --git a/Cargo.lock b/Cargo.lock
index ae87388ad..a66cb84df 100644
--- a/Cargo.lock
+++ b/Cargo.lock
@@ -6567,20 +6567,21 @@ dependencies = [
  "qos-actions",
  "qos-app",
  "reqwest 0.12.28",
  "runtime-dylib",
  "serde",
  "serde_json",
  "sha2 0.10.9",
  "taffy",
  "tempfile",
  "vello",
+ "windows-sys 0.61.2",
  "winit",
  "zbus 4.4.0",
  "zstd",
 ]
 
 [[package]]
 name = "imagesize"
 version = "0.13.0"
 source = "registry+https://github.com/rust-lang/crates.io-index"
 checksum = "edcd27d72f2f071c64249075f42e205ff93c9a4c5f6c6da53e79ed9f9832c285"
diff --git a/apps/imager/Cargo.toml b/apps/imager/Cargo.toml
index d547739e1..5222ef4e2 100644
--- a/apps/imager/Cargo.toml
+++ b/apps/imager/Cargo.toml
@@ -48,12 +48,15 @@ zbus = { workspace = true, optional = true, default-features = true }
 
 [target.'cfg(unix)'.dependencies]
 libc.workspace = true
 
 [target.'cfg(target_os = "linux")'.dependencies]
 ui = { package = "qos-app", path = "../../crates/app/qos-app", features = ["portal"] }
 
 [target.'cfg(not(target_os = "linux"))'.dependencies]
 ui = { package = "qos-app", path = "../../crates/app/qos-app" }
 
+[target.'cfg(windows)'.dependencies]
+windows-sys = { version = "0.61.2", features = ["Win32_Foundation", "Win32_Security", "Win32_Security_Authorization", "Win32_Storage_FileSystem", "Win32_System_Threading"] }
+
 [lints]
 workspace = true
diff --git a/apps/imager/src/setup/destination_security/macos_acl.rs b/apps/imager/src/setup/destination_security/macos_acl.rs
new file mode 100644
index 000000000..17767c45d
--- /dev/null
+++ b/apps/imager/src/setup/destination_security/macos_acl.rs
@@ -0,0 +1,136 @@
+//! Darwin extended ACLs can grant access even when mode bits are 0700.
+//! ABI constants/signatures follow the macOS SDK sys/acl.h and membership.h.
+use std::ffi::c_void;
+use std::fs::File;
+use std::io;
+use std::os::fd::AsRawFd;
+use std::ptr;
+
+use super::refusal;
+
+const KNOWN_PERMISSIONS: u64 = 0x0000_3ffe | (1 << 20);
+
+type AclObject = *mut c_void;
+unsafe extern "C" {
+    fn acl_get_fd_np(fd: i32, kind: u32) -> AclObject;
+    fn acl_free(object: AclObject) -> i32;
+    fn acl_get_entry(acl: AclObject, selector: i32, entry: *mut AclObject) -> i32;
+    fn acl_get_tag_type(entry: AclObject, tag: *mut u32) -> i32;
+    fn acl_get_permset_mask_np(entry: AclObject, mask: *mut u64) -> i32;
+    fn acl_get_flagset_np(entry: AclObject, flags: *mut AclObject) -> i32;
+    fn acl_get_flag_np(flags: AclObject, flag: u32) -> i32;
+    fn acl_get_qualifier(entry: AclObject) -> AclObject;
+    fn mbr_uid_to_uuid(uid: u32, uuid: *mut u8) -> i32;
+}
+
+struct Allocation(AclObject);
+impl Drop for Allocation {
+    fn drop(&mut self) {
+        // SAFETY: every instance owns an allocation returned by the ACL API.
+        unsafe {
+            acl_free(self.0);
+        }
+    }
+}
+
+pub(super) fn check(file: &File, current: u32, private: bool) -> io::Result<()> {
+    let mut user = [0_u8; 16];
+    let mut root = [0_u8; 16];
+    // SAFETY: both UUID outputs are 16-byte writable arrays.
+    if unsafe { mbr_uid_to_uuid(current, user.as_mut_ptr()) } != 0
+        || unsafe { mbr_uid_to_uuid(0, root.as_mut_ptr()) } != 0
+    {
+        return Err(refusal("cannot identify destination ACL principals"));
+    }
+    // SAFETY: valid borrowed fd; ACL_TYPE_EXTENDED from Darwin's sys/acl.h.
+    let raw = unsafe { acl_get_fd_np(file.as_raw_fd(), 0x100) };
+    if raw.is_null() {
+        let error = io::Error::last_os_error();
+        // On a live APFS/HFS descriptor Darwin returns ENOENT when no extended
+        // ACL is attached (verified with native ACL/no-ACL fixtures).
+        return if error.raw_os_error() == Some(libc::ENOENT) {
+            Ok(())
+        } else {
+            Err(error)
+        };
+    }
+    let acl = Allocation(raw);
+    let mut selector = 0; // ACL_FIRST_ENTRY; ACL_NEXT_ENTRY is -1 on Darwin.
+    loop {
+        let mut entry = ptr::null_mut();
+        // SAFETY: ACL allocation stays live; entry is an output into that ACL.
+        let result = unsafe { acl_get_entry(acl.0, selector, &raw mut entry) };
+        if result == -1 {
+            let error = io::Error::last_os_error();
+            // Darwin returns -1/EINVAL at the end, unlike POSIX ACL APIs.
+            if error.raw_os_error() == Some(libc::EINVAL) {
+                break;
+            }
+            return Err(error);
+        }
+        selector = -1;
+        if entry.is_null() {
+            return Err(refusal("invalid destination ACL entry"));
+        }
+        // SAFETY: entry belongs to the still-live native ACL allocation.
+        unsafe {
+            check_entry(entry, &user, &root, private)?;
+        }
+    }
+    Ok(())
+}
+
+unsafe fn check_entry(
+    entry: AclObject,
+    user: &[u8; 16],
+    root: &[u8; 16],
+    private: bool,
+) -> io::Result<()> {
+    let mut tag = 0;
+    let mut mask = 0;
+    let mut flags = ptr::null_mut();
+    // SAFETY: entry is a native ACL entry; all outputs are correctly sized.
+    if unsafe { acl_get_tag_type(entry, &raw mut tag) } != 0
+        || unsafe { acl_get_permset_mask_np(entry, &raw mut mask) } != 0
+        || unsafe { acl_get_flagset_np(entry, &raw mut flags) } != 0
+    {
+        return Err(io::Error::last_os_error());
+    }
+    match tag {
+        2 => return Ok(()), // Denies cannot grant mutation or disclosure rights.
+        1 => {}
+        _ => return Err(refusal("unsupported destination ACL entry type")),
+    }
+    // SAFETY: entry is valid; the returned UUID allocation requires acl_free.
+    let qualifier = unsafe { acl_get_qualifier(entry) };
+    if qualifier.is_null() {
+        return Err(io::Error::last_os_error());
+    }
+    let qualifier = Allocation(qualifier);
+    // SAFETY: an extended ACL qualifier is a UUID, exactly 16 bytes.
+    let principal = unsafe { ptr::read_unaligned(qualifier.0.cast::<[u8; 16]>()) };
+    if principal == *user || principal == *root {
+        return Ok(());
+    }
+    // SAFETY: flags belongs to entry; these are Darwin's inheritance flags.
+    let file_inherit = unsafe { acl_get_flag_np(flags, 1 << 5) };
+    let directory_inherit = unsafe { acl_get_flag_np(flags, 1 << 6) };
+    if file_inherit < 0 || directory_inherit < 0 {
+        return Err(io::Error::last_os_error());
+    }
+    let mutation =
+        (1 << 2) | (1 << 4) | (1 << 5) | (1 << 6) | (1 << 8) | (1 << 10) | (1 << 12) | (1 << 13);
+    if mask & !KNOWN_PERMISSIONS != 0 {
+        return Err(refusal("unsupported destination ACL permission bits"));
+    }
+    // Include inherit-only mutation grants: a newly created 0700 directory
+    // would inherit them. Refuse inheritable read grants too, to keep output
+    // private from its first creation without editing an existing parent's ACL.
+    if mask != 0 && (private || mask & mutation != 0 || file_inherit != 0 || directory_inherit != 0)
+    {
+        return Err(refusal(
+            "destination ACL grants another principal access to the private namespace",
+        ));
+    }
+    Ok(())
+}
diff --git a/apps/imager/src/setup/destination_security/mod.rs b/apps/imager/src/setup/destination_security/mod.rs
new file mode 100644
index 000000000..69ffc1253
--- /dev/null
+++ b/apps/imager/src/setup/destination_security/mod.rs
@@ -0,0 +1,22 @@
+//! Destination namespace protection, separate from read-only source access.
+//!
+//! The guarantee excludes hostile processes running as the current account or
+//! an administrator: those principals can alter final output regardless of the
+//! copy protocol. Other accounts must not be able to replace operation-owned
+//! names between identity checks and mkdir/link/unlink. Unknown security or
+//! filesystem semantics are a refusal, not an assumption of private access.
+
+use std::io;
+
+#[cfg(unix)]
+mod unix;
+#[cfg(unix)]
+pub(super) use unix::{check_directory, check_private_file, create_directory};
+#[cfg(windows)]
+mod windows;
+#[cfg(windows)]
+pub(super) use windows::{check_directory, check_private_file, create_directory};
+
+fn refusal(message: &str) -> io::Error {
+    io::Error::new(io::ErrorKind::PermissionDenied, message)
+}
diff --git a/apps/imager/src/setup/destination_security/unix.rs b/apps/imager/src/setup/destination_security/unix.rs
new file mode 100644
index 000000000..355efe8bf
--- /dev/null
+++ b/apps/imager/src/setup/destination_security/unix.rs
@@ -0,0 +1,127 @@
+use std::ffi::OsStr;
+use std::fs::File;
+use std::io;
+use std::os::fd::AsRawFd;
+use std::os::unix::fs::MetadataExt;
+use std::path::Path;
+
+use cap_primitives::fs::{DirBuilderExt, DirOptions, Metadata};
+
+use super::refusal;
+
+#[cfg(target_os = "macos")]
+#[path = "macos_acl.rs"]
+mod macos_acl;
+
+fn effective_uid() -> u32 {
+    // SAFETY: geteuid has no input pointers or preconditions.
+    unsafe { libc::geteuid() }
+}
+
+fn trusted_owner(uid: u32, current: u32) -> bool {
+    uid == current || uid == 0
+}
+
+pub(crate) fn check_directory(
+    file: &File,
+    child: Option<&Metadata>,
+    private: bool,
+) -> io::Result<()> {
+    check_filesystem(file)?;
+    let observed = file.metadata()?;
+    let current = effective_uid();
+    if !observed.is_dir() || !trusted_owner(observed.uid(), current) {
+        return Err(refusal("destination ancestry has an untrusted owner"));
+    }
+    if private {
+        check_private_file(file)?;
+    } else if observed.mode() & 0o022 != 0 {
+        if observed.mode() & 0o1000 == 0 {
+            return Err(refusal(
+                "destination ancestor is writable by another account without sticky protection",
+            ));
+        }
+        // Sticky directories protect only the entry owner (and directory owner
+        // / root). Checking the parent bit alone does not protect a foreign
+        // child. None means the future child will be created by this account.
+        if let Some(child) = child {
+            use cap_primitives::fs::MetadataExt;
+            if !trusted_owner(child.uid(), current) {
+                return Err(refusal(
+                    "sticky destination ancestor does not protect the selected child",
+                ));
+            }
+        }
+    }
+    #[cfg(target_os = "macos")]
+    macos_acl::check(file, current, private)?;
+    Ok(())
+}
+
+pub(crate) fn check_private_file(file: &File) -> io::Result<()> {
+    let metadata = file.metadata()?;
+    let current = effective_uid();
+    if metadata.uid() != current || metadata.mode() & 0o077 != 0 {
+        return Err(refusal(
+            "created destination is not private to the current account",
+        ));
+    }
+    #[cfg(target_os = "macos")]
+    macos_acl::check(file, current, true)?;
+    Ok(())
+}
+
+pub(crate) fn create_directory(parent: &File, name: &OsStr) -> io::Result<()> {
+    let mut options = DirOptions::new();
+    options.mode(0o700);
+    cap_primitives::fs::create_dir(parent, Path::new(name), &options)
+}
+
+fn check_filesystem(file: &File) -> io::Result<()> {
+    #[cfg(any(target_os = "macos", target_os = "linux"))]
+    {
+        let mut status = std::mem::MaybeUninit::<libc::statfs>::uninit();
+        // SAFETY: valid borrowed fd and correctly sized writable output.
+        if unsafe { libc::fstatfs(file.as_raw_fd(), status.as_mut_ptr()) } != 0 {
+            return Err(io::Error::last_os_error());
+        }
+        // SAFETY: fstatfs succeeded and initialized the entire output.
+        let status = unsafe { status.assume_init() };
+        #[cfg(target_os = "linux")]
+        {
+            // These local filesystems enforce Unix ownership and POSIX ACL
+            // masks. Inherited default ACLs are restricted by 0700/0600 at
+            // every creation. Do not infer this for FUSE, CIFS, NFS or FAT.
+            if !matches!(
+                u64::try_from(status.f_type)
+                    .map_err(|_| refusal("unknown destination filesystem type"))?,
+                0xef53 | 0x5846_5342 | 0x9123_683e | 0x0102_1994 | 0x794c_7630
+            ) {
+                return Err(refusal(
+                    "destination filesystem permission semantics are unsupported",
+                ));
+            }
+        }
+        #[cfg(target_os = "macos")]
+        {
+            // SAFETY: Darwin statfs contains a nul-terminated f_fstypename.
+            let name = unsafe { std::ffi::CStr::from_ptr(status.f_fstypename.as_ptr()) };
+            if !matches!(name.to_bytes(), b"apfs" | b"hfs")
+                || status.f_flags & libc::MNT_LOCAL as u32 == 0
+                || status.f_flags & libc::MNT_IGNORE_OWNERSHIP as u32 != 0
+            {
+                return Err(refusal(
+                    "destination needs local APFS/HFS with ownership enforcement",
+                ));
+            }
+        }
+        Ok(())
+    }
+    #[cfg(not(any(target_os = "macos", target_os = "linux")))]
+    {
+        let _ = file;
+        Err(refusal(
+            "destination permission verification is unavailable on this platform",
+        ))
+    }
+}
diff --git a/apps/imager/src/setup/destination_security/windows.rs b/apps/imager/src/setup/destination_security/windows.rs
new file mode 100644
index 000000000..e670c2356
--- /dev/null
+++ b/apps/imager/src/setup/destination_security/windows.rs
@@ -0,0 +1,473 @@
+//! Native handle-based ACL validation and creation-time private descriptors.
+//! No permission changes are made to existing parents or source objects.
+use std::ffi::{OsStr, OsString, c_void};
+use std::fs::File;
+use std::io;
+use std::os::windows::ffi::{OsStrExt, OsStringExt};
+use std::os::windows::io::AsRawHandle;
+use std::path::{Component, Path, PathBuf};
+use std::ptr;
+
+use cap_primitives::fs::Metadata;
+use windows_sys::Win32::Foundation::{CloseHandle, HANDLE, LocalFree};
+use windows_sys::Win32::Security::Authorization::{
+    ConvertSidToStringSidW, ConvertStringSecurityDescriptorToSecurityDescriptorW, GetSecurityInfo,
+    SE_FILE_OBJECT,
+};
+use windows_sys::Win32::Security::{
+    ACCESS_ALLOWED_ACE, ACE_HEADER, ACL, DACL_SECURITY_INFORMATION, GENERIC_MAPPING, GetAce,
+    GetLengthSid, GetSecurityDescriptorControl, GetTokenInformation, INHERIT_ONLY_ACE, IsValidAcl,
+    IsValidSid, MapGenericMask, OWNER_SECURITY_INFORMATION, PSID, SE_DACL_PROTECTED,
+    SECURITY_ATTRIBUTES, TOKEN_QUERY, TOKEN_USER, TokenUser,
+};
+use windows_sys::Win32::Storage::FileSystem::{
+    CreateDirectoryW, DELETE, FILE_ALL_ACCESS, FILE_DELETE_CHILD, FILE_GENERIC_EXECUTE,
+    FILE_GENERIC_READ, FILE_GENERIC_WRITE, FILE_WRITE_ATTRIBUTES, FILE_WRITE_DATA, FILE_WRITE_EA,
+    GetDriveTypeW, GetFinalPathNameByHandleW, GetVolumeInformationByHandleW, GetVolumePathNameW,
+    WRITE_DAC, WRITE_OWNER,
+};
+use windows_sys::Win32::System::Threading::{GetCurrentProcess, OpenProcessToken};
+
+use super::refusal;
+
+const SYSTEM_SID: &str = "S-1-5-18";
+const ADMINISTRATORS_SID: &str = "S-1-5-32-544";
+// Windows Modules Installer is the privileged owner of standard OS directories.
+const TRUSTED_INSTALLER_SID: &str =
+    "S-1-5-80-956008885-3418522649-1831038044-1853292631-2271478464";
+const FILE_PERSISTENT_ACLS: u32 = 8;
+const DRIVE_FIXED: u32 = 3;
+const DRIVE_REMOVABLE: u32 = 2;
+
+struct LocalAllocation(*mut c_void);
+impl Drop for LocalAllocation {
+    fn drop(&mut self) {
+        // SAFETY: all non-null instances own a LocalAlloc-family SDK output.
+        if !self.0.is_null() {
+            unsafe {
+                LocalFree(self.0);
+            }
+        }
+    }
+}
+struct Token(HANDLE);
+impl Drop for Token {
+    fn drop(&mut self) {
+        // SAFETY: owns the token handle returned by OpenProcessToken.
+        unsafe {
+            CloseHandle(self.0);
+        }
+    }
+}
+
+unsafe fn sid_text(sid: PSID) -> io::Result<String> {
+    // SAFETY: callers supply an SID within a live validated SDK buffer.
+    if sid.is_null() || unsafe { IsValidSid(sid) } == 0 {
+        return Err(refusal("invalid security principal"));
+    }
+    let mut text = ptr::null_mut();
+    // SAFETY: valid SID; text is a writable pointer output.
+    if unsafe { ConvertSidToStringSidW(sid, &raw mut text) } == 0 {
+        return Err(io::Error::last_os_error());
+    }
+    let allocated = LocalAllocation(text.cast());
+    let mut length = 0;
+    // SAFETY: the API returns a nul-terminated LocalAlloc UTF-16 string.
+    while unsafe { *text.add(length) } != 0 {
+        length = length
+            .checked_add(1)
+            .ok_or_else(|| refusal("SID string length overflow"))?;
+    }
+    // SAFETY: length was measured within the returned terminated allocation.
+    let value = String::from_utf16(unsafe { std::slice::from_raw_parts(text, length) })
+        .map_err(|_| refusal("invalid SID encoding"));
+    drop(allocated);
+    value
+}
+
+fn current_user() -> io::Result<String> {
+    let mut raw = ptr::null_mut();
+    // SAFETY: GetCurrentProcess returns a pseudo handle; raw is an output.
+    if unsafe { OpenProcessToken(GetCurrentProcess(), TOKEN_QUERY, &raw mut raw) } == 0 {
+        return Err(io::Error::last_os_error());
+    }
+    let token = Token(raw);
+    let mut bytes = 0;
+    // SAFETY: zero-length query obtains the required TOKEN_USER buffer size.
+    unsafe {
+        GetTokenInformation(token.0, TokenUser, ptr::null_mut(), 0, &raw mut bytes);
+    }
+    if (bytes as usize) < std::mem::size_of::<TOKEN_USER>() || bytes > 1024 * 1024 {
+        return Err(refusal("cannot size current-user security token"));
+    }
+    // usize storage provides alignment for TOKEN_USER on both Windows ABIs.
+    let mut buffer = vec![0_usize; (bytes as usize).div_ceil(std::mem::size_of::<usize>())];
+    // SAFETY: aligned buffer has at least bytes capacity; token is live.
+    if unsafe {
+        GetTokenInformation(
+            token.0,
+            TokenUser,
+            buffer.as_mut_ptr().cast(),
+            bytes,
+            &raw mut bytes,
+        )
+    } == 0
+    {
+        return Err(io::Error::last_os_error());
+    }
+    // SAFETY: successful TokenUser query initialized a TOKEN_USER with SID
+    // storage inside buffer, which remains live until sid_text returns.
+    unsafe { sid_text((*buffer.as_ptr().cast::<TOKEN_USER>()).User.Sid) }
+}
+
+fn trusted(sid: &str, user: &str) -> bool {
+    sid == user || matches!(sid, SYSTEM_SID | ADMINISTRATORS_SID | TRUSTED_INSTALLER_SID)
+}
+
+struct Security {
+    allocation: LocalAllocation,
+    owner: PSID,
+    dacl: *mut ACL,
+}
+impl Security {
+    fn query(file: &File) -> io::Result<Self> {
+        let mut descriptor = ptr::null_mut();
+        let mut owner = ptr::null_mut();
+        let mut dacl = ptr::null_mut();
+        // SAFETY: handle stays live; all pointers are SDK outputs. Cap's read
+        // directory handles request GENERIC_READ, including READ_CONTROL.
+        let result = unsafe {
+            GetSecurityInfo(
+                file.as_raw_handle(),
+                SE_FILE_OBJECT,
+                OWNER_SECURITY_INFORMATION | DACL_SECURITY_INFORMATION,
+                &raw mut owner,
+                ptr::null_mut(),
+                &raw mut dacl,
+                ptr::null_mut(),
+                &raw mut descriptor,
+            )
+        };
+        let allocation = LocalAllocation(descriptor);
+        if result != 0 {
+            return Err(io::Error::from_raw_os_error(result.cast_signed()));
+        }
+        // NULL DACL means unrestricted access; never interpret it as empty.
+        if owner.is_null()
+            || dacl.is_null()
+            || descriptor.is_null()
+            || unsafe { IsValidAcl(dacl) } == 0
+        {
+            return Err(refusal(
+                "destination security descriptor is unavailable or unrestricted",
+            ));
+        }
+        Ok(Self {
+            allocation,
+            owner,
+            dacl,
+        })
+    }
+
+    fn check(&self, user: &str, private: bool) -> io::Result<()> {
+        // SAFETY: owner belongs to the live GetSecurityInfo allocation.
+        let owner = unsafe { sid_text(self.owner)? };
+        if !trusted(&owner, user) || (private && owner != user) {
+            return Err(refusal("destination owner is not a trusted principal"));
+        }
+        // SAFETY: dacl was returned and validated by the SDK.
+        let count = unsafe { (*self.dacl).AceCount };
+        for index in 0..count {
+            let mut ace = ptr::null_mut();
+            // SAFETY: native ACL remains allocated; index is within AceCount.
+            if unsafe { GetAce(self.dacl, u32::from(index), &raw mut ace) } == 0 {
+                return Err(io::Error::last_os_error());
+            }
+            // SAFETY: GetAce returned a valid ACE_HEADER within the ACL.
+            let header = unsafe { &*ace.cast::<ACE_HEADER>() };
+            // Ordinary allow and deny entries are understood. Callback,
+            // object-specific and conditional entries require another adapter.
+            if !matches!(header.AceType, 0 | 1) {
+                return Err(refusal("unsupported destination ACL entry type"));
+            }
+            if header.AceType == 1 {
+                continue;
+            }
+            if !private && u32::from(header.AceFlags) & INHERIT_ONLY_ACE != 0 {
+                continue;
+            }
+            if header.AceSize < 16 {
+                return Err(refusal("malformed destination ACL entry"));
+            }
+            // SAFETY: allow ACE has header/mask/SID layout; minimum SID fits.
+            let allowed = unsafe { &*ace.cast::<ACCESS_ALLOWED_ACE>() };
+            let sid = ptr::addr_of!(allowed.SidStart).cast_mut().cast();
+            // SAFETY: the SID is in an OS-validated ACE; verify its entire
+            // length is within that ACE before converting it to a string.
+            if unsafe { GetLengthSid(sid) } > u32::from(header.AceSize).saturating_sub(8) {
+                return Err(refusal("destination ACL principal exceeds its entry"));
+            }
+            let principal = unsafe { sid_text(sid)? };
+            if trusted(&principal, user) {
+                continue;
+            }
+            let mut mask = allowed.Mask;
+            let mapping = GENERIC_MAPPING {
+                GenericRead: FILE_GENERIC_READ,
+                GenericWrite: FILE_GENERIC_WRITE,
+                GenericExecute: FILE_GENERIC_EXECUTE,
+                GenericAll: FILE_ALL_ACCESS,
+            };
+            // SAFETY: pointers reference initialized local values.
+            unsafe {
+                MapGenericMask(&raw mut mask, &raw const mapping);
+            }
+            let unsafe_rights = DELETE
+                | FILE_DELETE_CHILD
+                | WRITE_DAC
+                | WRITE_OWNER
+                | FILE_WRITE_DATA
+                | FILE_WRITE_EA
+                | FILE_WRITE_ATTRIBUTES;
+            // ADD_SUBDIRECTORY alone is permitted for ordinary C:\ ancestry:
+            // it cannot replace protected existing children. Exclusive mkdir
+            // rejects name collisions; new children receive an explicit DACL.
+            if (private && mask != 0) || mask & unsafe_rights != 0 || mask & !0x001f_01ff != 0 {
+                return Err(refusal(
+                    "destination ACL grants another principal namespace mutation rights",
+                ));
+            }
+        }
+        Ok(())
+    }
+
+    fn protected(&self) -> io::Result<bool> {
+        let mut control = 0;
+        let mut revision = 0;
+        // SAFETY: descriptor remains allocated; outputs are correctly sized.
+        if unsafe {
+            GetSecurityDescriptorControl(self.allocation.0, &raw mut control, &raw mut revision)
+        } == 0
+        {
+            return Err(io::Error::last_os_error());
+        }
+        Ok(control & SE_DACL_PROTECTED != 0)
+    }
+}
+
+fn handle_path(file: &File) -> io::Result<PathBuf> {
+    // SAFETY: live directory handle; zero capacity queries required length.
+    let length = unsafe { GetFinalPathNameByHandleW(file.as_raw_handle(), ptr::null_mut(), 0, 0) };
+    if length == 0 || length > 65_536 {
+        return Err(refusal("cannot resolve pinned destination handle"));
+    }
+    let mut name = vec![0_u16; length as usize];
+    // SAFETY: allocated buffer length matches supplied capacity.
+    let written =
+        unsafe { GetFinalPathNameByHandleW(file.as_raw_handle(), name.as_mut_ptr(), length, 0) };
+    if written == 0 {
+        return Err(io::Error::last_os_error());
+    }
+    let text = name
+        .get(..written as usize)
+        .filter(|_| written < length)
+        .ok_or_else(|| refusal("pinned destination spelling changed"))?;
+    Ok(PathBuf::from(OsString::from_wide(text)))
+}
+
+fn terminated(path: &OsStr) -> io::Result<Vec<u16>> {
+    let mut result: Vec<u16> = path.encode_wide().collect();
+    if result.contains(&0) {
+        return Err(refusal("destination name contains a nul"));
+    }
+    result.push(0);
+    Ok(result)
+}
+
+fn check_volume(file: &File) -> io::Result<()> {
+    let path = terminated(handle_path(file)?.as_os_str())?;
+    let mut root = vec![0_u16; 32_768];
+    // SAFETY: path is terminated; root is a writable MAX_PATH_EXTENDED buffer.
+    if unsafe { GetVolumePathNameW(path.as_ptr(), root.as_mut_ptr(), 32_768) } == 0 {
+        return Err(io::Error::last_os_error());
+    }
+    // SAFETY: GetVolumePathNameW produced a terminated volume-root spelling.
+    if !matches!(
+        unsafe { GetDriveTypeW(root.as_ptr()) },
+        DRIVE_FIXED | DRIVE_REMOVABLE
+    ) {
+        return Err(refusal(
+            "destination needs a supported local Windows volume",
+        ));
+    }
+    let mut flags = 0;
+    // SAFETY: live file handle and flags output; unused outputs may be NULL.
+    if unsafe {
+        GetVolumeInformationByHandleW(
+            file.as_raw_handle(),
+            ptr::null_mut(),
+            0,
+            ptr::null_mut(),
+            ptr::null_mut(),
+            &raw mut flags,
+            ptr::null_mut(),
+            0,
+        )
+    } == 0
+    {
+        return Err(io::Error::last_os_error());
+    }
+    if flags & FILE_PERSISTENT_ACLS == 0 {
+        return Err(refusal(
+            "destination volume does not enforce persistent ACLs",
+        ));
+    }
+    Ok(())
+}
+
+pub(crate) fn check_directory(
+    file: &File,
+    _child: Option<&Metadata>,
+    private: bool,
+) -> io::Result<()> {
+    check_volume(file)?;
+    if !file.metadata()?.is_dir() {
+        return Err(refusal("destination ancestor is not a directory"));
+    }
+    let security = Security::query(file)?;
+    security.check(&current_user()?, private)?;
+    if private && !security.protected()? {
+        return Err(refusal("new destination directory ACL is not protected"));
+    }
+    Ok(())
+}
+
+pub(crate) fn check_private_file(file: &File) -> io::Result<()> {
+    Security::query(file)?.check(&current_user()?, true)
+}
+
+fn descriptor(text: &str) -> io::Result<LocalAllocation> {
+    let text = terminated(OsStr::new(text))?;
+    let mut output = ptr::null_mut();
+    // SAFETY: valid terminated SDDL and SDK-owned pointer output; revision 1.
+    if unsafe {
+        ConvertStringSecurityDescriptorToSecurityDescriptorW(
+            text.as_ptr(),
+            1,
+            &raw mut output,
+            ptr::null_mut(),
+        )
+    } == 0
+    {
+        return Err(io::Error::last_os_error());
+    }
+    Ok(LocalAllocation(output))
+}
+
+pub(crate) fn create_directory(parent: &File, name: &OsStr) -> io::Result<()> {
+    // The caller holds/revalidates the full cap directory chain. On Windows
+    // those handles deny FILE_SHARE_DELETE, pinning all ancestor names while
+    // CreateDirectoryW uses this handle-derived spelling.
+    let mut components = Path::new(name).components();
+    if !matches!(components.next(), Some(Component::Normal(_))) || components.next().is_some() {
+        return Err(refusal("destination child must have one normal component"));
+    }
+    let user = current_user()?;
+    let security = descriptor(&format!(
+        "O:{user}D:P(A;OICI;FA;;;{user})(A;OICI;FA;;;SY)(A;OICI;FA;;;BA)"
+    ))?;
+    create_secured(parent, name, &security)
+}
+
+fn create_secured(parent: &File, name: &OsStr, security: &LocalAllocation) -> io::Result<()> {
+    let attributes = SECURITY_ATTRIBUTES {
+        nLength: u32::try_from(std::mem::size_of::<SECURITY_ATTRIBUTES>())
+            .map_err(|_| refusal("security attributes size overflow"))?,
+        lpSecurityDescriptor: security.0,
+        bInheritHandle: 0,
+    };
+    let path = terminated(handle_path(parent)?.join(name).as_os_str())?;
+    // SAFETY: live descriptor, attributes and terminated path. No inherited
+    // permissive-DACL window exists: security is applied at creation itself.
+    if unsafe { CreateDirectoryW(path.as_ptr(), &raw const attributes) } == 0 {
+        return Err(io::Error::last_os_error());
+    }
+    Ok(())
+}
+
+#[cfg(test)]
+mod tests {
+    use super::super::super::migration::copy_folder;
+    use super::*;
+    use std::fs;
+    use std::sync::atomic::AtomicBool;
+
+    fn acl_fixture(rule: &str) -> (tempfile::TempDir, PathBuf, PathBuf) {
+        let temp = tempfile::tempdir().unwrap();
+        let base = temp.path().canonicalize().unwrap();
+        let source = base.join("source");
+        fs::create_dir(&source).unwrap();
+        fs::write(source.join("hello"), b"hello").unwrap();
+        let parent =
+            cap_primitives::fs::open_ambient_dir(&base, cap_primitives::ambient_authority())
+                .unwrap();
+        let user = current_user().unwrap();
+        let security = descriptor(&format!(
+            "O:{user}D:P(A;OICI;FA;;;{user})(A;OICI;FA;;;SY)(A;OICI;FA;;;BA){rule}"
+        ))
+        .unwrap();
+        create_secured(&parent, OsStr::new("parent"), &security).unwrap();
+        (temp, source, base.join("parent"))
+    }
+
+    // Catches trusting ownership or READ_CONTROL alone while another account
+    // has authority to replace children between validation and mkdir/open.
+    #[test]
+    fn windows_refuses_parent_with_untrusted_delete_child_acl() {
+        let (_temp, source, parent) = acl_fixture("(A;;0x40;;;WD)");
+        fs::write(parent.join("sentinel"), b"keep").unwrap();
+        assert!(
+            copy_folder(
+                &source,
+                &parent.join("copy"),
+                &AtomicBool::new(false),
+                |_| {}
+            )
+            .is_err()
+        );
+        assert!(!parent.join("copy").exists());
+        assert_eq!(fs::read(parent.join("sentinel")).unwrap(), b"keep");
+    }
+
+    // Ancestor child-creation rights alone cannot replace our protected child.
+    #[test]
+    fn windows_allows_parent_add_subdirectory_without_replacement_rights() {
+        let (_temp, source, parent) = acl_fixture("(A;;0x4;;;WD)");
+        let report = copy_folder(
+            &source,
+            &parent.join("copy"),
+            &AtomicBool::new(false),
+            |_| {},
+        )
+        .unwrap();
+        assert!(report.complete(), "{report:?}");
+        assert_eq!(fs::read(parent.join("copy/hello")).unwrap(), b"hello");
+    }
+
+    // Catches inherited permissive ACLs or protecting the DACL only after
+    // directory creation. The private descriptor overrides inheritance.
+    #[test]
+    fn windows_creation_uses_protected_private_acl_despite_parent_inheritance() {
+        let (_temp, source, parent) = acl_fixture("(A;OICIIO;FA;;;WD)");
+        let destination = parent.join("copy");
+        let report = copy_folder(&source, &destination, &AtomicBool::new(false), |_| {}).unwrap();
+        assert!(report.complete(), "{report:?}");
+        let dir =
+            cap_primitives::fs::open_ambient_dir(&destination, cap_primitives::ambient_authority())
+                .unwrap();
+        check_directory(&dir, None, true).unwrap();
+        let copied = File::open(destination.join("hello")).unwrap();
+        check_private_file(&copied).unwrap();
+        assert_eq!(fs::read(destination.join("hello")).unwrap(), b"hello");
+    }
+}
diff --git a/apps/imager/src/setup/migration.rs b/apps/imager/src/setup/migration.rs
index 76e23265d..59c550db8 100644
--- a/apps/imager/src/setup/migration.rs
+++ b/apps/imager/src/setup/migration.rs
@@ -5,24 +5,25 @@
 //! source writes, merges, automatic retries, or executable launches occur here.
 
 use std::ffi::{OsStr, OsString};
 use std::fs::{self, File};
 use std::io::{self, Read, Seek, SeekFrom, Write};
 use std::path::{Component, Path, PathBuf};
 use std::sync::Arc;
 use std::sync::atomic::{AtomicBool, AtomicU64, Ordering};
 
 use cap_fs_ext::{OpenOptionsFollowExt, OpenOptionsSyncExt};
-use cap_primitives::fs::{DirOptions, FollowSymlinks, Metadata, OpenOptions};
+use cap_primitives::fs::{FollowSymlinks, Metadata, OpenOptions};
 use cap_std::fs::Dir;
 use sha2::{Digest, Sha256};
 
+use super::destination_security;
 use super::nofollow::{metadata_nofollow, open_directory_nofollow, same_directory_identity};
 
 const BUFFER_SIZE: usize = 64 * 1024;
 const MAX_DEPTH: usize = 128;
 static NEXT_TEMP: AtomicU64 = AtomicU64::new(0);
 
 #[derive(Clone, Debug, Default)]
 pub struct CopyProgress {
     pub verified_files: u64,
     pub verified_bytes: u64,
@@ -60,20 +61,21 @@ fn check_cancel(cancelled: &AtomicBool) -> io::Result<()> {
         Ok(())
     }
 }
 
 /// Each edge retains both the parent capability and the observed child identity.
 /// Sharing ancestors bounds descriptors to the depth of the active traversal.
 struct PinnedDirectory {
     file: File,
     identity: Metadata,
     parent: Option<(Arc<Self>, OsString)>,
+    created: bool,
 }
 
 impl PinnedDirectory {
     fn open_absolute(path: &Path) -> io::Result<Arc<Self>> {
         if !path.is_absolute() {
             return Err(changed("folder grant must be a native absolute path"));
         }
         let mut anchor = PathBuf::new();
         let mut names = Vec::new();
         for component in path.components() {
@@ -85,35 +87,37 @@ impl PinnedDirectory {
                 _ => return Err(changed("folder grant contains a non-normal component")),
             }
         }
         let file =
             cap_primitives::fs::open_ambient_dir(&anchor, cap_primitives::ambient_authority())?;
         let identity = Metadata::from_file(&file)?;
         let mut directory = Arc::new(Self {
             file,
             identity,
             parent: None,
+            created: false,
         });
         for name in names {
             let metadata = metadata_nofollow(&directory.file, Path::new(name))?;
             directory = directory.open_child(name, &metadata)?;
         }
         Ok(directory)
     }
 
     fn open_child(self: &Arc<Self>, name: &OsStr, expected: &Metadata) -> io::Result<Arc<Self>> {
         reject_windows_placeholder(expected)?;
         let file = open_directory_nofollow(&self.file, Path::new(name), expected)?;
         Ok(Arc::new(Self {
             identity: Metadata::from_file(&file)?,
             file,
             parent: Some((Arc::clone(self), name.to_os_string())),
+            created: false,
         }))
     }
 
     fn validate(&self) -> io::Result<()> {
         let mut current = self;
         while let Some((parent, name)) = &current.parent {
             let metadata = metadata_nofollow(&parent.file, Path::new(name))?;
             if metadata.is_symlink()
                 || !metadata.is_dir()
                 || !same_directory_identity(&metadata, &current.identity)
@@ -134,51 +138,62 @@ impl PinnedDirectory {
             if same_directory_identity(&current.identity, identity) {
                 return true;
             }
             match &current.parent {
                 Some((parent, _)) => current = parent,
                 None => return false,
             }
         }
     }
 
-    fn create_child(self: &Arc<Self>, name: &OsStr) -> io::Result<Arc<Self>> {
+    fn validate_destination(&self) -> io::Result<()> {
         self.validate()?;
-        let options = private_directory_options();
-        // mkdir is exclusive: an existing file, directory or link is an error.
-        cap_primitives::fs::create_dir(&self.file, Path::new(name), &options)?;
-        let expected = metadata_nofollow(&self.file, Path::new(name))?;
-        let child = self.open_child(name, &expected)?;
-        child.validate()?;
-        Ok(child)
+        let mut current = self;
+        let mut child = None;
+        loop {
+            destination_security::check_directory(&current.file, child.as_ref(), current.created)?;
+            child = Some(Metadata::from_file(&current.file)?);
+            match &current.parent {
+                Some((parent, _)) => current = parent,
+                None => break,
+            }
+        }
+        Ok(())
     }
-}
 
-fn private_directory_options() -> DirOptions {
-    #[allow(unused_mut)]
-    let mut options = DirOptions::new();
-    #[cfg(unix)]
-    {
-        use cap_primitives::fs::DirBuilderExt;
-        options.mode(0o700);
+    fn create_child(self: &Arc<Self>, name: &OsStr) -> io::Result<Arc<Self>> {
+        // Establish namespace protection BEFORE mkdir. Observation after an
+        // unprotected mkdir could adopt another account's replacement.
+        self.validate_destination()?;
+        destination_security::create_directory(&self.file, name)?;
+        let expected = metadata_nofollow(&self.file, Path::new(name))?;
+        let file = open_directory_nofollow(&self.file, Path::new(name), &expected)?;
+        destination_security::check_private_file(&file)?;
+        let child = Arc::new(Self {
+            identity: Metadata::from_file(&file)?,
+            file,
+            parent: Some((Arc::clone(self), name.to_os_string())),
+            created: true,
+        });
+        child.validate_destination()?;
+        Ok(child)
     }
-    options
 }
 
 #[cfg_attr(not(windows), allow(clippy::unnecessary_wraps))]
 fn reject_windows_placeholder(metadata: &Metadata) -> io::Result<()> {
     #[cfg(windows)]
     {
         use cap_primitives::fs::MetadataExt;
         // All reparse points (including cloud placeholders/junctions), offline,
         // recall-on-open and recall-on-data-access require a separate safe path.
-        if metadata.file_attributes() & (0x400 | 0x1000 | 0x40000 | 0x400000) != 0 {
+        if metadata.file_attributes() & (0x400 | 0x1000 | 0x0004_0000 | 0x0040_0000) != 0 {
             return Err(changed("reparse point or cloud placeholder is unsupported"));
         }
     }
     #[cfg(not(windows))]
     let _ = metadata;
     Ok(())
 }
 
 fn same_snapshot(before: &Metadata, after: &Metadata) -> bool {
     if !same_directory_identity(before, after)
@@ -223,21 +238,21 @@ fn preserve_times(file: &File, original: &Metadata) -> io::Result<()> {
         ));
     }
     Ok(())
 }
 
 // Linux scanner handles may be O_PATH and Windows scanner handles lack
 // FILE_WRITE_ATTRIBUTES. Reopen only the fresh destination using its pinned
 // parent, no-follow lookup and identity comparison before setting timestamps.
 fn preserve_directory_times(directory: &PinnedDirectory, original: &Metadata) -> io::Result<()> {
     use cap_fs_ext::OpenOptionsMaybeDirExt;
-    directory.validate()?;
+    directory.validate_destination()?;
     let (parent, name) = directory
         .parent
         .as_ref()
         .ok_or_else(|| changed("destination has no pinned parent"))?;
     let mut options = OpenOptions::new();
     options
         .read(true)
         .maybe_dir(true)
         .follow(FollowSymlinks::No);
     #[cfg(windows)]
@@ -257,21 +272,22 @@ fn preserve_directory_times(directory: &PinnedDirectory, original: &Metadata) ->
 /// no-follow identity still matches the handle created by this operation.
 struct OwnedTemporary {
     parent: Arc<PinnedDirectory>,
     name: OsString,
     file: File,
     identity: Metadata,
 }
 
 impl OwnedTemporary {
     fn create(parent: &Arc<PinnedDirectory>, excluded: &OsStr) -> io::Result<Self> {
-        parent.validate()?;
+        parent.validate_destination()?;
+        destination_security::check_private_file(&parent.file)?;
         let mut options = OpenOptions::new();
         options
             .read(true)
             .write(true)
             .create_new(true)
             .follow(FollowSymlinks::No);
         #[cfg(unix)]
         {
             use cap_primitives::fs::OpenOptionsExt;
             options.mode(0o600);
@@ -280,37 +296,40 @@ impl OwnedTemporary {
             let name = OsString::from(format!(
                 ".qos-copy-{}-{}",
                 std::process::id(),
                 NEXT_TEMP.fetch_add(1, Ordering::Relaxed)
             ));
             if name == excluded {
                 continue;
             }
             match cap_primitives::fs::open(&parent.file, Path::new(&name), &options) {
                 Ok(file) => {
+                    destination_security::check_private_file(&file)?;
                     let identity = Metadata::from_file(&file)?;
                     return Ok(Self {
                         parent: Arc::clone(parent),
                         name,
                         file,
                         identity,
                     });
                 }
                 Err(error) if error.kind() == io::ErrorKind::AlreadyExists => {}
                 Err(error) => return Err(error),
             }
         }
         Err(changed("cannot reserve an exclusive temporary filename"))
     }
 
     fn validate(&self) -> io::Result<()> {
-        self.parent.validate()?;
+        self.parent.validate_destination()?;
+        destination_security::check_private_file(&self.parent.file)?;
+        destination_security::check_private_file(&self.file)?;
         let metadata = metadata_nofollow(&self.parent.file, Path::new(&self.name))?;
         if !metadata.is_file()
             || metadata.is_symlink()
             || !same_directory_identity(&metadata, &self.identity)
         {
             return Err(changed("temporary destination was replaced"));
         }
         Ok(())
     }
 
@@ -477,21 +496,21 @@ impl<P: FnMut(CopyProgress)> Copier<'_, P> {
 
     fn walk(
         &mut self,
         source: &Arc<PinnedDirectory>,
         destination: &Arc<PinnedDirectory>,
         relative: &Path,
         depth: usize,
     ) -> io::Result<()> {
         check_cancel(self.cancelled)?;
         source.validate()?;
-        destination.validate()?;
+        destination.validate_destination()?;
         if depth > MAX_DEPTH {
             return Err(changed("folder nesting exceeds supported depth"));
         }
         let before = Metadata::from_file(&source.file)?;
         let directory = Dir::from_std_file(source.file.try_clone()?);
         let mut names = Vec::new();
         for entry in directory.entries()? {
             check_cancel(self.cancelled)?;
             match entry {
                 Ok(entry) => names.push(entry.file_name()),
@@ -500,35 +519,35 @@ impl<P: FnMut(CopyProgress)> Copier<'_, P> {
                     .failed
                     .push((relative.to_path_buf(), error.to_string())),
             }
         }
         names.sort();
         for name in names {
             let path = relative.join(&name);
             self.notify(&path);
             check_cancel(self.cancelled)?;
             source.validate()?;
-            destination.validate()?;
+            destination.validate_destination()?;
             if let Err(error) = self.copy_entry(source, destination, &name, &path, depth) {
                 if self.cancelled.load(Ordering::Relaxed) {
                     return Err(error);
                 }
                 self.report.failed.push((path, error.to_string()));
             }
         }
         source.validate()?;
         if !same_snapshot(&before, &Metadata::from_file(&source.file)?) {
             return Err(changed(
                 "source directory changed during enumeration; retry required",
             ));
         }
-        destination.validate()?;
+        destination.validate_destination()?;
         preserve_directory_times(destination, &before)?;
         Ok(())
     }
 
     fn copy_entry(
         &mut self,
         source: &Arc<PinnedDirectory>,
         destination: &Arc<PinnedDirectory>,
         name: &OsStr,
         relative: &Path,
@@ -581,21 +600,21 @@ impl<P: FnMut(CopyProgress)> Copier<'_, P> {
 pub fn copy_folder(
     source: &Path,
     destination: &Path,
     cancelled: &AtomicBool,
     progress: impl FnMut(CopyProgress),
 ) -> Result<CopyReport, String> {
     let mut copier = Copier {
         cancelled,
         progress,
         report: CopyReport {
-            metadata_limitations: vec!["Copies regular-file contents and access/modification times. Ownership, original permissions, ACLs, extended attributes, alternate streams, creation times, sparse layout and hard-link relationships are not preserved. New files use private user-owned permissions on Unix and inherit destination security on Windows.".to_string()],
+            metadata_limitations: vec!["Copies regular-file contents and access/modification times. Ownership, original permissions, ACLs, extended attributes, alternate streams, creation times, sparse layout and hard-link relationships are not preserved. New files use private user-owned permissions on Unix and use an explicit protected private directory ACL on Windows. Destination namespace protection excludes hostile same-account or administrator processes.".to_string()],
             ..CopyReport::default()
         },
     };
     if cancelled.load(Ordering::Relaxed) {
         copier.report.cancelled = true;
         return Ok(copier.report);
     }
     if !destination.is_absolute() {
         return Err("destination must be a native absolute path".to_string());
     }
@@ -805,20 +824,35 @@ mod tests {
                     .unwrap()
                     .permissions()
                     .mode()
                     & 0o077,
                 0
             );
         }
     }
 
     fn stage_fixture(source: &Path, destination: &Path) -> StagedFile {
+        #[cfg(unix)]
+        {
+            use std::os::unix::fs::PermissionsExt;
+            fs::set_permissions(destination, fs::Permissions::from_mode(0o700)).unwrap();
+        }
+        #[cfg(windows)]
+        {
+            // Staging requires an actually private directory, including its
+            // inherited child ACL; use the same native creation as production.
+            fs::remove_dir(destination).unwrap();
+            let parent = PinnedDirectory::open_absolute(destination.parent().unwrap()).unwrap();
+            parent
+                .create_child(destination.file_name().unwrap())
+                .unwrap();
+        }
         let source = PinnedDirectory::open_absolute(source).unwrap();
         let destination = PinnedDirectory::open_absolute(destination).unwrap();
         let expected = metadata_nofollow(&source.file, Path::new("hello")).unwrap();
         StagedFile::copy(
             &source,
             &destination,
             OsStr::new("hello"),
             &expected,
             &AtomicBool::new(false),
         )
@@ -977,11 +1011,207 @@ mod tests {
                     attempted = true;
                     assert!(fs::rename(&parent, base.join("renamed")).is_err());
                 }
             },
         )
         .unwrap();
         assert!(attempted);
         assert!(report.complete(), "{report:?}");
         assert_eq!(fs::read(parent.join("copy/hello")).unwrap(), b"hello");
     }
+    // A private child does not prevent another account replacing it through
+    // an unsafe parent. Refusal must happen before mkdir, not after adoption.
+    #[cfg(unix)]
+    #[test]
+    fn namespace_refuses_other_writable_parent_before_creating_anything() {
+        use std::os::unix::fs::PermissionsExt;
+        let (temp, source, _) = fixture();
+        let parent = temp.path().canonicalize().unwrap().join("public");
+        fs::create_dir(&parent).unwrap();
+        fs::set_permissions(&parent, fs::Permissions::from_mode(0o777)).unwrap();
+        fs::write(parent.join("sentinel"), b"keep").unwrap();
+        let result = copy_folder(
+            &source,
+            &parent.join("copy"),
+            &AtomicBool::new(false),
+            |_| {},
+        );
+        assert!(result.is_err());
+        assert!(!parent.join("copy").exists());
+        assert_eq!(fs::read(parent.join("sentinel")).unwrap(), b"keep");
+    }
+
+    #[cfg(unix)]
+    #[test]
+    fn namespace_checks_ancestor_replacement_rights() {
+        use std::os::unix::fs::PermissionsExt;
+        let (temp, source, _) = fixture();
+        let ancestor = temp.path().canonicalize().unwrap().join("public");
+        fs::create_dir(&ancestor).unwrap();
+        fs::create_dir(ancestor.join("private")).unwrap();
+        fs::set_permissions(&ancestor, fs::Permissions::from_mode(0o777)).unwrap();
+        fs::set_permissions(ancestor.join("private"), fs::Permissions::from_mode(0o700)).unwrap();
+        assert!(
+            copy_folder(
+                &source,
+                &ancestor.join("private/copy"),
+                &AtomicBool::new(false),
+                |_| {}
+            )
+            .is_err()
+        );
+        assert!(!ancestor.join("private/copy").exists());
+    }
+
+    #[cfg(unix)]
+    #[test]
+    fn namespace_preserves_safe_sticky_temporary_paths() {
+        use std::os::unix::fs::PermissionsExt;
+        let (temp, source, _) = fixture();
+        let parent = temp.path().canonicalize().unwrap().join("sticky");
+        fs::create_dir(&parent).unwrap();
+        fs::set_permissions(&parent, fs::Permissions::from_mode(0o1777)).unwrap();
+        fs::write(source.join("hello"), b"hello").unwrap();
+        let report = copy_folder(
+            &source,
+            &parent.join("copy"),
+            &AtomicBool::new(false),
+            |_| {},
+        )
+        .unwrap();
+        assert!(report.complete(), "{report:?}");
+        assert_eq!(fs::read(parent.join("copy/hello")).unwrap(), b"hello");
+        assert_eq!(
+            fs::metadata(parent.join("copy"))
+                .unwrap()
+                .permissions()
+                .mode()
+                & 0o777,
+            0o700
+        );
+    }
+
+    // Once the private namespace is opened to other writers, neither publish
+    // nor cleanup is allowed to perform its name-based mutation.
+    #[cfg(unix)]
+    #[test]
+    fn namespace_changed_permissions_stop_publication_and_cleanup() {
+        use std::os::unix::fs::PermissionsExt;
+        let (_temp, source, destination) = fixture();
+        fs::create_dir(&destination).unwrap();
+        fs::set_permissions(&destination, fs::Permissions::from_mode(0o700)).unwrap();
+        fs::write(source.join("hello"), b"hello").unwrap();
+        let staged = stage_fixture(&source, &destination);
+        let temporary = destination.join(&staged.temporary.name);
+        fs::set_permissions(&destination, fs::Permissions::from_mode(0o777)).unwrap();
+        assert!(staged.verify_and_publish(&AtomicBool::new(false)).is_err());
+        assert!(!destination.join("hello").exists());
+        assert_eq!(fs::read(&temporary).unwrap(), b"hello");
+    }
+
+    #[cfg(target_os = "macos")]
+    #[test]
+    fn namespace_macos_acl_write_grant_is_not_hidden_by_private_mode() {
+        use std::os::unix::fs::PermissionsExt;
+        let (temp, source, _) = fixture();
+        let parent = temp.path().canonicalize().unwrap().join("acl-parent");
+        fs::create_dir(&parent).unwrap();
+        fs::set_permissions(&parent, fs::Permissions::from_mode(0o700)).unwrap();
+        assert!(
+            std::process::Command::new("chmod")
+                .args([
+                    "+a",
+                    "everyone allow add_file,add_subdirectory,delete_child"
+                ])
+                .arg(&parent)
+                .status()
+                .unwrap()
+                .success()
+        );
+        let result = copy_folder(
+            &source,
+            &parent.join("copy"),
+            &AtomicBool::new(false),
+            |_| {},
+        );
+        assert!(result.is_err());
+        assert!(!parent.join("copy").exists());
+    }
+
+    #[cfg(target_os = "macos")]
+    #[test]
+    fn namespace_macos_inherit_only_write_acl_is_refused_before_mkdir() {
+        let (temp, source, _) = fixture();
+        let parent = temp.path().canonicalize().unwrap().join("acl-parent");
+        fs::create_dir(&parent).unwrap();
+        assert!(std::process::Command::new("chmod").args(["+a", "everyone allow write,append,delete_child,file_inherit,directory_inherit,only_inherit"]).arg(&parent).status().unwrap().success());
+        assert!(
+            copy_folder(
+                &source,
+                &parent.join("copy"),
+                &AtomicBool::new(false),
+                |_| {}
+            )
+            .is_err()
+        );
+        assert!(!parent.join("copy").exists());
+    }
+
+    #[cfg(target_os = "macos")]
+    #[test]
+    fn namespace_macos_read_only_acl_does_not_block_safe_copy() {
+        let (temp, source, _) = fixture();
+        let parent = temp.path().canonicalize().unwrap().join("acl-parent");
+        fs::create_dir(&parent).unwrap();
+        fs::write(source.join("hello"), b"hello").unwrap();
+        assert!(
+            std::process::Command::new("chmod")
+                .args([
+                    "+a",
+                    "everyone allow read,readattr,readextattr,readsecurity"
+                ])
+                .arg(&parent)
+                .status()
+                .unwrap()
+                .success()
+        );
+        let report = copy_folder(
+            &source,
+            &parent.join("copy"),
+            &AtomicBool::new(false),
+            |_| {},
+        )
+        .unwrap();
+        assert!(report.complete(), "{report:?}");
+        assert_eq!(fs::read(parent.join("copy/hello")).unwrap(), b"hello");
+    }
+    #[cfg(unix)]
+    #[test]
+    #[ignore = "requires root only to create a disposable foreign-owned child"]
+    fn namespace_sticky_parent_does_not_trust_a_foreign_owned_child() {
+        use std::os::fd::AsRawFd;
+        use std::os::unix::fs::PermissionsExt;
+        // SAFETY: geteuid has no preconditions. This opt-in test only changes
+        // ownership of a newly created empty directory in its own fixture.
+        assert_eq!(unsafe { libc::geteuid() }, 0);
+        let (temp, source, _) = fixture();
+        let parent = temp.path().canonicalize().unwrap().join("sticky");
+        fs::create_dir(&parent).unwrap();
+        fs::set_permissions(&parent, fs::Permissions::from_mode(0o1777)).unwrap();
+        let child = parent.join("foreign");
+        fs::create_dir(&child).unwrap();
+        let file = fs::File::open(&child).unwrap();
+        // SAFETY: valid fixture-only descriptor; uid/gid65534 is untrusted by
+        // a uid0 worker, independently of whether it names a local account.
+        assert_eq!(unsafe { libc::fchown(file.as_raw_fd(), 65_534, 65_534) }, 0);
+        assert!(
+            copy_folder(
+                &source,
+                &child.join("copy"),
+                &AtomicBool::new(false),
+                |_| {}
+            )
+            .is_err()
+        );
+        assert!(!child.join("copy").exists());
+    }
 }
diff --git a/apps/imager/src/setup/mod.rs b/apps/imager/src/setup/mod.rs
index 19a6099cb..ffdbcd103 100644
--- a/apps/imager/src/setup/mod.rs
+++ b/apps/imager/src/setup/mod.rs
@@ -1,9 +1,10 @@
 pub mod controller;
+mod destination_security;
 pub mod folders;
 pub mod known_folders;
 pub mod migration;
 pub mod model;
 mod nofollow;
 pub mod view;
 
 pub use view::app_root;
diff --git a/ui/src/widget/toolbar.rs b/ui/src/widget/toolbar.rs
index 51f2e8064..a757ebd8e 100644
--- a/ui/src/widget/toolbar.rs
+++ b/ui/src/widget/toolbar.rs
@@ -44,20 +44,21 @@ pub struct Toolbar {
     visible_count: usize,
     extents: Vec<Size<f32>>,
     chip_extent: Size<f32>,
     intrinsic: Size<f32>,
     font: TextStyle,
     padding: f32,
     minimum: f32,
     separator: f32,
     overflow_rect: Rect,
     hovered: Option<Target>,
+    pointer: Option<Point>,
     pressed: Option<Target>,
     focused: bool,
     focus: Option<Target>,
     menu: ContextMenu,
     menu_indices: Vec<Option<usize>>,
     viewport: Option<Rect>,
     swallow_release: bool,
 }
 
 impl Toolbar {
@@ -70,20 +71,21 @@ impl Toolbar {
             visible_count: 0,
             extents: Vec::new(),
             chip_extent: Size::ZERO,
             intrinsic: Size::ZERO,
             font: TextStyle::new(14.0),
             padding: 8.0,
             minimum: 32.0,
             separator: 9.0,
             overflow_rect: Rect::ZERO,
             hovered: None,
+            pointer: None,
             pressed: None,
             focused: false,
             focus: None,
             menu: ContextMenu::new(),
             menu_indices: Vec::new(),
             viewport: None,
             swallow_release: false,
         }
     }
 
@@ -296,21 +298,21 @@ impl Toolbar {
                 ),
             }
         } else {
             Rect::ZERO
         };
         self.reconcile_menu();
         let targets = self.targets();
         if self.focus.is_some_and(|target| !targets.contains(&target)) {
             self.focus = targets.last().copied();
         }
-        self.hovered = self.hovered.filter(|target| targets.contains(target));
+        self.refresh_hover();
         self.pressed = self.pressed.filter(|target| targets.contains(target));
     }
 
     fn reconcile_menu(&mut self) {
         let mut indices = Vec::new();
         let mut separator = false;
         for (index, item) in self.items.iter().enumerate().skip(self.visible_count) {
             match item {
                 ToolbarItem::Button { .. } => {
                     if separator && !indices.is_empty() {
@@ -359,41 +361,64 @@ impl Toolbar {
         }
     }
 
     fn open_menu(&mut self, keyboard: bool) {
         if !self.has_overflow() {
             return;
         }
         self.menu
             .open_anchored(self.overflow_rect, self.viewport.unwrap_or(self.rect));
         self.focus = Some(Target::Overflow);
+        self.hovered = None;
+        self.pressed = None;
         if keyboard {
             self.menu.focus_first_action();
         }
     }
     fn invoke(&mut self, index: usize) {
         if let Some(ToolbarItem::Button { on_click, .. }) = self.items.get_mut(index) {
             on_click();
         }
     }
     fn drain_menu(&mut self) {
         if let Some(index) = self
             .menu
             .take_selection()
             .and_then(|row| self.menu_indices.get(row).copied().flatten())
         {
             self.invoke(index);
         }
         if !self.menu.is_open() {
             self.focus = Some(Target::Overflow);
+            self.pressed = None;
+            self.refresh_hover();
         }
     }
+
+    /// Popup routing still updates `pointer`, so closing or relayout cannot
+    /// arm a command using a hover target from before the popup opened.
+    fn refresh_hover(&mut self) -> bool {
+        let hovered = if self.menu.is_open() {
+            None
+        } else {
+            self.pointer.and_then(|point| {
+                self.targets().into_iter().find(|target| {
+                    self.target_rect(*target)
+                        .is_some_and(|rect| rect.contains(point))
+                })
+            })
+        };
+        let changed = hovered != self.hovered;
+        self.hovered = hovered;
+        changed
+    }
+
     fn targets(&self) -> Vec<Target> {
         let mut targets: Vec<_> = self
             .items
             .iter()
             .enumerate()
             .take(self.visible_count)
             .filter_map(|(index, item)| {
                 matches!(item, ToolbarItem::Button { .. }).then_some(Target::Item(index))
             })
             .collect();
@@ -664,73 +689,71 @@ impl Widget for Toolbar {
         event: &WindowEvent,
         scale: f64,
         modifiers: &winit::event::Modifiers,
         state: &mut AutoCommit,
         path: &ObjId,
         handled: &mut bool,
         focus_target: &mut Option<NodeId>,
         node: NodeId,
         tree: &TaffyTree<()>,
     ) {
+        if let WindowEvent::CursorMoved { position, .. } = event {
+            self.pointer = Some(Point::new(position.x / scale, position.y / scale));
+        }
         if self.menu.is_open() {
             self.menu.handle_event(
                 event,
                 scale,
                 modifiers,
                 state,
                 path,
                 handled,
                 focus_target,
                 node,
                 tree,
             );
             if matches!(
                 event,
                 WindowEvent::MouseInput {
                     state: ElementState::Pressed,
+                    button: MouseButton::Left,
                     ..
                 }
             ) {
                 self.swallow_release = true;
             }
             self.drain_menu();
             return;
         }
         match event {
-            WindowEvent::CursorMoved { position, .. } => {
-                let point = Point::new(position.x / scale, position.y / scale);
-                let hovered = self.targets().into_iter().find(|target| {
-                    self.target_rect(*target)
-                        .is_some_and(|rect| rect.contains(point))
-                });
-                if hovered != self.hovered {
-                    self.hovered = hovered;
-                    *handled = true;
-                }
+            WindowEvent::CursorMoved { .. } => {
+                *handled |= self.refresh_hover();
             }
             WindowEvent::MouseInput {
                 state: ElementState::Pressed,
                 button: MouseButton::Left,
                 ..
             } => {
+                self.refresh_hover();
                 self.pressed = self.hovered;
                 if let Some(target) = self.pressed {
                     self.focus_target(target);
                     *focus_target = Some(node);
                     *handled = true;
                 }
             }
             WindowEvent::MouseInput {
                 state: ElementState::Released,
                 button: MouseButton::Left,
                 ..
             } => {
+                self.refresh_hover();
                 if self.swallow_release {
                     self.swallow_release = false;
                     self.pressed = None;
                     *handled = true;
                     return;
                 }
                 if let Some(target) = self
                     .pressed
                     .take()
                     .filter(|target| Some(*target) == self.hovered)
@@ -783,20 +806,21 @@ impl Widget for Toolbar {
             .any(|item| matches!(item, ToolbarItem::Button { .. }))
     }
     fn set_focus(&mut self, focused: bool) {
         self.focused = focused;
         if focused && self.focus.is_none() {
             self.focus = self.targets().first().copied();
         }
         if !focused {
             self.menu.close();
             self.pressed = None;
+            self.refresh_hover();
         }
     }
     fn is_focused(&self) -> bool {
         self.focused
     }
     fn traps_focus(&self) -> bool {
         self.menu.is_open()
     }
     fn wants_pointer_capture(&self) -> bool {
         self.menu.is_open() || self.pressed.is_some() || self.swallow_release
@@ -826,20 +850,21 @@ impl Widget for Toolbar {
                     ),
                     Target::Overflow => (
                         "More commands".to_owned(),
                         "toolbar.overflow".to_owned(),
                         Some(self.menu.is_open()),
                     ),
                 };
                 AccessNode::new(Role::Button)
                     .with_name(name)
                     .with_action_target(route)
+                    .with_bounds(self.target_rect(*target).unwrap_or(Rect::ZERO))
                     .with_state(AccessState {
                         focusable: true,
                         focused: self.focused
                             && !self.menu.is_open()
                             && self.focus == Some(*target),
                         expanded,
                         ..Default::default()
                     })
             })
             .collect();
@@ -850,29 +875,36 @@ impl Widget for Toolbar {
                 .enumerate()
                 .filter_map(|(row, index)| {
                     let index = (*index)?;
                     let ToolbarItem::Button { label, .. } = self.items.get(index)? else {
                         return None;
                     };
                     Some(
                         AccessNode::new(Role::MenuItem)
                             .with_name(label.clone())
                             .with_action_target(format!("toolbar.item.{index}"))
+                            // Keep scrolled-out actions focusable so semantic focus
+                            // can reveal them, but export no fabricated painted area.
+                            .with_bounds(self.menu.item_rect(row).unwrap_or(Rect::ZERO))
                             .with_state(AccessState {
                                 focusable: true,
                                 focused: self.focused && self.menu.hovered() == Some(row),
                                 ..Default::default()
                             }),
                     )
                 })
                 .collect();
-            children.push(AccessNode::new(Role::Menu).with_children(rows));
+            children.push(
+                AccessNode::new(Role::Menu)
+                    .with_bounds(self.menu.get_rect())
+                    .with_children(rows),
+            );
         }
         Some(
             AccessNode::new(Role::Toolbar)
                 .with_state(AccessState {
                     focusable: self.is_focusable(),
                     focused: self.focused,
                     ..Default::default()
                 })
                 .with_children(children),
         )
@@ -1324,37 +1356,37 @@ mod lifecycle_tests {
     fn mouse(tb: &mut Toolbar, state: ElementState) -> bool {
         dispatch(
             tb,
             WindowEvent::MouseInput {
                 device_id: unsafe { std::mem::zeroed::<DeviceId>() },
                 state,
                 button: MouseButton::Left,
             },
         )
     }
-    fn key(tb: &mut Toolbar, key: NamedKey) -> bool {
+    fn key_event(key: NamedKey) -> WindowEvent {
         let mut event: KeyEvent = unsafe { std::mem::zeroed() };
         event.logical_key = Key::Named(key);
         event.physical_key = winit::keyboard::PhysicalKey::Unidentified(
             winit::keyboard::NativeKeyCode::Unidentified,
         );
         event.location = winit::keyboard::KeyLocation::Standard;
         event.state = ElementState::Pressed;
         event.text = None;
-        dispatch(
-            tb,
-            WindowEvent::KeyboardInput {
-                device_id: unsafe { std::mem::zeroed() },
-                event,
-                is_synthetic: true,
-            },
-        )
+        WindowEvent::KeyboardInput {
+            device_id: unsafe { std::mem::zeroed() },
+            event,
+            is_synthetic: true,
+        }
+    }
+    fn key(tb: &mut Toolbar, key: NamedKey) -> bool {
+        dispatch(tb, key_event(key))
     }
     fn counted(n: usize) -> (Toolbar, Rc<RefCell<Vec<usize>>>) {
         let counts = Rc::new(RefCell::new(vec![0; n]));
         let mut tb = Toolbar::new(Orientation::Horizontal);
         for index in 0..n {
             let counts = counts.clone();
             tb = tb.push_button(&format!("Command {index}"), move || {
                 counts.borrow_mut()[index] += 1
             });
         }
@@ -1648,11 +1680,212 @@ mod lifecycle_tests {
             let mut renderer = crate::offscreen::OffscreenRenderer::new(width, height);
             let path = format!("{dir}/{name}.png");
             renderer.render_png(&scene, theme.bg_app, &path);
             key(&mut tb, NamedKey::Enter);
             assert_eq!(*fired.borrow(), 1);
             eprintln!(
                 "capture {path}; viewport={width}x{height}; toolbar_width={toolbar_width}; Theme::dark().with_text_scale({scale}); last command fired once"
             );
         }
     }
+    #[test]
+    fn review_emitted_accessibility_bounds_match_paint_and_scrolling() {
+        let (mut tb, _) = counted(12);
+        settle(&mut tb, 180.0, 45.0, 1.0);
+        let node = tb.accessibility().unwrap();
+        for (child, target) in node.children.iter().zip(tb.targets()) {
+            assert_eq!(
+                child.bounds.map(|bounds| bounds.to_rect()),
+                tb.target_rect(target)
+            );
+        }
+        tb.open_menu(true);
+        let menu_child = tb.targets().len();
+        let first_height = tb.menu.item_rect(0).unwrap().height();
+        tb.menu.focus_item(tb.menu_indices.len() - 1);
+        let node = tb.accessibility().unwrap();
+        let menu = &node.children[menu_child];
+        assert_eq!(menu.bounds.unwrap().to_rect(), tb.menu.get_rect());
+        let mut clipped = false;
+        for (child, row) in menu.children.iter().zip(
+            tb.menu_indices
+                .iter()
+                .enumerate()
+                .filter_map(|(row, index)| index.map(|_| row)),
+        ) {
+            let expected = tb.menu.item_rect(row).unwrap_or(Rect::ZERO);
+            assert_eq!(child.bounds.unwrap().to_rect(), expected);
+            clipped |= expected.height() > 0.0 && expected.height() < first_height;
+        }
+        assert!(clipped);
+        assert_eq!(menu.children[0].bounds.unwrap().to_rect(), Rect::ZERO);
+        assert!(
+            !menu.children[0].state.hidden,
+            "offscreen commands retain semantic focus access"
+        );
+        assert!(tb.focus_synthetic_accessibility(&[menu_child, 0]));
+        assert!(
+            !tb.accessibility().unwrap().children[menu_child].children[0]
+                .bounds
+                .unwrap()
+                .to_rect()
+                .is_zero_area()
+        );
+    }
+
+    #[test]
+    fn review_popup_close_rehits_pointer_before_second_click() {
+        for pointer_open in [false, true] {
+            for relayout in [false, true] {
+                let (mut tb, counts) = counted(8);
+                settle(&mut tb, 180.0, 45.0, 1.0);
+                let point = if pointer_open {
+                    tb.overflow_rect.center()
+                } else {
+                    tb.item_rects[0].center()
+                };
+                cursor(&mut tb, point);
+                if pointer_open {
+                    mouse(&mut tb, ElementState::Pressed);
+                    mouse(&mut tb, ElementState::Released);
+                } else {
+                    tb.set_focus(true);
+                    while tb.focus != Some(Target::Overflow) {
+                        key(&mut tb, NamedKey::ArrowRight);
+                    }
+                    key(&mut tb, NamedKey::Space);
+                }
+                let hidden = tb.menu_indices[0].unwrap();
+                let point = tb.menu.item_rect(0).unwrap().center();
+                assert!(!tb.rect.contains(point));
+                cursor(&mut tb, point);
+                mouse(&mut tb, ElementState::Pressed);
+                mouse(&mut tb, ElementState::Released);
+                if relayout {
+                    settle(&mut tb, 180.0, 45.0, 1.0);
+                }
+                mouse(&mut tb, ElementState::Pressed);
+                mouse(&mut tb, ElementState::Released);
+                let mut expected = vec![0; 8];
+                expected[hidden] = 1;
+                assert_eq!(
+                    *counts.borrow(),
+                    expected,
+                    "pointer_open={pointer_open}, relayout={relayout}"
+                );
+                assert!(
+                    !tb.menu.is_open(),
+                    "stale overflow hover must not reopen the menu"
+                );
+            }
+        }
+    }
+
+    #[test]
+    fn review_nonleft_popup_press_does_not_capture_next_sibling_click() {
+        for button in [MouseButton::Right, MouseButton::Middle] {
+            let (toolbar, _) = counted(8);
+            let (sibling, count) = counted(1);
+            let mut host = crate::widget::Row::new()
+                .no_wrap()
+                .push(Box::new(toolbar))
+                .push(Box::new(sibling));
+            let mut tree = TaffyTree::new();
+            let mut nodes = HashMap::new();
+            let theme = Theme::dark();
+            let node = host.build_layout(&mut tree, &theme, &mut nodes);
+            let children = tree.children(node).unwrap();
+            for (child, width) in children.iter().zip([180.0, 150.0]) {
+                let mut style = tree.style(*child).unwrap().clone();
+                style.size = Size {
+                    width: Dimension::length(width),
+                    height: Dimension::length(45.0),
+                };
+                tree.set_style(*child, style).unwrap();
+            }
+            let mut text = TextRenderer::new();
+            let mut bindings = crate::bound_dispatch::BoundNodeMap::default();
+            unsafe {
+                bindings.rebuild(&host, &tree, node, &nodes);
+                crate::widget::compute_widget_layout(
+                    &mut tree,
+                    node,
+                    Size {
+                        width: taffy::AvailableSpace::Definite(360.0),
+                        height: taffy::AvailableSpace::Definite(220.0),
+                    },
+                    &nodes,
+                    &bindings,
+                    &mut text,
+                )
+                .unwrap();
+            }
+            host.apply_layout(&tree, node, Point::ZERO);
+            let presence = PresenceCtx::default();
+            presence
+                .viewport
+                .set(Some(Rect::new(0.0, 0.0, 360.0, 220.0)));
+            host.draw(
+                &mut Scene::new(),
+                Affine::IDENTITY,
+                &mut text,
+                &theme,
+                &presence,
+            );
+            assert!(host.children_mut()[0].perform_semantic_action(
+                "toolbar.overflow",
+                &Action::Activate,
+                &mut AutoCommit::new(),
+                &automerge::ROOT
+            ));
+            let send = |host: &mut crate::widget::Row, event: WindowEvent| {
+                host.handle_event(
+                    &event,
+                    1.0,
+                    &Default::default(),
+                    &mut AutoCommit::new(),
+                    &automerge::ROOT,
+                    &mut false,
+                    &mut None,
+                    node,
+                    &tree,
+                );
+            };
+            let mouse_event = |button, state| WindowEvent::MouseInput {
+                device_id: unsafe { std::mem::zeroed() },
+                button,
+                state,
+            };
+            send(&mut host, mouse_event(button, ElementState::Pressed));
+            send(&mut host, mouse_event(button, ElementState::Released));
+            send(&mut host, key_event(NamedKey::Escape));
+            assert!(
+                !host.wants_pointer_capture(),
+                "{button:?} must not leave capture stuck"
+            );
+            let point = host.children()[1]
+                .synthetic_accessibility_rect(&[0])
+                .unwrap()
+                .center();
+            send(
+                &mut host,
+                WindowEvent::CursorMoved {
+                    device_id: unsafe { std::mem::zeroed() },
+                    position: winit::dpi::PhysicalPosition::new(point.x, point.y),
+                },
+            );
+            send(
+                &mut host,
+                mouse_event(MouseButton::Left, ElementState::Pressed),
+            );
+            send(
+                &mut host,
+                mouse_event(MouseButton::Left, ElementState::Released),
+            );
+            assert_eq!(
+                *count.borrow(),
+                vec![1],
+                "next sibling click must arrive through Row"
+            );
+        }
+    }
 }
