# Shared Task4 fix round1

Requirements: resolve all three Important findings in `task-4-review.md`. Root independently checked Toolbar event/accessibility branches and AccessKit synthetic export; findings are accepted and do not conflict with the brief.

1. Populate actual emitted AccessNode bounds for visible commands, overflow, menu and clipped rows from authoritative geometry. Handle scrolled-out rows consistently with semantic focus/scroll access. Test the AccessNode output, including clipped/scrolled row, rather than only the synthetic rectangle hook. No AccessKit bridge rewrite or Widget API change.
2. Track current pointer across popup routing, refresh/clear hover on popup close, and never activate based on stale hover. Reproduce keyboard-open from hovered A → click hidden B → release → same-position second click without CursorMoved; only B fires. Cover pointer-open stale Overflow and layout/close behavior as appropriate.
3. Release suppression must track the actual left press needing suppression; right/middle press-release then Escape must leave no pointer capture. Prove a subsequent sibling click routes successfully via actual host/container dispatch. Preserve outside dismissal consuming its matching left release.

Use focused RED/GREEN before each fix, then affected Toolbar/context menu/host checks once. Do not repeat unrelated broad suites or screenshots unless paint/layout changes. Preserve existing accepted measurement, callback ownership and manual compatibility. Existing __eh_frame warning is known baseline only.

Owned scope: toolbar.rs plus ContextMenu only if necessary; report append. No subagents, no pushes, no broad formatting. `git commit --only` exact owned paths; verify file list. Record commands/results, each finding's resolution, self-review and remaining limits in `task-4-report.md`. Return short commit/status/report summary. Root will dispatch scoped re-review.
