# Measured UI Components Implementation Plan

> **For agentic workers:** REQUIRED SUB-SKILL: Use superpowers:subagent-driven-development (recommended) or superpowers:executing-plans to implement this plan task-by-task. Steps use checkbox (`- [ ]`) syntax for tracking.

**Goal:** Repair shared sizing and interaction contracts so app authors get readable, balanced layouts with fewer manual measurements.

**Architecture:** Add one resolved-text normalization boundary while preserving existing relative APIs. Repair EmptyState, rich editor, opt-in scrolling editor fill and measured actionable Toolbar overflow. App composition migrations consume existing Card/Actions/FormPage rather than inventing another layout system.

**Tech Stack:** Rust, Taffy, cosmic-text, Vello and qOS Widget lifecycle.

**Spec:** `docs/superpowers/specs/2026-09-15-app-ui-balance.md`

## Global Constraints

- Reuse the repository Cargo target cache; do not rebuild all dependencies into a new target directory without a concrete build-isolation need. Isolate runtime captures with task-specific HOME and XDG_CONFIG_HOME/XDG_DATA_HOME/XDG_CACHE_HOME/XDG_STATE_HOME, separately from build caches.

- Prioritize ordinary100% and narrow layout as well as200% text.
- Preserve primary actions, keyboard access, state and explicit manual dimensions.
- Keep legacy renderer-relative font APIs compatible; theme-resolved fonts must scale once.
- Do not globally change primitive padding or reinterpret explicit fixed sizes.
- Preserve unrelated working changes and untracked Scratchpad ownership.
- No pushes, merges, publishing or dependency upgrades.
- Existing linked worktree /Users/xaver/dev/qos-macos-shell; sequential implementers and scoped reviews.
- Focused RED/GREEN behavior regressions before implementation; run relevant existing UI tests once before scoped commit. CARGO_BUILD_JOBS=4, CARGO_PROFILE_DEV_DEBUG=0, CARGO_PROFILE_TEST_DEBUG=0.
- Every task report includes exact commands/results, self-review, screenshot paths if requested, and remaining gaps. No subagents from implementers.


### Task 7: Preserve the final empty line in attributed text

**Execution order:** after Task4, before Task6. Shared2/3 accepted; this separate defect was discovered during writing-surface verification.
**Files:** `ui/src/richtext.rs`, focused regressions in `ui/src/widget/text_input.rs`; do not modify Scrollable or app source.
**Evidence:** `.superpowers/app-ui-2026-09-15/trailing-line-diagnosis.md` and its direct-rustc public API probe. cosmic-text 0.19.0 set_rich_text drops the final empty paragraph after LF, while set_text retains it. Metadata still contains the line, producing an EOF caret on row zero and wrong pointer mapping.

- [ ] Establish RED for plain versus styled `"x\n"`: equal two-line height, EOF caret on the final row, visual-line index, logical-line band and below-content hit returns EOF. Controls: `"x"`, `"x\ny"`, `"\n"`, multiple trailing LF and split attributed spans, at 1× and 2×.
- [ ] Normalize at the RichTextLayout attributed shaping boundary before shaping: final empty BufferLine, no artificial visible character or byte offset change, final effective run attrs/metrics and alignment preserved. Confirm actual cosmic-text APIs before implementation. Do not switch measurement to the broken styled height or special-case Scrollable.
- [ ] TextInput integration: measure then draw a multiline trailing-LF value; content height agrees within documented pixel ceiling, EOF caret remains at final row, clicking that row maps to `text.len()`, and caret-follow scroll stays at the end. Preserve attributed styling, current-line/gutter geometry and default/manual dimensions.
- [ ] Run focused richtext/TextInput/CodeEditor regressions and Scrollable integration suite, scoped check and format. Record exact RED/GREEN; no broad suite/dependency upgrade. Report any final-empty-line style ambiguity before expanding scope. Selection LF-only decoration redesign is excluded.

**Report:** `.superpowers/sdd/2026-09-15-measured-ui-components/task-7-report.md`. No subagents, no push. Commit only exact owned paths using `git commit --only` and verify the resulting file list.
