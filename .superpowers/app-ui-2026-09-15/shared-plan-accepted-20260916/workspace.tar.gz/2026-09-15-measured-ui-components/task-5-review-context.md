# Task 5 review context

Automatic minimum-height contract only: Card, ContentCard, CardGrid must contribute enough intrinsic height through nested auto-grid parents into scroll content. Default/manual dimensions stay unchanged. Do not accept screenshot correction if per-node layout allocation still overlaps and descendant scroll scanning merely hides the mistake.

Named dependent RED tests before this task:
- Store full_narrow_catalogue_keeps_discover_section_below_ready_cards: last Ready descendant y863, Discover y576.
- Settings region_preview_follows_every_format_control: last First day field y450, Preview y436.

App Task3 independent source review accepts its Store/Settings geometry composition pending this shared dependency. Themes has two unrelated fixes queued; do not flag or fix them in this task.

Explicit fixed180 card rows, fixed manual Button dimensions, zero min-width wrapping, default Column fill contracts must remain compatible. Read diagnostic file for hypothesis but trust actual RED/GREEN results and diff. No broad source crawl; named risks: fixed row clamp, automatic parent contribution propagation, short scroll ownership, resize stability.

Existing unrelated working diff in column.rs is formatting only and must not be absorbed. Pre-existing renderer regressions/design-token tests/manifests/runtime files belong to other work. No production or index changes by reviewer; no subagents. Both spec and quality verdicts required.
