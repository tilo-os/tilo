# Shared Task3 scoped change

commit fba9ea50f0e0547237ac4c3d7151c04b5e6ec145
Author:     Xaver Emmerling <xaver@Mac.lan>
AuthorDate: Wed Sep 16 10:39:12 2026 -0700
Commit:     Xaver Emmerling <xaver@Mac.lan>
CommitDate: Wed Sep 16 10:39:12 2026 -0700

    Add opt-in full-height writing surfaces to Scrollable

 .../task-3-report.md                               | 127 ++++++++++
 ui/src/widget/scrollable.rs                        | 226 +++++++++++++++++-
 ui/src/widget/text_input.rs                        |   5 +-
 ui/tests/scrollable_test.rs                        | 258 +++++++++++++++++++++
 4 files changed, 609 insertions(+), 7 deletions(-)

diff --git a/.superpowers/sdd/2026-09-15-measured-ui-components/task-3-report.md b/.superpowers/sdd/2026-09-15-measured-ui-components/task-3-report.md
new file mode 100644
index 000000000..2f041e5c3
--- /dev/null
+++ b/.superpowers/sdd/2026-09-15-measured-ui-components/task-3-report.md
@@ -0,0 +1,127 @@
+# Shared Task 3 — opt-in full writing surface
+
+## Outcome and scope
+
+Implemented `Scrollable::with_content_min_viewport_height()` and the authorized one-line Scratchpad opt-in. Empty auto-height editors fill the measured viewport; long editors retain intrinsic overflow; default compact fields and explicit child heights retain their contracts. Lower-area clicks focus and place the caret, including a second click on an already-focused editor. First-wheel scrolling reaches the outer pane without losing the event to fractional inner overflow.
+
+Initial HEAD was verified as `83c269dac5d2fa49078472887d9c4dda530c2ae6`. Concurrent unrelated work subsequently advanced HEAD (observed `396cf024b` before the final checks). No resets, pushes, merges, dependency upgrades, new build caches, or edits to other tasks' files were performed.
+
+Owned commit paths:
+
+- `ui/src/widget/scrollable.rs`
+- `ui/src/widget/text_input.rs` (controller-authorized intrinsic-height correction only)
+- `ui/tests/scrollable_test.rs`
+- `.superpowers/sdd/2026-09-15-measured-ui-components/task-3-report.md`
+
+Scratchpad remains pre-existing untracked work and is not committed. Original source was verified byte-for-byte against `.superpowers/app-ui-2026-09-15/scratchpad-original/lib.rs`, SHA256 `0875a6f0447707f20534e4123040fa39599024da0345c13238208d8cc6b0cce4`. Its only persistent source edit is `.with_content_min_viewport_height()` at the existing Scrollable chain. The exact app-only diff is saved in `task-3-scratchpad.patch` beside this report. All existing action bindings and app copy remain intact.
+
+## Implementation and self-review
+
+- The opt-in is absent by default. Existing Scrollable layout topology and intrinsic behavior stay unchanged when it is not used.
+- The builder installs one presentational `ViewportContent` wrapper. Builder order and repeated opt-in are covered. The wrapper reuses Container's ordinary child lifecycle while registering that layout node as its own; it exposes the real child through normal traversal and creates no accessible control.
+- A retained `Rc<Cell<f32>>` carries the measured viewport decision. Scrollable's adjustment changes only that decision. The wrapper changes only its own `min_size.height`. Neither adjustment mutates children or changes topology. Its Grid `minmax(min-content, 1fr)` row stretches short auto content while retaining long content. Explicit child sizing is never rewritten.
+- The retained-tree test uses the production bounded solver through repeated narrow/wide, short/long/short transitions, verifies the child's full Taffy style is unchanged, and checks real scroll extents. The public Driver tests cover the host's rebuild/interaction lifecycle as well.
+- Two independently reproduced interaction issues were corrected within controller-approved scope. TextInput's shaped multiline intrinsic height now rounds upward before Taffy rounds layout pixels, eliminating a phantom fractional inner scroll range. Fixed/manual dimensions and wheel-consumption logic are unchanged. Scrollable now assigns background focus only after an unhandled child press; explicit child focus survives, and scrollbar presses still focus the pane.
+- Existing scrollbar/background keyboard behavior, default compact fields, explicit 72px child height, lower clicks and caret placement at 1×/2×, and the app's action/persistence routes all pass.
+
+## RED evidence and investigation
+
+All Cargo commands used `CARGO_BUILD_JOBS=4 CARGO_PROFILE_DEV_DEBUG=0 CARGO_PROFILE_TEST_DEBUG=0` unless explicitly shown otherwise. Full logs are retained beside this report under `task-3-logs/`.
+
+1. Initial behavioral RED:
+   `cargo test -p ui --test it scrollable_test -- --nocapture`
+   — 6 passed, 2 failed. Empty editor ended at y=36 while the footer began at y=360, including the narrow resize fixture. `task3-red-integration.log` records it. A test-only no-op extension builder allowed a behavioral RED before the production API existed; it was removed when the real builder was implemented.
+2. Initial wrapper GREEN attempt: 7 passed, 1 failed because a test assumed every long document exceeded 1000px. At 760px wide, the fixture legitimately measured 816px. Corrected that assertion to the actual requirement, exceeding the 400px viewport. The next run passed 9/9 (`task3-green2.log`). No production change was made for that test correction.
+3. Expanded actual RED after app validation:
+   `cargo test -p ui --test it scrollable_test -- --nocapture`
+   — 8 passed, 2 failed (`task3-fractional-red4.log`).
+   - Second lower click: text remained `lower click` instead of `lower click at end`. Scrollable's early focus fallback displaced the already-focused child because TextInput did not request focus again.
+   - First wheel: 47 nonempty rows at font size 18.1, width 416, viewport height 300 produced a 1079px box with `content_height() == 1079.375`. The first wheel changed inner scroll from 0 to 0.375 while outer y remained 0, with the editor focused throughout.
+4. Default Scrollable focus RED:
+   `cargo test -p ui --test it scrollable_test::repeated_click_keeps_default_scrollable_editor_focused -- --exact --nocapture`
+   — failed, actual `first`, expected `first again` (`task3-focus-red.log`). This proves the fallback correction also covers the default tree.
+5. First-wheel correction GREEN:
+   `cargo test -p ui --test it scrollable_test::fractional_height_editor_routes_first_wheel_to_outer_scrollable -- --exact --nocapture`
+   — 1 passed (`task3-fractional-green.log`). Final all-Scrollable integration run passed 12/12.
+
+Transient unrelated compile blockers were preserved and later resolved by their owners: `headless.rs` missing `sync`/ambiguous integer; Chromium `encode_command` test expected Value instead of Option<Value>; `native_scenario.rs` called App probe methods that were not yet present. Initial library attempts are in `task3-red.log`, `task3-existing-ui-tests.log`, and `task3-existing-ui-tests2.log`. They are compile blockers, not behavioral REDs. The final library build and affected tests are green.
+
+The capture harness also required two fixture corrections: replace the unjustified height > 2× window check with true overflow; use Driver modifier state plus `key("End")`, since `key("Ctrl+End")` is a literal character string. Both helpers now use `Theme::dark().with_text_scale(scale)` to follow the normal resolved-theme contract. Earlier `task-3-captures`, `-v2`, and `-v3` directories are diagnostic artifacts, not acceptance captures. A repeated-wheel diagnostic did not resolve the actual issue and was removed; the final harness requires one downward wheel.
+
+## Final verification
+
+- `CARGO_BUILD_JOBS=4 CARGO_PROFILE_DEV_DEBUG=0 CARGO_PROFILE_TEST_DEBUG=0 cargo test -p ui --test it scrollable_test -- --nocapture`
+  — **12 passed**, 0 failed (`task3-final-integration.log`).
+- `CARGO_BUILD_JOBS=4 CARGO_PROFILE_DEV_DEBUG=0 CARGO_PROFILE_TEST_DEBUG=0 cargo test -p ui --lib widget::scrollable::tests -- --nocapture`
+  — **34 passed**, 0 failed (`task3-existing-ui-final.log`). Includes scrollbar drag, paging, clipping/focus boundaries, gutters, manual heights, and compact max-height behavior.
+- `target/debug/deps/ui-98aece3f3d10fdcd widget::text_input::tests --nocapture`
+  — **99 passed**, 0 failed (`task3-text-input-final.log`). Uses the just-built library test binary from the preceding Cargo command.
+- `target/debug/deps/ui-98aece3f3d10fdcd widget::code_editor::tests --nocapture`
+  — **23 passed**, 0 failed (`task3-code-editor-final.log`). Includes the wrapper's theme/renderer measurement regression.
+- `CARGO_BUILD_JOBS=4 CARGO_PROFILE_DEV_DEBUG=0 cargo check -p ui`
+  — passed (`task3-check-final.log`).
+- `rustfmt --edition 2024 --check ui/src/widget/scrollable.rs ui/src/widget/text_input.rs ui/tests/scrollable_test.rs`
+  — passed.
+- `git diff --check -- ui/src/widget/scrollable.rs ui/src/widget/text_input.rs ui/tests/scrollable_test.rs`
+  — passed.
+
+The final lib test link emitted the existing macOS `__eh_frame section too large` warning; compilation and tests succeeded.
+
+## Actual Scratchpad validation and captures
+
+Reproducible harness source: `task-3-scratchpad-check.rs` beside this report. It was temporarily copied to `apps/scratchpad/tests/task3_surface.rs` for compilation and removed after validation. No app test file was left behind or committed.
+
+Final build:
+
+```sh
+CARGO_BUILD_JOBS=4 CARGO_PROFILE_DEV_DEBUG=0 CARGO_PROFILE_TEST_DEBUG=0 cargo test -p qos-scratchpad --no-run
+```
+
+Build log: `task-3-logs/task3-app-final-build.log`. It built the source including the one-line app opt-in and both confirmed framework fixes. Binary timestamps were September 16, 2026, 10:34:54 local:
+
+- `/Users/xaver/dev/qos-macos-shell/target/debug/qos-scratchpad`
+  SHA256 `14568d44002fdd5713266ce1040de916389fad1c57dc005326f200766d0a96b4`
+- `/Users/xaver/dev/qos-macos-shell/target/debug/deps/task3_surface-b32c6a49fb72a68a`
+  SHA256 `958b13c2e3b7c5687c7a9fcbbebf39bf487af45c43f7ccf59dcc33569008b177`
+
+Runtime captures used isolated HOME and all four XDG directories, separately from the repository Cargo cache. With cwd `/Users/xaver/dev/qos-macos-shell`, the exact acceptance invocation was:
+
+```sh
+env HOME="$PWD/.superpowers/sdd/2026-09-15-measured-ui-components/task-3-runtime/home" \
+XDG_CONFIG_HOME="$PWD/.superpowers/sdd/2026-09-15-measured-ui-components/task-3-runtime/config" \
+XDG_DATA_HOME="$PWD/.superpowers/sdd/2026-09-15-measured-ui-components/task-3-runtime/data" \
+XDG_CACHE_HOME="$PWD/.superpowers/sdd/2026-09-15-measured-ui-components/task-3-runtime/cache" \
+XDG_STATE_HOME="$PWD/.superpowers/sdd/2026-09-15-measured-ui-components/task-3-runtime/state" \
+QOS_TASK3_CAPTURE_DIR="$PWD/.superpowers/sdd/2026-09-15-measured-ui-components/task-3-captures-final" \
+target/debug/deps/task3_surface-b32c6a49fb72a68a --nocapture
+```
+
+Result: **1 passed**, covering all four layouts (`task3-captures-final.log`). The same HOME/XDG environment, without QOS_TASK3_CAPTURE_DIR, ran:
+
+```sh
+target/debug/deps/scratchpad-43c30d0629dc06f2 --nocapture
+```
+
+Result: **7 passed**, 0 failed (`task3-existing-app-final.log`). This reuses the original `editor_uses_the_available_width_and_keeps_save_visible` and `typed_note_survives_save_close_and_reopen` tests, plus replay, save failure, exclusive profile lock, corrupt content, and CLI screenshot tests.
+
+Capture root (absolute):
+`/Users/xaver/dev/qos-macos-shell/.superpowers/sdd/2026-09-15-measured-ui-components/task-3-captures-final/`
+
+| Prefix | Viewport / scale | Empty editor y range | Save y range | Persisted long bytes |
+| --- | --- | --- | --- | --- |
+| `wide` | 1000×700 / 1× | 122–581 | 599–639 | 2516 |
+| `narrow` | 480×600 / 1× | 122–481 | 499–539 | 2518 |
+| `double` | 640×480 / 2× | 179–346 | 364–404 | 2518 |
+| `narrow-double` | 480×600 / 2× | 179–436 | 454–494 | 2525 |
+
+For each prefix the exact files are `<prefix>-empty.png`, `<prefix>-saved.png`, `<prefix>-reopened.png`, `<prefix>-long-top.png`, `<prefix>-long-bottom.png`, and `<prefix>-empty.json`. Profiles are retained at `profile-<prefix>` under that root.
+
+The harness clicks 25px above the lower editor edge, types Unicode text through the existing editor action, invokes the existing Save binding, drops/reopens the actual profile, and verifies exact persisted text. It then appends a long note through IME commit, verifies intrinsic overflow, scrolls to top then bottom with a single downward wheel, verifies the bottom equals the original viewport edge and the Save rectangle stays unchanged, saves, and reopens again to compare the complete body byte-for-byte.
+
+Visual inspection: all four empty PNGs and all four long-bottom PNGs, plus `narrow-reopened.png`, were opened and inspected. The editor reads as a full writing surface; the final marker `Final line — the end is reachable.` is fully visible at the bottom in every layout; Save and the reminder stay visible. Header/helper copy was retained because the filled surface fixes the hierarchy without requiring an unrelated app redesign. Controller owns its separate baseline-matched 1200×800 / 480×900 / 800×900@2 final image gate.
+
+## Remaining observations and limits
+
+- Separate trailing-newline diagnostic for controller follow-up, not changed here: `TextInput::local().multiline(true).with_font_size(18.1).with_initial_value(&"A line of text.\n".repeat(46))` in the opt-in Scrollable, viewport 416×300, measured box height 1079px but `content_height()` after Driver drawing/clicking at (30,30) was 1056.75px (one row less). Text, width and 1× theme were unchanged; no edits occurred. Both before and after the first wheel had that content height. Exact diagnostic output is in `task3-fractional-diagnostic.log`. Ending with nonempty `Final line` produces 1079.375px drawn content and the confirmed fractional RED. The final regression uses that nonempty last line. This whole-row trailing-newline discrepancy merits a bounded separate investigation rather than an unsupported fix in Task 3.
+- Captures use the shared production Driver layout/event/action path and offscreen renderer, not OS-level pointer injection into a live macOS window.
+- No full unrelated UI/workspace suite was run; the brief's focused affected suites, compilation checks, and real Scratchpad persistence/capture routes are green.
diff --git a/ui/src/widget/scrollable.rs b/ui/src/widget/scrollable.rs
index 399e6c6ca..37d623340 100644
--- a/ui/src/widget/scrollable.rs
+++ b/ui/src/widget/scrollable.rs
@@ -109,20 +109,22 @@ pub struct Scrollable {
     fixed_height: Option<f32>,
     /// Lets a document-size viewport shrink to its content while still
     /// becoming scrollable before it crowds its parent. This is deliberately
     /// distinct from `fixed_height`: dialogs often have short and long pages
     /// in one flow and should not reserve a large empty viewport for the
     /// short page.
     max_height: Option<f32>,
     /// Absorbs the parent's remaining flex height instead of claiming
     /// `percent(1.0)`. `fixed_height` wins if both are set.
     fill_parent_height: bool,
+    /// Opt-in inherited decision, consumed by the retained content wrapper.
+    content_min_viewport_height: Option<Rc<Cell<f32>>>,
     child: Option<Element>,
     /// Retained Taffy identity for `child`; refreshed with the layout tree so
     /// event and scroll-layout paths never allocate `taffy.children()`.
     child_node: Option<NodeId>,
     rect: Rect,
     /// True whenever `scroll_by`/`tick` actually moved `offset_*`; a wheel
     /// event that only mutates this touches no descendant. Cleared by
     /// `mark_drawn`.
     scroll_dirty: bool,
     show_scrollbar: bool,
@@ -187,20 +189,21 @@ impl Scrollable {
             content_h: 0.0,
             viewport_w: 0.0,
             viewport_h: 0.0,
             vx: 0.0,
             vy: 0.0,
             decay: 0.92,
             sticky_header_height: 0.0,
             fixed_height: None,
             max_height: None,
             fill_parent_height: false,
+            content_min_viewport_height: None,
             child: None,
             child_node: None,
             rect: Rect::ZERO,
             scroll_dirty: false,
             show_scrollbar: true,
             last_cursor: Point::ZERO,
             cursor_initialized: false,
             vbar: Scrollbar::vertical(),
             hbar: Scrollbar::horizontal(),
             overlay: true,
@@ -220,23 +223,46 @@ impl Scrollable {
         }
     }
     pub fn new_vertical() -> Self {
         Self::new(ScrollAxis::Vertical)
     }
     pub fn new_horizontal() -> Self {
         Self::new(ScrollAxis::Horizontal)
     }
     #[must_use]
     pub fn with_child(mut self, c: Element) -> Self {
-        self.child = Some(c);
+        self.child = Some(match &self.content_min_viewport_height {
+            Some(minimum) => Box::new(ViewportContent::new(c, Rc::clone(minimum))),
+            None => c,
+        });
         self
     }
+    /// Let auto-height content fill at least the measured viewport height,
+    /// retaining its intrinsic height when it overflows. This does not change
+    /// an explicitly sized child's authored height. Ordinary form fields stay
+    /// content-sized unless their Scrollable opts in.
+    ///
+    /// Adds a presentational single-child wrapper to normal widget traversal;
+    /// the content keeps its identity, focus and action bindings. Hosts must
+    /// use the shared measured layout solver to resolve the viewport minimum.
+    #[must_use]
+    pub fn with_content_min_viewport_height(mut self) -> Self {
+        if self.content_min_viewport_height.is_none() {
+            let minimum = Rc::new(Cell::new(0.0));
+            if let Some(child) = self.child.take() {
+                self.child = Some(Box::new(ViewportContent::new(child, Rc::clone(&minimum))));
+            }
+            self.content_min_viewport_height = Some(minimum);
+        }
+        self
+    }
+
     #[must_use]
     pub fn with_sticky_header(mut self, h: f32) -> Self {
         self.sticky_header_height = h;
         self
     }
     /// The bar still auto-hides per-axis whenever content fits regardless
     /// of this flag; `false` suppresses it unconditionally.
     #[must_use]
     pub fn with_scrollbar(mut self, show: bool) -> Self {
         self.show_scrollbar = show;
@@ -914,20 +940,178 @@ impl Scrollable {
         if shift && self.axis_has_horizontal() && dx == 0.0 {
             dx = dy;
             dy = 0.0;
         }
         let before = (self.offset_x, self.offset_y);
         self.scroll_by(dx, dy);
         (self.offset_x, self.offset_y) != before
     }
 }
 
+/// A presentational Grid surface. Container supplies the ordinary single-child
+/// lifecycle; we register its layout node as this wrapper's own node so only
+/// this hook adjusts its minimum. The child style is never rewritten.
+struct ViewportContent {
+    inner: crate::widget::Container,
+    minimum: Rc<Cell<f32>>,
+}
+
+impl ViewportContent {
+    fn new(child: Element, minimum: Rc<Cell<f32>>) -> Self {
+        Self {
+            inner: crate::widget::Container::new()
+                .with_no_padding()
+                .with_child(child),
+            minimum,
+        }
+    }
+}
+
+impl Widget for ViewportContent {
+    fn sync(&mut self, state: &mut AutoCommit, path: &ObjId) {
+        self.inner.sync(state, path);
+    }
+
+    fn update(&mut self, state: &mut AutoCommit, path: &ObjId) -> bool {
+        self.inner.update(state, path)
+    }
+
+    fn build_layout(
+        &mut self,
+        taffy: &mut TaffyTree<()>,
+        theme: &Theme,
+        nodes: &mut std::collections::HashMap<NodeId, *mut dyn Widget>,
+    ) -> NodeId {
+        use taffy::style_helpers::{fr, length, min_content, minmax};
+        let node = self.inner.build_layout(taffy, theme, nodes);
+        let _ = taffy.set_style(
+            node,
+            Style {
+                display: taffy::Display::Grid,
+                // The flexible track fills short content; its intrinsic minimum
+                // keeps a long measured editor taller than the viewport.
+                grid_template_rows: vec![minmax(min_content(), fr(1.0_f32))],
+                grid_template_columns: vec![minmax(length(0.0_f32), fr(1.0_f32))],
+                size: Size {
+                    width: Dimension::percent(1.0),
+                    height: Dimension::auto(),
+                },
+                min_size: Size {
+                    width: Dimension::length(0.0),
+                    height: Dimension::length(self.minimum.get()),
+                },
+                flex_shrink: 0.0,
+                ..Default::default()
+            },
+        );
+        nodes.insert(node, std::ptr::from_mut::<dyn Widget>(self));
+        node
+    }
+
+    fn adjust_layout_style(&mut self, taffy: &mut TaffyTree<()>, node: NodeId) -> bool {
+        let Ok(style) = taffy.style(node) else {
+            return false;
+        };
+        let height = Dimension::length(self.minimum.get());
+        if style.min_size.height == height {
+            return false;
+        }
+        let mut style = style.clone();
+        style.min_size.height = height;
+        taffy.set_style(node, style).is_ok()
+    }
+
+    fn apply_layout(&mut self, taffy: &TaffyTree<()>, node: NodeId, origin: Point) {
+        self.inner.apply_layout(taffy, node, origin);
+    }
+
+    fn draw(
+        &mut self,
+        scene: &mut Scene,
+        transform: Affine,
+        text: &mut TextRenderer,
+        theme: &Theme,
+        presence: &PresenceCtx,
+    ) {
+        self.inner.draw(scene, transform, text, theme, presence);
+    }
+
+    fn draw_with_presence(
+        &mut self,
+        scene: &mut Scene,
+        transform: Affine,
+        text: &mut TextRenderer,
+        theme: &Theme,
+        presence: &PresenceCtx,
+        permissions: &crate::permissions::PermissionContext,
+    ) {
+        self.inner
+            .draw_with_presence(scene, transform, text, theme, presence, permissions);
+    }
+
+    fn handle_event(
+        &mut self,
+        event: &WindowEvent,
+        scale: f64,
+        mods: &winit::event::Modifiers,
+        state: &mut AutoCommit,
+        path: &ObjId,
+        handled: &mut bool,
+        focus: &mut Option<NodeId>,
+        node: NodeId,
+        taffy: &TaffyTree<()>,
+    ) {
+        self.inner
+            .handle_event(event, scale, mods, state, path, handled, focus, node, taffy);
+    }
+
+    fn children(&self) -> Vec<&dyn Widget> {
+        self.inner.children()
+    }
+    fn for_each_child(&self, visitor: &mut dyn FnMut(&dyn Widget)) {
+        self.inner.for_each_child(visitor);
+    }
+    fn children_mut(&mut self) -> Vec<&mut (dyn Widget + '_)> {
+        self.inner.children_mut()
+    }
+    fn take_structure_dirty(&mut self) -> bool {
+        self.inner.take_structure_dirty()
+    }
+    fn wants_pointer_capture(&self) -> bool {
+        self.inner.wants_pointer_capture()
+    }
+    fn get_rect(&self) -> Rect {
+        self.inner.get_rect()
+    }
+    fn name(&self) -> &str {
+        "ScrollableContent"
+    }
+
+    fn start_resource_operation_with_document(
+        &mut self,
+        invocation: qos_actions::InvocationId,
+        kind: qos_actions::OperationKind,
+        type_id: &str,
+        payload: &[u8],
+        doc: &mut AutoCommit,
+        path: &ObjId,
+    ) -> Result<Option<crate::widget::ResourceOperationStart>, String> {
+        self.inner
+            .start_resource_operation_with_document(invocation, kind, type_id, payload, doc, path)
+    }
+
+    fn collect_damage(&self, regions: &mut Vec<Rect>) {
+        self.inner
+            .for_each_child(&mut |child| child.collect_damage(regions));
+    }
+}
+
 /// Maximum `rect.y1` across a widget subtree, for finding the true bottom
 /// edge when taffy's `content_size` under-reports.
 fn max_bottom_edge(w: &dyn Widget) -> f64 {
     let mut deepest = w.get_rect().y1;
     if w.child_clip_rect().is_some() {
         return deepest;
     }
     for c in w.children() {
         deepest = deepest.max(max_bottom_edge(c));
     }
@@ -1006,20 +1190,37 @@ impl Widget for Scrollable {
             ..Default::default()
         };
         let node = match self.child_node {
             Some(c) => taffy.parent_node(style, &[c]),
             None => taffy.leaf_node(style),
         };
         node_map.insert(node, std::ptr::from_mut::<dyn Widget>(self));
         node
     }
 
+    fn adjust_layout_style(&mut self, taffy: &mut TaffyTree<()>, node: NodeId) -> bool {
+        let Some(minimum) = &self.content_min_viewport_height else {
+            return false;
+        };
+        let Ok(layout) = taffy.layout(node) else {
+            return false;
+        };
+        let height = layout.size.height.max(0.0);
+        if (minimum.get() - height).abs() < f32::EPSILON {
+            return false;
+        }
+        // Inherited decision only. The wrapper's hook changes its OWN style,
+        // regardless of the host's node visitation order.
+        minimum.set(height);
+        true
+    }
+
     fn apply_layout(&mut self, taffy: &TaffyTree<()>, node: NodeId, origin: Point) {
         // Geometry may have moved beneath a stationary pointer. The next
         // same-position event must therefore be routed once again.
         self.cursor_initialized = false;
         let l = taffy.layout(node).copied().unwrap_or_default();
         self.rect = Rect::new(
             origin.x + f64::from(l.location.x),
             origin.y + f64::from(l.location.y),
             origin.x + f64::from(l.location.x) + f64::from(l.size.width),
             origin.y + f64::from(l.location.y) + f64::from(l.size.height),
@@ -1149,27 +1350,23 @@ impl Widget for Scrollable {
                     }
                     CursorMoveOutcome::Coalesced => return,
                 }
             }
             WindowEvent::MouseInput {
                 state: ElementState::Pressed,
                 button: MouseButton::Left,
                 ..
             } => {
                 let cur = self.last_cursor;
-                // A child that consumes the press overwrites `focus_target`
-                // afterward, so focus still lands on the deepest target.
-                if self.content_viewport_rect().contains(cur) {
-                    *focus_target = Some(node_id);
-                }
                 // Thumb press → drag; track press → page + hold.
                 if self.on_track_or_thumb_press(cur) {
+                    *focus_target = Some(node_id);
                     *handled = true;
                     return;
                 }
             }
             WindowEvent::MouseInput {
                 state: ElementState::Released,
                 button: MouseButton::Left,
                 ..
             } => {
                 let had_hold = self.hold.take().is_some();
@@ -1261,20 +1458,37 @@ impl Widget for Scrollable {
                 scale_factor,
                 mods,
                 doc,
                 obj,
                 handled,
                 focus_target,
                 child_node,
                 taffy,
             );
         }
+        // An already-focused editor can consume a press without requesting
+        // focus again. Only use the pane as a fallback for an unhandled
+        // background press; never displace the child's existing focus.
+        if !*handled
+            && focus_target.is_none()
+            && pointer_in_content
+            && matches!(
+                event,
+                WindowEvent::MouseInput {
+                    state: ElementState::Pressed,
+                    button: MouseButton::Left,
+                    ..
+                }
+            )
+        {
+            *focus_target = Some(node_id);
+        }
     }
 
     fn children(&self) -> Vec<&dyn Widget> {
         self.child
             .as_ref()
             .map(|c| c.as_ref() as &dyn Widget)
             .into_iter()
             .collect()
     }
 
diff --git a/ui/src/widget/text_input.rs b/ui/src/widget/text_input.rs
index fd61d5070..6139dad74 100644
--- a/ui/src/widget/text_input.rs
+++ b/ui/src/widget/text_input.rs
@@ -3673,21 +3673,24 @@ impl Widget for TextInput {
                     f64::from(layout.height())
                 })
                 + ML_PAD_Y * 2.0;
             self.model_layout_dirty = false;
             #[allow(
                 clippy::cast_possible_truncation,
                 reason = "content height is a bounded on-screen size for taffy layout, never near f32's range"
             )]
             return taffy::Size {
                 width,
-                height: height as f32,
+                // Taffy rounds layout boxes to pixels. Never round intrinsic
+                // text below its last row: subpixel inner overflow would eat
+                // the first wheel event instead of scrolling the outer pane.
+                height: height.ceil() as f32,
             };
         }
         let avail_w = (f64::from(width) - self.ml_left() - ML_PAD_X).max(1.0);
         self.build_lines(text_renderer, avail_w);
         #[allow(
             clippy::cast_possible_truncation,
             reason = "content height is a bounded on-screen size for taffy layout, never near f32's range"
         )]
         let height = self.content_height() as f32;
         self.model_layout_dirty = false;
diff --git a/ui/tests/scrollable_test.rs b/ui/tests/scrollable_test.rs
index 5b02773e2..68f893e0a 100644
--- a/ui/tests/scrollable_test.rs
+++ b/ui/tests/scrollable_test.rs
@@ -37,10 +37,268 @@ fn scrollable_momentum_decays() {
     s.set_viewport_size(200.0, 500.0);
     s.fling(0.0, 1500.0);
     let before = s.offset_y();
     for _ in 0..120 {
         s.tick(1.0 / 60.0);
     }
     let after = s.offset_y();
     assert!(after > before);
     assert!(s.momentum_speed() < 10.0);
 }
+
+use ui::State;
+use ui::headless::Driver;
+use ui::local_state::LocalState;
+use ui::theme::Theme;
+use ui::widget::{Button, Column, Container, Text, TextInput};
+
+fn editor_driver(text: &LocalState<String>, fill: bool, scale: f32) -> Driver {
+    let mut scroll = Scrollable::new_vertical().fill_parent_height();
+    if fill {
+        scroll = scroll.with_content_min_viewport_height();
+    }
+    let root = Column::new()
+        .with_no_padding()
+        .with_gap(0.0)
+        .push(Box::new(
+            scroll.with_child(Box::new(
+                TextInput::from_state(text)
+                    .multiline(true)
+                    .with_id("editor"),
+            )),
+        ))
+        .push(Box::new(Button::new("footer", "Save", None)));
+    let theme = Theme::dark().with_text_scale(scale);
+    Driver::new_with_theme(State::new(), Box::new(root), (600, 400), theme)
+}
+
+#[test]
+fn empty_writing_surface_fills_viewport_and_accepts_lower_click() {
+    for scale in [1.0, 2.0] {
+        let text = LocalState::new(String::new());
+        let mut driver = editor_driver(&text, true, scale);
+        let targets = driver.targets();
+        let editor = *targets.get("editor").unwrap();
+        let footer = *targets.get("footer").unwrap();
+        assert!(
+            (editor.y1 - footer.y0).abs() < 1.0,
+            "editor {editor:?}, footer {footer:?}"
+        );
+        assert!(editor.height() > 250.0);
+        driver.click_at(editor.x0 + 30.0, editor.y1 - 30.0);
+        driver.type_text("lower click");
+        assert_eq!(text.get(), "lower click");
+        driver.click_at(editor.x1 - 30.0, editor.y1 - 30.0);
+        driver.type_text(" at end");
+        assert_eq!(text.get(), "lower click at end");
+        assert!(driver.targets().get("footer").unwrap().y1 <= 400.0);
+    }
+}
+
+#[test]
+fn default_short_multiline_remains_content_sized() {
+    let text = LocalState::new(String::new());
+    let driver = editor_driver(&text, false, 1.0);
+    let targets = driver.targets();
+    assert!(targets.get("editor").unwrap().height() < 60.0);
+    assert!(targets.get("footer").unwrap().y0 > 300.0);
+}
+
+#[test]
+fn long_writing_surface_retains_overflow_and_footer() {
+    let text = LocalState::new("A line of the document.\n".repeat(80));
+    let mut driver = editor_driver(&text, true, 1.0);
+    let initial = *driver.targets().get("editor").unwrap();
+    let footer = *driver.targets().get("footer").unwrap();
+    assert!(initial.height() > 1000.0, "{initial:?}");
+    driver.click_at(30.0, 100.0);
+    driver.scroll(0.0, -800.0);
+    let moved = *driver.targets().get("editor").unwrap();
+    assert!(
+        moved.y0 < initial.y0 - 100.0,
+        "before {initial:?}, after {moved:?}"
+    );
+    assert_eq!(*driver.targets().get("footer").unwrap(), footer);
+    assert!(footer.y1 <= 400.0);
+}
+
+#[test]
+fn writing_surface_settles_resize_and_short_long_short_changes() {
+    let text = LocalState::new(String::new());
+    let mut driver = editor_driver(&text, true, 1.0);
+    for width in [280, 760, 280, 760] {
+        driver.resize((width, 400)).unwrap();
+        for body in [
+            String::new(),
+            "Wrapping document text with some words. ".repeat(100),
+            String::new(),
+        ] {
+            let long = !body.is_empty();
+            text.set(body);
+            driver.relayout();
+            let targets = driver.targets();
+            let editor = targets.get("editor").unwrap();
+            let footer = targets.get("footer").unwrap();
+            assert!(
+                (editor.width() - f64::from(width)).abs() < 1.0,
+                "{editor:?}"
+            );
+            if long {
+                assert!(editor.height() > 400.0, "{editor:?}");
+            } else {
+                assert!(
+                    (editor.y1 - footer.y0).abs() < 1.0,
+                    "editor {editor:?}, footer {footer:?}"
+                );
+            }
+        }
+    }
+}
+
+#[test]
+fn writing_surface_preserves_explicit_child_height() {
+    // The explicit Container remains 72px even though its wrapper fills 300px.
+    let root = Scrollable::new_vertical()
+        .with_height(300.0)
+        .with_content_min_viewport_height()
+        .with_child(Box::new(
+            Container::new()
+                .with_no_padding()
+                .with_height(72.0)
+                .with_child(Box::new(Text::new("Fixed content").with_id("fixed"))),
+        ));
+    let driver = Driver::new(State::new(), Box::new(root), (500, 300));
+    assert!((driver.targets().get("fixed").unwrap().height() - 72.0).abs() < 1.0);
+}
+
+#[test]
+fn writing_surface_retained_tree_settles_without_changing_child_style() {
+    use std::collections::HashMap;
+    use taffy::{AvailableSpace, Dimension, Size, TaffyTree};
+    use ui::bound_dispatch::BoundNodeMap;
+    use ui::text_render::TextRenderer;
+    use ui::widget::{Widget, compute_widget_layout};
+    use vello::kurbo::Point;
+
+    let text = LocalState::new(String::new());
+    // Also exercise child-before-opt-in builder ordering and repeated opt-in.
+    let mut scroll = Scrollable::new_vertical()
+        .with_child(Box::new(TextInput::from_state(&text).multiline(true)))
+        .with_content_min_viewport_height()
+        .with_content_min_viewport_height();
+    let mut tree = TaffyTree::new();
+    let mut nodes = HashMap::new();
+    let root = scroll.build_layout(&mut tree, &Theme::dark(), &mut nodes);
+    let wrapper = *tree.children(root).unwrap().first().unwrap();
+    let editor = *tree.children(wrapper).unwrap().first().unwrap();
+    let child_style = tree.style(editor).unwrap().clone();
+    let mut bindings = BoundNodeMap::new();
+    // SAFETY: one stable tree, exclusively owned throughout the test.
+    unsafe {
+        bindings.rebuild(&scroll, &tree, root, &nodes);
+    }
+    let mut renderer = TextRenderer::new();
+    let mut doc = automerge::AutoCommit::new();
+    for (width, height) in [(280.0, 180.0), (760.0, 420.0), (280.0, 300.0)] {
+        let mut style = tree.style(root).unwrap().clone();
+        style.size.height = Dimension::length(height);
+        tree.set_style(root, style).unwrap();
+        for body in [
+            String::new(),
+            "A document line.\n".repeat(80),
+            String::new(),
+        ] {
+            let long = !body.is_empty();
+            text.set(body);
+            scroll.sync(&mut doc, &automerge::ROOT);
+            tree.mark_dirty(editor).unwrap();
+            // SAFETY: no widgets move or change topology during settlement.
+            unsafe {
+                compute_widget_layout(
+                    &mut tree,
+                    root,
+                    Size {
+                        width: AvailableSpace::Definite(width),
+                        height: AvailableSpace::Definite(height),
+                    },
+                    &nodes,
+                    &bindings,
+                    &mut renderer,
+                )
+            }
+            .unwrap();
+            scroll.apply_layout(&tree, root, Point::ZERO);
+            assert_eq!(tree.style(editor).unwrap(), &child_style);
+            let editor_height = tree.layout(editor).unwrap().size.height;
+            if long {
+                assert!(editor_height > 1000.0);
+                assert!(scroll.max_offset_y() > 500.0);
+            } else {
+                assert!((editor_height - height).abs() < 1.0);
+                assert_eq!(scroll.max_offset_y(), 0.0);
+            }
+        }
+    }
+}
+
+#[test]
+fn fractional_height_editor_routes_first_wheel_to_outer_scrollable() {
+    // 47 nonempty rows at 22.625px plus padding end in .375px; rounding
+    // down must not create an inner scroll range in a fully laid-out input.
+    let root = Scrollable::new_vertical()
+        .with_height(300.0)
+        .with_content_min_viewport_height()
+        .with_child(Box::new(
+            TextInput::local()
+                .with_id("fractional-editor")
+                .multiline(true)
+                .with_font_size(18.1)
+                .with_initial_value(&("A line of text.\n".repeat(46) + "Final line")),
+        ));
+    let mut driver = Driver::new(State::new(), Box::new(root), (416, 300));
+    driver.click_at(30.0, 30.0);
+    let before = *driver.targets().get("fractional-editor").unwrap();
+    driver.scroll(0.0, -3.0);
+    let after = *driver.targets().get("fractional-editor").unwrap();
+    assert!(
+        after.y0 < before.y0 - 100.0,
+        "first wheel must move outer content: before {before:?}, after {after:?}"
+    );
+}
+
+#[test]
+fn repeated_click_keeps_default_scrollable_editor_focused() {
+    let text = LocalState::new(String::new());
+    let mut driver = editor_driver(&text, false, 1.0);
+    let editor = *driver.targets().get("editor").unwrap();
+    driver.click_at(editor.x0 + 25.0, editor.center().y);
+    driver.type_text("first");
+    driver.click_at(editor.x1 - 25.0, editor.center().y);
+    driver.type_text(" again");
+    assert_eq!(text.get(), "first again");
+}
+
+#[test]
+fn pane_background_and_scrollbar_press_still_focus_the_scrollable() {
+    for x in [250.0, 394.0] {
+        let root = Scrollable::new_vertical()
+            .with_height(300.0)
+            .with_child(Box::new(
+                Container::new()
+                    .with_no_padding()
+                    .with_size(100.0, 900.0)
+                    .with_child(Box::new(
+                        Text::new("Tall narrow content").with_id("content"),
+                    )),
+            ));
+        let mut driver = Driver::new(State::new(), Box::new(root), (400, 300));
+        // x=250 hits empty pane background; x=394 hits the scrollbar thumb.
+        driver.click_at(x, 20.0);
+        assert_eq!(
+            driver.focused_access_node().unwrap().role,
+            ui::a11y::Role::Group
+        );
+        let before = driver.targets().get("content").unwrap().y0;
+        driver.key("ArrowDown");
+        assert!(driver.targets().get("content").unwrap().y0 < before);
+    }
+}

## One-line app integration in pre-existing untracked Scratchpad

--- a/apps/scratchpad/src/lib.rs
+++ b/apps/scratchpad/src/lib.rs
@@ -118,6 +118,7 @@
                 .push(Box::new(
                     Scrollable::new_vertical()
                         .fill_parent_height()
+                        .with_content_min_viewport_height()
                         .with_child(Box::new(editor)),
                 )),
         ))
