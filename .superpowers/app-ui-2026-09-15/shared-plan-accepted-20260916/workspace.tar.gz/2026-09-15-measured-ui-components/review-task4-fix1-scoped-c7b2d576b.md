# Review package: c66ec996c..c7b2d576b

## Commits
c7b2d576b Fix toolbar popup pointer state and exported accessibility bounds

## Files changed
 .../task-4-report.md                               |  36 +++
 ui/src/widget/toolbar.rs                           | 275 +++++++++++++++++++--
 2 files changed, 290 insertions(+), 21 deletions(-)

## Diff
diff --git a/.superpowers/sdd/2026-09-15-measured-ui-components/task-4-report.md b/.superpowers/sdd/2026-09-15-measured-ui-components/task-4-report.md
index 47edd9aca..f686d557a 100644
--- a/.superpowers/sdd/2026-09-15-measured-ui-components/task-4-report.md
+++ b/.superpowers/sdd/2026-09-15-measured-ui-components/task-4-report.md
@@ -85,10 +85,46 @@ b9b87e5052b19b95137fc0cdfadbd982730c44164685e50a3f730696cbaa5e36  ui/src/widget/
 - Confirmed `Widget` remains unchanged and existing ContextMenu/TextInput route tests pass.
 - Confirmed actual shared host admission/settlement is exercised, not just manually seeded geometry.
 - Confirmed explicit narrow allocations and menu viewport containment with ordinary and 200% rendered evidence.
 - App-specific consumer migrations and live OS focus/assistive-technology acceptance are outside this shared-widget task. No full workspace suite, app startup, or end-user app screenshot claims are made.
 - `open_anchored` is an owned-menu route; callers should run `layout_within` before paint (Toolbar does this in normal draw, then uses the same geometry in overlay/input). Existing retained legacy ContextMenu sizing remains unchanged.
 - No known blocking issue remains from scoped tests/self-review. Independent controller code review remains the next gate.
 
 ## Commit discipline
 
 Commit only `ui/src/widget/toolbar.rs`, `ui/src/widget/context_menu.rs`, and this report with `git commit --only`. Verify the resulting commit file list; preserve all unrelated working-tree and index content. The returned task status records the resulting commit ID.
+
+## Fix round 1 — accepted review findings
+
+Verified starting HEAD `2aff2e6c7` and read `task-4-fix-1.md` plus `task-4-review.md`. Used receiving-code-review/systematic-debugging to check the named event branches and AccessKit export contract before implementing the accepted fixes. Production scope for this round is **Toolbar only**; ContextMenu, the Widget trait and AccessKit bridge are unchanged. Concurrent non-owned work was preserved.
+
+### Resolutions
+
+1. **Exported accessibility geometry:** visible command/overflow nodes now use `with_bounds` from their authoritative painted rects. The menu node exports its popup rect; menu items export the clipped ContextMenu row rect. Scrolled-out actions export `Rect::ZERO`, remain semantically focusable/visible, and receive real clipped bounds when semantic focus reveals them. The regression asserts the emitted AccessNode fields themselves, including a partially clipped row, zero-area offscreen row and focus-to-reveal transition.
+2. **Stale pointer targets after popup routing:** Toolbar stores the current logical pointer position even while ContextMenu consumes events. Opening clears its old hover/armed target; closing and relayout re-hit-test the stored position. Press/release also re-hit-test before arming/activating. Regression covers keyboard opening from hovered A and pointer opening from hovered Overflow, selection of hidden B, a same-position second click with no CursorMoved, and variants with/without intervening layout. Only B fires once and Overflow stays closed.
+3. **Non-left release suppression:** only a left press routed through the popup arms its matching release suppression. Right/middle press-release followed by Escape leaves no pointer capture. A regression uses a real Row with two retained Toolbars, admitted shared layout and Row event dispatch; the subsequent sibling left click reaches its callback once. Existing outside-left-dismiss suppression remains covered by the full Toolbar group.
+
+### Focused RED / GREEN and final verification
+
+Every Cargo command retained the repository target cache and used `CARGO_BUILD_JOBS=4 CARGO_PROFILE_DEV_DEBUG=0 CARGO_PROFILE_TEST_DEBUG=0`.
+
+- `cargo test -p ui --lib widget::toolbar::lifecycle_tests::review_ -- --nocapture`
+  - **RED: 0 passed, 3 failed** for the exact accepted defects: exported bounds `None` versus painted rect; callback counts `[1,1,0,…]` versus `[0,1,0,…]`; stuck capture after a right press-release and Escape.
+  - **GREEN: 3 passed** after the fixes. All requested variants are contained in those tests, including real Row sibling routing.
+- `cargo test -p ui --lib widget::toolbar -- --nocapture`: **18 passed, 1 existing manual GPU fixture ignored**.
+- `cargo test -p ui --lib context_menu -- --nocapture`: **15 passed**, including legacy TextInput copy/cut routes.
+- `cargo test -p ui --lib widget::layout -- --nocapture`: **7 passed**.
+- `cargo check -p ui --lib`: **passed**.
+- `rustfmt --edition 2024 --check ui/src/widget/toolbar.rs`: **passed**.
+- `git diff --check -- ui/src/widget/toolbar.rs`: **passed**.
+
+The known macOS `__eh_frame` lib-test linker warning remains. Shared-target/package-cache lock waits and recompilation of concurrent vendor changes occurred; no build cache isolation or dependency changes were introduced by this worker. The current lib-test binary path is `target/debug/deps/ui-c93bc6d5c202339c`.
+
+Validated Toolbar source SHA-256: `ce4f839a59fb02e1ba0ddf0785722af0c25b1476dd5ffe9d10c17b03a618585e`.
+
+### Self-review and limits
+
+Checked that platform-exported bounds now come from AccessNode output, while fallback click bounds and semantic action routes remain intact. Checked that popup cursor events update the same pointer used after close/layout, and every left press/release activation revalidates geometry. Verified that right/middle events cannot create unmatched release suppression and that the host regression actually reaches the sibling callback through Row.
+
+No layout, typography, popup paint or callback ownership changes were made in this fix round; the accepted rendered captures/provenance above remain retained and were not regenerated. No broad suite or live macOS accessibility/focus acceptance claim is added. Independent scoped re-review remains the next gate.
+
+Round-1 commit is restricted with `git commit --only` to `ui/src/widget/toolbar.rs` and this report; verify its exact file list after committing. Returned worker status records the commit ID.
diff --git a/ui/src/widget/toolbar.rs b/ui/src/widget/toolbar.rs
index 51f2e8064..a757ebd8e 100644
--- a/ui/src/widget/toolbar.rs
+++ b/ui/src/widget/toolbar.rs
@@ -44,20 +44,21 @@ pub struct Toolbar {
     visible_count: usize,
     extents: Vec<Size<f32>>,
     chip_extent: Size<f32>,
     intrinsic: Size<f32>,
     font: TextStyle,
     padding: f32,
     minimum: f32,
     separator: f32,
     overflow_rect: Rect,
     hovered: Option<Target>,
+    pointer: Option<Point>,
     pressed: Option<Target>,
     focused: bool,
     focus: Option<Target>,
     menu: ContextMenu,
     menu_indices: Vec<Option<usize>>,
     viewport: Option<Rect>,
     swallow_release: bool,
 }
 
 impl Toolbar {
@@ -70,20 +71,21 @@ impl Toolbar {
             visible_count: 0,
             extents: Vec::new(),
             chip_extent: Size::ZERO,
             intrinsic: Size::ZERO,
             font: TextStyle::new(14.0),
             padding: 8.0,
             minimum: 32.0,
             separator: 9.0,
             overflow_rect: Rect::ZERO,
             hovered: None,
+            pointer: None,
             pressed: None,
             focused: false,
             focus: None,
             menu: ContextMenu::new(),
             menu_indices: Vec::new(),
             viewport: None,
             swallow_release: false,
         }
     }
 
@@ -296,21 +298,21 @@ impl Toolbar {
                 ),
             }
         } else {
             Rect::ZERO
         };
         self.reconcile_menu();
         let targets = self.targets();
         if self.focus.is_some_and(|target| !targets.contains(&target)) {
             self.focus = targets.last().copied();
         }
-        self.hovered = self.hovered.filter(|target| targets.contains(target));
+        self.refresh_hover();
         self.pressed = self.pressed.filter(|target| targets.contains(target));
     }
 
     fn reconcile_menu(&mut self) {
         let mut indices = Vec::new();
         let mut separator = false;
         for (index, item) in self.items.iter().enumerate().skip(self.visible_count) {
             match item {
                 ToolbarItem::Button { .. } => {
                     if separator && !indices.is_empty() {
@@ -359,41 +361,64 @@ impl Toolbar {
         }
     }
 
     fn open_menu(&mut self, keyboard: bool) {
         if !self.has_overflow() {
             return;
         }
         self.menu
             .open_anchored(self.overflow_rect, self.viewport.unwrap_or(self.rect));
         self.focus = Some(Target::Overflow);
+        self.hovered = None;
+        self.pressed = None;
         if keyboard {
             self.menu.focus_first_action();
         }
     }
     fn invoke(&mut self, index: usize) {
         if let Some(ToolbarItem::Button { on_click, .. }) = self.items.get_mut(index) {
             on_click();
         }
     }
     fn drain_menu(&mut self) {
         if let Some(index) = self
             .menu
             .take_selection()
             .and_then(|row| self.menu_indices.get(row).copied().flatten())
         {
             self.invoke(index);
         }
         if !self.menu.is_open() {
             self.focus = Some(Target::Overflow);
+            self.pressed = None;
+            self.refresh_hover();
         }
     }
+
+    /// Popup routing still updates `pointer`, so closing or relayout cannot
+    /// arm a command using a hover target from before the popup opened.
+    fn refresh_hover(&mut self) -> bool {
+        let hovered = if self.menu.is_open() {
+            None
+        } else {
+            self.pointer.and_then(|point| {
+                self.targets().into_iter().find(|target| {
+                    self.target_rect(*target)
+                        .is_some_and(|rect| rect.contains(point))
+                })
+            })
+        };
+        let changed = hovered != self.hovered;
+        self.hovered = hovered;
+        changed
+    }
+
     fn targets(&self) -> Vec<Target> {
         let mut targets: Vec<_> = self
             .items
             .iter()
             .enumerate()
             .take(self.visible_count)
             .filter_map(|(index, item)| {
                 matches!(item, ToolbarItem::Button { .. }).then_some(Target::Item(index))
             })
             .collect();
@@ -664,73 +689,71 @@ impl Widget for Toolbar {
         event: &WindowEvent,
         scale: f64,
         modifiers: &winit::event::Modifiers,
         state: &mut AutoCommit,
         path: &ObjId,
         handled: &mut bool,
         focus_target: &mut Option<NodeId>,
         node: NodeId,
         tree: &TaffyTree<()>,
     ) {
+        if let WindowEvent::CursorMoved { position, .. } = event {
+            self.pointer = Some(Point::new(position.x / scale, position.y / scale));
+        }
         if self.menu.is_open() {
             self.menu.handle_event(
                 event,
                 scale,
                 modifiers,
                 state,
                 path,
                 handled,
                 focus_target,
                 node,
                 tree,
             );
             if matches!(
                 event,
                 WindowEvent::MouseInput {
                     state: ElementState::Pressed,
+                    button: MouseButton::Left,
                     ..
                 }
             ) {
                 self.swallow_release = true;
             }
             self.drain_menu();
             return;
         }
         match event {
-            WindowEvent::CursorMoved { position, .. } => {
-                let point = Point::new(position.x / scale, position.y / scale);
-                let hovered = self.targets().into_iter().find(|target| {
-                    self.target_rect(*target)
-                        .is_some_and(|rect| rect.contains(point))
-                });
-                if hovered != self.hovered {
-                    self.hovered = hovered;
-                    *handled = true;
-                }
+            WindowEvent::CursorMoved { .. } => {
+                *handled |= self.refresh_hover();
             }
             WindowEvent::MouseInput {
                 state: ElementState::Pressed,
                 button: MouseButton::Left,
                 ..
             } => {
+                self.refresh_hover();
                 self.pressed = self.hovered;
                 if let Some(target) = self.pressed {
                     self.focus_target(target);
                     *focus_target = Some(node);
                     *handled = true;
                 }
             }
             WindowEvent::MouseInput {
                 state: ElementState::Released,
                 button: MouseButton::Left,
                 ..
             } => {
+                self.refresh_hover();
                 if self.swallow_release {
                     self.swallow_release = false;
                     self.pressed = None;
                     *handled = true;
                     return;
                 }
                 if let Some(target) = self
                     .pressed
                     .take()
                     .filter(|target| Some(*target) == self.hovered)
@@ -783,20 +806,21 @@ impl Widget for Toolbar {
             .any(|item| matches!(item, ToolbarItem::Button { .. }))
     }
     fn set_focus(&mut self, focused: bool) {
         self.focused = focused;
         if focused && self.focus.is_none() {
             self.focus = self.targets().first().copied();
         }
         if !focused {
             self.menu.close();
             self.pressed = None;
+            self.refresh_hover();
         }
     }
     fn is_focused(&self) -> bool {
         self.focused
     }
     fn traps_focus(&self) -> bool {
         self.menu.is_open()
     }
     fn wants_pointer_capture(&self) -> bool {
         self.menu.is_open() || self.pressed.is_some() || self.swallow_release
@@ -826,20 +850,21 @@ impl Widget for Toolbar {
                     ),
                     Target::Overflow => (
                         "More commands".to_owned(),
                         "toolbar.overflow".to_owned(),
                         Some(self.menu.is_open()),
                     ),
                 };
                 AccessNode::new(Role::Button)
                     .with_name(name)
                     .with_action_target(route)
+                    .with_bounds(self.target_rect(*target).unwrap_or(Rect::ZERO))
                     .with_state(AccessState {
                         focusable: true,
                         focused: self.focused
                             && !self.menu.is_open()
                             && self.focus == Some(*target),
                         expanded,
                         ..Default::default()
                     })
             })
             .collect();
@@ -850,29 +875,36 @@ impl Widget for Toolbar {
                 .enumerate()
                 .filter_map(|(row, index)| {
                     let index = (*index)?;
                     let ToolbarItem::Button { label, .. } = self.items.get(index)? else {
                         return None;
                     };
                     Some(
                         AccessNode::new(Role::MenuItem)
                             .with_name(label.clone())
                             .with_action_target(format!("toolbar.item.{index}"))
+                            // Keep scrolled-out actions focusable so semantic focus
+                            // can reveal them, but export no fabricated painted area.
+                            .with_bounds(self.menu.item_rect(row).unwrap_or(Rect::ZERO))
                             .with_state(AccessState {
                                 focusable: true,
                                 focused: self.focused && self.menu.hovered() == Some(row),
                                 ..Default::default()
                             }),
                     )
                 })
                 .collect();
-            children.push(AccessNode::new(Role::Menu).with_children(rows));
+            children.push(
+                AccessNode::new(Role::Menu)
+                    .with_bounds(self.menu.get_rect())
+                    .with_children(rows),
+            );
         }
         Some(
             AccessNode::new(Role::Toolbar)
                 .with_state(AccessState {
                     focusable: self.is_focusable(),
                     focused: self.focused,
                     ..Default::default()
                 })
                 .with_children(children),
         )
@@ -1324,37 +1356,37 @@ mod lifecycle_tests {
     fn mouse(tb: &mut Toolbar, state: ElementState) -> bool {
         dispatch(
             tb,
             WindowEvent::MouseInput {
                 device_id: unsafe { std::mem::zeroed::<DeviceId>() },
                 state,
                 button: MouseButton::Left,
             },
         )
     }
-    fn key(tb: &mut Toolbar, key: NamedKey) -> bool {
+    fn key_event(key: NamedKey) -> WindowEvent {
         let mut event: KeyEvent = unsafe { std::mem::zeroed() };
         event.logical_key = Key::Named(key);
         event.physical_key = winit::keyboard::PhysicalKey::Unidentified(
             winit::keyboard::NativeKeyCode::Unidentified,
         );
         event.location = winit::keyboard::KeyLocation::Standard;
         event.state = ElementState::Pressed;
         event.text = None;
-        dispatch(
-            tb,
-            WindowEvent::KeyboardInput {
-                device_id: unsafe { std::mem::zeroed() },
-                event,
-                is_synthetic: true,
-            },
-        )
+        WindowEvent::KeyboardInput {
+            device_id: unsafe { std::mem::zeroed() },
+            event,
+            is_synthetic: true,
+        }
+    }
+    fn key(tb: &mut Toolbar, key: NamedKey) -> bool {
+        dispatch(tb, key_event(key))
     }
     fn counted(n: usize) -> (Toolbar, Rc<RefCell<Vec<usize>>>) {
         let counts = Rc::new(RefCell::new(vec![0; n]));
         let mut tb = Toolbar::new(Orientation::Horizontal);
         for index in 0..n {
             let counts = counts.clone();
             tb = tb.push_button(&format!("Command {index}"), move || {
                 counts.borrow_mut()[index] += 1
             });
         }
@@ -1648,11 +1680,212 @@ mod lifecycle_tests {
             let mut renderer = crate::offscreen::OffscreenRenderer::new(width, height);
             let path = format!("{dir}/{name}.png");
             renderer.render_png(&scene, theme.bg_app, &path);
             key(&mut tb, NamedKey::Enter);
             assert_eq!(*fired.borrow(), 1);
             eprintln!(
                 "capture {path}; viewport={width}x{height}; toolbar_width={toolbar_width}; Theme::dark().with_text_scale({scale}); last command fired once"
             );
         }
     }
+    #[test]
+    fn review_emitted_accessibility_bounds_match_paint_and_scrolling() {
+        let (mut tb, _) = counted(12);
+        settle(&mut tb, 180.0, 45.0, 1.0);
+        let node = tb.accessibility().unwrap();
+        for (child, target) in node.children.iter().zip(tb.targets()) {
+            assert_eq!(
+                child.bounds.map(|bounds| bounds.to_rect()),
+                tb.target_rect(target)
+            );
+        }
+        tb.open_menu(true);
+        let menu_child = tb.targets().len();
+        let first_height = tb.menu.item_rect(0).unwrap().height();
+        tb.menu.focus_item(tb.menu_indices.len() - 1);
+        let node = tb.accessibility().unwrap();
+        let menu = &node.children[menu_child];
+        assert_eq!(menu.bounds.unwrap().to_rect(), tb.menu.get_rect());
+        let mut clipped = false;
+        for (child, row) in menu.children.iter().zip(
+            tb.menu_indices
+                .iter()
+                .enumerate()
+                .filter_map(|(row, index)| index.map(|_| row)),
+        ) {
+            let expected = tb.menu.item_rect(row).unwrap_or(Rect::ZERO);
+            assert_eq!(child.bounds.unwrap().to_rect(), expected);
+            clipped |= expected.height() > 0.0 && expected.height() < first_height;
+        }
+        assert!(clipped);
+        assert_eq!(menu.children[0].bounds.unwrap().to_rect(), Rect::ZERO);
+        assert!(
+            !menu.children[0].state.hidden,
+            "offscreen commands retain semantic focus access"
+        );
+        assert!(tb.focus_synthetic_accessibility(&[menu_child, 0]));
+        assert!(
+            !tb.accessibility().unwrap().children[menu_child].children[0]
+                .bounds
+                .unwrap()
+                .to_rect()
+                .is_zero_area()
+        );
+    }
+
+    #[test]
+    fn review_popup_close_rehits_pointer_before_second_click() {
+        for pointer_open in [false, true] {
+            for relayout in [false, true] {
+                let (mut tb, counts) = counted(8);
+                settle(&mut tb, 180.0, 45.0, 1.0);
+                let point = if pointer_open {
+                    tb.overflow_rect.center()
+                } else {
+                    tb.item_rects[0].center()
+                };
+                cursor(&mut tb, point);
+                if pointer_open {
+                    mouse(&mut tb, ElementState::Pressed);
+                    mouse(&mut tb, ElementState::Released);
+                } else {
+                    tb.set_focus(true);
+                    while tb.focus != Some(Target::Overflow) {
+                        key(&mut tb, NamedKey::ArrowRight);
+                    }
+                    key(&mut tb, NamedKey::Space);
+                }
+                let hidden = tb.menu_indices[0].unwrap();
+                let point = tb.menu.item_rect(0).unwrap().center();
+                assert!(!tb.rect.contains(point));
+                cursor(&mut tb, point);
+                mouse(&mut tb, ElementState::Pressed);
+                mouse(&mut tb, ElementState::Released);
+                if relayout {
+                    settle(&mut tb, 180.0, 45.0, 1.0);
+                }
+                mouse(&mut tb, ElementState::Pressed);
+                mouse(&mut tb, ElementState::Released);
+                let mut expected = vec![0; 8];
+                expected[hidden] = 1;
+                assert_eq!(
+                    *counts.borrow(),
+                    expected,
+                    "pointer_open={pointer_open}, relayout={relayout}"
+                );
+                assert!(
+                    !tb.menu.is_open(),
+                    "stale overflow hover must not reopen the menu"
+                );
+            }
+        }
+    }
+
+    #[test]
+    fn review_nonleft_popup_press_does_not_capture_next_sibling_click() {
+        for button in [MouseButton::Right, MouseButton::Middle] {
+            let (toolbar, _) = counted(8);
+            let (sibling, count) = counted(1);
+            let mut host = crate::widget::Row::new()
+                .no_wrap()
+                .push(Box::new(toolbar))
+                .push(Box::new(sibling));
+            let mut tree = TaffyTree::new();
+            let mut nodes = HashMap::new();
+            let theme = Theme::dark();
+            let node = host.build_layout(&mut tree, &theme, &mut nodes);
+            let children = tree.children(node).unwrap();
+            for (child, width) in children.iter().zip([180.0, 150.0]) {
+                let mut style = tree.style(*child).unwrap().clone();
+                style.size = Size {
+                    width: Dimension::length(width),
+                    height: Dimension::length(45.0),
+                };
+                tree.set_style(*child, style).unwrap();
+            }
+            let mut text = TextRenderer::new();
+            let mut bindings = crate::bound_dispatch::BoundNodeMap::default();
+            unsafe {
+                bindings.rebuild(&host, &tree, node, &nodes);
+                crate::widget::compute_widget_layout(
+                    &mut tree,
+                    node,
+                    Size {
+                        width: taffy::AvailableSpace::Definite(360.0),
+                        height: taffy::AvailableSpace::Definite(220.0),
+                    },
+                    &nodes,
+                    &bindings,
+                    &mut text,
+                )
+                .unwrap();
+            }
+            host.apply_layout(&tree, node, Point::ZERO);
+            let presence = PresenceCtx::default();
+            presence
+                .viewport
+                .set(Some(Rect::new(0.0, 0.0, 360.0, 220.0)));
+            host.draw(
+                &mut Scene::new(),
+                Affine::IDENTITY,
+                &mut text,
+                &theme,
+                &presence,
+            );
+            assert!(host.children_mut()[0].perform_semantic_action(
+                "toolbar.overflow",
+                &Action::Activate,
+                &mut AutoCommit::new(),
+                &automerge::ROOT
+            ));
+            let send = |host: &mut crate::widget::Row, event: WindowEvent| {
+                host.handle_event(
+                    &event,
+                    1.0,
+                    &Default::default(),
+                    &mut AutoCommit::new(),
+                    &automerge::ROOT,
+                    &mut false,
+                    &mut None,
+                    node,
+                    &tree,
+                );
+            };
+            let mouse_event = |button, state| WindowEvent::MouseInput {
+                device_id: unsafe { std::mem::zeroed() },
+                button,
+                state,
+            };
+            send(&mut host, mouse_event(button, ElementState::Pressed));
+            send(&mut host, mouse_event(button, ElementState::Released));
+            send(&mut host, key_event(NamedKey::Escape));
+            assert!(
+                !host.wants_pointer_capture(),
+                "{button:?} must not leave capture stuck"
+            );
+            let point = host.children()[1]
+                .synthetic_accessibility_rect(&[0])
+                .unwrap()
+                .center();
+            send(
+                &mut host,
+                WindowEvent::CursorMoved {
+                    device_id: unsafe { std::mem::zeroed() },
+                    position: winit::dpi::PhysicalPosition::new(point.x, point.y),
+                },
+            );
+            send(
+                &mut host,
+                mouse_event(MouseButton::Left, ElementState::Pressed),
+            );
+            send(
+                &mut host,
+                mouse_event(MouseButton::Left, ElementState::Released),
+            );
+            assert_eq!(
+                *count.borrow(),
+                vec![1],
+                "next sibling click must arrive through Row"
+            );
+        }
+    }
 }
