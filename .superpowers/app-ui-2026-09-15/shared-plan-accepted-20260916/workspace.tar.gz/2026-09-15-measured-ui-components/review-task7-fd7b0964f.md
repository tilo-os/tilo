# Review package: ca5b92f36..fd7b0964f

## Commits
fd7b0964f fix(ui): preserve attributed trailing empty line

## Files changed
 .../task-7-report.md                               | 130 +++++++++++++++++++++
 ui/src/richtext.rs                                 | 130 ++++++++++++++++++++-
 ui/src/widget/text_input.rs                        |  80 +++++++++++++
 3 files changed, 338 insertions(+), 2 deletions(-)

## Diff
diff --git a/.superpowers/sdd/2026-09-15-measured-ui-components/task-7-report.md b/.superpowers/sdd/2026-09-15-measured-ui-components/task-7-report.md
new file mode 100644
index 000000000..44efefdf5
--- /dev/null
+++ b/.superpowers/sdd/2026-09-15-measured-ui-components/task-7-report.md
@@ -0,0 +1,130 @@
+# Task 7 report: Preserve the final empty attributed line
+
+## Scope and result
+
+- Owned production path: `ui/src/richtext.rs`.
+- Owned regression path: `ui/src/widget/text_input.rs` (including the colocated `RichTextLayout` tests in `richtext.rs`).
+- Normalized the attributed shaping boundary after `Buffer::set_rich_text`: when the source ends in LF, append the final empty `BufferLine` that cosmic-text 0.19.0 omits.
+- The appended line contains no visible character and changes no source byte offset. It uses `LineEnding::None`, `Shaping::Advanced`, the final effective non-empty run attributes/metrics (base attributes as the empty-input fallback), and the requested block alignment.
+- No Scrollable or app source, dependencies, manifests, or unrelated dirty/untracked files were changed for this task. No push was performed.
+
+## Root cause and API confirmation
+
+The supplied runtime diagnosis was reproduced by the regression tests. `Buffer::set_text` adds an empty terminal line after a line ending, while cosmic-text 0.19.0 `Buffer::set_rich_text` derives paragraphs from `BidiParagraphs`, which omits the paragraph after a terminal LF. `RichTextLayout` still retains its own final logical-line metadata, so the absent cosmic-text row caused the height, caret, visual-line, logical-band, hit, gutter, current-line, and caret-follow geometry to disagree.
+
+The installed cosmic-text 0.19.0 API was read before implementation. `Buffer::lines` is public, and `BufferLine::new`, `AttrsList::new`, `LineEnding::None`, and `BufferLine::set_align` provide the required normalization without changing dependency code or inserting a sentinel byte.
+
+## TDD evidence
+
+### RED
+
+An initial exact-filter attempt was too strict and selected no test; it did not count as RED:
+
+```sh
+CARGO_BUILD_JOBS=4 CARGO_PROFILE_TEST_DEBUG=0 cargo test -p ui --lib attributed_terminal_lf_preserves_the_plain_layout_final_row -- --exact --nocapture
+```
+
+Result: exit 0, `0 passed; 3162 filtered out`.
+
+The corrected focused commands failed for the expected missing-row behavior before production code changed:
+
+```sh
+CARGO_BUILD_JOBS=4 CARGO_PROFILE_TEST_DEBUG=0 cargo test -p ui --lib attributed_terminal_lf_preserves_the_plain_layout_final_row -- --nocapture
+```
+
+Result: exit 101. `"x\n" styled and plain heights at 1x: expected 40, got 20`.
+
+```sh
+CARGO_BUILD_JOBS=4 CARGO_PROFILE_TEST_DEBUG=0 cargo test -p ui --lib multiline_trailing_lf_keeps_measure_draw_hit_and_caret_scroll_in_sync -- --nocapture
+```
+
+Result: exit 101. TextInput measured `56.0` but the attributed draw path reported `36` at 1×.
+
+```sh
+CARGO_BUILD_JOBS=4 CARGO_PROFILE_TEST_DEBUG=0 cargo test -p ui --lib terminal_empty_row_inherits_the_final_run_metrics_and_alignment -- --nocapture
+```
+
+Result: exit 101. The final buffer line was `"x"`, not the required empty row.
+
+### GREEN
+
+After the single boundary repair:
+
+```sh
+CARGO_BUILD_JOBS=4 CARGO_PROFILE_TEST_DEBUG=0 cargo test -p ui --lib attributed_terminal_lf_preserves_the_plain_layout_final_row -- --nocapture
+```
+
+Result: exit 0, `1 passed; 0 failed`. Covers `"x"`, `"x\ny"`, `"x\n"`, `"\n"`, multiple terminal LFs, and split attributed spans at 1× and 2×; asserts plain/styled height, EOF caret, visual row, logical-line band, and below-content hit behavior.
+
+```sh
+CARGO_BUILD_JOBS=4 CARGO_PROFILE_TEST_DEBUG=0 cargo test -p ui --lib terminal_empty_row_inherits_the_final_run_metrics_and_alignment -- --nocapture
+```
+
+Result: exit 0, `1 passed; 0 failed`. Confirms empty text, `LineEnding::None`, final run bold/italic/24px metrics, and centered alignment.
+
+```sh
+CARGO_BUILD_JOBS=4 CARGO_PROFILE_TEST_DEBUG=0 cargo test -p ui --lib multiline_trailing_lf_keeps_measure_draw_hit_and_caret_scroll_in_sync -- --nocapture
+```
+
+Result: exit 0, `1 passed; 0 failed`. At 1× and 2×, measure and attributed draw agree within the documented subpixel ceiling, EOF remains the final visual row, the last-row click returns `text.len()`, caret-follow scroll reaches the end, syntax attribution remains present, and gutter/current-line row geometry includes both logical lines.
+
+The first post-fix TextInput run exposed a test-only assumption that 2× text would not wrap (`visual_line_index == 1`). The assertion was narrowed to the intended contract: EOF visual index plus one equals the shaped run count, and EOF caret bottom equals layout height. The production fix did not change.
+
+## Focused verification
+
+```sh
+CARGO_BUILD_JOBS=4 CARGO_PROFILE_TEST_DEBUG=0 cargo test -p ui --lib richtext::tests -- --nocapture
+```
+
+Result: exit 0, `20 passed; 0 failed`.
+
+```sh
+CARGO_BUILD_JOBS=4 CARGO_PROFILE_TEST_DEBUG=0 cargo test -p ui --lib widget::text_input::tests -- --nocapture
+```
+
+Result: exit 0, `100 passed; 0 failed`.
+
+```sh
+CARGO_BUILD_JOBS=4 CARGO_PROFILE_TEST_DEBUG=0 cargo test -p ui --lib widget::code_editor::tests -- --nocapture
+```
+
+Result: exit 0, `23 passed; 0 failed`.
+
+```sh
+CARGO_BUILD_JOBS=4 CARGO_PROFILE_TEST_DEBUG=0 cargo test -p ui --test it scrollable_test -- --nocapture
+```
+
+Result: exit 0, `12 passed; 0 failed`.
+
+```sh
+CARGO_BUILD_JOBS=4 CARGO_PROFILE_DEV_DEBUG=0 cargo check -p ui
+```
+
+Result: exit 0.
+
+```sh
+rustfmt --edition 2024 ui/src/richtext.rs ui/src/widget/text_input.rs
+git diff --check -- ui/src/richtext.rs ui/src/widget/text_input.rs
+rustfmt --edition 2024 --check ui/src/richtext.rs ui/src/widget/text_input.rs
+```
+
+Result: formatting applied only to the two owned Rust paths; both checks exited 0.
+
+Cargo test emitted the existing macOS linker warning that `__eh_frame` is too large for compact unwind encoding. It did not fail compilation or tests. Some commands briefly waited for the intentionally shared target-directory lock.
+
+## Self-review
+
+- Scope: the only production branch is `full_text.ends_with('\n')`; non-terminal and plain shaping remain unchanged.
+- Data integrity: the source string, `text_len`, `line_starts`, `line_lens`, offset map, and decoration ranges are unchanged. No sentinel character or virtual source byte was added.
+- Style: `built.last()` is the final effective non-empty run produced by the existing normalization; an empty trailing `RichSpan` is not an effective run and remains ignored consistently with `build_rich_runs`.
+- Geometry: the new row participates in cosmic-text shaping before size, wrap, and layout resolution, so existing caret, hit, logical-band, gutter, current-line, and scroll code consume one authoritative layout.
+- Source reasoning: deleting the append corresponds to the already executed pre-fix RED state and reintroduces its failures. The dedicated style/alignment assertions are designed to fail if the appended line uses base metrics or omits alignment; those additional temporary mutations were not executed.
+- No architectural ambiguity or scope expansion was found.
+
+## Limits and excluded work
+
+- This compatibility normalization is specific to terminal LF and cosmic-text 0.19.0. It can be removed after an upstream version preserves the final rich-text paragraph and the regressions remain green.
+- CR/CRLF behavior was not expanded because Task 7 specifies LF and `RichTextLayout::line_map` models LF.
+- LF-only selection decoration redesign remains excluded as required.
+- No screenshot was requested or needed for this geometry/API regression.
+- No broad workspace suite was run; verification stayed within the requested UI scopes.
diff --git a/ui/src/richtext.rs b/ui/src/richtext.rs
index f8e277391..793cbc29e 100644
--- a/ui/src/richtext.rs
+++ b/ui/src/richtext.rs
@@ -1,19 +1,19 @@
 //! `RichTextLayout` — attributed, word-wrapped, hit-testable text layout. The
 //! toolkit's rich-text primitive (cosmic-text under the hood): per-run
 //! **bold**/*italic*, underlines, wrapping to a width, caret geometry, selection
 //! rectangles, and point↔offset hit-testing. Render it with
 //! [`crate::text_render::TextRenderer::draw_rich`].
 
 use cosmic_text::{
-    Affinity, Align, Attrs, Buffer, Cursor, Family, FontSystem, Metrics, Shaping, Style, Weight,
-    Wrap,
+    Affinity, Align, Attrs, AttrsList, Buffer, BufferLine, Cursor, Family, FontSystem, LineEnding,
+    Metrics, Shaping, Style, Weight, Wrap,
 };
 
 use crate::text_break::OffsetMap;
 use crate::text_selection::{TextAffinity, TextPosition};
 
 /// A generic font family the toolkit can resolve from system fonts.
 #[derive(Clone, Copy, Debug, PartialEq, Eq, Default)]
 pub enum FontFamily {
     #[default]
     Sans,
@@ -348,20 +348,36 @@ impl RichTextLayout {
             Self::build_rich_runs(spans, style, &offset_map, &base, size, line_height_mult);
 
         buffer.set_rich_text(
             built
                 .iter()
                 .map(|(text, attrs)| (text.as_ref(), attrs.clone())),
             &base,
             Shaping::Advanced,
             align.to_cosmic(),
         );
+        // cosmic-text 0.19's rich setter omits the final empty paragraph after
+        // an LF, unlike its plain setter. Restore that line at this boundary so
+        // attributed and plain layouts expose the same bytes and geometry.
+        if full_text.ends_with('\n') {
+            let terminal_attrs = built
+                .last()
+                .map_or_else(|| base.clone(), |(_, attrs)| attrs.clone());
+            let mut terminal_line = BufferLine::new(
+                "",
+                LineEnding::None,
+                AttrsList::new(&terminal_attrs),
+                Shaping::Advanced,
+            );
+            terminal_line.set_align(align.to_cosmic());
+            buffer.lines.push(terminal_line);
+        }
         let reserved_hyphen_width = if align == TextAlign::Left {
             discretionary_hyphen_width
         } else {
             0.0
         };
         let layout_width = max_width.map(|width| (width - reserved_hyphen_width).max(0.0));
         buffer.set_size(layout_width, None);
         buffer.set_wrap(if max_width.is_some() {
             Wrap::Word
         } else {
@@ -813,20 +829,27 @@ impl RichTextLayout {
             }
         }
         rects
     }
 }
 
 #[cfg(test)]
 mod tests {
     use super::*;
 
+    fn assert_near(actual: f32, expected: f32, message: &str) {
+        assert!(
+            (actual - expected).abs() < 0.01,
+            "{message}: expected {expected}, got {actual}"
+        );
+    }
+
     fn layout(text: &str, width: f32) -> RichTextLayout {
         let mut fs = crate::font_catalog::fixture_font_system();
         RichTextLayout::shape(
             &mut fs,
             &[RichSpan::new(text)],
             false,
             18.0,
             width,
             TextAlign::Left,
             FontFamily::Sans,
@@ -855,20 +878,123 @@ mod tests {
         let (x0, _, h) = layout.caret_geometry(0);
         assert!(x0 < 2.0 && h > 0.0);
         let (xend, _, _) = layout.caret_geometry(11);
         assert!(xend > x0);
         assert!(layout.hit(xend - 1.0, 1.0) > 0);
         let rects = layout.selection_rects(0, 5);
         assert_eq!(rects.len(), 1);
         assert!(rects[0].2 > rects[0].0);
     }
 
+    #[test]
+    fn attributed_terminal_lf_preserves_the_plain_layout_final_row() {
+        use crate::text_render::TextStyle;
+
+        for scale in [1.0, 2.0] {
+            let style = TextStyle::new(16.0 * scale).with_line_height(1.25);
+            let fixtures = [
+                ("x", vec![RichSpan::new("x")], 1usize),
+                ("x\ny", vec![RichSpan::new("x\ny")], 2),
+                ("x\n", vec![RichSpan::new("x\n")], 2),
+                ("\n", vec![RichSpan::new("\n")], 2),
+                ("x\n\n", vec![RichSpan::new("x\n\n")], 3),
+                (
+                    "x\n",
+                    vec![
+                        RichSpan::new("x").bold(true),
+                        RichSpan::new("\n").italic(true),
+                    ],
+                    2,
+                ),
+            ];
+
+            for (text, spans, expected_rows) in fixtures {
+                let mut fs = crate::font_catalog::fixture_font_system();
+                let plain = RichTextLayout::shape_plain(&mut fs, text, &style, Some(300.0));
+                let styled = RichTextLayout::shape_styled(
+                    &mut fs,
+                    &spans,
+                    &style,
+                    Some(300.0),
+                    TextAlign::Left,
+                    vec![],
+                    vec![],
+                );
+
+                assert_near(
+                    styled.height(),
+                    plain.height(),
+                    &format!("{text:?} styled and plain heights at {scale}x"),
+                );
+                let plain_eof = plain.caret_geometry(text.len());
+                let styled_eof = styled.caret_geometry(text.len());
+                assert_near(
+                    styled_eof.1,
+                    plain_eof.1,
+                    &format!("{text:?} EOF caret top at {scale}x"),
+                );
+                assert_near(
+                    styled_eof.2,
+                    plain_eof.2,
+                    &format!("{text:?} EOF caret height at {scale}x"),
+                );
+                assert_eq!(
+                    styled.visual_line_index(text.len()),
+                    expected_rows - 1,
+                    "{text:?} EOF visual row at {scale}x"
+                );
+                assert_eq!(
+                    styled.logical_line_bands(text.len()).len(),
+                    1,
+                    "{text:?} EOF logical line has one shaped band at {scale}x"
+                );
+                assert_eq!(
+                    styled.hit(0.0, styled.height() + style.line_height_px()),
+                    text.len(),
+                    "{text:?} hit below content resolves to EOF at {scale}x"
+                );
+            }
+        }
+    }
+
+    #[test]
+    fn terminal_empty_row_inherits_the_final_run_metrics_and_alignment() {
+        use crate::text_render::TextStyle;
+
+        let style = TextStyle::new(16.0).with_line_height(1.25);
+        let mut final_run = RichSpan::new("\n").bold(true).italic(true);
+        final_run.size = Some(24.0);
+        let mut fs = crate::font_catalog::fixture_font_system();
+        let layout = RichTextLayout::shape_styled(
+            &mut fs,
+            &[RichSpan::new("x"), final_run],
+            &style,
+            Some(300.0),
+            TextAlign::Center,
+            vec![],
+            vec![],
+        );
+
+        let final_line = layout.buffer.lines.last().expect("terminal empty line");
+        let attrs = final_line.attrs_list().defaults();
+        assert_eq!(final_line.text(), "");
+        assert_eq!(final_line.ending(), cosmic_text::LineEnding::None);
+        assert_eq!(final_line.align(), Some(Align::Center));
+        assert_eq!(attrs.weight, Weight::BOLD);
+        assert_eq!(attrs.style, Style::Italic);
+        assert_eq!(
+            attrs.metrics_opt,
+            Some(Metrics::new(24.0, 30.0).into()),
+            "the final empty row keeps the last effective run's metrics"
+        );
+    }
+
     #[test]
     fn rtl_caret_geometry_follows_visual_direction() {
         let text = "שלום";
         let layout = layout(text, 400.0);
         let (start_x, top, height) = layout.caret_geometry(0);
         let (end_x, _, _) = layout.caret_geometry(text.len());
 
         assert!(
             start_x > end_x,
             "the logical start of an RTL paragraph is its visual right edge: start={start_x}, end={end_x}"
diff --git a/ui/src/widget/text_input.rs b/ui/src/widget/text_input.rs
index 6139dad74..172d79260 100644
--- a/ui/src/widget/text_input.rs
+++ b/ui/src/widget/text_input.rs
@@ -6914,20 +6914,100 @@ mod tests {
         );
         let last_row = layout.visual_line_index(input.text_to_layout_byte(text.len()));
         let caret = input.caret_rect(&theme, text.len());
         assert_eq!(
             (caret.y0 / caret.height()).floor() as usize,
             last_row,
             "caret row and shaped visual row index agree"
         );
     }
 
+    #[test]
+    fn multiline_trailing_lf_keeps_measure_draw_hit_and_caret_scroll_in_sync() {
+        let text = "let value = 1;\n";
+        for scale in [1.0, 2.0] {
+            let theme = Theme::dark().with_text_scale(scale);
+            let mut input = TextInput::local()
+                .multiline(true)
+                .with_mono()
+                .with_gutter(true)
+                .with_current_line_highlight(true)
+                .with_initial_value(text);
+            input.set_highlighter(crate::widget::code_editor::Language::Rust.highlighter());
+            input.set_focus(true);
+            input.set_cursor_pos(text.len());
+
+            let mut renderer = TextRenderer::new();
+            renderer.set_text_scale(theme.text_scale);
+            let measured = Widget::measure(
+                &mut input,
+                taffy::Size {
+                    width: Some(240.0),
+                    height: None,
+                },
+                taffy::Size {
+                    width: taffy::AvailableSpace::Definite(240.0),
+                    height: taffy::AvailableSpace::MaxContent,
+                },
+                &mut renderer,
+            );
+            let viewport_height =
+                f64::from(input.multiline_style(scale).line_height_px()) + ML_PAD_Y * 2.0;
+            input.apply_layout_external(Rect::new(0.0, 0.0, 240.0, viewport_height));
+            draw_with_theme(&mut input, &theme);
+
+            let drawn_height = input.content_height() as f32;
+            assert!(
+                measured.height >= drawn_height && measured.height - drawn_height < 1.0,
+                "pixel-ceiled measure {measured:?} agrees with attributed draw height {drawn_height} at {scale}x"
+            );
+            let layout = input
+                .single_layout
+                .as_ref()
+                .expect("draw retained attributed multiline layout");
+            let (_, eof_top, eof_height) =
+                layout.caret_geometry(input.text_to_layout_byte(text.len()));
+            assert_eq!(
+                layout.visual_line_index(text.len()).saturating_add(1),
+                layout.buffer.layout_runs().count(),
+                "EOF stays on the final visual row even when large text wraps"
+            );
+            assert_eq!(layout.logical_line_origins().len(), 2);
+            assert!(
+                (eof_top + eof_height - layout.height()).abs() < 0.01,
+                "EOF caret reaches the bottom of the final row"
+            );
+
+            let caret = input.caret_rect(&theme, text.len());
+            assert_eq!(
+                input.byte_at_point(Point::new(caret.x0 + 1.0, caret.center().y)),
+                text.len(),
+                "clicking the final empty row returns EOF"
+            );
+            let view_height = input.rect.height() - ML_PAD_Y * 2.0;
+            let expected_scroll = (f64::from(layout.height()) - view_height).max(0.0);
+            assert!(expected_scroll > 0.0);
+            assert!(
+                (input.scroll_y() - expected_scroll).abs() < 0.01,
+                "caret-follow scroll remains at the EOF row"
+            );
+            assert!(input.gutter_width() > 0.0);
+            assert!(
+                input
+                    .code_row_colors(&theme)
+                    .iter()
+                    .any(|(_, color)| *color != theme.text_primary),
+                "syntax attribution survives terminal-row normalization"
+            );
+        }
+    }
+
     #[test]
     fn multiline_measure_uses_build_layout_theme_scale_when_renderer_is_stale() {
         let text = "The layout theme owns accessibility scale even when a retained renderer still carries its previous frame value.";
         let mut input = TextInput::local().multiline(true).with_initial_value(text);
         let large = Theme::dark().with_text_scale(2.0);
         let mut taffy = TaffyTree::<()>::new();
         let mut node_map = std::collections::HashMap::new();
         let _ = Widget::build_layout(&mut input, &mut taffy, &large, &mut node_map);
 
         let mut renderer = TextRenderer::new();
