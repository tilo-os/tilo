# Measured UI Components Implementation Plan

> **For agentic workers:** REQUIRED SUB-SKILL: Use superpowers:subagent-driven-development (recommended) or superpowers:executing-plans to implement this plan task-by-task. Steps use checkbox (`- [ ]`) syntax for tracking.

**Goal:** Repair shared sizing and interaction contracts so app authors get readable, balanced layouts with fewer manual measurements.

**Architecture:** Add one resolved-text normalization boundary while preserving existing relative APIs. Repair EmptyState, rich editor, opt-in scrolling editor fill and measured actionable Toolbar overflow. App composition migrations consume existing Card/Actions/FormPage rather than inventing another layout system.

**Tech Stack:** Rust, Taffy, cosmic-text, Vello and qOS Widget lifecycle.

**Spec:** `docs/superpowers/specs/2026-09-15-app-ui-balance.md`

## Global Constraints

- Reuse the repository Cargo target cache; do not rebuild all dependencies into a new target directory without a concrete build-isolation need. Isolate runtime captures with task-specific HOME and XDG_CONFIG_HOME/XDG_DATA_HOME/XDG_CACHE_HOME/XDG_STATE_HOME, separately from build caches.

- Prioritize ordinary100% and narrow layout as well as200% text.
- Preserve primary actions, keyboard access, state and explicit manual dimensions.
- Keep legacy renderer-relative font APIs compatible; theme-resolved fonts must scale once.
- Do not globally change primitive padding or reinterpret explicit fixed sizes.
- Preserve unrelated working changes and untracked Scratchpad ownership.
- No pushes, merges, publishing or dependency upgrades.
- Existing linked worktree /Users/xaver/dev/qos-macos-shell; sequential implementers and scoped reviews.
- Focused RED/GREEN behavior regressions before implementation; run relevant existing UI tests once before scoped commit. CARGO_BUILD_JOBS=4, CARGO_PROFILE_DEV_DEBUG=0, CARGO_PROFILE_TEST_DEBUG=0.
- Every task report includes exact commands/results, self-review, screenshot paths if requested, and remaining gaps. No subagents from implementers.

### Task 1: Resolved text sizing and bounded EmptyState

**Files:** `ui/src/text_render.rs`, `ui/src/widget/text.rs`, focused module tests.

Verified current source: `TextRenderer::scaled_style` (1367) multiplies size and letter spacing; `measure_style` (1470) and `draw_style` (1833) use renderer scaling. `Theme::with_text_scale` already changes typography tokens (`theme.rs` around 736). `Text::renderer_input_style` (375) privately divides resolved size by renderer scale. No `FontSize` enum found in current non-vendor Rust; recheck before editing because other work may add one.

- [ ] Add `pub fn renderer_input_style(&self, resolved: &TextStyle) -> TextStyle` on TextRenderer, returning a clone with `size` and `letter_spacing` divided by sanitized `self.text_scale()`. Document that input is final logical pixels; theme typography is already resolved. Leave `measure`, `measure_style`, `draw_text`, `draw_style` semantics intact. If a concurrent explicit FontSize API exists, consume it instead of adding this method.
- [ ] For immediate drawing use one normalized style for both calls: `let style = tr.renderer_input_style(&TextStyle::new(theme.tokens.typography.scale.sm)); let (w, h) = tr.measure_style(label, Some(width), &style); tr.draw_style(scene, label, color, transform, Some(width), &style);` Do not mutate global renderer scale around a draw.
- [ ] Keep Text's explicit/base/fixed semantics and cache invalidation. Reuse the public normalization for fully resolved styles only; examine letter-spacing semantics before replacing the existing private size-only adjustment wholesale.
- [ ] Tests: legacy14px at renderer2 measures as28px; resolved28px measures identically at renderer1 and2; resolved letter spacing also stays identical; theme ui1.25/text2 scales once; same resolved style produces identical measurement and shaped glyph bounds. Existing `text::tests::theme_resolved_sizes_are_independent_of_renderer_scale` is a useful regression anchor.

**Gate:** `cargo test -p ui --lib text_scale`; `cargo test -p ui --lib theme_resolved_sizes`. Add/run the new focused test filter. Do not broad-rewrite callers whose literals are intentionally base sizes.

#### EmptyState consumer

**Files:** `ui/src/widget/empty_state.rs`; tests in that module.

`paint_empty_state` (137 onward) takes already-scaled title/message tokens through relative APIs, measures all text with no width, uses34px action height, and centers potentially wider-than-pane content. `Fit::choose` removes icon then message but can still produce negative top when title+action exceed height. VPN review-3 documents the visible4× symptom; both retained and immediate entry points already share this function.

- [ ] Normalize title, message and button styles once using the resolved-style helper in this same task; measure with inner width `max(rect.width()-2*s4, 1)` and draw with the same width. Center the measured wrapped block, not an unbounded single line.
- [ ] Compute action height from measured label line height plus vertical padding, min existing34px; wrap long labels within inner width. Preserve returned action rectangle as the sole paint/hit/focus geometry.
- [ ] Retain icon shedding. Prefer keeping explanatory message when it fits after wrapping. If essential content exceeds available height, anchor at pane top and expose a scrolling retained route rather than silently deleting the action. Immediate paint must document its minimum essential height; app parent supplies scroll for physically insufficient panes. Do not shrink fonts or return an invisible action hit target.
- [ ] Tests: width240/480, scales1/2, long localized title/message/action; glyph and action bounds fit width, action grows, painted action equals pointer target; Tab/Enter existing action route remains functional; tiny heights shed decoration first and do not place hit geometry above pane.

