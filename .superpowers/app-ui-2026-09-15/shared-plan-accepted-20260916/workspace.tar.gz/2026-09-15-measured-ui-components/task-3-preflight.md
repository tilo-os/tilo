# Task 3 preflight — source-backed candidate, not verified implementation

Root inspected current Scrollable build/apply and Widget adjustment contract while Task2 worker ran independently.

- `ui/src/widget/scrollable.rs:960`: vertical Scrollable deliberately uses FlexStart cross-axis to keep intrinsic overflow. Do not globally replace it with stretch: a long multiline leaf could receive only viewport height and lose its content extent.
- `ui/src/widget/scrollable.rs:1016`: content extent comes from retained child layout/content_size plus descendant bottom bounds. The wrapper must contribute actual long content height here, not merely paint below its rectangle.
- `ui/src/widget/mod.rs:598`: renderer-aware adjustment can retain inherited decisions for descendant hooks, but may change only its own Taffy node and cannot change topology.

Candidate within the approved contract: opt-in retained single-child Grid wrapper, created once in builder/build topology (never in adjustment), one min-content/flexible row. Scrollable's hook stores measured viewport height as an inherited decision; wrapper's hook applies it to its OWN minimum height. Grid stretches an auto-height input when short, while a min-content track retains long content height. Explicit child height remains authored. This is a hypothesis requiring the brief's real editor and fixed-height tests, not a mandate to bypass testing or add unconditional pixel dimensions to the child.

Do not copy a TextInput implementation or expand every multiline form. Keep default Scrollable tree/behavior unchanged when option is off. Test repeated narrow/wide layout settlement and dynamic short→long→short input in addition to the brief's footer, click, scrolling and explicit-size cases; the inherited decision must converge within existing host pass limits.

Potential compatibility surface: opt-in wrapper changes immediate child traversal shape. Preserve actual editor identity/action binding through normal children traversal, document any new wrapper if needed, and ensure Scratchpad save/reopen is exercised. Do not add an extra accessible control for the wrapper.

Scratchpad preparation: current apps/scratchpad/src/lib.rs still exactly matches the saved original (SHA2560875a6f0447707f20534e4123040fa39599024da0345c13238208d8cc6b0cce4). Existing integration tests apps/scratchpad/tests/scratchpad.rs include editor_uses_the_available_width_and_keeps_save_visible and typed_note_survives_save_close_and_reopen; reuse these real action/persistence routes. Preserve the untracked app and manifests, save only the one-line integration patch as directed. Reevaluate baseline hierarchy finding after the actual writing area fills; do not automatically remove helpful copy without seeing the result.
