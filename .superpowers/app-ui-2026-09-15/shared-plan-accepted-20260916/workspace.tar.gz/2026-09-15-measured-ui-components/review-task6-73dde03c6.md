# Review package: fe4908e59..73dde03c6

## Commits
73dde03c6 fix(ui): shape rich inline marks once for paint and interaction

## Files changed
 .../task-6-report.md                               |  99 +++++
 ui/src/widget/block_editor.rs                      |  90 +++-
 ui/src/widget/rich_text_line.rs                    | 410 +++++++-----------
 ui/src/widget/text_input.rs                        | 480 ++++++++++++++++++++-
 4 files changed, 800 insertions(+), 279 deletions(-)

## Diff
diff --git a/.superpowers/sdd/2026-09-15-measured-ui-components/task-6-report.md b/.superpowers/sdd/2026-09-15-measured-ui-components/task-6-report.md
new file mode 100644
index 000000000..8e383627d
--- /dev/null
+++ b/.superpowers/sdd/2026-09-15-measured-ui-components/task-6-report.md
@@ -0,0 +1,99 @@
+# Task 6 — one shaped layout for inline marks
+
+## Result and owned scope
+
+Implemented the single-line rich-mark repair. `RichTextLine` no longer paints marked glyphs over plain glyphs. The inner `TextInput.single_layout` owns attributed shaping, glyph paint, caret stops, selection, scrolling, and pointer inversion. Normal TextInput remains plain unless the internal attributed API is supplied.
+
+Owned production files: `ui/src/widget/rich_text_line.rs`, `ui/src/widget/text_input.rs`, plus the controller-approved narrow live-link fix in `ui/src/widget/block_editor.rs`. No changes to `richtext.rs`, `text_render.rs`, application production files, dependencies, or unrelated dirty files. Starting source base: `90e68a2e9`; unrelated commits continued on the shared checkout.
+
+Controller approved the BlockEditor addition after inspection showed `live_link_hits` refreshed before line drawing, using previous-frame metrics. Its refresh now follows drawing and consumes TextInput's shaped selection rectangles, preserving the existing full-line vertical target. This also supports reversed ranges and separate link segments without joining an unmarked gap.
+
+## Geometry, decorations, and invalidation
+
+- Complete RichSpan runs come from valid UTF-8 mark segments, including unmarked text. Bold/italic shape with the run; code/link use the theme accent. Code retains the existing sans face, two-pixel horizontal chip padding, one-pixel vertical inset, three-pixel radius, and raised-surface color.
+- `shape_styled` fills the existing `single_layout`; `draw_rich` emits its glyphs once. Underline/strike ranges use the same layout. Accent link rules and code chips use its `selection_rects`, including IME display remapping.
+- Paint order is chip background → local selection → glyphs/underline/strike → accent link rules → local caret. BlockEditor peer presence remains after all lines. An opaque chip therefore cannot erase local selection or subsequent peer presence.
+- Attributes refresh at mark mutations, model adoption/sync, local edit reconciliation, accessibility replacement, themed build, measurement, and draw. The wrapper supplies theme scale before measurement. Attributed single-line measurement shapes the current runs while retaining the existing fixed row sizing contract.
+- Cache signatures cover span text/boundaries, bold, italic, size, family, foreground/background, baseline shift, underline/strike/chip/link ranges, base family/size, display text, and IME position. Theme scale is applied once; changes to attributed size/family/mono/model text invalidate measurement.
+- Existing preedit insertion is shared with the multiline highlighter: preedit stays a default-style display-only run. Committed decorations split/shift around it. IME commit still goes through the real inner event path and mark reconciliation.
+- `diff_splice` now retreats common-prefix/suffix boundaries to complete UTF-8 characters. Replacing `é` with `ê` no longer describes a splice inside their shared leading byte.
+- Task 2's multiline resolved measurement/model invalidation and Task 7's terminal empty-line normalization were preserved. Their existing module regressions pass.
+
+## RED evidence
+
+All Cargo tests used the existing repository target cache and:
+
+```sh
+CARGO_BUILD_JOBS=4 CARGO_PROFILE_DEV_DEBUG=0 CARGO_PROFILE_TEST_DEBUG=0
+```
+
+Commands below include that environment prefix when using Cargo. Logs are retained under `.superpowers/app-ui-2026-09-15/task6-after-20260916/verification/`.
+
+1. `CARGO_BUILD_JOBS=4 CARGO_PROFILE_DEV_DEBUG=0 CARGO_PROFILE_TEST_DEBUG=0 cargo test -p ui --lib rich_marks_ -- --nocapture`
+   - `task6-red.log`: **0 passed, 2 failed**. `aBz` with bold B painted 4 glyphs instead of 3; adding bold to unchanged WWW left the authoritative caret advance unchanged.
+2. `CARGO_BUILD_JOBS=4 CARGO_PROFILE_DEV_DEBUG=0 CARGO_PROFILE_TEST_DEBUG=0 cargo test -p ui --lib attributed_single_line_is_shaped_during_measure_before_draw -- --nocapture`
+   - `task6-measure-red.log`: **0 passed, 1 failed**, no layout after measurement. An initial test compilation typo (`Size::MAX_CONTENT` trait import) was corrected before this behavioral RED.
+3. `target/debug/deps/ui-c93bc6d5c202339c rich_marks_utf8_replacement_keeps_complete_boundaries --nocapture`
+   - `task6-utf8-red.log`: **0 passed, 1 failed**; observed `(1, 1, 1)` instead of complete-character `(0, 2, 2)`.
+4. `CARGO_BUILD_JOBS=4 CARGO_PROFILE_DEV_DEBUG=0 CARGO_PROFILE_TEST_DEBUG=0 cargo test -p ui --lib rich_link_hits_follow_current_draw -- --nocapture`
+   - `task6-link-red.log`: **0 passed, 1 failed**; first-frame actual BlockEditor lookup at the final link sliver returned None.
+5. `CARGO_BUILD_JOBS=4 CARGO_PROFILE_DEV_DEBUG=0 CARGO_PROFILE_TEST_DEBUG=0 cargo test -p ui --lib rich_link_hits_cover_the_shaped_rtl_range -- --nocapture`
+   - `task6-link-rtl-red.log`: **0 passed, 1 failed**; endpoint-only bounds rejected the painted Hebrew link range.
+
+## GREEN verification
+
+The new focused tests cover glyph count, shaped weights 400/700/400 before draw, add/remove bold with unchanged text, caret/selection/inversion at 1× and 2× including horizontal scroll, actual IME preedit+commit beside multibyte text, full style inputs, chip/link path bounds, and real CRDT sync/undo/redo. BlockEditor tests exercise the actual first-frame and changed-style/scale link hit cache, RTL, and two link segments around an unmarked mixed-direction gap.
+
+Exact final module commands and outcomes:
+
+| Command | Result | Log |
+| --- | --- | --- |
+| `CARGO_BUILD_JOBS=4 CARGO_PROFILE_DEV_DEBUG=0 CARGO_PROFILE_TEST_DEBUG=0 cargo test -p ui --lib widget::text_input::tests -- --nocapture` | 105 passed | `task6-text-input-suite.log` |
+| `target/debug/deps/ui-c93bc6d5c202339c widget::rich_text_line::tests --nocapture` | 29 passed | `task6-rich-line-suite.log` |
+| `CARGO_BUILD_JOBS=4 CARGO_PROFILE_DEV_DEBUG=0 CARGO_PROFILE_TEST_DEBUG=0 cargo test -p ui --lib widget::block_editor::tests -- --nocapture` | 72 passed | `task6-block-editor-suite-final.log` |
+| `target/debug/deps/ui-c93bc6d5c202339c richtext::tests --nocapture` | 20 passed | `task6-richtext-suite.log` |
+| `target/debug/deps/ui-c93bc6d5c202339c widget::rich_text_editor::tests --nocapture` | 16 passed | `task6-rich-editor-suite.log` |
+| `target/debug/deps/ui-c93bc6d5c202339c widget::code_editor::tests --nocapture` | 23 passed | `task6-code-editor-suite.log` |
+| `CARGO_BUILD_JOBS=4 CARGO_PROFILE_DEV_DEBUG=0 cargo check -p ui` | passed | `task6-check.log` |
+| `CARGO_BUILD_JOBS=4 CARGO_PROFILE_DEV_DEBUG=0 cargo build -p notes --bin notes --message-format=json` | passed | `final-notes-build.log`, `final-build-artifacts.jsonl` |
+| `git diff --check -- ui/src/widget/text_input.rs ui/src/widget/rich_text_line.rs ui/src/widget/block_editor.rs` | passed | no output |
+
+Total: **265 relevant module tests passed, zero failed**. The macOS test linker emits its existing `__eh_frame` compact-unwind warning.
+
+A transient unrelated Chromium test edit first blocked compilation (missing NavigationDirection/direction fields). No Chromium source was touched; one retry after its writer supplied matching production edits compiled successfully.
+
+Optional `CARGO_BUILD_JOBS=4 CARGO_PROFILE_DEV_DEBUG=0 cargo clippy -p ui --lib` is **not green**: 100 existing errors/12 warnings across the shared tree, including untouched TextInput multiline measurement casts/map_or and unrelated tabs/scrollable code. No diagnostic points to Task 6 added logic. This is retained in `task6-clippy.log`; no blanket lint cleanup was attempted. The scoped compiler check is green.
+
+## Actual Notes interaction and visual evidence
+
+Evidence directory: `.superpowers/app-ui-2026-09-15/task6-after-20260916/`.
+
+`notes-interaction.rs` is a standalone evidence harness, not an app production edit. It links the exact Notes/qos-app artifacts emitted by the Cargo build (`interaction-build-command.json`), creates throwaway workspaces, and drives real NotesApp Widget events against settled Taffy layouts. Runtime HOME and **all four XDG homes** are isolated in `interaction-profile`; Cargo's repository cache remains shared. `interaction-run-command.json` records exact executable arguments and environment. Rendering uses `Theme::with_text_scale` and CPU offscreen paint.
+
+The final run (`interaction-run.log`, exit 0) at both 1× and 2× proves:
+
+- Actual click at the painted bold end places caret at byte 13.
+- Actual pointer drag selects exactly bytes 9..13 (`bold`).
+- Actual pointer drag selects exactly bytes 18..22 (`code`), and its selection remains visible over the chip.
+- A native `SetBlockMarks` action plus normal app sync applies overlapping bold and a valid page link. The actual hit route rejects edge+0.1px; clicking edge−0.1px navigates Notes to the expected Reading list UUID and body.
+
+The fixture explicitly initializes the canonical document and native link action. Earlier exploratory runs retained a nil legacy Markdown placeholder link; their refused navigation correctly exposed an incomplete harness fixture, not a passing click test. Only `interactions-final-verified/` is acceptance evidence.
+
+Fresh accepted screenshots (all 1200×800):
+
+- `interactions-final-verified/caret-1x.png`, `caret-2x.png`
+- `interactions-final-verified/selection-1x.png`, `selection-2x.png`
+- `interactions-final-verified/code-selection-1x.png`, `code-selection-2x.png`
+- `interactions-final-verified/bold-link-1x.png`, `bold-link-2x.png`
+- `interactions-final-verified/link-opened-1x.png`, `link-opened-2x.png`
+
+Implementer visually inspected 1× selection and 2× code-selection: single crisp bold, aligned selection, and visible code selection. Controller independently inspected all ten earlier accepted interaction images (`interactions-accepted/`; `interaction-image-comparison.json` compares the final rerun) and six standard actual Notes captures (wide, compact, narrow, large text, scale baseline, short), recording the visual pass in `.superpowers/app-ui-2026-09-15/task6-controller-visual.md`. Standard screenshot manifest: `.superpowers/app-ui-2026-09-15/task6-notes-final-20260916/capture-results.json`.
+
+## Provenance, self-review, and limits
+
+- Final Notes binary SHA256, stable through the final controller captures: `c1f09b8aede7e4a2021a9f0704818a13d0ae739dda8ba782d722bfd8eb655039`. The earlier candidate was `6b5d2cbbb5ed9f4b582606b0aa25686edca09015941e44707f9e8aba7fd45c97`. All six final standard PNG hashes are exactly identical to the earlier individually inspected images; the controller recorded this byte-identical proof.
+- `provenance.json` records source HEAD, SHA256 for all three owned source files, standalone harness source/executable hashes, and each accepted PNG hash. `owned-working-diff.patch` records the scoped source changes; Cargo artifact JSON records the linked library graph.
+- After the captured binary, only cfg(test) fixture refinement and restoring the original `too_many_arguments` annotation to its original draw helper changed. Neither changes runtime behavior. The final post-review Notes rebuild (`post-review-notes-build.log`) changed the executable hash; the controller therefore recaptured its matrix, and the implementer relinked/re-ran the actual interaction harness against the final library artifacts. Both final interaction scales passed again. All twelve final interaction PNGs (including initial-state images) are byte-for-byte identical to the earlier run; comparison is recorded in `interaction-image-comparison.json`.
+- Self-review checked complete span coverage, signature inputs, theme scaling, UTF-8 edit boundaries, IME display/committed offsets, chip/selection/presence layering, unchanged ordinary single-line defaults, model adoption routes, and the final commit scope. The old overpaint context/helpers are removed; no eraser pass or second editor/layout exists.
+- A trial styled mixed-direction range was visually contiguous; requiring two selection bands was an invalid fixture assumption. The final tests retain a reversed range and a real unmarked mixed-direction gap between separate link segments. Existing shaping/selection behavior was consumed unchanged; no typography/BiDi engine redesign was introduced.
+- Full workspace tests and global clippy cleanliness are not claimed. Independent controller source review remains the acceptance gate. No push, merge, deployment, or unrelated source edits.
diff --git a/ui/src/widget/block_editor.rs b/ui/src/widget/block_editor.rs
index b41855bc5..c0a0ff487 100644
--- a/ui/src/widget/block_editor.rs
+++ b/ui/src/widget/block_editor.rs
@@ -1558,26 +1558,29 @@ impl BlockEditor {
     }
 
     fn refresh_live_link_hits(&mut self, theme: &Theme) {
         self.live_link_hits.clear();
         for block in &self.blocks {
             let line = &block.line;
             for span in line.marks() {
                 let Mark::Link(id) = &span.mark else {
                     continue;
                 };
-                let x0 = line.pixel_x_for_byte(theme, span.range.start);
-                let x1 = line.pixel_x_for_byte(theme, span.range.end);
-                if x1 > x0 {
-                    let rect = line.get_rect();
-                    self.live_link_hits
-                        .push((Rect::new(x0, rect.y0, x1, rect.y1), *id));
+                for band in line
+                    .inner()
+                    .selection_rects(theme, span.range.start, span.range.end)
+                {
+                    if band.width() > 0.0 {
+                        let rect = line.get_rect();
+                        self.live_link_hits
+                            .push((Rect::new(band.x0, rect.y0, band.x1, rect.y1), *id));
+                    }
                 }
             }
         }
     }
 
     fn commit_link_selection(&mut self, page: &PageEntry) {
         let Some(focused_idx) = self.focused else {
             return;
         };
         let Some(open_byte) = self.link_open_at.take() else {
@@ -3828,21 +3831,20 @@ impl Widget for BlockEditor {
 
     fn draw(
         &mut self,
         scene: &mut Scene,
         transform: Affine,
         text_renderer: &mut TextRenderer,
         theme: &Theme,
         presence: &PresenceCtx,
     ) {
         let tokens = &theme.tokens;
-        self.refresh_live_link_hits(theme);
 
         // Painted BEFORE block content so the live caret stays on top.
         if self.blocks.len() == 1
             && let Some(first) = self.blocks.first()
             && matches!(first.kind, BlockKind::Paragraph)
             && first.line.value().is_empty()
         {
             let line_rect = first.line.get_rect();
             // Same vertical centring as the inner TextInput so the hint
             // reads as this line's placeholder, not a floating label.
@@ -3923,20 +3925,22 @@ impl Widget for BlockEditor {
 
         for (idx, b) in self.blocks.iter_mut().enumerate() {
             draw_block(b, idx, &mut ctx, &mut formulas);
         }
 
         // Runs AFTER the block loop: pixel_x_for_byte needs this frame's
         // fresh `char_x_positions`.
         for (i, b) in self.blocks.iter().enumerate() {
             self.draw_block_presence(i, b, &mut ctx);
         }
+        // Link routing must use the same freshly shaped advances as paint.
+        self.refresh_live_link_hits(theme);
     }
 
     fn handle_event(
         &mut self,
         event: &WindowEvent,
         scale_factor: f64,
         modifiers: &Modifiers,
         state: &mut AutoCommit,
         path: &ObjId,
         handled: &mut bool,
@@ -5615,20 +5619,92 @@ mod tests {
         renderer.set_text_scale(theme.text_scale);
         editor.draw(
             &mut Scene::new(),
             Affine::IDENTITY,
             &mut renderer,
             theme,
             &PresenceCtx::empty(),
         );
     }
 
+    #[test]
+    fn rich_link_hits_follow_current_draw_on_first_frame_style_and_scale_changes() {
+        let target = PageId::from_u128(42);
+        let mut block = Block::paragraph("WWW end");
+        block
+            .line
+            .set_marks(vec![MarkSpan::new(0..3, Mark::Link(target))]);
+        let mut editor = BlockEditor::new();
+        editor.set_blocks(vec![block]);
+        for (scale, bold) in [(1.0, false), (1.0, true), (2.0, true), (1.0, false)] {
+            let mut marks = vec![MarkSpan::new(0..3, Mark::Link(target))];
+            if bold {
+                marks.push(MarkSpan::new(0..3, Mark::Bold));
+            }
+            editor.blocks[0].line.set_marks(marks);
+            let theme = Theme::dark().with_text_scale(scale);
+            layout_and_draw_editor(&mut editor, &theme);
+            let line = &editor.blocks[0].line;
+            let right = line.pixel_x_for_byte(&theme, 3);
+            let y = line.get_rect().center().y;
+            assert_eq!(
+                editor.link_at_point(Point::new(right - 0.1, y)),
+                Some(target),
+                "the final painted sliver must link on this frame at {scale}x, bold={bold}"
+            );
+            assert_eq!(editor.link_at_point(Point::new(right + 0.1, y)), None);
+        }
+    }
+
+    #[test]
+    fn rich_link_hits_cover_the_shaped_rtl_range() {
+        let target = PageId::from_u128(43);
+        let mut block = Block::paragraph("אבג rest");
+        block.line.set_marks(vec![
+            MarkSpan::new(0..6, Mark::Link(target)),
+            MarkSpan::new(0..6, Mark::Bold),
+        ]);
+        let mut editor = BlockEditor::new();
+        editor.set_blocks(vec![block]);
+        let theme = Theme::dark();
+        layout_and_draw_editor(&mut editor, &theme);
+        let band = editor.blocks[0].line.selection_rect(&theme, 0, 6);
+        assert_eq!(editor.link_at_point(band.center()), Some(target));
+    }
+
+    #[test]
+    fn rich_link_hits_exclude_the_gap_between_mixed_direction_segments() {
+        let target = PageId::from_u128(44);
+        let mut block = Block::paragraph("ab אבג cd");
+        block.line.set_marks(vec![
+            MarkSpan::new(0..2, Mark::Link(target)),
+            MarkSpan::new(10..12, Mark::Link(target)),
+            MarkSpan::new(0..12, Mark::Bold),
+        ]);
+        let mut editor = BlockEditor::new();
+        editor.set_blocks(vec![block]);
+        let theme = Theme::dark();
+        layout_and_draw_editor(&mut editor, &theme);
+        let line = &editor.blocks[0].line;
+        let first = line.selection_rect(&theme, 0, 2);
+        let last = line.selection_rect(&theme, 10, 12);
+        assert_eq!(editor.link_at_point(first.center()), Some(target));
+        assert_eq!(editor.link_at_point(last.center()), Some(target));
+        let gap = line.selection_rect(&theme, 3, 9);
+        assert!(gap.x0 >= first.x1 && gap.x1 <= last.x0);
+        assert_eq!(
+            editor.link_at_point(gap.center()),
+            None,
+            "unmarked Hebrew remains outside the link"
+        );
+    }
+
     #[test]
     fn heading_paragraph_inline_code_and_numbered_prefix_scale_once() {
         let heading = Block::heading(1, "Heading");
         let mut paragraph = Block::paragraph("inline code");
         paragraph
             .line
             .set_marks(vec![MarkSpan::new(0..6, Mark::Code)]);
         paragraph.line.inner_mut().set_selection(0, 6);
         let numbered = Block::numbered(0, "numbered");
         let mut editor = BlockEditor::new();
diff --git a/ui/src/widget/rich_text_line.rs b/ui/src/widget/rich_text_line.rs
index 027402787..4f5ebc898 100644
--- a/ui/src/widget/rich_text_line.rs
+++ b/ui/src/widget/rich_text_line.rs
@@ -5,25 +5,27 @@
 //! * Intercepts Enter, Backspace at byte 0, Up at the start, and Down at the
 //!   end before the inner input sees them, queuing [`LineSignal`]s the
 //!   parent ([`crate::widget::block_editor::BlockEditor`]) consumes instead.
 //! * A per-line font size so a block editor can render H1/H2/H3 headings
 //!   without forking the widget.
 //! * A [`MarkSpan`] list (inline bold/italic/code/link) with rendering and
 //!   Ctrl-B/I/E toggling built on the inner `TextInput`'s selection range.
 
 use std::collections::HashMap;
 
+use crate::color_compat::ColorCompat;
+use crate::richtext::RichSpan;
+use crate::widget::text_input::SingleLineAttributes;
 use automerge::{AutoCommit, ObjId, ReadDoc, ScalarValue};
 use taffy::{Dimension, NodeId, Size, Style, TaffyTree};
 use vello::Scene;
 use vello::kurbo::{Affine, Point, Rect};
-use vello::peniko::BlendMode;
 use winit::event::{ElementState, KeyEvent, Modifiers, WindowEvent};
 use winit::keyboard::{Key, NamedKey};
 
 use crate::presence::PresenceCtx;
 use crate::text_render::{TextRenderer, TextWeight};
 use crate::theme::Theme;
 use crate::widget::TaffyTreeExt;
 use crate::widget::marks::{self, Mark, MarkSegment, MarkSpan, PageId};
 use crate::widget::{TextInput, Widget};
 
@@ -59,40 +61,28 @@ pub enum LineSignal {
     /// `open_at`. Brackets fall through to the inner input — the popover's
     /// commit-link logic strips them.
     LinkOpen {
         open_at: usize,
     },
 }
 
 /// Matches the body baseline the rest of the UI uses for `TextInput`.
 const DEFAULT_FONT_SIZE: f32 = 16.0;
 
-/// Geometry shared by every mark segment `draw` paints in one frame, so
-/// `paint_mark_segment` doesn't need a fistful of separate parameters.
-struct MarkDrawCtx<'a> {
-    text: &'a str,
-    xs: &'a [f64],
-    rect: Rect,
-    pad: f64,
-    scroll_x: f64,
-    text_y: f64,
-    line_height: f64,
-    text_size: f32,
-}
-
 pub struct RichTextLine {
     inner: TextInput,
     /// At most one signal in flight per frame; new signals overwrite the slot.
     signal: Option<LineSignal>,
     font_size: f32,
     /// Kept sorted by `range.start`.
     marks: Vec<MarkSpan>,
+    accent_rgb: Option<[u8; 3]>,
     /// Drained once `handle_event` observes a text-input edit.
     pending_marks: Vec<Mark>,
     /// Snapshot used to detect splice direction + length so `marks` stays
     /// aligned across user edits.
     prev_text: String,
     /// Cursor position before the most-recent edit; used with `prev_text` to
     /// figure out where the splice landed.
     prev_cursor: usize,
     /// `(byte_start, byte_end, author_id)` read from the bound Text's marks
     /// during `sync`; drives the authorship highlight in `BlockEditor::draw`.
@@ -103,20 +93,21 @@ impl RichTextLine {
     pub fn new() -> Self {
         // Block-editor cells render as document copy, not a form field.
         let inner = TextInput::local()
             .with_plain_chrome()
             .with_font_size(DEFAULT_FONT_SIZE);
         Self {
             inner,
             signal: None,
             font_size: DEFAULT_FONT_SIZE,
             marks: Vec::new(),
+            accent_rgb: None,
             pending_marks: Vec::new(),
             prev_text: String::new(),
             prev_cursor: 0,
             author_runs: Vec::new(),
         }
     }
 
     /// Dirty flag stays false — this is a programmatic seed.
     #[must_use]
     pub fn with_text(mut self, s: &str) -> Self {
@@ -153,20 +144,21 @@ impl RichTextLine {
     pub fn bind_text(&mut self, obj: ObjId) {
         self.inner.bind_text(obj);
     }
 
     pub(super) fn adopt_bound_text(
         &mut self,
         state: &AutoCommit,
     ) -> Result<(), crate::view::ThawError> {
         self.inner.adopt_bound_text(state)?;
         self.align_bound_projection(state);
+        self.refresh_attributes();
         Ok(())
     }
 
     fn align_bound_projection(&mut self, state: &AutoCommit) {
         self.prev_text = self.inner.value().to_string();
         self.prev_cursor = self.inner.cursor_pos();
 
         // Marks are char-indexed; convert to byte ranges for `pixel_x_for_byte`.
         self.author_runs.clear();
         if let Some(obj) = self.inner.bound_obj().cloned() {
@@ -209,20 +201,21 @@ impl RichTextLine {
 
     /// Does NOT mark the line dirty — programmatic writes are not user edits.
     pub fn set_text(&mut self, s: &str) {
         self.inner.set_text(s);
         self.inner.set_cursor_pos(s.len());
         // Doesn't preserve prior marks; parents re-seed via `set_marks`.
         self.marks.clear();
         self.pending_marks.clear();
         self.prev_text = s.to_string();
         self.prev_cursor = s.len();
+        self.refresh_attributes();
     }
 
     pub fn take_dirty(&mut self) -> Option<String> {
         self.inner.take_dirty()
     }
 
     pub fn is_focused(&self) -> bool {
         self.inner.is_focused()
     }
 
@@ -269,36 +262,39 @@ impl RichTextLine {
         self.font_size
     }
 
     pub fn marks(&self) -> &[MarkSpan] {
         &self.marks
     }
 
     pub fn set_marks(&mut self, marks: Vec<MarkSpan>) {
         self.marks = marks;
         self.marks.sort_by_key(|s| s.range.start);
+        self.refresh_attributes();
     }
 
     pub fn add_mark(&mut self, span: MarkSpan) {
         self.marks.push(span);
         self.marks.sort_by_key(|s| s.range.start);
+        self.refresh_attributes();
     }
 
     pub fn pending_marks(&self) -> &[Mark] {
         &self.pending_marks
     }
 
     /// With no active selection, pushes the mark onto the pending list so
     /// the next typed character inherits it.
     pub fn toggle_mark(&mut self, mark: Mark) {
         if let Some((s, e)) = self.inner.selection_range_public() {
             marks::toggle_mark_range(&mut self.marks, s..e, mark);
+            self.refresh_attributes();
         } else {
             // Pushing the same mark twice cancels it (Notion-style).
             if let Some(idx) = self.pending_marks.iter().position(|m| m.same_kind(&mark)) {
                 self.pending_marks.remove(idx);
             } else {
                 self.pending_marks.push(mark);
             }
         }
     }
 
@@ -316,38 +312,24 @@ impl RichTextLine {
 
     /// So a peer caret on this line is pixel-identical to the line's own focused caret.
     pub fn caret_rect(&self, theme: &Theme, byte: usize) -> Rect {
         self.inner.caret_rect(theme, byte)
     }
 
     pub fn selection_rect(&self, theme: &Theme, start: usize, end: usize) -> Rect {
         self.inner.selection_rect(theme, start, end)
     }
 
-    /// Inverse of [`pixel_x_for_byte`]; for the click-on-link hit-test.
-    pub fn byte_for_pixel_x(&self, theme: &Theme, x: f64) -> usize {
-        let xs = self.inner.char_x_positions();
-        if xs.is_empty() {
-            return 0;
-        }
-        let pad = self.inner.text_padding_x(theme);
-        let relative = x - self.inner.get_rect().x0 - pad + self.inner.scroll_x();
-        let mut best = 0usize;
-        let mut best_d = f64::MAX;
-        for (i, px) in xs.iter().enumerate() {
-            let d = (relative - *px).abs();
-            if d < best_d {
-                best_d = d;
-                best = i;
-            }
-        }
-        best
+    /// Inverse of [`pixel_x_for_byte`], using the shaped caret stops.
+    pub fn byte_for_pixel_x(&self, _theme: &Theme, x: f64) -> usize {
+        self.inner
+            .byte_at_point(Point::new(x, self.inner.get_rect().center().y))
     }
 
     /// Prefers [`Mark::Link`] over other kinds so link hit-tests still
     /// find the link even if the text is also bold.
     pub fn mark_at_byte(&self, byte: usize) -> Option<&Mark> {
         let mut link_hit: Option<&Mark> = None;
         let mut any_hit: Option<&Mark> = None;
         for s in &self.marks {
             if s.range.start <= byte && byte < s.range.end {
                 if matches!(s.mark, Mark::Link(_)) {
@@ -365,20 +347,72 @@ impl RichTextLine {
     pub fn inner_mut(&mut self) -> &mut TextInput {
         &mut self.inner
     }
 
     /// For `BlockEditor`'s cross-block drag coordinator, to check drag state without `&mut self`.
     #[doc(hidden)]
     pub fn inner(&self) -> &TextInput {
         &self.inner
     }
 
+    fn refresh_attributes(&mut self) {
+        let text = self.inner.value();
+        // Ignore malformed mark endpoints while still retaining every UTF-8
+        // byte in the complete run list.
+        let marks: Vec<_> = self
+            .marks
+            .iter()
+            .filter(|mark| {
+                mark.range.start < mark.range.end
+                    && mark.range.end <= text.len()
+                    && text.is_char_boundary(mark.range.start)
+                    && text.is_char_boundary(mark.range.end)
+            })
+            .cloned()
+            .collect();
+        let mut attributes = SingleLineAttributes::default();
+        for segment in marks::segments_for(text.len(), &marks) {
+            let range = (segment.range.start, segment.range.end);
+            let Some(slice) = text.get(segment.range.clone()) else {
+                continue;
+            };
+            let span = RichSpan::new(slice)
+                .bold(segment.bold)
+                .italic(segment.italic)
+                .color(if segment.code || segment.link.is_some() {
+                    self.accent_rgb
+                } else {
+                    None
+                });
+            attributes.spans.push(span);
+            if segment.underline {
+                attributes.underlines.push(range);
+            }
+            if segment.strikethrough {
+                attributes.strikes.push(range);
+            }
+            if segment.code {
+                attributes.chips.push(range);
+            }
+            if segment.link.is_some() && !segment.underline {
+                attributes.links.push(range);
+            }
+        }
+        self.inner.set_single_line_attributes(attributes);
+    }
+
+    fn prepare_attributes(&mut self, theme: &Theme) {
+        let color = theme.tokens.colors.accent[5];
+        self.accent_rgb = Some([color.r(), color.g(), color.b()]);
+        self.refresh_attributes();
+    }
+
     /// Ctrl/Super + b/i/e/u toggles the corresponding mark. Returns `true`
     /// when `c` matched one of the shortcuts (case-insensitively).
     fn handle_mark_shortcut(&mut self, c: &str) -> bool {
         match c.to_lowercase().as_str() {
             "b" => self.toggle_mark(Mark::Bold),
             "i" => self.toggle_mark(Mark::Italic),
             "e" => self.toggle_mark(Mark::Code),
             "u" => self.toggle_mark(Mark::Underline),
             _ => return false,
         }
@@ -419,121 +453,85 @@ impl Default for RichTextLine {
         Self::new()
     }
 }
 
 impl Widget for RichTextLine {
     fn sync(&mut self, state: &mut AutoCommit, path: &ObjId) {
         // Realigning the mark-diff snapshot here keeps a remotely-synced edit
         // from being misread as a local splice on the next keystroke.
         self.inner.sync(state, path);
         self.align_bound_projection(state);
+        self.refresh_attributes();
     }
 
     fn build_layout(
         &mut self,
         taffy: &mut TaffyTree<()>,
         theme: &Theme,
         node_map: &mut HashMap<NodeId, *mut dyn Widget>,
     ) -> NodeId {
         // Font overrides remain base values. TextInput's shaped layout applies
         // the theme scale exactly once; the row height is resolved here because
         // this wrapper owns the surrounding document geometry.
+        self.prepare_attributes(theme);
+        self.inner.capture_layout_text_scale(theme.text_scale);
         let scale = theme.text_scale;
         self.inner.set_font_size(self.font_size);
         // font_size * 1.5 so headings end up taller than paragraph rows without a measure pass.
         let height = (self.font_size * scale * 1.5).max(20.0 * scale);
         let node = taffy.leaf_node(Style {
             size: Size {
                 width: Dimension::percent(1.0),
                 height: Dimension::length(height),
             },
             ..Default::default()
         });
         node_map.insert(node, std::ptr::from_mut::<dyn Widget>(self));
         node
     }
 
+    fn measure(
+        &mut self,
+        known: Size<Option<f32>>,
+        available: Size<taffy::AvailableSpace>,
+        text_renderer: &mut TextRenderer,
+    ) -> Size<f32> {
+        self.refresh_attributes();
+        self.inner.measure(known, available, text_renderer)
+    }
+
+    fn layout_needs_measure(&self) -> bool {
+        self.inner.layout_needs_measure()
+    }
+
     fn apply_layout(&mut self, taffy: &TaffyTree<()>, node: NodeId, origin: Point) {
         let layout = taffy.layout(node).copied().unwrap_or_default();
         let rect = Rect::new(
             origin.x + f64::from(layout.location.x),
             origin.y + f64::from(layout.location.y),
             origin.x + f64::from(layout.location.x) + f64::from(layout.size.width),
             origin.y + f64::from(layout.location.y) + f64::from(layout.size.height),
         );
         self.inner.apply_layout_external(rect);
     }
 
     fn draw(
         &mut self,
         scene: &mut Scene,
         transform: Affine,
         text_renderer: &mut TextRenderer,
         theme: &Theme,
         presence: &PresenceCtx,
     ) {
-        // The inner TextInput draws the plain text first; mark-styled
-        // segments are then overpainted on top only where styling differs.
+        self.prepare_attributes(theme);
         self.inner
             .draw(scene, transform, text_renderer, theme, presence);
-
-        if self.marks.is_empty() {
-            return;
-        }
-
-        let text = self.inner.value().to_string();
-        let segments = marks::segments_for(text.len(), &self.marks);
-        if segments.is_empty() {
-            return;
-        }
-
-        // Styled runs are painted through `TextRenderer` and therefore take
-        // its global accessibility scale themselves. Their geometry still
-        // needs the physical line height used by the scaled inner input.
-        let text_size = self.font_size;
-        let line_height = f64::from(text_size * theme.text_scale) * 1.25;
-        let rect = self.inner.get_rect();
-        let pad = self.inner.text_padding_x(theme);
-        let scroll_x = self.inner.scroll_x();
-        let text_y = rect.y0 + (rect.height() - line_height) / 2.0;
-        let xs = self.inner.char_x_positions();
-        if xs.is_empty() {
-            // First frame — inner input hasn't populated char_x_positions yet.
-            return;
-        }
-
-        // Clips overpaint so a scrolled long line doesn't bleed glyphs past the column.
-        let clip_shape =
-            vello::kurbo::RoundedRect::from_rect(rect, f64::from(theme.tokens.radii.md));
-        scene.push_layer(
-            vello::peniko::Fill::NonZero,
-            BlendMode::default(),
-            1.0,
-            transform,
-            &clip_shape,
-        );
-
-        let ctx = MarkDrawCtx {
-            text: &text,
-            xs,
-            rect,
-            pad,
-            scroll_x,
-            text_y,
-            line_height,
-            text_size,
-        };
-        for seg in &segments {
-            paint_mark_segment(scene, transform, text_renderer, theme, seg, &ctx);
-        }
-
-        scene.pop_layer();
     }
 
     fn handle_event(
         &mut self,
         event: &WindowEvent,
         scale_factor: f64,
         modifiers: &Modifiers,
         state: &mut AutoCommit,
         path: &ObjId,
         handled: &mut bool,
@@ -623,20 +621,21 @@ impl Widget for RichTextLine {
             focus_target,
             node_id,
             taffy,
         );
 
         // Reconcile marks against any text edit using byte-deltas from the previous snapshot.
         let new_text = self.inner.value().to_string();
         if new_text != self.prev_text {
             self.reconcile_marks_after_edit(&new_text);
             self.prev_text = new_text;
+            self.refresh_attributes();
         }
         self.prev_cursor = self.inner.cursor_pos();
     }
 
     fn name(&self) -> &'static str {
         "RichTextLine"
     }
 
     fn get_rect(&self) -> Rect {
         self.inner.get_rect()
@@ -676,225 +675,66 @@ impl Widget for RichTextLine {
         action: &crate::a11y::Action,
         state: &mut AutoCommit,
         path: &ObjId,
     ) -> bool {
         let handled = Widget::perform_action(&mut self.inner, action, state, path);
         if handled && matches!(action, crate::a11y::Action::SetValue(_)) {
             self.marks.clear();
             self.pending_marks.clear();
             self.prev_text = self.inner.value().to_string();
             self.prev_cursor = self.inner.cursor_pos();
+            self.refresh_attributes();
         }
         handled
     }
 }
 
-/// Paints one mark segment's overpaint (code chip, link/underline/strike
-/// rules, and restyled glyphs) inside the clip layer `draw` already pushed.
-/// A pure function of its inputs — no `self` needed.
-fn paint_mark_segment(
-    scene: &mut Scene,
-    transform: Affine,
-    text_renderer: &mut TextRenderer,
-    theme: &Theme,
-    seg: &MarkSegment,
-    ctx: &MarkDrawCtx<'_>,
-) {
-    if seg.range.start >= ctx.text.len() {
-        return;
-    }
-    // A mark's byte range might not land on a char boundary after an edit
-    // races the mark-shift logic; skip rather than panic.
-    let Some(slice) = ctx
-        .text
-        .get(seg.range.start..seg.range.end.min(ctx.text.len()))
-    else {
-        return;
-    };
-    if slice.is_empty() {
-        return;
-    }
-
-    let x_offset = ctx.xs.get(seg.range.start).copied().unwrap_or(0.0);
-    let x = ctx.rect.x0 + ctx.pad + x_offset - ctx.scroll_x;
-    let sans_end_x_offset = ctx
-        .xs
-        .get(seg.range.end.min(ctx.xs.len().saturating_sub(1)))
-        .copied()
-        .unwrap_or(x_offset);
-    let sans_end_x = ctx.rect.x0 + ctx.pad + sans_end_x_offset - ctx.scroll_x;
-
-    paint_segment_decorations(scene, transform, theme, seg, ctx, x, sans_end_x);
-
-    let needs_overpaint = seg.bold
-        || seg.italic
-        || seg.code
-        || seg.underline
-        || seg.strikethrough
-        || seg.link.is_some();
-    if !needs_overpaint {
-        return;
-    }
-
-    let tokens = &theme.tokens;
-    let color = if seg.link.is_some() || seg.code {
-        tokens.colors.accent[5]
-    } else {
-        tokens.colors.text_primary
-    };
-
-    let weight = if seg.bold {
-        TextWeight::Bold
-    } else {
-        TextWeight::Regular
-    };
-    let italic = seg.italic;
-    let mono = false;
-
-    text_renderer.draw_text_styled(
-        scene,
-        slice,
-        ctx.text_size,
-        color,
-        translated(transform, x, ctx.text_y),
-        None,
-        weight,
-        italic,
-        mono,
-    );
-}
-
-/// Draws the code-chip background and the link/underline/strikethrough
-/// rules for one segment — the parts of `paint_mark_segment` that don't
-/// depend on the restyled text run itself.
-fn paint_segment_decorations(
-    scene: &mut Scene,
-    transform: Affine,
-    theme: &Theme,
-    seg: &MarkSegment,
-    ctx: &MarkDrawCtx<'_>,
-    x: f64,
-    sans_end_x: f64,
-) {
-    let tokens = &theme.tokens;
-
-    if seg.code {
-        // Inline code renders in the document font (`mono = false` in
-        // `paint_mark_segment`) so its extent matches the sans layout slot
-        // exactly; a wider monospace measurement would overlap next chars.
-        let bg_rect = Rect::new(
-            x - 2.0,
-            ctx.text_y + 1.0,
-            sans_end_x + 2.0,
-            ctx.text_y + ctx.line_height - 1.0,
-        );
-        let bg = vello::kurbo::RoundedRect::from_rect(bg_rect, 3.0);
-        scene.fill(
-            vello::peniko::Fill::NonZero,
-            transform,
-            tokens.colors.surfaces.raised,
-            None,
-            &bg,
-        );
-    }
-
-    if seg.link.is_some() {
-        let underline = Rect::new(
-            x,
-            ctx.text_y + ctx.line_height - 2.0,
-            sans_end_x,
-            ctx.text_y + ctx.line_height - 1.0,
-        );
-        scene.fill(
-            vello::peniko::Fill::NonZero,
-            transform,
-            tokens.colors.accent[5],
-            None,
-            &underline,
-        );
-    }
-
-    // In text colour, distinct from the accent-coloured link underline above.
-    if seg.underline {
-        let rule = Rect::new(
-            x,
-            ctx.text_y + ctx.line_height - 2.0,
-            sans_end_x,
-            ctx.text_y + ctx.line_height - 1.0,
-        );
-        scene.fill(
-            vello::peniko::Fill::NonZero,
-            transform,
-            tokens.colors.text_primary,
-            None,
-            &rule,
-        );
-    }
-
-    if seg.strikethrough {
-        let mid = ctx.text_y + ctx.line_height * 0.5;
-        let rule = Rect::new(x, mid - 0.5, sans_end_x, mid + 0.5);
-        scene.fill(
-            vello::peniko::Fill::NonZero,
-            transform,
-            tokens.colors.text_primary,
-            None,
-            &rule,
-        );
-    }
-}
-
-/// Composes `transform` with a translation by `(dx, dy)`. `kurbo::Affine`'s
-/// `Mul` impl trips `arithmetic_side_effects` like any operator overload,
-/// but composing two f64-based affine transforms cannot meaningfully
-/// overflow — same reasoning clippy already exempts bare `f64` arithmetic
-/// for.
-#[allow(
-    clippy::arithmetic_side_effects,
-    reason = "Affine::mul composes f64 transform matrices; cannot meaningfully overflow"
-)]
-fn translated(transform: Affine, dx: f64, dy: f64) -> Affine {
-    transform * Affine::translate((dx, dy))
-}
-
 /// Clamps to the end. Converts Automerge marks (char-indexed) to the byte
 /// offsets `pixel_x_for_byte` uses.
 fn char_to_byte(text: &str, char_idx: usize) -> usize {
     text.char_indices()
         .nth(char_idx)
         .map_or(text.len(), |(b, _)| b)
 }
 
 /// Returns `(at, inserted, removed)`. The simple LCP/LCS-prefix algorithm is
 /// fine because a `TextInput` always splices at the caret, so the diff is a
 /// single insertion or deletion.
 pub(crate) fn diff_splice(old: &str, new: &str) -> (usize, usize, usize) {
     let oa = old.as_bytes();
     let na = new.as_bytes();
 
     // Longest common prefix.
-    let prefix = oa.iter().zip(na.iter()).take_while(|(o, n)| o == n).count();
+    let mut prefix = oa.iter().zip(na.iter()).take_while(|(o, n)| o == n).count();
+    while !old.is_char_boundary(prefix) || !new.is_char_boundary(prefix) {
+        prefix = prefix.saturating_sub(1);
+    }
 
     let o_rest = oa.len().saturating_sub(prefix);
     let n_rest = na.len().saturating_sub(prefix);
 
     // Longest common suffix within the bytes past the prefix. `zip` already
     // stops at the shorter of the two (reversed, prefix-skipped) iterators,
     // matching the original bound of `min(o_rest, n_rest)`.
-    let suffix = oa
+    let mut suffix = oa
         .iter()
         .skip(prefix)
         .rev()
         .zip(na.iter().skip(prefix).rev())
         .take_while(|(o, n)| o == n)
         .count();
 
+    while !old.is_char_boundary(old.len().saturating_sub(suffix))
+        || !new.is_char_boundary(new.len().saturating_sub(suffix))
+    {
+        suffix = suffix.saturating_sub(1);
+    }
     let removed = o_rest.saturating_sub(suffix);
     let inserted = n_rest.saturating_sub(suffix);
     (prefix, inserted, removed)
 }
 
 /// Re-exported so callers don't have to depend on the `marks` module
 /// directly.
 pub fn segments_of(text_len: usize, marks: &[MarkSpan]) -> Vec<MarkSegment> {
     marks::segments_for(text_len, marks)
 }
@@ -978,21 +818,21 @@ mod tests {
             &modifiers,
             &mut state,
             &root,
             &mut handled,
             &mut focus_target,
             fake_node,
             &taffy,
         );
     }
 
-    fn layout_and_draw(line: &mut RichTextLine, theme: &Theme, width: f32) {
+    fn layout_and_draw(line: &mut RichTextLine, theme: &Theme, width: f32) -> Scene {
         let mut taffy = TaffyTree::<()>::new();
         let mut node_map = HashMap::new();
         let node = line.build_layout(&mut taffy, theme, &mut node_map);
         taffy
             .compute_layout(
                 node,
                 Size {
                     width: taffy::AvailableSpace::Definite(width),
                     height: taffy::AvailableSpace::MaxContent,
                 },
@@ -1003,20 +843,76 @@ mod tests {
         let mut renderer = TextRenderer::new();
         renderer.set_text_scale(theme.text_scale);
         let mut scene = Scene::new();
         line.draw(
             &mut scene,
             Affine::IDENTITY,
             &mut renderer,
             theme,
             &PresenceCtx::empty(),
         );
+        scene
+    }
+
+    #[test]
+    fn rich_marks_utf8_replacement_keeps_complete_boundaries() {
+        assert_eq!(diff_splice("éx", "êx"), (0, 2, 2));
+        assert_eq!(diff_splice("xé", "xê"), (1, 2, 2));
+    }
+
+    #[test]
+    fn rich_marks_paint_each_glyph_once() {
+        let mut line = RichTextLine::new().with_text("aBz");
+        line.set_marks(vec![MarkSpan::new(1..2, Mark::Bold)]);
+        let scene = layout_and_draw(&mut line, &Theme::dark(), 320.0);
+        assert_eq!(scene.encoding().resources.glyphs.len(), 3);
+    }
+
+    #[test]
+    fn rich_marks_style_only_changes_refresh_authoritative_geometry() {
+        for scale in [1.0, 2.0] {
+            let theme = Theme::dark().with_text_scale(scale);
+            let mut line = RichTextLine::new().with_text("WWW end");
+            layout_and_draw(&mut line, &theme, 400.0);
+            let plain = line.pixel_x_for_byte(&theme, 3);
+            line.set_marks(vec![MarkSpan::new(0..3, Mark::Bold)]);
+            layout_and_draw(&mut line, &theme, 400.0);
+            let bold = line.pixel_x_for_byte(&theme, 3);
+            assert!(
+                (bold - plain).abs() > 0.1,
+                "bold must change the authoritative advances"
+            );
+            assert!((line.caret_rect(&theme, 3).x0 - bold).abs() < 0.01);
+            assert!((line.selection_rect(&theme, 0, 3).x1 - bold).abs() < 0.01);
+            assert_eq!(line.byte_for_pixel_x(&theme, bold), 3);
+            line.set_marks(vec![]);
+            layout_and_draw(&mut line, &theme, 400.0);
+            assert!((line.pixel_x_for_byte(&theme, 3) - plain).abs() < 0.01);
+        }
+    }
+
+    #[test]
+    fn rich_marks_scrolled_selection_and_pointer_share_the_painted_end() {
+        for scale in [1.0, 2.0] {
+            let theme = Theme::dark().with_text_scale(scale);
+            let mut line = RichTextLine::new().with_text("prefix WWW tail");
+            line.set_marks(vec![MarkSpan::new(7..10, Mark::Bold)]);
+            line.set_focus(true);
+            line.inner_mut().set_selection(7, 10);
+            layout_and_draw(&mut line, &theme, 80.0);
+            assert!(line.inner().scroll_x() > 0.0);
+            let x = line.pixel_x_for_byte(&theme, 10);
+            assert!(x <= line.get_rect().x1);
+            assert!((line.caret_rect(&theme, 10).x0 - x).abs() < 0.01);
+            assert!((line.selection_rect(&theme, 7, 10).x1 - x).abs() < 0.01);
+            assert_eq!(line.byte_for_pixel_x(&theme, x), 10);
+        }
     }
 
     #[test]
     fn base_font_override_scales_once_across_relayout_caret_selection_and_pointer() {
         let mut line = RichTextLine::new().with_text("alpha beta").with_size(16.0);
         line.set_marks(vec![MarkSpan::new(0..5, Mark::Code)]);
         line.inner_mut().set_selection(0, 5);
 
         let normal = Theme::dark();
         layout_and_draw(&mut line, &normal, 320.0);
diff --git a/ui/src/widget/text_input.rs b/ui/src/widget/text_input.rs
index 172d79260..f090271e0 100644
--- a/ui/src/widget/text_input.rs
+++ b/ui/src/widget/text_input.rs
@@ -138,20 +138,31 @@ const GUTTER_PAD_R: f64 = 12.0;
 /// Unit the in-flight drag snaps to, set from the click ladder on press.
 #[derive(Copy, Clone, Debug, PartialEq, Eq)]
 enum DragUnit {
     Char,
     Word,
     All,
 }
 
 type TextChangeCallback = Box<dyn FnMut(&str)>;
 
+/// Complete committed-text runs for an unmasked single line. Decorations use
+/// byte ranges in that same text; IME insertion remaps them only for display.
+#[derive(Clone, Debug, Default)]
+pub(super) struct SingleLineAttributes {
+    pub spans: Vec<RichSpan>,
+    pub underlines: Vec<(usize, usize)>,
+    pub strikes: Vec<(usize, usize)>,
+    pub chips: Vec<(usize, usize)>,
+    pub links: Vec<(usize, usize)>,
+}
+
 #[allow(
     clippy::struct_excessive_bools,
     reason = "each bool is an independent widget-configuration or ephemeral-UI-state flag (hover/focus/drag/dirty/secret/etc), not a state machine; grouping them would misrepresent orthogonal concerns and ripple through every accessor in this file"
 )]
 pub struct TextInput {
     id: String,
     path: Vec<PathSegment>,
     rect: Rect,
     is_hovered: bool,
     is_focused: bool,
@@ -202,20 +213,21 @@ pub struct TextInput {
     /// Optional local-only mirror for secrets and other values that must not
     /// enter an Automerge history. The owner controls its lifetime and can
     /// zero/clear it immediately after use.
     external_buffer: Option<Arc<Mutex<String>>>,
     on_change_path: String,
     last_mouse_pos: Point,
     char_x_positions: Vec<f64>,
     /// Authoritative cosmic-text geometry for a visible, unmasked single-line
     /// value. Painting, carets, selection, and hit-testing all consume it.
     single_layout: Option<RichTextLayout>,
+    single_attributes: Option<SingleLineAttributes>,
     single_origin: Point,
     shaped_layout_signature: u64,
     /// In-progress IME composition. It is inserted only in the display
     /// layout and never exposed through value, clipboard, CRDT, or a11y.
     preedit: String,
     preedit_cursor: Option<(usize, usize)>,
     scroll_x: f64,
     last_edit_time: Option<Instant>,
     font_size_override: Option<f32>,
     /// Theme scale captured during `build_layout`; direct measurement falls
@@ -364,20 +376,21 @@ impl TextInput {
             is_dragging: false,
             drag_unit: DragUnit::Char,
             drag_anchor_span: (0, 0),
             last_click_time: None,
             last_click_pos: Point::ZERO,
             click_count: 0,
             on_change_path: String::new(),
             last_mouse_pos: Point::ZERO,
             char_x_positions: Vec::new(),
             single_layout: None,
+            single_attributes: None,
             single_origin: Point::ZERO,
             shaped_layout_signature: u64::MAX,
             preedit: String::new(),
             preedit_cursor: None,
             scroll_x: 0.0,
             last_edit_time: None,
             dirty: false,
             on_change: None,
             action: None,
             last_notified_text: String::new(),
@@ -474,29 +487,29 @@ impl TextInput {
     }
 
     /// Replace text read from model state without reporting a user edit.
     /// Returns whether the value changed so direct bindings can preserve
     /// their existing reconciliation signal.
     fn adopt_model_text(&mut self, text: String) -> bool {
         if self.text == text {
             return false;
         }
         self.text = text;
-        self.model_layout_dirty |= self.multiline;
+        self.model_layout_dirty |= self.multiline || self.single_attributes.is_some();
         true
     }
 
     /// Capture the resolved theme scale before a renderer-backed measurement.
     pub(super) fn capture_layout_text_scale(&mut self, text_scale: f32) {
         if self.layout_text_scale != Some(text_scale) {
             self.layout_text_scale = Some(text_scale);
-            self.model_layout_dirty |= self.multiline;
+            self.model_layout_dirty |= self.multiline || self.single_attributes.is_some();
         }
     }
 
     /// Keep the binding readable while an owning action bridge handles user writes.
     pub fn set_direct_crdt_writes(&mut self, enabled: bool) {
         self.direct_crdt_writes = enabled;
     }
 
     fn resolve_text_obj(&self, state: &AutoCommit, root: &ObjId) -> Option<ObjId> {
         if !self.direct_crdt_writes {
@@ -547,35 +560,41 @@ impl TextInput {
         self
     }
 
     #[must_use]
     pub fn with_plain_chrome(mut self) -> Self {
         self.plain = true;
         self
     }
 
     pub fn set_font_size(&mut self, size: f32) {
-        self.font_size_override = Some(size);
+        if self.font_size_override != Some(size) {
+            self.model_layout_dirty |= self.single_attributes.is_some();
+            self.font_size_override = Some(size);
+        }
     }
 
     pub fn set_plain_chrome(&mut self, plain: bool) {
         self.plain = plain;
     }
 
     #[must_use]
     pub fn with_mono(mut self) -> Self {
         self.mono = true;
         self.kind = TextInputKind::Code;
         self
     }
 
     pub fn set_mono(&mut self, mono: bool) {
+        if self.mono != mono {
+            self.model_layout_dirty |= self.single_attributes.is_some();
+        }
         self.mono = mono;
         if mono {
             self.set_kind(TextInputKind::Code);
         }
     }
 
     pub fn is_mono(&self) -> bool {
         self.mono
     }
 
@@ -683,21 +702,24 @@ impl TextInput {
     }
 
     /// Wins over the mono flag.
     #[must_use]
     pub fn with_font_family(mut self, family: FontChoice) -> Self {
         self.family = Some(family);
         self
     }
 
     pub fn set_font_family(&mut self, family: Option<FontChoice>) {
-        self.family = family;
+        if self.family != family {
+            self.model_layout_dirty |= self.single_attributes.is_some();
+            self.family = family;
+        }
     }
 
     pub fn font_family(&self) -> Option<&FontChoice> {
         self.family.as_ref()
     }
 
     /// Picks the same family the draw path will use, so `char_x_positions`
     /// and the drawn glyphs agree.
     fn measure_str(&self, tr: &mut TextRenderer, s: &str, size: f32) -> (f32, f32) {
         if let Some(fam) = &self.family {
@@ -729,20 +751,28 @@ impl TextInput {
         }
         hash.finish()
     }
 
     fn attributed_signature(base: u64, spans: &[RichSpan]) -> u64 {
         use std::collections::hash_map::DefaultHasher;
         use std::hash::{Hash, Hasher};
         let mut hash = DefaultHasher::new();
         base.hash(&mut hash);
         for span in spans {
+            span.text.hash(&mut hash);
+            span.size.map(f32::to_bits).hash(&mut hash);
+            std::mem::discriminant(&span.family).hash(&mut hash);
+            if let Some(family) = span.family {
+                std::mem::discriminant(&family).hash(&mut hash);
+            }
+            span.background.hash(&mut hash);
+            std::mem::discriminant(&span.baseline).hash(&mut hash);
             span.color.hash(&mut hash);
             span.bold.hash(&mut hash);
             span.italic.hash(&mut hash);
         }
         hash.finish()
     }
 
     /// Convert the highlighter's logical-line ranges into a complete set of
     /// attributed document spans, then insert IME preedit as a display-only
     /// default-colour run. Concatenating the result always reproduces
@@ -792,20 +822,24 @@ impl TextInput {
                 spans.push(RichSpan::new(mid).color(Some(color)));
             }
             cursor = end;
         }
         if (cursor < self.text.len() || spans.is_empty())
             && let Some(tail) = self.text.get(cursor..)
         {
             spans.push(RichSpan::new(tail));
         }
 
+        self.insert_preedit_span(spans)
+    }
+
+    fn insert_preedit_span(&self, spans: Vec<RichSpan>) -> Vec<RichSpan> {
         if self.preedit.is_empty() {
             return spans;
         }
         let at = self.cursor_pos.min(self.text.len());
         let mut display = Vec::with_capacity(spans.len().saturating_add(2));
         let mut consumed = 0usize;
         let mut inserted = false;
         for span in spans {
             let end = consumed.saturating_add(span.text.len());
             if !inserted && at <= end {
@@ -837,20 +871,81 @@ impl TextInput {
                 display.push(span);
             }
             consumed = end;
         }
         if !inserted {
             display.push(RichSpan::new(&self.preedit));
         }
         display
     }
 
+    pub(super) fn set_single_line_attributes(&mut self, attributes: SingleLineAttributes) {
+        let signature = Self::single_attributes_signature(&attributes);
+        if self
+            .single_attributes
+            .as_ref()
+            .is_none_or(|old| Self::single_attributes_signature(old) != signature)
+        {
+            self.single_attributes = Some(attributes);
+            self.single_layout = None;
+            self.model_layout_dirty = true;
+        }
+    }
+
+    fn single_attributes_signature(attributes: &SingleLineAttributes) -> u64 {
+        use std::hash::{Hash, Hasher};
+        let mut hash = std::collections::hash_map::DefaultHasher::new();
+        Self::attributed_signature(0, &attributes.spans).hash(&mut hash);
+        attributes.underlines.hash(&mut hash);
+        attributes.strikes.hash(&mut hash);
+        attributes.chips.hash(&mut hash);
+        attributes.links.hash(&mut hash);
+        hash.finish()
+    }
+
+    fn valid_single_attributes(&self) -> Option<&SingleLineAttributes> {
+        self.single_attributes.as_ref().filter(|attributes| {
+            attributes
+                .spans
+                .iter()
+                .map(|s| s.text.as_str())
+                .collect::<String>()
+                == self.text
+        })
+    }
+
+    /// Preedit is its own run: adjacent committed decorations do not expand
+    /// over it. An insertion inside a marked run splits its decoration.
+    fn display_ranges(&self, ranges: &[(usize, usize)]) -> Vec<(usize, usize)> {
+        let at = self.cursor_pos.min(self.text.len());
+        let extra = self.preedit.len();
+        let mut display = Vec::new();
+        for &(start, end) in ranges {
+            if start >= end
+                || end > self.text.len()
+                || !self.text.is_char_boundary(start)
+                || !self.text.is_char_boundary(end)
+            {
+                continue;
+            }
+            if extra == 0 || end <= at {
+                display.push((start, end));
+            } else if start >= at {
+                display.push((start.saturating_add(extra), end.saturating_add(extra)));
+            } else {
+                display.push((start, at));
+                display.push((at.saturating_add(extra), end.saturating_add(extra)));
+            }
+        }
+        display
+    }
+
     /// No CRDT integration — for a field with no CRDT path to spend.
     pub fn local() -> Self {
         let mut s = Self::new(Vec::new());
         s.crdt_bound = false;
         s
     }
 
     /// Explicit host language without discovery or background dictionary warmup.
     pub(crate) fn local_with_language(language: &str) -> Self {
         Self::with_language(Vec::new(), language.to_owned())
@@ -920,21 +1015,21 @@ impl TextInput {
         if self.text == s {
             return;
         }
         if self.secret {
             self.text.zeroize();
         }
         self.text = s.to_string();
         self.selection_anchor = None;
         self.clamp_to_text();
         self.dirty = false;
-        self.model_layout_dirty = self.multiline;
+        self.model_layout_dirty = self.multiline || self.single_attributes.is_some();
         self.last_edit_time = None;
         self.last_notified_text.clone_from(&self.text);
         if self.action.is_none() {
             self.publish_local_state();
         }
     }
 
     pub fn value(&self) -> &str {
         &self.text
     }
@@ -3624,20 +3719,32 @@ impl Widget for TextInput {
 
     /// Single-line keeps its fixed row height from `build_layout` (ZERO
     /// here). Embedded callers use `apply_layout_external` and never reach this.
     fn measure(
         &mut self,
         known: taffy::Size<Option<f32>>,
         available: taffy::Size<taffy::AvailableSpace>,
         text_renderer: &mut TextRenderer,
     ) -> taffy::Size<f32> {
         if !self.multiline {
+            if !self.masked() && self.single_attributes.is_some() {
+                let scale = self
+                    .layout_text_scale
+                    .unwrap_or_else(|| text_renderer.text_scale());
+                let display = self.layout_display_text();
+                self.build_single_line_metrics(
+                    text_renderer,
+                    &display,
+                    self.effective_font_size(),
+                    scale,
+                );
+            }
             self.model_layout_dirty = false;
             return taffy::Size::ZERO;
         }
         let width = known.width.unwrap_or(match available.width {
             taffy::AvailableSpace::Definite(w) => w,
             _ => 400.0,
         });
         if !self.masked() {
             let scale = self
                 .layout_text_scale
@@ -3734,53 +3841,56 @@ impl Widget for TextInput {
         } else {
             f64::from(theme.padding_standard)
         };
         let text_y = self.rect.y0 + (self.rect.height() - line_height) / 2.0;
 
         // `char_x_positions` remains as a compatibility/readback surface, but
         // normal text now gets every position from the same shaped paragraph
         // used for paint and hit-testing. Masked fields keep the prefix path
         // because bullet byte offsets intentionally differ from the secret.
         let display = self.layout_display_text();
-        let total_w = self.build_single_line_metrics(text_renderer, &display, text_size, theme);
+        let total_w =
+            self.build_single_line_metrics(text_renderer, &display, text_size, theme.text_scale);
         self.single_origin = Point::new(self.rect.x0 + padding_x, text_y);
 
         let cursor_x_offset = self.single_line_cursor_x_offset(total_w);
         self.update_single_line_scroll(cursor_x_offset, padding_x);
 
         scene.push_layer(
             vello::peniko::Fill::NonZero,
             BlendMode::default(),
             1.0,
             transform,
             &shape,
         );
 
+        self.draw_single_line_decorations(scene, transform, theme, true);
         self.draw_single_line_selection(scene, transform, theme);
 
         let text_color = if self.effectively_disabled() {
             theme.text_dim
         } else {
             theme.text_primary
         };
         self.draw_single_line_text(
             scene,
             transform,
             text_renderer,
             theme,
             &display,
             text_size,
             padding_x,
             text_y,
             text_color,
         );
 
+        self.draw_single_line_decorations(scene, transform, theme, false);
         if self.is_focused && !self.effectively_disabled() {
             self.draw_single_line_caret(scene, transform, theme);
         }
 
         scene.pop_layer();
         self.draw_spelling(scene, transform, theme);
         self.draw_autocorrection(scene, transform, theme);
         self.draw_autocorrection_preview(scene, transform, text_renderer, theme);
     }
 
@@ -4328,21 +4438,21 @@ impl TextInput {
         );
     }
 
     /// Rebuilds `self.char_x_positions` (and, when unmasked, `self.single_layout`)
     /// for the current single-line text and returns the total shaped width.
     fn build_single_line_metrics(
         &mut self,
         text_renderer: &mut TextRenderer,
         display: &str,
         text_size: f32,
-        theme: &Theme,
+        text_scale: f32,
     ) -> f32 {
         self.char_x_positions.clear();
         self.char_x_positions
             .resize(self.text.len().saturating_add(1), 0.0);
         if self.masked() {
             self.single_layout = None;
             for (byte_idx, _) in self.text.grapheme_indices(true) {
                 let (w, _) =
                     self.measure_str(text_renderer, &self.display_prefix(byte_idx), text_size);
                 if let Some(slot) = self.char_x_positions.get_mut(byte_idx) {
@@ -4353,32 +4463,48 @@ impl TextInput {
             if let Some(slot) = self.char_x_positions.get_mut(self.text.len()) {
                 *slot = f64::from(width);
             }
             width
         } else {
             let family = self.family.clone().unwrap_or(if self.mono {
                 FontChoice::Monospace
             } else {
                 FontChoice::SansSerif
             });
-            let layout_size = text_size * theme.text_scale;
+            let layout_size = text_size * text_scale;
             let style = TextStyle::new(layout_size)
                 .with_line_height(LINE_HEIGHT_RATIO)
                 .with_family(family.clone());
-            let signature = self.shaped_signature(display, &family, layout_size, None);
+            let base = self.shaped_signature(display, &family, layout_size, None);
+            let attributes = self.valid_single_attributes();
+            let signature = attributes.map_or(base, |a| {
+                Self::attributed_signature(base ^ Self::single_attributes_signature(a), &a.spans)
+            });
             if self.single_layout.is_none() || self.shaped_layout_signature != signature {
-                let mut layout = RichTextLayout::shape_plain(
-                    &mut text_renderer.font_system,
-                    display,
-                    &style,
-                    None,
-                );
+                let mut layout = if let Some(attributes) = attributes {
+                    RichTextLayout::shape_styled(
+                        &mut text_renderer.font_system,
+                        &self.insert_preedit_span(attributes.spans.clone()),
+                        &style,
+                        None,
+                        TextAlign::Left,
+                        self.display_ranges(&attributes.underlines),
+                        self.display_ranges(&attributes.strikes),
+                    )
+                } else {
+                    RichTextLayout::shape_plain(
+                        &mut text_renderer.font_system,
+                        display,
+                        &style,
+                        None,
+                    )
+                };
                 if !self.preedit.is_empty() {
                     let start = self.cursor_pos.min(self.text.len());
                     layout.add_underline(start..start.saturating_add(self.preedit.len()));
                 }
                 self.single_layout = Some(layout);
                 self.shaped_layout_signature = signature;
             }
             let Some(layout) = self.single_layout.as_ref() else {
                 return 0.0;
             };
@@ -4450,20 +4576,77 @@ impl TextInput {
             scene.fill(
                 vello::peniko::Fill::NonZero,
                 transform,
                 sel_color,
                 None,
                 &sel_rect,
             );
         }
     }
 
+    /// Code chips precede selection and glyphs; accent link rules follow
+    /// glyphs. All bounds come from the exact layout used for interaction.
+    fn draw_single_line_decorations(
+        &self,
+        scene: &mut Scene,
+        transform: Affine,
+        theme: &Theme,
+        backgrounds: bool,
+    ) {
+        if self.masked() {
+            return;
+        }
+        let (Some(attributes), Some(layout)) =
+            (self.valid_single_attributes(), &self.single_layout)
+        else {
+            return;
+        };
+        let ranges = if backgrounds {
+            &attributes.chips
+        } else {
+            &attributes.links
+        };
+        for (start, end) in self.display_ranges(ranges) {
+            for (x0, y0, x1, y1) in layout.selection_rects(start, end) {
+                let x = self.single_origin.x - self.scroll_x;
+                let y = self.single_origin.y;
+                let rect = if backgrounds {
+                    Rect::new(
+                        x + f64::from(x0) - 2.0,
+                        y + f64::from(y0) + 1.0,
+                        x + f64::from(x1) + 2.0,
+                        y + f64::from(y1) - 1.0,
+                    )
+                } else {
+                    Rect::new(
+                        x + f64::from(x0),
+                        y + f64::from(y1) - 2.0,
+                        x + f64::from(x1),
+                        y + f64::from(y1) - 1.0,
+                    )
+                };
+                let color = if backgrounds {
+                    theme.tokens.colors.surfaces.raised
+                } else {
+                    theme.tokens.colors.accent[5]
+                };
+                scene.fill(
+                    vello::peniko::Fill::NonZero,
+                    transform,
+                    color,
+                    None,
+                    &RoundedRect::from_rect(rect, if backgrounds { 3.0 } else { 0.0 }),
+                );
+            }
+        }
+    }
+
     #[allow(clippy::too_many_arguments, reason = "internal draw-pass helper")]
     fn draw_single_line_text(
         &self,
         scene: &mut Scene,
         transform: Affine,
         text_renderer: &mut TextRenderer,
         theme: &Theme,
         display: &str,
         text_size: f32,
         padding_x: f64,
@@ -5181,20 +5364,287 @@ impl TextInput {
     /// resolves to denied. Concept's every-widget convention is
     /// `bg-black/30` ≈ 0.30 × 255 ≈ 77.
     pub(crate) const PERMISSION_DENIED_OVERLAY: vello::peniko::Color =
         crate::tokens::colors::PERMISSION_DENIED_SCRIM;
 }
 
 #[cfg(test)]
 mod tests {
     use super::*;
 
+    #[test]
+    fn attributed_single_line_is_shaped_during_measure_before_draw() {
+        use crate::widget::marks::{Mark, MarkSpan};
+        use crate::widget::rich_text_line::RichTextLine;
+        for scale in [1.0, 2.0] {
+            let theme = Theme::dark().with_text_scale(scale);
+            let mut line = RichTextLine::new().with_text("aBz");
+            line.set_marks(vec![MarkSpan::new(1..2, Mark::Bold)]);
+            let mut taffy = TaffyTree::new();
+            line.build_layout(&mut taffy, &theme, &mut Default::default());
+            let mut renderer = TextRenderer::new(); // intentionally stale 1x
+            line.measure(
+                Size::NONE,
+                Size {
+                    width: taffy::AvailableSpace::MaxContent,
+                    height: taffy::AvailableSpace::MaxContent,
+                },
+                &mut renderer,
+            );
+            let layout = line
+                .inner()
+                .single_layout
+                .as_ref()
+                .expect("measurement must shape styled text");
+            let weights: Vec<_> = layout
+                .buffer
+                .layout_runs()
+                .flat_map(|r| r.glyphs.iter().map(|g| g.font_weight.0))
+                .collect();
+            assert_eq!(weights, [400, 700, 400]);
+            assert_eq!(layout.buffer.metrics().font_size, 16.0 * scale);
+        }
+    }
+
+    fn draw_rich_line_for_test(line: &mut crate::widget::RichTextLine, theme: &Theme) -> Scene {
+        let mut renderer = TextRenderer::new();
+        renderer.set_text_scale(theme.text_scale);
+        let mut scene = Scene::new();
+        line.draw(
+            &mut scene,
+            Affine::IDENTITY,
+            &mut renderer,
+            theme,
+            &crate::presence::PresenceCtx::empty(),
+        );
+        scene
+    }
+
+    #[test]
+    fn attributed_single_line_preedit_preserves_utf8_marks_and_commit_route() {
+        use crate::widget::marks::{Mark, MarkSpan};
+        for scale in [1.0, 2.0] {
+            let theme = Theme::dark().with_text_scale(scale);
+            let mut line = crate::widget::RichTextLine::new().with_text("éW");
+            line.set_marks(vec![
+                MarkSpan::new(0..3, Mark::Bold),
+                MarkSpan::new(0..3, Mark::Code),
+                MarkSpan::new(0..3, Mark::Underline),
+                MarkSpan::new(0..3, Mark::Strikethrough),
+            ]);
+            line.apply_layout_external(Rect::new(0.0, 0.0, 400.0, 60.0));
+            line.set_focus(true);
+            line.set_cursor_pos(2);
+            let mut doc = AutoCommit::new();
+            let (taffy, node) = test_node();
+            let mut send = |line: &mut crate::widget::RichTextLine, event: WindowEvent| {
+                line.handle_event(
+                    &event,
+                    1.0,
+                    &Modifiers::default(),
+                    &mut doc,
+                    &automerge::ROOT,
+                    &mut false,
+                    &mut None,
+                    node,
+                    &taffy,
+                );
+            };
+            send(
+                &mut line,
+                WindowEvent::Ime(winit::event::Ime::Preedit("漢".into(), Some((3, 3)))),
+            );
+            draw_rich_line_for_test(&mut line, &theme);
+            assert_eq!(line.value(), "éW");
+            let input = line.inner();
+            let layout = input.single_layout.as_ref().unwrap();
+            assert_eq!(layout.buffer.lines[0].text(), "é漢W");
+            assert_eq!(layout.underlines, [(0, 2), (5, 6), (2, 5)]);
+            assert_eq!(layout.strikes, [(0, 2), (5, 6)]);
+            let weights: Vec<_> = layout
+                .buffer
+                .layout_runs()
+                .flat_map(|r| r.glyphs.iter().map(|g| g.font_weight.0))
+                .collect();
+            assert_eq!(weights, [700, 400, 700]);
+            let anchor = input.ime_cursor_rect().unwrap();
+            assert!(anchor.x0 > line.caret_rect(&theme, 2).x0);
+            assert_eq!(
+                input.display_ranges(&input.single_attributes.as_ref().unwrap().chips),
+                [(0, 2), (5, 6)]
+            );
+            send(
+                &mut line,
+                WindowEvent::Ime(winit::event::Ime::Commit("漢".into())),
+            );
+            let scene = draw_rich_line_for_test(&mut line, &theme);
+            assert_eq!(line.value(), "é漢W");
+            assert_eq!(line.cursor_pos(), 5);
+            assert_eq!(scene.encoding().resources.glyphs.len(), 3);
+            assert!(
+                line.marks()
+                    .iter()
+                    .all(|m| line.value().is_char_boundary(m.range.start)
+                        && line.value().is_char_boundary(m.range.end))
+            );
+        }
+    }
+
+    #[test]
+    fn attributed_single_line_chip_and_link_rules_follow_shaped_ranges() {
+        use crate::widget::marks::{Mark, MarkSpan};
+        for scale in [1.0, 2.0] {
+            let theme = Theme::dark().with_text_scale(scale);
+            let mut line = crate::widget::RichTextLine::new().with_text("aWWWz");
+            line.set_marks(vec![
+                MarkSpan::new(1..4, Mark::Bold),
+                MarkSpan::new(1..4, Mark::Code),
+                MarkSpan::new(1..4, Mark::Link(uuid::Uuid::from_u128(1))),
+                MarkSpan::new(1..4, Mark::Strikethrough),
+            ]);
+            line.apply_layout_external(Rect::new(10.0, 20.0, 400.0, 90.0));
+            let scene = draw_rich_line_for_test(&mut line, &theme);
+            assert_eq!(scene.encoding().resources.glyphs.len(), 5);
+            let input = line.inner();
+            let left = input.caret_rect(&theme, 1).x0;
+            let right = input.caret_rect(&theme, 4).x0;
+            let layout = input.single_layout.as_ref().unwrap();
+            assert_eq!(layout.strikes, [(1, 4)]);
+            assert!(
+                layout
+                    .buffer
+                    .layout_runs()
+                    .flat_map(|r| r.glyphs.iter())
+                    .all(|g| g.font_size == 16.0 * scale)
+            );
+            for (background, pad) in [(true, 2.0), (false, 0.0)] {
+                let mut decorations = Scene::new();
+                input.draw_single_line_decorations(
+                    &mut decorations,
+                    Affine::IDENTITY,
+                    &theme,
+                    background,
+                );
+                let xs: Vec<_> = decorations
+                    .encoding()
+                    .path_data
+                    .chunks_exact(2)
+                    .map(|xy| f64::from(f32::from_bits(xy[0])))
+                    .collect();
+                let min = xs.iter().copied().fold(f64::INFINITY, f64::min);
+                let max = xs.iter().copied().fold(f64::NEG_INFINITY, f64::max);
+                assert!((min - (left - pad)).abs() < 0.01);
+                assert!((max - (right + pad)).abs() < 0.01);
+                assert_eq!(
+                    decorations.encoding().resources.glyphs.len(),
+                    0,
+                    "decorations never repaint text"
+                );
+            }
+        }
+    }
+
+    #[test]
+    fn attributed_single_line_style_inputs_invalidate_cached_shape() {
+        use crate::richtext::{BaselineShift, FontFamily};
+        let mut input = TextInput::local().with_initial_value("WWW");
+        input.apply_layout_external(Rect::new(0.0, 0.0, 400.0, 60.0));
+        let mut attributes = SingleLineAttributes {
+            spans: vec![RichSpan::new("WWW")],
+            ..Default::default()
+        };
+        input.set_single_line_attributes(attributes.clone());
+        draw_to_populate(&mut input);
+        let original_width = input.single_layout.as_ref().unwrap().width();
+        attributes.spans[0].size = Some(28.0);
+        input.set_single_line_attributes(attributes.clone());
+        draw_to_populate(&mut input);
+        let sized_width = input.single_layout.as_ref().unwrap().width();
+        assert!(sized_width > original_width * 1.5);
+        attributes.spans[0].family = Some(FontFamily::Mono);
+        input.set_single_line_attributes(attributes.clone());
+        draw_to_populate(&mut input);
+        assert!((input.single_layout.as_ref().unwrap().width() - sized_width).abs() > 1.0);
+        attributes.spans[0].background = Some([40, 50, 60]);
+        attributes.spans[0].baseline = BaselineShift::Super;
+        attributes.spans[0].color = Some([100, 110, 120]);
+        attributes.underlines = vec![(0, 1)];
+        attributes.strikes = vec![(1, 3)];
+        input.set_single_line_attributes(attributes);
+        draw_to_populate(&mut input);
+        let layout = input.single_layout.as_ref().unwrap();
+        assert_eq!(layout.backgrounds, [(0, 3, [40, 50, 60])]);
+        assert_eq!(layout.baselines, [(0, 3, BaselineShift::Super)]);
+        assert_eq!(layout.underlines, [(0, 1)]);
+        assert_eq!(layout.strikes, [(1, 3)]);
+        assert!(
+            layout
+                .buffer
+                .layout_runs()
+                .flat_map(|r| r.glyphs.iter())
+                .all(|g| g.color_opt == Some(cosmic_text::Color::rgb(100, 110, 120)))
+        );
+    }
+
+    #[test]
+    fn attributed_single_line_sync_undo_redo_rebuilds_runs() {
+        use crate::widget::marks::{Mark, MarkSpan};
+        let mut state = crate::State::new();
+        let text = state
+            .doc
+            .put_object(&state.root, "body", ObjType::Text)
+            .unwrap();
+        state.doc.splice_text(&text, 0, 0, "WWW").unwrap();
+        state.commit_action(None, None);
+        let mut line = crate::widget::RichTextLine::new();
+        line.bind_text(text.clone());
+        line.sync(&mut state.doc, &state.root);
+        line.set_marks(vec![MarkSpan::new(0..3, Mark::Bold)]);
+        line.apply_layout_external(Rect::new(0.0, 0.0, 400.0, 60.0));
+        let theme = Theme::dark().with_text_scale(2.0);
+        draw_rich_line_for_test(&mut line, &theme);
+        let wide = line.pixel_x_for_byte(&theme, 3);
+        state.doc.splice_text(&text, 0, 3, "iii").unwrap();
+        state.commit_action(None, None);
+        for (step, expected) in [(0, "iii"), (1, "WWW"), (2, "iii")] {
+            if step == 1 {
+                state.undo(None, None).unwrap();
+            }
+            if step == 2 {
+                state.redo(None, None).unwrap();
+            }
+            line.sync(&mut state.doc, &state.root);
+            let _ = line.take_dirty(); // preserve direct-binding reconciliation semantics
+            assert!(line.layout_needs_measure());
+            draw_rich_line_for_test(&mut line, &theme);
+            assert_eq!(line.value(), expected);
+            let input = line.inner();
+            assert!(
+                input
+                    .single_layout
+                    .as_ref()
+                    .unwrap()
+                    .buffer
+                    .layout_runs()
+                    .flat_map(|r| r.glyphs.iter())
+                    .all(|g| g.font_weight.0 == 700)
+            );
+            let x = line.pixel_x_for_byte(&theme, 3);
+            if expected == "WWW" {
+                assert!((x - wide).abs() < 0.01);
+            } else {
+                assert!(x < wide * 0.6);
+            }
+            assert_eq!(line.byte_for_pixel_x(&theme, x), 3);
+        }
+    }
+
     #[test]
     fn programmatic_caret_never_splits_a_grapheme() {
         let mut combining = TextInput::local().with_initial_value("a\u{301}b");
         combining.set_cursor_pos(1);
         assert_eq!(combining.cursor_pos(), 0);
 
         let mut emoji = TextInput::local().with_initial_value("👩‍👩‍👧‍👦!");
         emoji.set_cursor_pos(4);
         assert_eq!(emoji.cursor_pos(), 0);
         emoji.set_cursor_pos("👩‍👩‍👧‍👦".len());
