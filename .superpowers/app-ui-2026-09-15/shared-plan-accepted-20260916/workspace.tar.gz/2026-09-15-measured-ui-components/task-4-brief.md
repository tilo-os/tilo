# Measured UI Components Implementation Plan

> **For agentic workers:** REQUIRED SUB-SKILL: Use superpowers:subagent-driven-development (recommended) or superpowers:executing-plans to implement this plan task-by-task. Steps use checkbox (`- [ ]`) syntax for tracking.

**Goal:** Repair shared sizing and interaction contracts so app authors get readable, balanced layouts with fewer manual measurements.

**Architecture:** Add one resolved-text normalization boundary while preserving existing relative APIs. Repair EmptyState, rich editor, opt-in scrolling editor fill and measured actionable Toolbar overflow. App composition migrations consume existing Card/Actions/FormPage rather than inventing another layout system.

**Tech Stack:** Rust, Taffy, cosmic-text, Vello and qOS Widget lifecycle.

**Spec:** `docs/superpowers/specs/2026-09-15-app-ui-balance.md`

## Global Constraints

- Reuse the repository Cargo target cache; do not rebuild all dependencies into a new target directory without a concrete build-isolation need. Isolate runtime captures with task-specific HOME and XDG_CONFIG_HOME/XDG_DATA_HOME/XDG_CACHE_HOME/XDG_STATE_HOME, separately from build caches.

- Prioritize ordinary100% and narrow layout as well as200% text.
- Preserve primary actions, keyboard access, state and explicit manual dimensions.
- Keep legacy renderer-relative font APIs compatible; theme-resolved fonts must scale once.
- Do not globally change primitive padding or reinterpret explicit fixed sizes.
- Preserve unrelated working changes and untracked Scratchpad ownership.
- No pushes, merges, publishing or dependency upgrades.
- Existing linked worktree /Users/xaver/dev/qos-macos-shell; sequential implementers and scoped reviews.
- Focused RED/GREEN behavior regressions before implementation; run relevant existing UI tests once before scoped commit. CARGO_BUILD_JOBS=4, CARGO_PROFILE_DEV_DEBUG=0, CARGO_PROFILE_TEST_DEBUG=0.
- Every task report includes exact commands/results, self-review, screenshot paths if requested, and remaining gaps. No subagents from implementers.

### Task 4: Measured Toolbar with reachable overflow

**Files:** `ui/src/widget/toolbar.rs`, scoped additions in `ui/src/widget/context_menu.rs`; reuse existing Widget overlay/focus hooks (`ui/src/widget/mod.rs`) without changing that trait. Do not confuse widget Toolbar with `ui/src/chrome/toolbar.rs`.

**Preflight:** `.superpowers/sdd/2026-09-15-measured-ui-components/task-4-preflight.md` maps the existing APIs and concrete gaps. ContextMenu currently has point-only placement, full unbounded height and no scrolling. Extend it with a bounded anchored route, measured row/label geometry, clipping, scrolling and offset-aware hit testing; retain legacy callers' placement behavior unless they opt into the new route. This is shared menu infrastructure, not a second Toolbar-specific popup. Keep host focus on Toolbar and route internal focus into/out of the owned menu through existing hooks. Synthetic menu accessibility must include action targets and painted bounds, not just nested labels. Tests must cover the existing legacy menu behavior as well as the new route.

Three separate approximate sizing paths currently disagree: `measure_item_axis`147, `decide_visible_count`214 and `measure_visible_axes`252. apply_layout loses theme and falls back to character count and16px labels. draw uses actual renderer measurement. `is_overflow_open`202 explicitly says host paints the popover; the widget supplies no reachable hidden command route, and its accessibility node is only Role::Toolbar.

- [ ] Cache theme font/padding during build_layout, then actual label width/height during `adjust_layout_with_measure` (Widget hook, mod.rs602; Form/Field demonstrate usage). Use one cached item extent vector for visibility, placement and intrinsic sizing. Reserve measured overflow control before fitting commands. Invalidate on theme/scale/label changes. Retain public recompute_visible compatibility, but avoid using its approximate result as authoritative final layout.
- [ ] Implement overflow using existing ContextMenu selection drain: menu maps each visible menu entry back to original ToolbarItem index; use `take_selection()` to call the original FnMut, preserving command ownership. Include only hidden buttons and meaningful separators. Widget draws it through draw_overlay and routes popup input before underlying buttons. Reuse dismissal/positioning infrastructure; do not create another floating-window system.
- [ ] Add focusable command/overflow semantics, keyboard opening, arrow navigation, Enter activation, Escape close and focus return. Popup must remain within host bounds and scroll if taller than viewport. A toggled boolean is not acceptance.
- [ ] Tests with `WWW` versus `iii`, non-Latin text, long translations, both orientations, widths less than chip width, scale changes and resize after opening. Every original callback reachable exactly once through pointer and keyboard; invisible item rectangles zero; separator-only overflow prohibited; accessibility exposes commands.
- [ ] Retain actual rendered test-fixture images at ordinary width and narrow2×, overflow open and final hidden command reachable. Reuse the tested widget/renderer path rather than adding an app; record source/binary/theme/viewport provenance for controller visual inspection.


