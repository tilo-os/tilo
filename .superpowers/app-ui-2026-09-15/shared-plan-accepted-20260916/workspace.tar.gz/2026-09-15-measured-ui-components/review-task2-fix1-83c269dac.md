# Task2 fix round1 scoped diff

commit 83c269dac5d2fa49078472887d9c4dda530c2ae6
Author:     Xaver Emmerling <xaver@Mac.lan>
AuthorDate: Wed Sep 16 10:11:21 2026 -0700
Commit:     Xaver Emmerling <xaver@Mac.lan>
CommitDate: Wed Sep 16 10:11:21 2026 -0700

    fix(ui): propagate editor layout invalidation

 .../task-2-report.md                               |  46 +++++++
 ui/src/widget/code_editor.rs                       |  82 +++++++++++-
 ui/src/widget/text_input.rs                        | 148 +++++++++++++--------
 3 files changed, 222 insertions(+), 54 deletions(-)

diff --git a/.superpowers/sdd/2026-09-15-measured-ui-components/task-2-report.md b/.superpowers/sdd/2026-09-15-measured-ui-components/task-2-report.md
index 8205ee82f..680afefa3 100644
--- a/.superpowers/sdd/2026-09-15-measured-ui-components/task-2-report.md
+++ b/.superpowers/sdd/2026-09-15-measured-ui-components/task-2-report.md
@@ -77,10 +77,56 @@ The test link emits the existing macOS `__eh_frame section too large` warning. I
 - Verified base-versus-resolved ownership: `RichTextLine` and `TextInput` overrides remain base values; only the shaped layout and wrapper geometry resolve the active theme scale.
 - Verified renderer-relative conversion is limited to gutter painting and measurement; direct `RichTextLayout` shaping receives resolved sizes.
 - Verified the same widget instance transitions 1x -> 2x and 2x -> 1x, and model replay equivalent to undo/redo invalidates and restores wrapped geometry.
 - Verified actual caret, selection, wrapped logical rows, pointer events, inline-code marks, heading/paragraph sizes and numbered-prefix alignment rather than row-height constants alone.
 - Preserved all unrelated dirty and untracked files. Only the four task widget files and this report are intended for the scoped commit.
 
 ## Remaining gaps
 
 - No application capture was produced in this implementer task; the controller owns Notes, Calendar and corrected Typst integration captures.
 - The full UI suite was intentionally not repeated because the task brief directs focused editor filters and records unrelated Chromium churn. All relevant editor module tests and `cargo check -p ui` are green.
+
+## Review fix round 1
+
+### RED evidence
+
+The two review findings were reproduced with production-lifecycle regressions before their fixes:
+
+1. `CARGO_BUILD_JOBS=4 CARGO_PROFILE_DEV_DEBUG=0 CARGO_PROFILE_TEST_DEBUG=0 cargo test -p ui --lib widget::code_editor::tests::wrapper_layout_uses_theme_scale_with_a_stale_renderer_and_reverses_to_normal -- --exact --nocapture`
+   - Failed at `wrapper measure and draw must share the 2x paragraph height`.
+   - The test drives the wrapper through Taffy `build_layout`, measured layout computation, `apply_layout`, and `draw` with a renderer left at 1x. This confirmed that `CodeEditor::build_layout` discarded the 2x theme scale before delegating measurement.
+
+2. `CARGO_BUILD_JOBS=4 CARGO_PROFILE_DEV_DEBUG=0 CARGO_PROFILE_TEST_DEBUG=0 cargo test -p ui --lib widget::text_input::tests::crdt_sync_undo_redo_invalidates_multiline_measurement -- --exact --nocapture`
+   - Failed at `CRDT text growth invalidates retained measurement` after `take_dirty()` returned `None`.
+   - The test creates a real Automerge `Text`, commits a wrapping replacement through `State`, synchronizes the bound input, and then performs real `State::undo` and `State::redo`. This confirmed that path-bound model adoption changed text without setting `model_layout_dirty`.
+
+### Implementation
+
+- `CodeEditor::build_layout` now forwards the resolved theme text scale through a dedicated `TextInput::capture_layout_text_scale` method before registering the wrapper leaf. The existing direct-measure fallback to the renderer remains intact for callers that have no themed build pass.
+- Scalar values, Automerge `Text` values, removed paths, and direct bound-text adoption now share `TextInput::adopt_model_text`. A changed multiline value sets `model_layout_dirty`; path synchronization remains a model update rather than a user edit, while direct bindings preserve their existing reconciliation dirty signal.
+- Corrected the `ensure_shaped_layout` comment to describe its actual unit return and rebuild inputs.
+- Corrected the gutter-width comment to distinguish retained glyph measurement from the pre-measure estimate.
+- Replaced the earlier `set_text` undo/redo surrogate with the real CRDT commit/undo/redo regression above.
+
+### GREEN verification
+
+Focused regressions on the final implementation:
+
+- `CARGO_BUILD_JOBS=4 CARGO_PROFILE_DEV_DEBUG=0 CARGO_PROFILE_TEST_DEBUG=0 cargo test -p ui --lib widget::code_editor::tests::wrapper_layout_uses_theme_scale_with_a_stale_renderer_and_reverses_to_normal -- --exact --nocapture` — 1 passed, 0 failed.
+- `CARGO_BUILD_JOBS=4 CARGO_PROFILE_DEV_DEBUG=0 CARGO_PROFILE_TEST_DEBUG=0 cargo test -p ui --lib widget::text_input::tests::crdt_sync_undo_redo_invalidates_multiline_measurement -- --exact --nocapture` — 1 passed, 0 failed.
+
+Affected module tests on the formatted final source:
+
+- `CARGO_BUILD_JOBS=4 CARGO_PROFILE_DEV_DEBUG=0 CARGO_PROFILE_TEST_DEBUG=0 cargo test -p ui --lib widget::code_editor::tests -- --nocapture` — 23 passed, 0 failed.
+- `CARGO_BUILD_JOBS=4 CARGO_PROFILE_DEV_DEBUG=0 CARGO_PROFILE_TEST_DEBUG=0 cargo test -p ui --lib widget::text_input::tests -- --nocapture` — 99 passed, 0 failed.
+- `CARGO_BUILD_JOBS=4 CARGO_PROFILE_DEV_DEBUG=0 cargo check -p ui` — passed.
+- `rustfmt --edition 2024 ui/src/widget/code_editor.rs ui/src/widget/text_input.rs` — passed.
+- `git diff --check -- ui/src/widget/code_editor.rs ui/src/widget/text_input.rs` — passed.
+
+The test link continues to emit the existing macOS `__eh_frame section too large` warning; it does not fail compilation or the test executable.
+
+### Self-review and remaining gaps
+
+- Confirmed the wrapper test catches both the original 2x mismatch and same-instance 2x-to-1x invalidation while the renderer remains stale at 1x throughout.
+- Confirmed the CRDT regression consumes initial measurement, keeps model sync out of `take_dirty`, and requires a new measurement after replacement, undo, and redo.
+- Confirmed unchanged model text does not mark measurement dirty, and removed paths use the same change comparison before invalidation.
+- No app files or `Scrollable` production code changed. Controller-owned image review and separately queued app geometry remain outside this fix round.
diff --git a/ui/src/widget/code_editor.rs b/ui/src/widget/code_editor.rs
index 125cee27c..f9289635b 100644
--- a/ui/src/widget/code_editor.rs
+++ b/ui/src/widget/code_editor.rs
@@ -436,30 +436,30 @@ impl Widget for CodeEditor {
     fn update(&mut self, state: &mut AutoCommit, path: &ObjId) -> bool {
         self.inner.update(state, path)
     }
 
     fn build_layout(
         &mut self,
         taffy: &mut TaffyTree<()>,
         theme: &Theme,
         node_map: &mut std::collections::HashMap<NodeId, *mut dyn Widget>,
     ) -> NodeId {
+        self.inner.capture_layout_text_scale(theme.text_scale);
         // Registers *this* widget (not the inner input) so the host
         // drives CodeEditor's own passes.
         let node = taffy.leaf_node(Style {
             size: Size {
                 width: Dimension::percent(1.0),
                 height: Dimension::auto(),
             },
             ..Default::default()
         });
-        let _ = theme;
         node_map.insert(node, std::ptr::from_mut::<dyn Widget>(self));
         node
     }
 
     fn measure(
         &mut self,
         known: taffy::Size<Option<f32>>,
         available: taffy::Size<taffy::AvailableSpace>,
         text_renderer: &mut TextRenderer,
     ) -> taffy::Size<f32> {
@@ -1689,20 +1689,53 @@ mod tests {
         handled
     }
 
     fn draw_once(ed: &mut CodeEditor, theme: &Theme) {
         let presence = PresenceCtx::default();
         let mut tr = TextRenderer::new();
         let mut scene = Scene::new();
         Widget::draw(ed, &mut scene, Affine::IDENTITY, &mut tr, theme, &presence);
     }
 
+    fn lay_out_and_draw(
+        ed: &mut CodeEditor,
+        theme: &Theme,
+        renderer: &mut TextRenderer,
+        width: f32,
+    ) -> f32 {
+        let mut taffy = TaffyTree::<()>::new();
+        let mut node_map = std::collections::HashMap::new();
+        let node = Widget::build_layout(ed, &mut taffy, theme, &mut node_map);
+        taffy
+            .compute_layout_with_measure(
+                node,
+                taffy::Size {
+                    width: taffy::AvailableSpace::Definite(width),
+                    height: taffy::AvailableSpace::MaxContent,
+                },
+                |known, available, id, _, _| {
+                    node_map
+                        .get(&id)
+                        .map_or(taffy::Size::ZERO, |&widget| unsafe {
+                            (*widget).measure(known, available, renderer)
+                        })
+                },
+            )
+            .expect("code editor layout computes");
+        let height = taffy.layout(node).expect("code editor layout").size.height;
+        Widget::apply_layout(ed, &taffy, node, Point::ZERO);
+        let presence = PresenceCtx::default();
+        let mut scene = Scene::new();
+        Widget::draw(ed, &mut scene, Affine::IDENTITY, renderer, theme, &presence);
+        height
+    }
+
     use crate::text_render::TextRenderer;
 
     #[test]
     fn typing_inserts_on_the_real_key_path() {
         let mut ed = CodeEditor::local();
         ed.set_focused(true);
         ed.set_rect(Rect::new(0.0, 0.0, 400.0, 200.0));
         let mut doc = AutoCommit::new();
         for ch in ["f", "n", " ", "x"] {
             assert!(drive(
@@ -1990,11 +2023,58 @@ mod tests {
                 button: winit::event::MouseButton::Left,
             },
             mods(false, false),
         ));
         assert_eq!(
             large.cursor_pos(),
             second_start,
             "pointer event places the caret on the logical second line through wrapped rows"
         );
     }
+
+    #[test]
+    fn wrapper_layout_uses_theme_scale_with_a_stale_renderer_and_reverses_to_normal() {
+        let text = "a long source line wraps over several visual rows while the wrapper owns the themed layout lifecycle";
+        let mut editor = CodeEditor::local().with_initial_value(text);
+        let mut renderer = TextRenderer::new();
+        assert_eq!(renderer.text_scale(), 1.0, "stale renderer precondition");
+
+        let large_theme = Theme::dark().with_text_scale(2.0);
+        let large_height = lay_out_and_draw(&mut editor, &large_theme, &mut renderer, 190.0);
+        let large_gutter = editor.gutter_width();
+        let large_font = editor
+            .inner()
+            .shaped_font_size_for_test()
+            .expect("large shaped font");
+        assert!(
+            (f64::from(large_height) - editor.inner().content_height()).abs() < 0.1,
+            "wrapper measure and draw must share the 2x paragraph height"
+        );
+
+        let normal_theme = Theme::dark();
+        let mut taffy = TaffyTree::<()>::new();
+        let mut node_map = std::collections::HashMap::new();
+        let _ = Widget::build_layout(&mut editor, &mut taffy, &normal_theme, &mut node_map);
+        assert!(
+            Widget::layout_needs_measure(&editor),
+            "the same wrapper becomes measure-dirty when theme scale returns to 1x"
+        );
+        let normal_height = lay_out_and_draw(&mut editor, &normal_theme, &mut renderer, 190.0);
+        let normal_gutter = editor.gutter_width();
+        let normal_font = editor
+            .inner()
+            .shaped_font_size_for_test()
+            .expect("normal shaped font");
+        assert!(
+            (f64::from(normal_height) - editor.inner().content_height()).abs() < 0.1,
+            "wrapper measure and draw must share the restored 1x paragraph height"
+        );
+        assert!(large_height > normal_height * 1.8);
+        assert!(large_gutter >= normal_gutter * 1.8);
+        assert!(large_font >= normal_font * 1.9);
+        assert_eq!(
+            renderer.text_scale(),
+            1.0,
+            "renderer stayed stale throughout"
+        );
+    }
 }
diff --git a/ui/src/widget/text_input.rs b/ui/src/widget/text_input.rs
index f92ea5b5c..fd61d5070 100644
--- a/ui/src/widget/text_input.rs
+++ b/ui/src/widget/text_input.rs
@@ -458,29 +458,48 @@ impl TextInput {
         &mut self,
         state: &AutoCommit,
     ) -> Result<(), crate::view::ThawError> {
         let obj = self
             .bound_text
             .as_ref()
             .ok_or_else(|| crate::view::ThawError::State("text is not bound".into()))?;
         let text = state
             .text(obj)
             .map_err(|e| crate::view::ThawError::State(e.to_string()))?;
-        if self.text != text {
-            self.text = text;
+        if self.adopt_model_text(text) {
             self.dirty = true;
         }
         self.clamp_to_text();
         self.last_notified_text.clone_from(&self.text);
         Ok(())
     }
 
+    /// Replace text read from model state without reporting a user edit.
+    /// Returns whether the value changed so direct bindings can preserve
+    /// their existing reconciliation signal.
+    fn adopt_model_text(&mut self, text: String) -> bool {
+        if self.text == text {
+            return false;
+        }
+        self.text = text;
+        self.model_layout_dirty |= self.multiline;
+        true
+    }
+
+    /// Capture the resolved theme scale before a renderer-backed measurement.
+    pub(super) fn capture_layout_text_scale(&mut self, text_scale: f32) {
+        if self.layout_text_scale != Some(text_scale) {
+            self.layout_text_scale = Some(text_scale);
+            self.model_layout_dirty |= self.multiline;
+        }
+    }
+
     /// Keep the binding readable while an owning action bridge handles user writes.
     pub fn set_direct_crdt_writes(&mut self, enabled: bool) {
         self.direct_crdt_writes = enabled;
     }
 
     fn resolve_text_obj(&self, state: &AutoCommit, root: &ObjId) -> Option<ObjId> {
         if !self.direct_crdt_writes {
             return None;
         }
         if self.action.is_some() {
@@ -1578,22 +1597,21 @@ impl TextInput {
                 false,
                 self.mono,
             );
         }
     }
 
     /// Every unmasked multiline input—including attributed source code—uses
     /// the same shaped paragraph for paint, wrapping, carets, selection,
     /// hit-testing, vertical movement, and IME composition.
     /// Rebuilds `self.single_layout` (and its signature) if the shaped
-    /// spans, family or size changed since the last draw. Returns the
-    /// `TextStyle` used, so gutter line numbers reuse the exact metrics.
+    /// spans, family, size, or available width changed.
     fn ensure_shaped_layout(
         &mut self,
         tr: &mut TextRenderer,
         theme: &Theme,
         style: &TextStyle,
         available_width: f32,
     ) {
         self.refresh_highlight();
         let display = self.layout_display_text();
         let spans = self.highlighted_display_spans(theme);
@@ -2420,21 +2438,22 @@ impl TextInput {
     #[must_use]
     pub fn with_tab_width(mut self, n: usize) -> Self {
         self.tab_spaces = Some(n);
         self
     }
 
     pub fn set_tab_width(&mut self, n: usize) {
         self.tab_spaces = Some(n);
     }
 
-    /// Pure function of line count + font size, so geometry and painting stay identical.
+    /// Uses measured line-number glyphs after layout, with a font-size
+    /// estimate only before the first measurement.
     fn code_gutter_w(&self) -> f64 {
         if !self.gutter || !self.multiline {
             return 0.0;
         }
         if self.measured_gutter_width > 0.0 {
             return self.measured_gutter_width;
         }
         let lines = self
             .text
             .bytes()
@@ -3534,57 +3553,54 @@ impl Widget for TextInput {
         }
         if !self.crdt_bound {
             return;
         }
         match state.get(root, self.on_change_path.as_str()) {
             Ok(Some((val, obj_id))) => {
                 self.path_was_present = true;
                 match val {
                     Value::Scalar(s) => {
                         if let automerge::ScalarValue::Str(text) = s.as_ref() {
-                            self.text = text.to_string();
+                            self.adopt_model_text(text.to_string());
                         }
                     }
                     Value::Object(ObjType::Text) => {
                         if let Ok(text) = state.text(&obj_id) {
-                            self.text = text;
+                            self.adopt_model_text(text);
                         }
                     }
                     Value::Object(_) => {}
                 }
             }
             Ok(None) if self.path_was_present => {
                 self.path_was_present = false;
-                self.text.clear();
+                self.adopt_model_text(String::new());
                 self.cursor_pos = 0;
                 self.selection_anchor = None;
                 self.goal_x = None;
             }
             Ok(None) | Err(_) => {
                 // Keep an app-provided initial value until the binding has
                 // existed. An error is likewise not evidence of deletion.
             }
         }
         self.clamp_to_text();
         self.last_notified_text.clone_from(&self.text);
     }
 
     fn build_layout(
         &mut self,
         taffy: &mut TaffyTree<()>,
         theme: &Theme,
         node_map: &mut std::collections::HashMap<NodeId, *mut dyn Widget>,
     ) -> NodeId {
-        if self.layout_text_scale != Some(theme.text_scale) {
-            self.layout_text_scale = Some(theme.text_scale);
-            self.model_layout_dirty |= self.multiline;
-        }
+        self.capture_layout_text_scale(theme.text_scale);
         // Multiline is measured (grows with content, see `measure`); single-line is a fixed 40px row.
         let height = if self.multiline {
             Dimension::auto()
         } else {
             Dimension::length(40.0_f32.max(self.interaction.minimum_target()))
         };
         let node = taffy.leaf_node(Style {
             size: Size {
                 width: Dimension::percent(1.0),
                 height,
@@ -6995,65 +7011,91 @@ mod tests {
             input.rect.y0 + ML_PAD_Y + f64::from(top + height / 2.0),
         );
         assert_eq!(
             input.byte_at_point(point),
             second,
             "pointer uses the applied widget origin before the first draw"
         );
     }
 
     #[test]
-    fn scaled_multiline_geometry_refreshes_across_model_undo_redo_replay() {
-        let long = "undo and redo replay model text through the same widget, including a long line that wraps at large text";
+    fn crdt_sync_undo_redo_invalidates_multiline_measurement() {
+        let short = "short";
+        let long = "undo and redo replay real CRDT text through the same widget, including a long line that wraps at large text";
         let theme = Theme::dark().with_text_scale(2.0);
-        let mut input = TextInput::local().multiline(true).with_initial_value(long);
-        input.apply_layout_external(Rect::new(0.0, 0.0, 180.0, 400.0));
-        draw_with_theme(&mut input, &theme);
-        let long_height = input.content_height();
-        let long_rows = input
-            .single_layout
-            .as_ref()
-            .expect("redo source layout")
-            .buffer
-            .layout_runs()
-            .count();
-        assert!(long_rows > 1, "precondition: large text wraps");
+        let mut state = crate::State::new();
+        let text_obj = state
+            .doc
+            .put_object(&state.root, "body", ObjType::Text)
+            .expect("create document text");
+        state
+            .doc
+            .splice_text(&text_obj, 0, 0, short)
+            .expect("seed document text");
+        state.commit_action(None, None);
+
+        let mut input = TextInput::from_document_string("body").multiline(true);
+        Widget::sync(&mut input, &mut state.doc, &state.root);
+        let mut renderer = TextRenderer::new();
+        let mut taffy = TaffyTree::<()>::new();
+        let mut node_map = std::collections::HashMap::new();
+        let _ = Widget::build_layout(&mut input, &mut taffy, &theme, &mut node_map);
+        let measure = |input: &mut TextInput, renderer: &mut TextRenderer| {
+            Widget::measure(
+                input,
+                taffy::Size {
+                    width: Some(180.0),
+                    height: None,
+                },
+                taffy::Size {
+                    width: taffy::AvailableSpace::Definite(180.0),
+                    height: taffy::AvailableSpace::MaxContent,
+                },
+                renderer,
+            )
+            .height
+        };
+        let short_height = measure(&mut input, &mut renderer);
+        input.apply_layout_external(Rect::new(0.0, 0.0, 180.0, f64::from(short_height)));
+        assert!(!Widget::layout_needs_measure(&input));
 
-        input.set_text("undo");
-        input.set_cursor_pos(input.value().len());
-        draw_with_theme(&mut input, &theme);
-        assert_eq!(
-            input
-                .single_layout
-                .as_ref()
-                .expect("undo layout")
-                .buffer
-                .layout_runs()
-                .count(),
-            1
+        let old_len = state.doc.length(&text_obj);
+        state
+            .doc
+            .splice_text(
+                &text_obj,
+                0,
+                isize::try_from(old_len).expect("test text length fits isize"),
+                long,
+            )
+            .expect("replace with wrapping text");
+        state.commit_action(None, None);
+        Widget::sync(&mut input, &mut state.doc, &state.root);
+        assert_eq!(input.take_dirty(), None, "model sync is not a user edit");
+        assert!(
+            Widget::layout_needs_measure(&input),
+            "CRDT text growth invalidates retained measurement"
         );
-        assert!(input.content_height() < long_height);
+        let long_height = measure(&mut input, &mut renderer);
+        assert!(long_height > short_height * 1.8, "long text wraps at 2x");
 
-        input.set_text(long);
-        input.set_cursor_pos(long.len());
-        draw_with_theme(&mut input, &theme);
-        assert_eq!(
-            input
-                .single_layout
-                .as_ref()
-                .expect("redo layout")
-                .buffer
-                .layout_runs()
-                .count(),
-            long_rows
-        );
-        assert!((input.content_height() - long_height).abs() < 0.1);
+        state.undo(None, None).expect("undo long text");
+        Widget::sync(&mut input, &mut state.doc, &state.root);
+        assert!(Widget::layout_needs_measure(&input));
+        let undo_height = measure(&mut input, &mut renderer);
+        assert!((undo_height - short_height).abs() < 0.1);
+
+        state.redo(None, None).expect("redo long text");
+        Widget::sync(&mut input, &mut state.doc, &state.root);
+        assert!(Widget::layout_needs_measure(&input));
+        let redo_height = measure(&mut input, &mut renderer);
+        assert!((redo_height - long_height).abs() < 0.1);
     }
 
     /// Mirrors the handler's own `padding_x = 10.0`; assumes `scroll_x == 0`.
     fn x_for_byte(ti: &TextInput, b: usize) -> f64 {
         ti.rect.x0 + 10.0 + ti.char_x_positions()[b]
     }
 
     #[test]
     fn shift_arrow_extends_selection_by_char() {
         let mut ti = TextInput::local().with_initial_value("abcdef");
