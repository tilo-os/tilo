# Task2 fix round1 re-review scope

Original findings: task-2-review.md. Re-review the two Important findings and two stale comments only, plus new breakage in the fix diff. Do not rerun the implementer's passing tests on unchanged source. Report each finding ADDRESSED/NOT ADDRESSED and spec/quality verdicts.

The authoritative theme scale must survive the real CodeEditor build→measure→apply→draw lifecycle, including stale renderer and2→1 on the same wrapper. CRDT scalar/Text/removal adoption must request fresh multiline geometry after user dirty state is consumed; actual State history replay must be covered, not a set_text substitute. Preserve direct-binding dirty/action semantics and single-line behavior.

Root inspected all15fresh Notes/Calendar/Typst PNGs after initial candidate. Text scale and Typst gutter improved; separate preexisting Notes styled-glyph overdraw is now SharedTask6, Calendar app chips/label geometry TextGeometry23, Typst toolbar/status Composition6. They remain explicit open app findings. This fix does not claim to close those independent defects.

Global constraints from task brief remain: no app/Scrollable edits, no global scale contract changes, preserve unrelated working source, manual sizes and ordinary density. Report in task-2-fix-1-review.md.
